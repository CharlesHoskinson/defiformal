r1: abbrev P := Unit clashed with Typed.Unit (Type → Type). Elaboration sorry then blocked #eval. No source sorry.
