lookupLeaf_eq_lookupCollected Option.map/find?_append failed. Rewrite via getD and induction.
