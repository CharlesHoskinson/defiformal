omit Fintype failed because startTree/advanceIn live in the Fintype section.
