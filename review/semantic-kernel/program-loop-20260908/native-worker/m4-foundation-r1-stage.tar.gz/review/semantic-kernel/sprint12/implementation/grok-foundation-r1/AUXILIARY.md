# Recorded auxiliary module

`lean/DefiKernel/Nary/Tree/FoundationChecks.lean` is the only extra Lean module
beyond the five assigned Tree files.

Responsibilities: nonempty unique-name `#eval` comparisons of the actual Tree
runtime against independent literals (empty/singleton/refusal/path/full-field).
It does not import `Nary.Examples`, does not implement F01–F20, and is not a
root import.

Empty comparison lists throw. Duplicate names throw. Any `false` throws.
The module is not required by later production proof or fixture lanes.
