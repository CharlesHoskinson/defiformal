r8: nary_machine_eta + flatten_eq_skip/refuse/accept. lake build DefiKernel.Nary.Tree.Simulation exit 0, 2.21s.
