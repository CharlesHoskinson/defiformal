getD inversion fails when stored state is emptyLocal. Prove find?_collectLocals instead.
