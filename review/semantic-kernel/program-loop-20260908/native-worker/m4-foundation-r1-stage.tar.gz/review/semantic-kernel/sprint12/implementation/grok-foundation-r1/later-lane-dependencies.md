# APIs later proof/fixture lanes need

Foundation does not close M4. Later disjoint-recovery, contracts, fixtures and
integrated-evidence lanes should import these Tree modules directly. Do not add
`lean/DefiKernel.lean` root imports in this package.

## Runtime (before `-- BEGIN PROOFS`)

### Shape
- types: `Tree`, `LocalTree`, `TreeMultiplicity`, `TreeAdmissionFailure`
- `Tree.leaves`, `Tree.count`, `emptyLocals`, `LocalTree.shape`
- `checkTreeFrom`, `checkTree`, `admitTree`, `WellFormed`
- `admitTree` is `match` (not `do`); base `Nary.admit` runs first

### Paths
- `Direction`, `Path`, `PathFailure`
- `chooseChild`, `resolve`, `leafOf`, `encodeOne`, `encodePaths`
- `decodeFrom`, `decodePaths`, `consDecoded`
- decode keeps the submitted full path and token index on the first failure

### Execution
- `TreeMachine`, `TreeResult`, `PathResult`
- `startTree`, `lookupLeaf`, `firstLeaf`
- `skipSelected`, `refusedConsumed`, `refuseSelected`, `acceptSelected`
- `stepLeaf`, `advanceIn` (`Option`), `advanceTree`, `continueTree`
- `runTreePrefix`, `runTree`, `runTreePaths`
- `siblingFailureBlocks` is constantly `false` (M06 later)
- `advanceIn` never calls `Nary.advance`; `none` means absent; `advanceTree`
  then returns the original machine. Duplicate identity: first DFS leaf.

### Observation
- `flattenMachine` is observation-only
- `Rep` (`Nary.MachineEquivalent` of the flattening)
- `fullMachineEq`, `fullResultEq`, `fullAttemptsConjunct`
- `CanonicalLocal`, `canonicalOf`, `canonicalEq`
- `collectLocals`, `lookupCollected`, `emptyLocal`

## Proofs (Simulation, plus Shape/Paths/Execution/Observation lemmas)

Needed by later correspondence/fixture proofs:
- `wellFormed_count`, `wellFormed_iff_check`, `admitTree_base`, `admitTree_tree`, `admitTree_ok`
- `startTree_shape`, `advanceTree_none`, `continueTree_cons`, `runTreePaths_decodeRefused`
- `Rep_iff`, `fullMachineEq_iff`, `lookupCollected_eq_lookupLeaf`
- `flatten_start`, `Rep_start`, `flatten_advanceTree`, `flatten_advanceTree_of_wf`
- `one_token_simulation`, `flatten_continueTree`, `arbitrary_entry_simulation`
- `flatten_runTreePrefix`, `runPrefix_rep`, `result_projection`
- `regrouping`, `fork_assoc_wellFormed`, `fork_assoc_regrouping`
- `empty_unit_left`, `empty_unit_right`, `empty_unit_regrouping`
- `resolve_encode_of_count`, `decode_encode`, `decode_append_error_offset`

`WellFormed` is roster-order expected-one. A fork child is not well-formed for
the parent roster. Flatten simulation uses unique token count, not subtree
`WellFormed`.

## Not this lane
- `DisjointRuntime`, `Compatibility`, `Recovery`, `Monitor`, `Contracts`
- F01–F20 / 313 labels / mutations
- `FoundationChecks` (auxiliary only)
