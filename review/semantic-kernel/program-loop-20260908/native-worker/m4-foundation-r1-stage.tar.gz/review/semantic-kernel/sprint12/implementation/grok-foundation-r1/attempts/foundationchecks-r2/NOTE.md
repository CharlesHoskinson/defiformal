r2: LocalState/Event/World have no DecidableEq because State.balance is a function. Compare consumed/nextIndex/isEmpty/isNone and Parallel.worldEq.
