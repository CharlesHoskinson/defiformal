Repr LocalState missing; WellFormed Except universe; throw/do-notation did not simp. Repaired with match, Prop WellFormed, Except.error.
