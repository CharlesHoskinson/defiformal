decodeFrom_error_head Except.isOk mismatch; split into resolve-error and leaf-none lemmas.
