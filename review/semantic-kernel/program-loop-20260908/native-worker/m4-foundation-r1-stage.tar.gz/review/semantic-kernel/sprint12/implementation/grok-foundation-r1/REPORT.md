# M4 foundation implementation (native Grok 4.6)

This is the assigned foundation dependency (tasks 2.1–2.5 and 3.1–3.5 except
full F01–F20 fixtures). It is **not** whole-M4 acceptance and **not** whole-program
acceptance. Root freezes and independent GPT-6 checks this package.

- Author: native Grok 4.6
- Checker: independent GPT-6 (not this document)
- Foreman: not used
- Commits/push/self-acceptance: none
- Source HEAD: `a12b7cac05a818cc8d35c2ca440b7170a2807e92` (unchanged)
- Cache: this worktree’s `lean/.lake` (directory, not a symlink)
- Lean: 4.33.0-rc2 (`d8b18978322de05a8f3dba51ef03cf5461676c17`)
- Lake: 5.0.0-src+d8b1897 at `/home/charl/.elan/bin/lake`

Planning launch binding used as given: GPT-6 official review
`review/semantic-kernel/program-loop-20260908/m4-official-r1-gpt6-review.md` SHA
`266141847dc7168040fb8e626c60baebb7f70daed6e3c5578c8dd847321a87c8`, inputs
`review/semantic-kernel/program-loop-20260908/m4-official-r1-gpt6-inputs.json` SHA
`2f448971b5d4597b09c03e6c07ae4b5953903dbd280ad6f94a495e2fb717c2c8`, recorded
`review/semantic-kernel/program-loop-20260908/m4-official-planning-acceptance.json`,
verdict `ACCEPT_WITH_LIMITATIONS`, no required fixes. Official archive
`a50c3c615d1ccd919844e8665a02e5480025c3c46bf1d7889ad3e894b8dae120` (139 files).
Official package bytes were re-checked against `MANIFEST.json`: match.

## Owned sources

New Lean only:

| File | SHA-256 | Bytes | Lines |
|---|---|---:|---:|
| `lean/DefiKernel/Nary/Tree/Shape.lean` | `b2d3702e47bd8bb98abfc638e0609a1bb0e17d867c6d2224658a04376cbfdb3b` | 6908 | 179 |
| `lean/DefiKernel/Nary/Tree/Paths.lean` | `e7ef0fdbf5433a3161976935680babcd89bcda43934c39eb123cfc4b5306b355` | 4097 | 127 |
| `lean/DefiKernel/Nary/Tree/Execution.lean` | `f6e11ad82429aa05730b2d1a2181b1df32a0229cdbdac5162a9cf52472f65e7d` | 13599 | 302 |
| `lean/DefiKernel/Nary/Tree/Observation.lean` | `caf13187be8594fba314c1825e056437d1cada824ea7702585503b0c230d08a3` | 8014 | 190 |
| `lean/DefiKernel/Nary/Tree/Simulation.lean` | `fbd407a58abba205024983d5c899e2f192a293404f8908d7f5475ec9b8edd032` | 33951 | 681 |
| `lean/DefiKernel/Nary/Tree/FoundationChecks.lean` | `83a86d90d06a0c7533afe41d890cf0c71a5f51e3f191c59877d72f397b746455` | 11554 | 246 |

`FoundationChecks.lean` is the recorded local auxiliary (`AUXILIARY.md`).
No `sorry`, `native_decide`, or `axiom` in these files. Runtime/proof split uses
`-- BEGIN PROOFS`. `Execution.advanceIn` does not call `Nary.advance`.
`flattenMachine` lives in Observation.

No edits to root imports, Verify, harness, DisjointRuntime, Compatibility,
Recovery, Monitor, Contracts, Examples, Tests, Fixtures, or historical sources.
OpenSpec live files that were already dirty before this lane were not rewritten
here. Official freeze originals remain byte-identical to their manifest.

## Compile evidence

Final commands, `cwd=lean`, all exit 0. Full logs under `logs/*-final-*`.

| Command | Module | Exit | Time (s) |
|---|---|---:|---:|
| `lake build DefiKernel.Nary.Tree.Shape` | Shape | 0 | 0.718 |
| `lake env lean DefiKernel/Nary/Tree/Shape.lean` | Shape | 0 | 1.520 |
| `lake build DefiKernel.Nary.Tree.Paths` | Paths | 0 | 0.617 |
| `lake env lean DefiKernel/Nary/Tree/Paths.lean` | Paths | 0 | 1.370 |
| `lake build DefiKernel.Nary.Tree.Execution` | Execution | 0 | 0.717 |
| `lake env lean DefiKernel/Nary/Tree/Execution.lean` | Execution | 0 | 1.570 |
| `lake build DefiKernel.Nary.Tree.Observation` | Observation | 0 | 0.766 |
| `lake env lean DefiKernel/Nary/Tree/Observation.lean` | Observation | 0 | 1.420 |
| `lake build DefiKernel.Nary.Tree.Simulation` | Simulation | 0 | 0.717 |
| `lake env lean DefiKernel/Nary/Tree/Simulation.lean` | Simulation | 0 | 1.771 |
| `lake build DefiKernel.Nary.Tree.FoundationChecks` | FoundationChecks | 0 | 0.617 |
| `lake env lean DefiKernel/Nary/Tree/FoundationChecks.lean` | FoundationChecks | 0 | 1.674 |

Earlier development builds that failed are preserved under `attempts/`
(`attempts/INDEX.md`) and `logs/`. They were repaired, not weakened.

## FoundationChecks

46 unique nonempty comparisons, all `true` under
`logs/foundationchecks-final-lake-env-lean.stdout`. Names throw on empty or
duplicate. Expected values are independent literals, not runner output.
Coverage: empty/singleton trees, catalog/base/tree refusals, absent token,
duplicate first-DFS leaf, skip consumed-only with peers preserved, path
encode/decode/full-path offset diagnostics, `runTreePaths` decode-first with
entry world, full `fullMachineEq` / `Nary.machineEq` / world+store+consumed
fields. Not F01–F20.

## Contracts implemented

- Dispatcher never flattens and never calls `Nary.advance`.
- Absent/empty `advanceIn` is `none`; `advanceTree` keeps the original machine.
- Duplicate identity: first depth-first leaf.
- `executeStep` only on the active non-exhausted selected leaf.
- Failed/exhausted selected: consumed +1, peers unchanged, world/store retained.
- `admitTree`: full M3 `Nary.admit` then `checkTree`.
- `runTreePaths`: decode entire paths first; refusal has offset, full path,
  entry world, and no machine.
- Fixed-schedule regrouping: well-formed related machines, shared writes
  permitted, compatibility not required. Proofs are actual flatten equations,
  not assumed target-run equality.
- Default lookup (`emptyLocal`) is only the well-formed-irrelevant fallback.

## API inventory

`api-inventory.json`: 251 exported names (125 runtime, 126 proof). Later lanes
should use `later-lane-dependencies.md`. Simulation is proof-only after the
marker. FoundationChecks is auxiliary.

## What this does not claim

- Whole M4 is not accepted.
- The remaining program is not accepted.
- Full F01–F20 / 313 labels / mutations remain the later fixture lane.
- Disjoint recovery, contracts, monitor runtime, and integrated evidence are
  later exclusive lanes.
- This report is author evidence for GPT-6, not a checker verdict.
