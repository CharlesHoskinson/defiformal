r6: helpers compiled; simpa [flattenMachine] unfolded skip/refuse so helper types no longer matched; refuse world unfolded to setLocal.
