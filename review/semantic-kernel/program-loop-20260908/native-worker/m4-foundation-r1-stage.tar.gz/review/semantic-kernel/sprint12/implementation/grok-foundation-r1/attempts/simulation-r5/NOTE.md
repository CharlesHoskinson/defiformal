r5: flatten_advanceTree field simp still unfolded lookupCollected; accept_stored_receipt tautology; decode_append match; executeStep world mismatch.
