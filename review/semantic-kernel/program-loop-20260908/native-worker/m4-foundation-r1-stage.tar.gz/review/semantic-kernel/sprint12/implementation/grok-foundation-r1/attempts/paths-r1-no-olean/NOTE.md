lake env lean on Paths failed: Shape.olean missing. Use lake build of the module.
