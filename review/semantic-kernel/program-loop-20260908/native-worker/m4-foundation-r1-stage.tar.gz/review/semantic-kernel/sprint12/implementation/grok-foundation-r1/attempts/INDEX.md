# Preserved failed attempts

None of these were erased. Green rebuilds sit beside them.

| Attempt | Failure |
|---|---|
| `shape-r1` | `LocalTree deriving Repr`; `WellFormed` via `checkTree = .ok PUnit.unit`; `do`/`throw` |
| `shape-r2` | `PUnit` universe metavariables in `admitTree`/`checkTree` |
| `paths-r1-no-olean` | `lake env lean` without `Shape.olean` |
| `paths-decode-lemma` | `decodeFrom_error_head` vs `Except.isOk` |
| `execution-omit-fintype` | `omit [Fintype]` on defs that live in the Fintype section |
| `observation-lookup-r1` | `Option.map Prod.snd`; unused simp; `ihL` not a proposition |
| `observation-lookup-r2` | `==` vs `decide (pair.1 = b)` |
| `observation-lookup-r3` | `getD` inversion against `emptyLocal` |
| `simulation-r1`–`r3` | `List.mem_iff_count`; `congrArg₃`; `prefix` keyword; subst of token `b` |
| `simulation-r4` | remaining flatten field goals; `Except.mapError`; decode index shift |
| `simulation-r5` | `accept_stored_receipt` tautology; `flattenMachine` unfold vs `own` |
| `simulation-r6` | `simpa [flattenMachine]` unfolded `skip`/`refuse` |
| `simulation-r7` | `machine_mk_eq` unified `TreeMachine` fields |
| `foundationchecks-r1` | `abbrev P := Unit` clashed with `Typed.Unit` |
| `foundationchecks-r2` | `DecidableEq` on `LocalState`/`Event`/`World` (function balances) |

Green: Shape r3, Paths r2, Execution r2, Observation r4, Simulation r8, FoundationChecks r3.
