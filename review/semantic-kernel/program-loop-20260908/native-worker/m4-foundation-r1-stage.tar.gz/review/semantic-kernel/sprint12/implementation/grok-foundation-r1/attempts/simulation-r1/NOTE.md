44 compile errors: mem_iff_count, duplicate continueTree, prefix keyword, congrArg3, flatten_start subst, split on equality.
