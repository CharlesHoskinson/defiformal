PUnit universe metavariables in admitTree/checkTree; switch to Unit.
