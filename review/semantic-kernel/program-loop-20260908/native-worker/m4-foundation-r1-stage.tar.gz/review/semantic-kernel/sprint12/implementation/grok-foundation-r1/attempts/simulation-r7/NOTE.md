r7: machine_mk_eq unified TreeMachine fields; skip world/attempts already defeq tm.world/attempts.
