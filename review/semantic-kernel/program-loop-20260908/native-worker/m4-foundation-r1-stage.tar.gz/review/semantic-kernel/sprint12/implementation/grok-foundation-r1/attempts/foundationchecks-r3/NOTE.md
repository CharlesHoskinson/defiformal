r3: Bool P/A/D; field-wise local comparison; 46/46 true; lake build exit 0, 2.01s.
