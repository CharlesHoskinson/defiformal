find? predicate == vs decide mismatch; rewrite fork case with decide and getD inversion.
