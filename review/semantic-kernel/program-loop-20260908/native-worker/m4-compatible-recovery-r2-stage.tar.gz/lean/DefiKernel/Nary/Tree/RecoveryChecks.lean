import DefiKernel.Nary.Tree.Recovery
import DefiKernel.Parallel.Examples

/-! Recorded auxiliary for the compatible-recovery lane.
Independent literals: F13 conflict directions and shared-read, F20 unowned
sentinel 11 vs 22, F15 competing-write incompatibility, canonical projection
iff, admitIsolated after tree admission, funded F06 success-then-refusal, and
actual opposite-order competition execution. Does not import Nary.Examples and
does not claim F01–F20 / 313 labels. -/
namespace DefiKernel.Nary.Tree.RecoveryChecks
open Typed Composition Parallel
open DefiKernel.Nary.Tree

abbrev P := Bool
abbrev A := Bool
abbrev D := Bool
abbrev W := World P A D

def emptyRegistry : Registry P A D := fun _ => none
def emptyCatalog : Catalog P A D := []
def emptyCfg : Config P A D := ⟨emptyRegistry, fun _ => false, emptyCatalog⟩
def dupCatalog : Catalog P A D :=
  [⟨⟨0⟩, [], [], [], []⟩, ⟨⟨0⟩, [], [], [], []⟩]
def dupCfg : Config P A D := ⟨emptyRegistry, fun _ => false, dupCatalog⟩

def cellV : Cell P A D := (false, false, false)
def cellS : Cell P A D := (true, false, false)
def cellO : Cell P A D := (false, true, false)

def mkBal (v s o : ℚ) : Cell P A D → ℚ := fun c =>
  if c = cellV then v else if c = cellS then s else if c = cellO then o else 0

def mkWorld (v s o : ℚ) (hv : 0 ≤ v) (hs : 0 ≤ s) (ho : 0 ≤ o) : W :=
  ⟨⟨mkBal v s o, fun c => by
      simp only [mkBal]
      split_ifs
      · exact hv
      · exact hs
      · exact ho
      · exact le_rfl⟩, CapabilityStore.empty⟩

def initial : W := mkWorld 10 11 0 (by decide) (by decide) (by decide)
def leftWorld : W := mkWorld 3 22 0 (by decide) (by decide) (by decide)
def rightWorld : W := mkWorld 10 22 7 (by decide) (by decide) (by decide)

def fpWriteV : Footprint P A D := ⟨[cellV], [cellV]⟩
def fpReadV : Footprint P A D := ⟨[cellV], []⟩
def fpWriteO : Footprint P A D := ⟨[cellO], [cellO]⟩
def fpEmpty : Footprint P A D := .empty

def emptyRoster : Roster Empty := Roster.empty Empty.elim
def fin2Roster : Roster (Fin 2) where
  order := [0, 1]
  nodup := by decide
  complete := by
    intro b
    match b with
    | ⟨0, _⟩ => exact List.Mem.head _
    | ⟨1, _⟩ => exact List.Mem.tail _ (List.Mem.head _)

def emptyBounds : Boundaries Empty P A D := fun b => nomatch b
def emptyBranches : Branches Empty P A D := fun b => nomatch b
def fin2Bounds : Boundaries (Fin 2) P A D := fun _ _ =>
  ⟨⟨false, false⟩, fun _ => none, 0⟩
def fin2None : Branches (Fin 2) P A D := fun _ => []
def fin2Fork : Tree (Fin 2) := .fork (.leaf 0) (.leaf 1)

def merged : W := mergeOwned fpWriteV fpWriteO initial leftWorld rightWorld

def assocOK : List (Fin 2 × Footprint P A D) :=
  [(0, fpWriteV), (1, fpWriteO)]
def assocWW : List (Fin 2 × Footprint P A D) :=
  [(0, fpWriteV), (1, fpWriteV)]
def assocShared : List (Fin 2 × Footprint P A D) :=
  [(0, fpReadV), (1, fpReadV)]

def locA : CanonicalLocal P A D := ⟨1, ⟨[], [], 1, none⟩⟩
def locB : CanonicalLocal P A D := ⟨1, ⟨[], [], 1, some ⟨0, none, .configuration⟩⟩⟩
def obsA : CanonicalObservation (Fin 2) P A D := ⟨initial, [(0, locA), (1, locA)]⟩
def obsB : CanonicalObservation (Fin 2) P A D := ⟨initial, [(0, locA), (1, locB)]⟩
def obsWorld : CanonicalObservation (Fin 2) P A D := ⟨leftWorld, [(0, locA), (1, locA)]⟩

def comparisons : List (String × Bool) := [
  ("recovery.f13.write-write",
    decide (checkPair (0 : Fin 2) 1 fpWriteV fpWriteV =
      .error ⟨0, 1, .writeWrite, cellV⟩)),
  ("recovery.f13.left-write-right-read",
    decide (checkPair (0 : Fin 2) 1 fpWriteV fpReadV =
      .error ⟨0, 1, .leftWriteRightRead, cellV⟩)),
  ("recovery.f13.right-write-left-read",
    decide (checkPair (0 : Fin 2) 1 fpReadV fpWriteV =
      .error ⟨0, 1, .rightWriteLeftRead, cellV⟩)),
  ("recovery.f13.shared-read",
    decide (checkPair (0 : Fin 2) 1 fpReadV fpReadV = .ok ())),
  ("recovery.f13.disjoint-writes",
    decide (checkPair (0 : Fin 2) 1 fpWriteV fpWriteO = .ok ())),
  ("recovery.f13.pairwise-ok",
    decide (checkPairwise assocOK = .ok ())),
  ("recovery.f13.pairwise-ww",
    match checkPairwise assocWW with
    | .error e => decide (e.kind = .writeWrite ∧ e.cell = cellV)
    | .ok _ => false),
  ("recovery.f13.pairwise-shared",
    decide (checkPairwise assocShared = .ok ())),
  ("recovery.f20.sentinel11",
    decide (merged.state.balance cellS = 11)),
  ("recovery.f20.not22",
    decide (merged.state.balance cellS ≠ 22)),
  ("recovery.f20.owner-left",
    decide (merged.state.balance cellV = 3)),
  ("recovery.f20.owner-right",
    decide (merged.state.balance cellO = 7)),
  ("recovery.f20.store-fixed",
    decide (merged.capabilities = initial.capabilities)),
  ("recovery.f15.competing-not-compatible",
    match checkPair (0 : Fin 2) 1 fpWriteV fpWriteV with
    | .error e => decide (e.kind = .writeWrite)
    | .ok _ => false),
  ("recovery.canonical.refl",
    canonicalEq obsA obsA),
  ("recovery.canonical.failure-diff",
    !canonicalEq obsA obsB),
  ("recovery.canonical.world-diff",
    !canonicalEq obsA obsWorld),
  ("recovery.admit.isolated-empty",
    match admitIsolated emptyCfg emptyRoster emptyBounds emptyBranches [] Tree.empty with
    | .ok assoc => decide (assoc = [])
    | .error _ => false),
  ("recovery.admit.isolated-dup-catalog",
    match admitIsolated dupCfg emptyRoster emptyBounds emptyBranches [] Tree.empty with
    | .error (.inl (.base .configuration)) => true
    | _ => false),
  ("recovery.isolated.consumed-empty",
    decide (isolatedConsumed ([] : Parallel.Branch P A D) = 0)),
  ("recovery.runIsolated.empty-tree",
    Parallel.worldEq
      (runIsolatedTree emptyCfg emptyBounds initial emptyBranches []
        (Tree.empty : Tree Empty)).1
      initial)
]

namespace Funded
open Typed Composition Parallel
open Typed.Examples
open DefiKernel.Nary.Tree

def fundedCfg := Parallel.Examples.cfg
def fundedInitial := Parallel.Examples.initial
def aliceBound : Boundary Party Asset Domain := ⟨aliceContext, fresh, 100⟩
def naryBounds : Boundaries (Fin 2) Party Asset Domain := fun _ _ => aliceBound

def f06Branch : Parallel.Branch Party Asset Domain :=
  [Parallel.Examples.usd 3, Parallel.Examples.usd 8]
def isoPrefix : Cursor Party Asset Domain :=
  isolated fundedCfg (fun _ => aliceBound) fundedInitial f06Branch 1
def isoRefused : Cursor Party Asset Domain :=
  isolated fundedCfg (fun _ => aliceBound) fundedInitial f06Branch 2

def firstStep : Except Composition.Failure (StepResult Party Asset Domain) :=
  executeStep fundedCfg aliceBound 0 [] (.invoke (Parallel.Examples.usd 3)) fundedInitial

def afterSuccess : World Party Asset Domain :=
  match firstStep with
  | .ok result => result.world
  | .error _ => fundedInitial

def secondStep : Except Composition.Failure (StepResult Party Asset Domain) :=
  match firstStep with
  | .ok result =>
    executeStep fundedCfg aliceBound 1 result.outputs
      (.invoke (Parallel.Examples.usd 8)) result.world
  | .error reason => .error reason

def fin2Roster : Roster (Fin 2) where
  order := [0, 1]
  nodup := by decide
  complete := by
    intro b
    match b with
    | ⟨0, _⟩ => exact List.Mem.head _
    | ⟨1, _⟩ => exact List.Mem.tail _ (List.Mem.head _)

def fin2Fork : Tree (Fin 2) := .fork (.leaf 0) (.leaf 1)

def disjBranches : Branches (Fin 2) Party Asset Domain := fun b =>
  if b = 0 then [Parallel.Examples.usd 3] else [Parallel.Examples.shares 4]

def f15Branches : Branches (Fin 2) Party Asset Domain := fun b =>
  if b = 0 then [Parallel.Examples.usd 3] else [Parallel.Examples.usd 8]

def mLR : Nary.Machine (Fin 2) Party Asset Domain :=
  Nary.runPrefix fundedCfg naryBounds fundedInitial f15Branches [0, 1]
def mRL : Nary.Machine (Fin 2) Party Asset Domain :=
  Nary.runPrefix fundedCfg naryBounds fundedInitial f15Branches [1, 0]

def tmLR : TreeMachine (Fin 2) Party Asset Domain :=
  runTreePrefix fundedCfg naryBounds fundedInitial fin2Fork f15Branches [0, 1]
def tmRL : TreeMachine (Fin 2) Party Asset Domain :=
  runTreePrefix fundedCfg naryBounds fundedInitial fin2Fork f15Branches [1, 0]

def tmDisjLR : TreeMachine (Fin 2) Party Asset Domain :=
  runTreePrefix fundedCfg naryBounds fundedInitial fin2Fork disjBranches [0, 1]
def tmDisjRL : TreeMachine (Fin 2) Party Asset Domain :=
  runTreePrefix fundedCfg naryBounds fundedInitial fin2Fork disjBranches [1, 0]

def disjAssoc : List (Fin 2 × Footprint Party Asset Domain) :=
  match Nary.analyzeAll fundedCfg naryBounds disjBranches [0, 1] with
  | .ok assoc => assoc
  | .error _ => []

def isoDisj : CanonicalObservation (Fin 2) Party Asset Domain :=
  isolatedCanonical fin2Roster fundedCfg naryBounds fundedInitial disjBranches
    disjAssoc fin2Fork

def f15failure (m : Nary.Machine (Fin 2) Party Asset Domain) (b : Fin 2) : Bool :=
  (m.locals b).failure.isSome

def funded : List (String × Bool) := [
  ("recovery.f06.catalog", validateCatalog fundedCfg.registry fundedCfg.catalog),
  ("recovery.f06.first-ok",
    match firstStep with
    | .ok _ => true
    | .error _ => false),
  ("recovery.f06.second-insufficientFunds",
    match secondStep with
    | .error (.kernel .insufficientFunds) => true
    | _ => false),
  ("recovery.f06.prefix-retained",
    decide (isoRefused.events.length = 1) &&
      decide (isoPrefix.failure = none) &&
      decide (isoRefused.failure.isSome)),
  ("recovery.f06.refusal-kernel",
    match isoRefused.failure with
    | some f => decide (f.reason = .kernel .insufficientFunds)
    | none => false),
  ("recovery.f06.store-fixed",
    decide (isoRefused.world.capabilities = fundedInitial.capabilities) &&
      decide (afterSuccess.capabilities = fundedInitial.capabilities)),
  ("recovery.f06.world-alice7",
    decide (isoRefused.world.state.balance Parallel.Examples.aliceUSD = 7) &&
      decide (afterSuccess.state.balance Parallel.Examples.aliceUSD = 7)),
  ("recovery.f06.world-bob3",
    decide (isoRefused.world.state.balance Parallel.Examples.bobUSD = 3)),
  ("recovery.f15.lr-right-refuses",
    decide (!f15failure mLR 0) && f15failure mLR 1),
  ("recovery.f15.rl-left-refuses",
    f15failure mRL 0 && decide (!f15failure mRL 1)),
  ("recovery.f15.worlds-differ",
    !Parallel.worldEq mLR.world mRL.world),
  ("recovery.f15.canonical-differ",
    !canonicalEq (canonicalOf fin2Roster tmLR) (canonicalOf fin2Roster tmRL)),
  ("recovery.f15.competing-ww",
    match Nary.analyzeAll fundedCfg naryBounds f15Branches [0, 1] with
    | .ok assoc =>
      match checkPairwise assoc with
      | .error e => decide (e.kind = .writeWrite)
      | .ok _ => false
    | .error _ => false),
  ("recovery.canonical.disjoint-schedules",
    canonicalEq (canonicalOf fin2Roster tmDisjLR) (canonicalOf fin2Roster tmDisjRL)),
  ("recovery.canonical.disjoint-isolated",
    canonicalEq (canonicalOf fin2Roster tmDisjLR) isoDisj &&
      canonicalEq (canonicalOf fin2Roster tmDisjRL) isoDisj)
]

theorem funded_catalog :
    validateCatalog fundedCfg.registry fundedCfg.catalog = true := by decide

theorem funded_disj_complete :
    Nary.Complete disjBranches ([0, 1] : Schedule (Fin 2)) := by
  intro b
  match b with
  | ⟨0, _⟩ => simp [disjBranches]
  | ⟨1, _⟩ => simp [disjBranches]

theorem funded_f15_complete :
    Nary.Complete f15Branches ([0, 1] : Schedule (Fin 2)) := by
  intro b
  match b with
  | ⟨0, _⟩ => simp [f15Branches]
  | ⟨1, _⟩ => simp [f15Branches]

theorem funded_wf : WellFormed fin2Roster fin2Fork := by
  intro b hb
  match b with
  | ⟨0, _⟩ => simp [fin2Fork, Tree.count, Tree.leaves]
  | ⟨1, _⟩ => simp [fin2Fork, Tree.count, Tree.leaves]

end Funded

def allComparisons : List (String × Bool) :=
  comparisons ++ Funded.funded

def main : IO Unit := do
  if allComparisons.isEmpty then
    throw (IO.userError "recovery comparisons empty")
  if !(allComparisons.map Prod.fst).Nodup then
    throw (IO.userError "recovery comparison names are duplicated")
  for (name, passed) in allComparisons do
    IO.println s!"{name}: {passed}"
  let failures := allComparisons.filter (!·.2) |>.map Prod.fst
  if !failures.isEmpty then
    throw (IO.userError s!"recovery comparisons failed: {failures}")

#eval main

end DefiKernel.Nary.Tree.RecoveryChecks
