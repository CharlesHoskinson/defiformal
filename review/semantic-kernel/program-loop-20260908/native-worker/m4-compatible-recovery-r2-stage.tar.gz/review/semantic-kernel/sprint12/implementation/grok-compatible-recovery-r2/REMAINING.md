# Remaining after r2 generic recovery candidate

Core assigned 4.1–4.6 generic proofs in this slice are elaborated (no `sorry`).
Items below are later separate work, not unfinished induction/equality.

1. **Full fixture enumeration.** F01–F20 / 313 labels and the 90 F05/F06
   complete schedules remain later instances of `complete_schedule_canonicalEq`
   / `complete_schedule_independence`. One funded F06 companion and one actual
   F15 opposite-order execution are in RecoveryChecks.

2. **Kernel `exact` of the generic theorem on Parallel.Examples assoc.**
   `#eval` shows `canonicalEq` of disjoint `[0,1]`/`[1,0]` vs `isolatedCanonical`.
   `funded_catalog` / `funded_wf` / `funded_disj_complete` are proved. A named
   `exact complete_schedule_canonicalEq …` for that catalog still needs kernel
   `analyzeAll = .ok` and `PairwiseCompatible` witnesses.

3. **Contracts / monitor / Examples / Tests / Audit / Fixtures / Verify /
   harness / root imports.** Out of this slice.

4. **Arbitrary populated-entry schedule independence.** Explicitly excluded.
   Recovery starts from genesis `Nary.start` / `runTreePrefix`.

No `sorry` stands in for these.
