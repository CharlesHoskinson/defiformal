funded_wf `decide` rejected Fin `isLt` free variables. Replaced with Tree.count simp.
