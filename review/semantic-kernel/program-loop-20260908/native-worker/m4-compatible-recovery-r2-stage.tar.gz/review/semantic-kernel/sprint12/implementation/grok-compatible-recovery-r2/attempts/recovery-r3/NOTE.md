Grouping/canonical first elaboration: leaf membership direction `b = x`;
CanonicalLocal is not Prod; toCursor.world needed unfolding; map_congr after
over-simp; independence Fintype metavar; admitIsolated error-branch unsolved.
Compiler, not a semantic negative.
