Failed first Compatibility pairwise-iff elaboration: `rfl`/`subst` on membership
eliminated `other`/`head`; `List.mem_map` wanted `q.1 = head.1`; `List.not_mem_nil`
is a proposition, not a function. Compiler/setup, not a semantic negative.
