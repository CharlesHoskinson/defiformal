# M4 compatible isolated recovery r2 (native Grok 4.6)

Assigned slice: tasks 4.1–4.6. This is a **reviewable generic recovery
candidate** for GPT-6, not whole-M4 or whole-program acceptance, and not
author self-acceptance. R1 remains PARTIAL historical evidence; its archive
is preserved and was not overwritten.

- Author: native Grok 4.6
- Checker: independent GPT-6 (not this document)
- Foreman: not used
- Commits/push/self-acceptance: none
- Source HEAD: `a12b7cac05a818cc8d35c2ca440b7170a2807e92` (unchanged)
- R1 archive: `review/semantic-kernel/program-loop-20260908/native-worker/m4-compatible-recovery-r1-stage.tar.gz`
  SHA-256 `8f4ad43a1829df2c4038ac2dadd57f1ee42bdf0ced3ff63372d4e2785707a9d8`
- Foundation 6 files: sealed, hashes match r1 `before/foundation-sealed.json`
- `DisjointRuntime.lean`: unchanged from r1 (`5c67ddfd…687eed44`)
- Cache: this worktree `lean/.lake` (directory, not a symlink)
- Lean 4.33.0-rc2 / Lake 5.0.0-src+d8b1897 (`d8b18978322de05a8f3dba51ef03cf5461676c17`)

## Owned sources (r2)

| File | SHA-256 | Bytes |
|---|---|---:|
| `lean/DefiKernel/Nary/Tree/DisjointRuntime.lean` | `5c67ddfd1ee6fbf4d57be181633b4625b3195f08ba54a5f05aa3a308687eed44` | 13777 |
| `lean/DefiKernel/Nary/Tree/Compatibility.lean` | `e9c012e6d69a1eeb89380aad8de473ad882031a556aea3d435fb7be69f9fb425` | 9347 |
| `lean/DefiKernel/Nary/Tree/Recovery.lean` | `a7f34726e42e5575f424830df7f477a9ae127a89983d2dfe7816ebee1e8f9b33` | 50657 |
| `lean/DefiKernel/Nary/Tree/RecoveryChecks.lean` | `65e90a0add8305d8d480d6741e31c8c8338928ca1f81217cd7460e1a117e15c3` | 12226 |

No `sorry` / `native_decide` / `axiom`. `runTree` was not modified and has no
compatibility guard. `Parallel.Compatible` is referenced only from Compatibility.
`mergeNonneg` keeps `first | exact hr | exact add_nonneg hl hr` for M13.

R1 `checkPairwise_ok_of` required self-pair `Compatible`, which forces empty
writes. r2 proves `checkPairwise_ok_iff` from `PairwiseCompatible` (distinct
identities) under `(assoc.map Prod.fst).Nodup`. `checkPair_error_iff` records
identity/kind/first-cell correspondence with `checkCompatibility` without
matching its `PUnit` return in a Tree definition.

## Compile

Eight final commands, `cwd=lean`, all exit 0. Logs: `logs/*-final-*`.

| Command | Exit | Time (s) |
|---|---:|---:|
| `lake build DefiKernel.Nary.Tree.DisjointRuntime` | 0 | 0.70 |
| `lake env lean DefiKernel/Nary/Tree/DisjointRuntime.lean` | 0 | 1.55 |
| `lake build DefiKernel.Nary.Tree.Compatibility` | 0 | 0.69 |
| `lake env lean DefiKernel/Nary/Tree/Compatibility.lean` | 0 | 1.48 |
| `lake build DefiKernel.Nary.Tree.Recovery` | 0 | 0.72 |
| `lake env lean DefiKernel/Nary/Tree/Recovery.lean` | 0 | 1.96 |
| `lake build DefiKernel.Nary.Tree.RecoveryChecks` | 0 | 0.71 |
| `lake env lean DefiKernel/Nary/Tree/RecoveryChecks.lean` | 0 | 2.55 |

## Checks

36 unique nonempty `#eval` rows, all `true` (`lake env lean` stdout). Coverage:

- F13 write/write and both write/read directions, shared-read, disjoint writes,
  pairwise ok/ww/shared
- F20 sentinel 11≠22, unique owners, fixed store
- F06 funded `executeStep` success then `.kernel .insufficientFunds`, guard
  true, prefix retention, store fixed, Alice USD 7 / Bob USD 3
- F15 actual opposite-order shared execution: LR right refuses / RL left
  refuses, worlds differ, canonical observations differ, analyzed WW conflict
- Complete disjoint schedules `[0,1]` vs `[1,0]` agree with each other and with
  `isolatedCanonical`
- admitIsolated empty/dup-catalog, isolated empty tree

Not F01–F20 / 313 labels / 90 complete-schedule fixture enumeration.

Kernel instantiations in RecoveryChecks: `funded_catalog`, `funded_disj_complete`,
`funded_f15_complete`, `funded_wf`. Generic `complete_schedule_canonicalEq` is
not `exact`-applied to the Parallel.Examples assoc (analyzeAll/PairwiseCompatible
for that catalog remain computational in the `#eval` rows).

## Proved in this candidate (generic, kernel-checked)

- Distinct-participant `checkPairwise` ↔ `PairwiseCompatible` under nodup
- `checkPair_error_iff` diagnostic correspondence
- `Simulates.advance` / `continue` / `runPrefix` for admitted pairwise-compatible
  analyzed footprints, genesis empty locals, `Nary.Reachable`, no all-success
  or desired full-run equality. Own success / financial refusal / failed skip /
  exhausted skip / peers covered via `executeStep` frames and
  `Interleaving.Recovery.cursor_advance_congr`
- Complete-schedule `canonicalEq` of `canonicalOf (runTreePrefix …)` vs
  independent `isolatedCanonical`, including refusals; consumed = branch.length;
  schedule independence from genesis through the isolated projection
- Isolated tree vs flat `foldIsolatedWorld` world equivalence, empty-unit,
  fork reassociation, outside-write frame, store = initial capabilities
- Unique owner-selecting merge; no state-sum; no sibling restart

Premises are explicit: `analyzeAll = .ok assoc`, `PairwiseCompatible`,
`Roster.nodup`/`complete`, `WellFormed`, `validateCatalog`, `Nary.Complete`.
Outside-roster default empty footprints are not used as write frames;
`Roster.complete` puts every `b : B` on the analyzed order.

## What this does not claim

Whole M4, whole program, contracts/monitor, full Examples/Tests/Audit/Fixtures/
Verify/harness/rootimports, 90 F05/F06 schedules, arbitrary populated-entry
schedule independence, or GPT-6 acceptance of this candidate.
