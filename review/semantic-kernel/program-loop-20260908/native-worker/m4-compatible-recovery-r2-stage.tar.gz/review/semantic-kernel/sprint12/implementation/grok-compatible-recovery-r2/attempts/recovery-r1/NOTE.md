analyzeAll_map_fst nil: simp already reduced Except.ok to fps = [].
footprintOf_of_mem mem_map wanted `b = head.1` not `head.1 = b`.
Compiler, not a semantic negative.
