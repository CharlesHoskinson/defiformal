# Auxiliary

`lean/DefiKernel/Nary/Tree/RecoveryChecks.lean` is the recorded auxiliary for
this lane. It is not Nary.Examples / Tree.Examples / Tests / Audit / Fixtures.
It imports existing `DefiKernel.Parallel.Examples` only to construct a funded
catalog for F06/F15 execution. Those library files were not edited.
