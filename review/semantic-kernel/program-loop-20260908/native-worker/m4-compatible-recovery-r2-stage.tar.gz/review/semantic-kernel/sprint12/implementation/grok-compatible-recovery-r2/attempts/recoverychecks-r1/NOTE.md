checkCompatibility in #eval comparisons reintroduced PUnit universe metavariables.
Funded.initial resolved to the Bool RecoveryChecks world, not Parallel.Examples.
Compiler, not a semantic negative. Diagnostic correspondence stays the
checkPair_error_iff theorem, not a Bool checkCompatibility row.
