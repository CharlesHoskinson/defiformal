lake env lean --version
