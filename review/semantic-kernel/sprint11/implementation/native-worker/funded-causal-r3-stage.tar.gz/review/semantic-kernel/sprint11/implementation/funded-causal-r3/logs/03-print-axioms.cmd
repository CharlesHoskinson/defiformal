lake env lean --stdin
