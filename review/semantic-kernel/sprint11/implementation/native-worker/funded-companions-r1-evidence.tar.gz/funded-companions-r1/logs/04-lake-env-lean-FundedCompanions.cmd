cd /home/charl/defiformal-wt-sprint11-grok-gpt6-20260907/lean && lake env lean DefiKernel/Nary/FundedCompanions.lean
