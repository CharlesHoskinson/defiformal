## Purpose

Specify certificates, representation correspondence, source refinement, runtime adapters, environment evaluation, untouched holdouts, Atlas residuals, and the final paper and developer package.

## ADDED Requirements

### Requirement: Typed sequential certificates recompute judgments

`P19` SHALL define a serialized module and transition format and a checker that recomputes typing, footprints, authority, accounting, and sequential composition by invoking actual delivered Lean entrypoints. Claimed judgment tags, theorem names, and envelope hashes MUST NOT be treated as proof. The unaccepted candidate at `/home/charl/defiformal-wt-certificates-grok-gpt6-20260908/openspec/changes/serialized-kernel-certificates/` is a planning input, not an accepted gate.

#### Scenario: Tag does not skip Args.check
- **WHEN** a payload claims `TypeCorrect` and units mismatch
- **THEN** the checker still runs `Args.check` and reports the evaluation error

#### Scenario: Unsupported form is rejected
- **WHEN** a document contains a tree-join or Claims operator with a valid invoke rest
- **THEN** the result is `unsupportedForm`, not a complete certificate

### Requirement: Quantified representation correspondence and wider operators

`P20` SHALL prove a quantified representation-to-Lean correspondence for the supported certificate domain, then extend only with actual consumer need and a new correspondence result per extension. Quint abstractions, if introduced, MUST have the same correspondence obligation. Codec correctness MUST NOT close source refinement.

#### Scenario: Bounded fixture is not universal correspondence
- **WHEN** finite fixtures F25/F27/F28 round-trip
- **THEN** they are bounded evidence and do not discharge the universal correspondence theorem

### Requirement: Reusable differential execution and selected source refinement

`P30` SHALL run identical generated sequences against pinned implementations and models for successful and refused behavior, detect characteristic mutations, and prove selected concrete implementation-to-model refinements. This sprint MUST remain required before full-program closure even if an earlier increment shipped with refinement open.

#### Scenario: Refinement still required
- **WHEN** P16 and P18 published model-verified bounded comparisons with refinement outstanding
- **THEN** `P30` remains unchecked and the program is not complete

### Requirement: Runtime adapters with readiness gates

`P31` SHALL add chain and runtime adapters only through verified interfaces. Moriarty, Compact, ZKIR, and proof-carrying-transaction integration MUST each have a named readiness task and a named implementation task. If a verified interface or source is unavailable, the implementation task SHALL stay `blocked_unavailable` and MUST NOT be marked complete by deferral. The 2026-09-06 source plan lines 1140–1142 are agenda input: no invented semantics.

#### Scenario: Missing Moriarty interface
- **WHEN** no verified Moriarty interface or source is supplied
- **THEN** readiness records the gap, adapter implementation is blocked, and kernel modules do not import imagined Moriarty APIs

#### Scenario: PCT after verified interface
- **WHEN** a verified proof-carrying-transaction interface exists and is pinned
- **THEN** implementation may bind kernel certificates as a referenced obligation class without collapsing cryptographic, semantic, oracle, and legal evidence

### Requirement: Environment pins and evaluations

`P32` SHALL pin implementations, versions, deployments, and relevant execution environments, covering EVM, Solana, Cosmos, Move/Sui, sovereign cross-chain, and payment-channel environments named in the 2026-09-06 source plan line 1116. Each environment MUST have a readiness record. Unavailable toolchains or sources SHALL be blocked, not scored.

#### Scenario: EVM pin for token0
- **WHEN** Uniswap v3-core `e3589b192d0be27e100cd0daaf6c97204fdb1899` executes under a declared solc and EVM harness
- **THEN** that record counts as EVM environment evidence for the declared function, not as Solana, Cosmos, Move, sovereign, or payment-channel coverage

#### Scenario: Missing Move toolchain
- **WHEN** no pinned Move/Sui source and toolchain are available
- **THEN** Move/Sui evaluation is `blocked_unavailable` and MUST NOT inherit EVM scores

### Requirement: Kernel freeze and twelve-case replacement policy

`P33` SHALL freeze relevant kernel, schema, and library versions before untouched evaluation. The existing 75 candidates MUST remain development. Prior twelve REPORT labels are exposure records with original IDs unknown; they MUST NOT yield an untouched score. Replacement of contaminated cases SHALL follow an exposure-audited policy. Held assessment payloads MUST NOT be read during this program’s planning or during `P33` policy freeze.

#### Scenario: Development case is not a holdout
- **WHEN** a candidate was used to design the kernel or appears on the prior-exposure ledger
- **THEN** it stays development and is ineligible as an untouched evaluation case

### Requirement: Independent untouched evaluation and separated metrics

`P34` SHALL evaluate independently selected untouched cases after the freeze and SHALL report schema coverage, behavioral coverage, library reuse, new kernel concepts, new library templates, external assumptions, and verification effort as separate metrics. A new library function is not a kernel failure; a new state, effect, or composition concept required to encode a holdout is.

#### Scenario: Separated metrics
- **WHEN** evaluation results are published
- **THEN** each metric has its own denominator and no single percentage is advertised as whole-program completion

### Requirement: Atlas candidate and residual interaction

`P35` SHALL independently review the Atlas accessibility candidate archive `56c3a1d532669f229e9c67f7e25f3253bedabd9baad5ae4942f306ef9c487db6` (author 238 checks are not acceptance) and SHALL complete residual keyboard traversal, search-list, badges, zoom, print, find-in-page, 200-percent zoom, reduced motion, and readability obligations from `openspec/changes/design-atlas-visualization/tasks.md` items 7.4, 8.2, 8.3, and 8.4 plus CURRENT.json residuals.

#### Scenario: Author 238 checks
- **WHEN** the Atlas candidate reports 238 author checks
- **THEN** independent review of the exact candidate is still required and new scientific features stay parked until schema stability

### Requirement: Scientific Atlas and graph after stable schema

`P36` SHALL update the ontology visualization and repository graph after the accepted schema stabilizes, without implying periodic-law predictive power. `P36` MUST depend on accepted residual Atlas work and on a stable schema from accepted platform results.

#### Scenario: Mapping statement remains visible
- **WHEN** the scientific refresh ships
- **THEN** every layout header retains the mapping statement and missing-denominator mark for incomplete evidence

### Requirement: Paper and external developer package

`P37` SHALL rewrite the paper around demonstrated results and limits, ship a versioned external-developer example and API package, and complete verified delivery to `semantic-kernel-pivot` only. Remaining blocked obligations MUST be listed. Full-program closure MUST include selected source refinement (`P30`) and MUST NOT merge to `main`.

#### Scenario: Developer package instantiates an accepted library
- **WHEN** an external-developer package is published
- **THEN** it instantiates an accepted financial library and executor interface, states a meaningful financial predicate, binds a pinned implementation, and shows proved, measured, and assumed obligations exactly
