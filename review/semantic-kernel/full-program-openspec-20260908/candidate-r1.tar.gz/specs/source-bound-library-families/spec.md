## Purpose

Specify source-bound financial libraries: first pinned Uniswap token0 execution, a contrasting vault after actual source readiness, then resource-gated remaining families without inventing missing pins.

## ADDED Requirements

### Requirement: First pinned Uniswap token0 operation

`P16` SHALL execute the pinned Uniswap V3 token0 next-price operation from v3-core `e3589b192d0be27e100cd0daaf6c97204fdb1899` under pinned compiler settings and a declared EVM harness, or justify another actual source-semantics reference. The independent Python transcription MUST remain a diagnostic third implementation. Predeclared nonempty partitions SHALL cover ordinary inputs, multiplication overflow, denominator-sum overflow, rounding boundaries, add and remove paths, zero input, and applicable refusals. Standalone function admissibility MUST be distinguished from full-pool reachability.

#### Scenario: Sum-overflow mismatch is repaired
- **WHEN** sqrtP is MAX_SQRT_RATIO−1, liquidity is max uint128, amount causes numerator1+product uint256 overflow while the product fits
- **THEN** Lean library and pinned Solidity results agree, or the case is an explicit exclusion recorded before scoring

#### Scenario: M09 does not protect F28
- **WHEN** the planned M09 mutant flips the direction predicate
- **THEN** F28 is removed or replaced as a protected control because amountIn changes from 2 to 1, and a genuinely unaffected sibling is named

### Requirement: Contrasting vault after source readiness

`P17` SHALL select a narrow stateful vault deposit or withdrawal with asset/share rounding and transfer refusal. A reviewed executable vault pin is not established at planning time. `P17` MUST verify or acquire an exact source closure from development material before implementation, and MUST record `blocked_missing_source` rather than invent fidelity if none is ready.

#### Scenario: No vault pin
- **WHEN** retained development sources lack an adequate vault revision, compiler, and observation closure
- **THEN** `P17` implementation stays blocked, the missing pin is named, and a second AMM formula is not substituted

### Requirement: Resource-gated remaining families

`P21`–`P29` SHALL start only after the measured two-case reuse gate, except independent source-readiness inspection. Each family MUST have a pinned source, observation/refusal contract, nonempty fixtures, characteristic mutations, and explicit remainders. Missing pins stay blocked.

#### Scenario: Source inspection before reuse gate
- **WHEN** a Curve or Morpho pin can be verified from retained development bytes
- **THEN** readiness records MAY be written before `P18`, and library implementation still waits on the reuse gate

### Requirement: Full concentrated-liquidity traversal

`P21` SHALL extend the token0 slice to tick traversal, including the named remainders `R-FULL-TRAVERSAL`, `G-FULLMATH-ASSEMBLY`, and `G-NO-SOLC-DIFFERENTIAL` from the unaccepted liquidity candidate. Assembly FullMath identity, `Pool.swap` lock/callback/payment, and deployment fidelity MUST stay named gaps until separately discharged.

#### Scenario: One-word bitmap is not full traversal
- **WHEN** `nextInitializedTickWithinOneWord` proofs pass
- **THEN** the Uniswap-style concentrated-liquidity roadmap item remains open until actual multi-word traversal and declared pool observations are accepted or explicitly excluded

### Requirement: Curve iteration and nonconvergence

`P22` SHALL implement Curve-style iterative invariant calculation with success, nonconvergence, and max-iteration refusal observations against a pinned source. Nonconvergence MUST be a first-class refusal, not an omitted loop.

#### Scenario: Nonconvergence refusal
- **WHEN** iteration hits the declared bound without meeting the invariant tolerance
- **THEN** the library returns the specified refusal and does not emit a fabricated convergent output

### Requirement: Liquity ordered redemption is not the liquidation dispute

`P23` SHALL implement Liquity-style ordered redemption against a pinned source distinct from the `P10` liquidation-source challenge. Redemption order, partial fills, and refusal when no redeemable trove exists MUST be observed.

#### Scenario: Empty redeemable set
- **WHEN** no trove is redeemable under the pinned order
- **THEN** redemption refuses without rewriting the liquidation-source overlay

### Requirement: Morpho bad-debt loss allocation

`P24` SHALL implement Morpho-style bad-debt realization and loss allocation against a pinned source, including a reachable loss and a refusal or no-op when no bad debt exists.

#### Scenario: Loss allocated to the declared party
- **WHEN** a realized bad-debt fixture executes
- **THEN** balances and shares match the pinned allocation rule and an unaffected control market is unchanged

### Requirement: Balancer vault, hooks, and transient accounting

`P25` SHALL implement Balancer-style shared vault accounting, hooks, and transient settlement against a pinned source. This family MUST NOT be used as a substitute for the `P17` contrasting vault pin unless that exact pin is the reviewed Balancer source.

#### Scenario: Transient settlement not committed on hook revert
- **WHEN** a hook reverts during a vault operation
- **THEN** transient accounting is not published as committed state

### Requirement: Asynchronous workflows

`P26` SHALL implement message lifecycles, finality, replay protection, timeouts, challenges, and compensation, and SHALL represent oracle, custody, legal, sequencing, and finality assumptions explicitly. Synchronous rollback MUST NOT be assumed.

#### Scenario: Replay after finality
- **WHEN** a finalized message identifier is submitted again
- **THEN** the workflow refuses replay and retains the original final observation

### Requirement: Signed margin, funding, unsettled PnL, liquidation, and bankruptcy

`P27` SHALL implement signed margin, funding, unsettled profit and loss, liquidation, and bankruptcy handling against a pinned source, with refusals for under-margin and insolvent cases.

#### Scenario: Unsettled PnL is not cash
- **WHEN** an account has positive unsettled PnL and insufficient margin
- **THEN** liquidation or refusal follows the pinned rule and unsettled PnL is not treated as withdrawable cash unless the source says so

### Requirement: Conditional insurance and off-chain claims

`P28` SHALL implement external conditional claims, including insurance or tokenized off-chain obligations, with explicit oracle, custody, and legal assumptions. Off-chain truth MUST remain an assumption where unproved.

#### Scenario: Oracle assumption is explicit
- **WHEN** an insurance claim is paid from an oracle attestation
- **THEN** the evidence packet classifies oracle truth as an external assumption, not a proved fact

### Requirement: Complete cross-domain workflow

`P29` SHALL implement one actual complete cross-domain financial workflow with no synchronous-rollback assumption, including the required finality, replay, timeout, challenge, and compensation semantics. A sketch or single-chain stand-in MUST NOT close this obligation.

#### Scenario: Counterparty domain timeout
- **WHEN** the remote domain does not finalize before the declared timeout
- **THEN** compensation or challenge follows the workflow contract and local committed state is not silently rolled back
