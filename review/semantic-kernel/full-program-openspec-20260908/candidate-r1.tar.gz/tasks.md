## 1. Standing gates for every later sprint

- [ ] 1.1 Record exact frozen input hashes, requested model identity, reported model identity, and tool versions on every `P01`–`P37` candidate; verify author exit is not treated as independent GPT-6 acceptance.
- [ ] 1.2 Require nonempty positive and negative inventories on every credited check; verify empty glob, empty directory, or zero-iteration loops exit 3 (blocked), never 0.
- [ ] 1.3 Credit production mutations only for actual compiled mutants that change a designated observation while an unaffected control stays true; verify timeout, setup, and compile errors are blocked, not detections.
- [ ] 1.4 Produce complete proof inventories (statements, premises, transitive axioms) with no `sorry`, custom axioms, or `native_decide`; verify changed modules plus affected consumers are checked and exact unchanged-dependency reuse is allowed.
- [ ] 1.5 Default to one independent GPT-6 review plus one targeted rereview; verify further rounds occur only for a concrete unresolved finding and that unavailable review leaves the gate open.
- [ ] 1.6 Deliver accepted work only by parent-owned commit, push, and readback to `semantic-kernel-pivot`; verify no merge to `main` and that this planning change does not start implementation or lift the dispatch hold.
- [ ] 1.7 Keep model proof, bounded source execution, representation correspondence, source refinement, and external assumptions distinct; verify a codec-to-Lean theorem is never used to discharge source refinement.
- [ ] 1.8 Apply cleanup only with exact consumer, root, build, or CLI evidence, keep it reversible, and preserve historical proofs, negative results, partials, and dirty worktrees; verify graph isolation is not used as deletion proof.

## 2. P01 M4 recovery r2 closeout

- [ ] 2.1 Bind delivered Sprint 10 and M3 APIs and the frozen recovery archive `9b700c0f6ff4a49d008cb3e5eb6a6d9a6b10ad9366b8a63f0c2619eb205c7741` for `P01`; verify original `operational-tree-regrouping` task IDs 1.1–3.5 (planning/runtime foundation) and 4.1–4.6 (recovery) remain discoverable and are not relabelled delivered by this program. Missing foundation artifacts are `P01` setup failure, not a new delivered claim.
- [ ] 2.2 Execute `P01` original task 4.1: roster-pair compatibility diagnostics over actual footprints, full read/write/output dependency and compatible subtree-union laws, F13 conflict directions and shared-read positive.
- [ ] 2.3 Execute `P01` original task 4.2: separate actual runBranch-per-leaf flat reference and owner-selecting merge; verify F20 nonzero unowned sentinel, store, and successful-prefix refusal retention.
- [ ] 2.4 Execute `P01` original task 4.3: recursive isolated tree execution, flat-reference correspondence, grouping/empty units and outside-write frame; verify F20 independently expected balances.
- [ ] 2.5 Execute `P01` original task 4.4: shared-prefix versus isolated-consumed-prefix simulation with actual dependency/refusal congruence; verify no desired full-run equality premise.
- [ ] 2.6 Execute `P01` original task 4.5: canonical comparator, complete-schedule recovery including F06 financial refusals, and F05/F06 all 90 complete schedules.
- [ ] 2.7 Execute `P01` original task 4.6: F15 opposite-order competition counterexample and full-trace versus canonical distinctions in F19; exclude arbitrary populated-entry schedule independence.
- [ ] 2.8 Run `P01` from `lean/`: `lake env lean DefiKernel/Nary/Tree/Compatibility.lean`, `Recovery.lean`, and `RecoveryChecks.lean`; classify missing artifacts as setup failure (blocked), not refutation.
- [ ] 2.9 Obtain independent GPT-6 review of the exact `P01` candidate; stop on missing assigned theorem, circular premise, vacuous compatibility, absent refusal, or empty inventory, and issue only a bounded repair.

## 3. P02 M4 remaining contracts, monitors, fixtures, mutations, integration

- [ ] 3.1 After accepted `P01`, bind `P02` to original `operational-tree-regrouping` tasks 5.1–7.5 without renaming those IDs delivered.
- [ ] 3.2 Execute `P02` task 5.1: transport M3 reachability/local order/initialized interference through representation; verify F17 initialized and unequal-entry companions.
- [ ] 3.3 Execute `P02` task 5.2: instantiate accepted M2 region/global-binding contracts with the unchanged full edge set; verify F16 dropped-cross-edge and F17 paired-debit prefixes 5/5→4/4→3/3→2/2 with total 10.
- [ ] 3.4 Execute `P02` task 5.3: monitor wrapper using one actual tree step and newly appended attempt/none; prove erasure and fixed-parameter monitor correspondence; verify F18 funded provenance and skipped-token input.
- [ ] 3.5 Execute `P02` task 5.4: fixed-prefix monitor regrouping/common-prefix equality and F18 order-list counterexample; keep callback constants as explicit limits.
- [ ] 3.6 Execute `P02` tasks 6.1–6.2: all twenty fixture contracts with literal expected worlds and exactly 90 unique complete (2,2,2) schedules plus 12 funded causal schedules.
- [ ] 3.7 Execute `P02` tasks 6.3–6.5: Audit/runner adaptation, eighteen compiled production mutants with intended false oracles and protected positives, and no semantic credit for compiler failure/timeout.
- [ ] 3.8 Execute `P02` tasks 7.1–7.5: integrated Lean/runtime checks, complete theorem/axiom inventories, scenario reconciliation, independent GPT-6 evidence review, and parent-owned delivery of this bounded tree/regrouping scope only.

## 4. P03 official M5 active extension

- [ ] 4.1 Wait for delivered `P02`/M4, then refresh every `operational-active-extension/api-refresh.json` row against actual signatures for `P03`; verify the provisional r2 plan is not treated as official freeze.
- [ ] 4.2 Execute `P03` original tasks 1.1–1.4: fixture/mutation/control refresh, same-candidate planning reviews, and fresh baselines with nonempty inventories.
- [ ] 4.3 Execute `P03` original tasks 2.1–2.4: `Extension/Projection.lean` and `Isolation.lean` restriction, protected observations, and footprint checker soundness without extra invariant claims.
- [ ] 4.4 Execute `P03` original tasks 3.1–3.6: actual old/new step simulation, prefix simulation, and supported ledger transport with an unsupported global-total counterexample.
- [ ] 4.5 Execute `P03` original tasks 4.1–4.4: invocation-only context grammar, negatives for omitted cells/peer history/revoked stores/Atomic abort, and tree transport using actual M4 fixed-schedule simulation.
- [ ] 4.6 Execute `P03` original tasks 5.1–5.7: twenty fixtures, sixteen compiled mutants, inherited controls, proof inventory, independent review, and parent-owned delivery without claiming dynamic provenance or deployment fidelity.

## 5. P04 M6 atomic metatheory transfer

- [ ] 5.1 After delivered `P02` and `P03`, refresh `atomic-metatheory-transfer/api-refresh.json` for `P04` against actual Atomic, finite, tree, and extension APIs; reject unresolved proposed names.
- [ ] 5.2 Execute `P04` original tasks 2.1–2.5: finite Atomic policy, execution, observation, prefix soundness, and commit characterization without assuming atomic commit.
- [ ] 5.3 Execute `P04` original tasks 3.1–3.4: binary correspondence, independent tree execution around actual M4 steps, and negatives for split transfer, early loan settlement, and differing first abort.
- [ ] 5.4 Execute `P04` original tasks 4.1–4.5: restricted atomic active extension, lane-effect safety, outstanding/residual preservation, and all 12 F13 schedules with independent expectations.
- [ ] 5.5 Execute `P04` original tasks 5.1–5.7: twenty fixtures, eighteen compiled mutants, inherited controls, inventories, independent review, and delivery excluding general new-lane settlement and moved boundaries.

## 6. P05 capability provenance and isolation

- [ ] 6.1 For `P05`, review the capability-foundation archive `7fc31431a2b5d6f0198f8a182fcd31a35b90d323c076c1c0bc000c9a3b30c52a` and resolve CF1 revoked-ID discrimination and CF2 22-versus-23 check counts before whole-foundation acceptance; no M4 prerequisite.
- [ ] 6.2 Execute `P05` original tasks 2.1–2.6: trusted-root OriginAt, unique origin, allocation counts, tombstones, current-store authority, and rejected-administration prefix retention.
- [ ] 6.3 Execute `P05` original tasks 3.1–3.2: read-only origin/authority queries and auditRun with forged-event negative companion.
- [ ] 6.4 Execute `P05` original tasks 4.1–4.6: observation support, frames, peer-private exclusion, and negatives for untrusted roots, read-only flow, and store-sensitive frames.
- [ ] 6.5 Execute `P05` original tasks 5.1–5.3 and 6.1–6.7: F01–F20 fixtures, fourteen compiled query mutants, 65 inherited controls, inventories, independent review, and delivery without confidentiality or concurrent-allocation claims.

## 7. P06 Claims generic partial recovery

- [ ] 7.1 Inspect the cancelled `P06` archive `6fdca9817bc2a4bba52b5a58c6c605a16aacb7fb9c0b46100ff8b3bf26239ee3` (`PaymentSoundness`, `Conservative`, `Preservation`); verify `cancelled`/`max_turns_reached` is not completion.
- [ ] 7.2 Choose one bounded `P06` obligation from original claims tasks 4.2, 4.3, or 4.7 and finish only that obligation; preserve remaining partial bytes.
- [ ] 7.3 Independently review the chosen `P06` obligation with complete inventories; do not rewrite historical World/Right statements.

## 8. P07 Claims full lifecycle, payment, non-erasure, fixtures, delivery

- [ ] 8.1 After `P06`, refresh Typed/Composition/Atomic identities and the inherited runner catalog for `P07`; obtain planning review on the refreshed claims bundle.
- [ ] 8.2 Execute `P07` original tasks 2.1–2.5: claim records, lookup/role checks, transfer/extension, forgiveness/default, and nondecreasing time with exact failure order.
- [ ] 8.3 Execute `P07` original tasks 3.1–3.6: actual Composition-backed createLoan and repayment, paymentMismatch, one publication point, and sticky failed suffix.
- [ ] 8.4 Execute `P07` original tasks 4.1–4.8: full comparator, payment soundness from `executeStep_sound`, preservation, no-disappearance, paid-versus-forgiven equation, funding witnesses, and conservative legacy projection.
- [ ] 8.5 Execute `P07` original tasks 5.1–5.8: F01–F24 fixtures, twenty compiled mutants, `scripts/claims_gate.py` and `scripts/test_claims_gate.py`, inventories, independent review, and parent-owned delivery; keep conditional/indexed/async/legal gaps explicit.

## 9. P08 corpus classification and capture-derived-span repair

- [ ] 9.1 For `P08`, repair EigenCloud attempt classification that treats a challenge-page HTTP 403 body as `substantive`; verify the record confers zero semantic support.
- [ ] 9.2 For `P08`, rebind CoW `bonding:funded-safe` / `vouch-and-release` spans from the 404 sibling `space: body` to the derived UTF-8 artifact named by `evidence-locators.json`; keep the failed attempt separate.
- [ ] 9.3 Encode the `P08` invariant that cited span maps to exact derived artifact, extraction record, and original successful response; verify challenge/404 captures remain retained with zero support.
- [ ] 9.4 Independently review the `P08` repairs without completing all 169 work items and without opening holdout payloads.

## 10. P09 corpus 169 work, 75 identities, 29 disputes

- [ ] 10.1 After `P08`, execute `P09` original corpus tasks 3.1–3.2: organization/product/version/deployment identities for all 75 development candidates and additional split/residue records.
- [ ] 10.2 Execute `P09` original tasks 5.1–5.3 and 5.5: INTERSECTION_UNRESOLVED derivation, `evidence-adjudication/1` rules, append-only dispositions, and all 29 disagreements (32 label instances) with silence-not-refutation.
- [ ] 10.3 Execute `P09` original tasks 6.1–6.3: monotonic development exposure, separate evaluation manifest, and freeze-readiness validation; verify all 75 remain development.
- [ ] 10.4 Execute `P09` original tasks 7.1–8.3 tooling/acceptance on the overlay produced after `P08` repairs; verify `review_pending` is excluded from complete-work exit 0.

## 11. P10 Liquity challenge, dependencies, ambiguity, reference reconstruction

- [ ] 11.1 Execute `P10` original corpus task 5.4: separate Liquity V1 liquidation-source challenge with retained primary packets; do not treat this as `P23` ordered-redemption implementation.
- [ ] 11.2 Execute `P10` original tasks 3.3 and 4.1–4.3: typed dependencies, source pins, deployment records, and independent fidelity statuses; unknown evidence is never promoted by a URL.
- [ ] 11.3 Execute `P10` original tasks 2.1–2.2: original-recovery versus reconstructed-replacement for unresolved supplied-proposal references, including 72 rows, 62 citation occurrences, 45 token groups, and two attachment pointers.
- [ ] 11.4 Independently review `P10` decisions; keep unresolved originals unresolved and forbid invented collector runs.

## 12. P11 historical H02/H12 scope and like-for-like measurements

- [ ] 12.1 For `P11`, remove or replace H02 Independence and H12 Interface links that cite the Convex/Saturation review which excluded claim overlays; preserve the Interface counterexample.
- [ ] 12.2 Rebuild the `P11` measurement table with like predicates and universes; use retained R∩W figures in `formal/v3/VERIFICATION.md` (seeded 50,223 / 50,611 / 50,276 and exhaustive 32,188,276 pairs / 396,437 failures) rather than R-only 3,342 / 2,955 / 2,809 under an R∩W headline.
- [ ] 12.3 Independently review `P11` repairs; do not change historical theorem statements.

## 13. P12 full historical occurrence and claim reconciliation

- [ ] 13.1 After `P11`, execute `P12` original tasks 2.1–2.7: claim ledger CLI, downstream occurrence inventory, and CL01–CL18 dispositions on the prose allowlist with protected environments preserved.
- [ ] 13.2 Execute `P12` original tasks 3.1–3.7: DefiHistorical Convex Data/Saturation/Instances/Counterexamples and algorithm-correspondence record at exact unary-instance scope.
- [ ] 13.3 Execute `P12` original tasks 4.1–4.4 and 5.1–5.6: bound-aware m5 execution, 26 controls, lakefile DefiHistorical target outside kernel Verify, inventories, independent review, and delivery.

## 14. P13 reporting candidate and malformed/schema/package/audit-root diagnostics

- [ ] 14.1 Independently review the `P13` honest-gate closeout candidate archive `6e2a7315945080c021c84b19a25a996991d77bfa547b3e48ef1a2901a6c45f07`; verify author 210/0 is not acceptance and historical honest-gate tasks 1.1–7.4 remain completed baseline.
- [ ] 14.2 If that `P13` candidate is accepted, parent-deliver the coherent fix; if rejected, record findings and a bounded repair.
- [ ] 14.3 Add `P13` malformed-input diagnostics, standalone schema constraints, and package directory inventory checks (R43) with nonempty positive and negative controls and exit 0/1/3.
- [ ] 14.4 Add `P13` current-module-exclusion and broader audit-root fixtures (R44); verify empty theorem scope is blocked.

## 15. P14 duplicate-capability, vault-liquidity, actor/effect/supply, projection, wrong-world

- [ ] 15.1 Prove a general duplicate-capability-list theorem for `P14` (R45) over actual capability stores; verify a duplicate-id mutant is detected and a unique-id sibling stays true.
- [ ] 15.2 Add an isolated vault-liquidity regression for `P14` (R45) as a dedicated nonempty comparison, not a comment in a shared wrapper; verify a designated mutant and an unaffected sibling.
- [ ] 15.3 Extend individual actor, effect, and supply comparison mutations in the older contract wrapper for `P14` (R46); verify each compiled mutant changes its designated field and preserves unrelated fields.
- [ ] 15.4 Strengthen `P14` mutation projection guards for attributed declarations, macros, notation, and deriving, and add separated wrong-world oracles (R47); verify no runtime declaration is discarded and wrong-world oracles do not leak into the candidate world.

## 16. P15 minimum reusable platform contracts

- [ ] 16.1 Freeze `P15` kernel/operator version and typed operation boundary (dimensions, roles, effects, supply, access, exact refusal order) from delivered APIs into proposed `openspec/changes/reusable-verification-platform-program/contracts/`; invent no undeclared fields.
- [ ] 16.2 Freeze `P15` library amount/rounding/error contract with machine width and wrapped-sum versus checked-failure semantics explicit.
- [ ] 16.3 Freeze `P15` adapter input/pre-state and output/post-state relation, omitting invented ledger history for pure functions.
- [ ] 16.4 Freeze `P15` common evidence-packet schema and obligation classes (model proof, bounded source execution, representation correspondence, source refinement, authenticity/environment assumption).
- [ ] 16.5 Independently review the `P15` freeze; verify certificates are not a prerequisite to `P16`.

## 17. P16 pinned Uniswap token0, overflow-oracle repair, M09/F28 repair

- [ ] 17.1 Verify `P16` pin closure for Uniswap v3-core `e3589b192d0be27e100cd0daaf6c97204fdb1899` and compiler settings; treat the unaccepted liquidity candidate as planning input only.
- [ ] 17.2 Repair the `P16` Python diagnostic oracle so denominator-sum overflow uses the Solidity 0.7.6 wrapped-sum fallback; keep Python as a third implementation, not source execution.
- [ ] 17.3 Repair `P16` M09 so F28 is not a protected control (amountIn 2→1 under the direction flip) and name a genuinely unaffected sibling.
- [ ] 17.4 Implement the `P16` token0 next-price library under proposed `lean/DefiKernel/ConcentratedLiquidity/` using `P15` contracts and delivered Arithmetic words.
- [ ] 17.5 Execute pinned Solidity under pinned compiler/EVM harness for `P16` on predeclared nonempty partitions: ordinary, mul-overflow, sum-overflow, rounding, add/remove, zero, refusals; distinguish standalone admissibility from pool reachability.
- [ ] 17.6 Prove the scoped `P16` library property, run actual compiled mutants with unaffected controls, and independently review; leave full traversal to `P21` and source refinement to `P30`.

## 18. P17 contrasting vault source readiness and reuse gate

- [ ] 18.1 For `P17`, search retained development sources for a vault deposit/withdrawal pin with share rounding and transfer refusal; if none is adequate, record `blocked_missing_source` and do not substitute a second AMM. No reviewed vault pin exists at planning time.
- [ ] 18.2 If a `P17` pin exists, freeze observation/refusal contracts, implement proposed `lean/DefiKernel/Vault/`, and execute pinned source on ordinary success and reachable refusal.
- [ ] 18.3 Name a genuinely reused library lemma or financial contract and an executor or composition theorem for `P17`; if the operations do not financially compose, report narrower interface/library reuse rather than invent a workflow.
- [ ] 18.4 Independently review `P17`; a new global induction, cloned dispatcher, or checker exemption blocks the unchanged-interface reuse claim.

## 19. P18 bounded platform increment publication

- [ ] 19.1 Publish `P18` minimum evidence packets for accepted `P16` (and `P17` if the reuse claim is made) with identities, theorems, bounded executions, mutants, and remaining obligations.
- [ ] 19.2 Check `P18` changed modules plus affected consumers, reuse exact unchanged-dependency evidence, and parent-deliver to `semantic-kernel-pivot` with readback; do not merge to `main`.
- [ ] 19.3 Provide a versioned external-user example/API under proposed `examples/platform-increment/` for `P18`; keep source refinement outstanding and do not claim untouched generalization.

## 20. P19 Typed sequential certificates

- [ ] 20.1 Obtain independent planning acceptance of the repaired Typed/sequential subset for `P19` from the unaccepted candidate `/home/charl/defiformal-wt-certificates-grok-gpt6-20260908/openspec/changes/serialized-kernel-certificates/`; keep `STATUS.gate_accepted=false` until that review.
- [ ] 20.2 Execute `P19` candidate tasks 2.1–2.6: schema, rationals, identifiers, encode/decode, decodeBytes/checkIR, and resource-limit blocked outcomes.
- [ ] 20.3 Execute `P19` candidate tasks 3.1–4.4: recompute typing, footprints, authority, accounting, and sequential `run` via actual Lean entrypoints; reject tags, theorem names, and unsupported Tree/Claims forms.
- [ ] 20.4 Execute `P19` candidate tasks 5.3–8.6 except universal correspondence (that is `P20`): Report/reportEq, outstanding library/refinement classes, audit roots, fixtures, M01–M16 compiled mutants, projection, inventories, independent review, and delivery of the supported subset only.

## 21. P20 quantified representation correspondence and wider operators

- [ ] 21.1 Prove `P20` quantified encode/decode and checker-to-Lean correspondence (`checkIR_execute_ok` / `_error` and step forms) over the supported IR domain; treat F25/F27/F28 as bounded evidence, not the universal theorem.
- [ ] 21.2 For each `P20` wider operator (Claims, Tree, Nary, parallel, atomic, Quint if introduced), either prove a new correspondence result or keep `unsupportedForm`; never silently accept.
- [ ] 21.3 Independently review `P20`; verify codec correspondence does not close `P30` source refinement.

## 22. P21 full concentrated liquidity and tick traversal

- [ ] 22.1 After `P16` and the `P17` reuse resource gate, implement `P21` tick traversal observations beyond one-word bitmap, including declared multi-word search and pool-step remainder named in the liquidity candidate as `R-FULL-TRAVERSAL`.
- [ ] 22.2 Keep `P21` remainders `G-FULLMATH-ASSEMBLY` and `G-NO-SOLC-DIFFERENTIAL` explicit until separately discharged; do not claim `Pool.swap` lock/callback/payment unless pinned and observed.
- [ ] 22.3 Add `P21` fixtures, compiled mutants, inventories, and independent review; leave R22 unchecked until traversal is actually accepted.

## 23. P22 Curve iteration, nonconvergence, refusal

- [ ] 23.1 Locate or acquire a `P22` Curve invariant source pin from development material; if unavailable, record `blocked_missing_source` and do not invent iteration semantics.
- [ ] 23.2 If pinned, freeze `P22` success, nonconvergence, and max-iteration refusal observations; implement proposed `lean/DefiKernel/Curve/` against those observations.
- [ ] 23.3 Add `P22` nonempty fixtures, a characteristic compiled mutant, independent review, or keep the sprint blocked rather than complete-by-deferral.

## 24. P23 Liquity ordered redemption

- [ ] 24.1 Locate or acquire a `P23` ordered-redemption source pin distinct from the `P10` liquidation-source challenge; if unavailable, record `blocked_missing_source`.
- [ ] 24.2 If pinned, implement `P23` redemption order, partial fills, and empty redeemable-set refusal under proposed `lean/DefiKernel/Redemption/`.
- [ ] 24.3 Add `P23` fixtures, compiled mutants, independent review, or keep blocked; do not close R12 by this library sprint.

## 25. P24 Morpho bad-debt loss allocation

- [ ] 25.1 Locate or acquire a `P24` Morpho-style loss-allocation pin; if unavailable, record `blocked_missing_source`.
- [ ] 25.2 If pinned, implement `P24` reachable bad-debt realization and a no-bad-debt control under proposed `lean/DefiKernel/LossAllocation/`; do not market nonnegative balances as solvency.
- [ ] 25.3 Add `P24` fixtures, compiled mutants, independent review, or keep blocked.

## 26. P25 Balancer vault, hooks, and transient accounting

- [ ] 26.1 Locate or acquire a `P25` Balancer-style vault/hooks/transient pin; if unavailable, record `blocked_missing_source`. Do not silently reuse an unpinned `P17` vault.
- [ ] 26.2 If pinned, implement `P25` shared accounting, hook revert, and non-publication of transient state under proposed `lean/DefiKernel/SharedVault/`.
- [ ] 26.3 Add `P25` fixtures, compiled mutants, independent review, or keep blocked.

## 27. P26 async lifecycle, finality, replay, timeout, challenge, compensation

- [ ] 27.1 Select a concrete `P26` workflow and freeze message lifecycle, finality, replay protection, timeout, challenge, and compensation contracts with explicit oracle, custody, legal, sequencing, and finality assumptions.
- [ ] 27.2 Implement `P26` under proposed `lean/DefiKernel/Async/` without assuming synchronous rollback; verify replay-after-finality refuses and retains the original observation.
- [ ] 27.3 Add `P26` fixtures, compiled mutants, independent review, and named remaining assumptions.

## 28. P27 signed margin, funding, unsettled PnL, liquidation, bankruptcy

- [ ] 28.1 Locate or acquire a `P27` margin/funding source pin; if unavailable, record `blocked_missing_source`.
- [ ] 28.2 If pinned, implement `P27` signed margin, funding, unsettled PnL, liquidation, and bankruptcy under proposed `lean/DefiKernel/Margin/`; verify unsettled PnL is not treated as cash unless the source says so.
- [ ] 28.3 Add `P27` under-margin and insolvency fixtures, compiled mutants, independent review, or keep blocked.

## 29. P28 conditional insurance and off-chain claims

- [ ] 29.1 Locate or acquire a `P28` insurance or tokenized off-chain obligation pin; if unavailable, record `blocked_missing_source`.
- [ ] 29.2 If pinned, implement `P28` under proposed `lean/DefiKernel/ConditionalClaims/` with oracle, custody, and legal assumptions classified as assumptions, not proofs.
- [ ] 29.3 Add `P28` pay/refuse fixtures, compiled mutants, independent review, or keep blocked.

## 30. P29 complete cross-domain workflow

- [ ] 30.1 After `P26`, select one actual complete `P29` cross-domain workflow; reject a single-chain stand-in and any synchronous-rollback assumption.
- [ ] 30.2 Implement `P29` under proposed `lean/DefiKernel/CrossDomain/` including remote timeout, challenge, and compensation; verify local committed state is not silently rolled back.
- [ ] 30.3 Add `P29` end-to-end fixtures, compiled mutants, independent review, and explicit environment assumptions.

## 31. P30 reusable differential execution and selected source refinement

- [ ] 31.1 Build a reusable `P30` differential harness under proposed `scripts/differential_execution/` that runs identical sequences against pinned implementations and models for success and refusal, starting from the `P16` pin.
- [ ] 31.2 Detect `P30` characteristic mutations in rounding, fees, ordering, losses, authority, oracles, or delayed settlement with unaffected controls.
- [ ] 31.3 Prove selected concrete implementation-to-model refinements for `P30` without a premise that asserts the desired postcondition; keep compiler/runtime/authenticity assumptions explicit.
- [ ] 31.4 Independently review `P30`; this sprint remains required before `P37` full-program closure even if `P18` shipped with refinement open.

## 32. P31 Moriarty, Compact, ZKIR, and proof-carrying-transaction adapters

- [ ] 32.1 Write a `P31` Moriarty readiness record naming verified interface/source or `blocked_unavailable`; never invent Moriarty semantics (source-plan lines 1140–1142 are agenda input).
- [ ] 32.2 Write a `P31` Compact readiness record naming verified interface/source or `blocked_unavailable`; never invent Compact semantics.
- [ ] 32.3 Write a `P31` ZKIR readiness record naming verified interface/source or `blocked_unavailable`; never invent ZKIR semantics.
- [ ] 32.4 Write a `P31` proof-carrying-transaction readiness record naming verified interface/source or `blocked_unavailable`; keep cryptographic, semantic, oracle, and legal evidence classes separate.
- [ ] 32.5 Implement `P31` adapter code under proposed `lean/DefiKernel/Adapters/` only against those verified pins; if a pin is missing, leave the implementation task blocked and do not mark it complete by deferral.
- [ ] 32.6 Independently review `P31` readiness and any actual integrations; verify kernel modules do not import imagined APIs.

## 33. P32 deployment and environment pins

- [ ] 33.1 Record `P32` EVM environment readiness, including the Uniswap token0 pin when `P16` exists; do not treat that record as coverage of other environments.
- [ ] 33.2 Record `P32` Solana environment readiness with toolchain and source pin, or `blocked_unavailable` if missing.
- [ ] 33.3 Record `P32` Cosmos environment readiness with toolchain and source pin, or `blocked_unavailable` if missing.
- [ ] 33.4 Record `P32` Move/Sui environment readiness with toolchain and source pin, or `blocked_unavailable` if missing.
- [ ] 33.5 Record `P32` sovereign cross-chain environment readiness with toolchain and source pin, or `blocked_unavailable` if missing.
- [ ] 33.6 Record `P32` payment-channel environment readiness with toolchain and source pin, or `blocked_unavailable` if missing.
- [ ] 33.7 Independently review the six `P32` records; source-plan line 1116 is agenda input, not verified evidence that these toolchains exist here.

## 34. P33 kernel freeze and twelve-case replacement policy

- [ ] 34.1 After `P18`, freeze `P33` kernel, schema, and library versions used for later evaluation; bind exact hashes.
- [ ] 34.2 Write the `P33` exposure-audited replacement policy for the prior twelve REPORT labels; keep original IDs unknown, keep all existing 75 as development, and do not read held assessment payloads.
- [ ] 34.3 Independently review `P33`; verify no untouched score is computed from REPORT labels and no 75+12 disjoint denominator is advertised.

## 35. P34 independent untouched evaluation and separated metrics

- [ ] 35.1 After `P33`, run an independent evaluator workflow for `P34` on replacement-policy cases only; do not use development cases as holdouts.
- [ ] 35.2 Report `P34` schema coverage, behavioral coverage, library reuse, new kernel concepts, new library templates, external assumptions, and verification effort as separate metrics with their own denominators.
- [ ] 35.3 Use `P32` environment records in `P34` only where unblocked; blocked environments stay blocked and unscored.
- [ ] 35.4 Independently review `P34` as a non-author of the freeze.

## 36. P35 Atlas candidate and residual interaction

- [ ] 36.1 Independently review the `P35` Atlas candidate archive `56c3a1d532669f229e9c67f7e25f3253bedabd9baad5ae4942f306ef9c487db6`; verify author 238 checks are not acceptance.
- [ ] 36.2 Complete `P35` original Atlas task 7.4 keyboard traversal across all reading orders.
- [ ] 36.3 Complete `P35` original Atlas tasks 8.2–8.4: screenshot limits without interaction, README/atlas cross-reference, and open questions in `design.md`.
- [ ] 36.4 Complete `P35` CURRENT residuals: search-list, badges, zoom including 200-percent, print, find-in-page, reduced motion, and readability; park new scientific features for `P36`.

## 37. P36 stable-schema scientific Atlas and graph

- [ ] 37.1 After accepted `P35` and a stable accepted schema, update `P36` ontology visualization without periodic-table implication; keep mapping statements and missing-denominator marks.
- [ ] 37.2 Update the `P36` repository graph under proposed `graphify-out/platform-program/`; do not delete graph-orphan sources.
- [ ] 37.3 Independently review `P36`.

## 38. P37 paper, external developer package, verified delivery

- [ ] 38.1 Rewrite the paper for `P37` around demonstrated results and their limits, including remaining blocked obligations; do not check blocked adapters or environments as complete.
- [ ] 38.2 Ship a `P37` versioned external-developer package that instantiates an accepted financial library and executor interface, states a meaningful financial predicate, binds a pinned implementation, and lists proved, measured, and assumed obligations.
- [ ] 38.3 Verify `P30` selected source refinement is accepted or explicitly blocks `P37` closure; codec correspondence must not stand in for it.
- [ ] 38.4 Parent-deliver accepted `P37` artifacts to `semantic-kernel-pivot` with transport/readback; verify no merge to `main` and that whole-program definition of done lists supported-domain limits.
