# Reusable verification platform — sprint plan

Planning only. Native Grok 4.6 author; independent GPT-6 checker. No Foreman. This document does not execute sprints or lift the strategy-audit dispatch hold.

Machine-readable fields live in `sprint-index.json`. Original OpenSpec task IDs remain the contracts for existing packages; `tasks.md` enumerates future work with `Pnn` in every task line.

## Historical completed baseline

Do not redo these. Reuse exact delivered APIs.

| Baseline | Title | Status | Identity |
| --- | --- | --- | --- |
| Sprints 1–4 | Pilot, trusted operation contracts, provisional corpus reconstruction, typed execution/capabilities | completed historical | roadmap grouping before archived OpenSpec sprints |
| Sprint 5 | Typed interfaces and sequential composition | accepted, delivered, archived | `openspec/changes/archive/2026-09-06-typed-interfaces-sequential-composition/`; source/evidence `5fb0929` |
| Sprint 6 | Disjoint parallel composition | accepted, delivered, archived | source `fae07ca`; evidence `26bb17d` |
| Sprint 7 | Shared-state interleaving | accepted, delivered, archived | source `bea105ec` |
| Sprint 8 | Atomic synchronization | accepted, delivered, archived | evidence `2c038094`; archive `9501f0a4` |
| Sprint 9 | Sequential congruence and configuration preservation | accepted, delivered, archived | source `eec499d6`; evidence `ec9ed80`; archive `9908d9b5` |
| Sprint 10 | Operational interfaces and binding preservation | accepted, delivered, archived | source `b165bc58` |
| Sprint 11 / M3 | Finite-participant causal composition | accepted with limitations, delivered, archived | source `94f70e50`; evidence `3e736fb0`; archive `681362d8` |
| Checked integer arithmetic | Widths, overflow, rounding, fees | accepted, delivered, archived | source `ddf1ac0e`; archive `6d73e6dc` |

Honest-gate-failure tasks 1.1–7.4 and Atlas tasks except 7.4/8.2/8.3/8.4 are completed package baselines. Their remaining residuals are `P13`/`P14` and `P35`, not a rewrite of those original IDs.

## Hard dependencies versus recommended order

True hard edges are in the DAG below and in `sprint-index.json` `dependencies`. Recommended first wave is `P01`, `P08`, `P11`, `P13`, `P15`, and `P16` source-readiness, in any order that keeps one author and one checker. Wider families `P21`–`P29` are resource-gated by measured two-case reuse (`P17` / `P18` reuse claim), not by an arbitrary serial backlog. Certificates `P19` are not a prerequisite to `P16`. Claims `P06`/`P07` and capability `P05` are not blanket M4 dependents.

```mermaid
flowchart TD
  subgraph baseline [Completed baseline - not redone]
    S11[Sprint11_M3]
  end
  subgraph meta [Metatheory hard chain]
    P01[P01 M4 recovery] --> P02[P02 M4 remainder]
    P02 --> P03[P03 M5]
    P03 --> P04[P04 M6]
  end
  subgraph claims [Claims]
    P06[P06 partial] --> P07[P07 full]
  end
  subgraph corpus [Corpus]
    P08[P08 repair] --> P09[P09 identities]
    P08 --> P10[P10 Liquity refs]
  end
  subgraph hist [Historical]
    P11[P11 scope measurements] --> P12[P12 reconciliation]
  end
  subgraph platform [First library slice]
    P15[P15 contracts] --> P16[P16 Uniswap token0]
    P16 --> P17[P17 vault reuse]
    P16 --> P18[P18 increment]
    P16 --> P21[P21 full CL]
    P16 --> P30[P30 refinement]
  end
  subgraph certs [Certificates]
    P19[P19 Typed sequential] --> P20[P20 correspondence]
  end
  P26[P26 async] --> P29[P29 cross-domain]
  P33[P33 freeze] --> P34[P34 untouched]
  P35[P35 Atlas residual] --> P36[P36 scientific Atlas]
  P18 --> P33
  P18 --> P37[P37 paper delivery]
  P30 --> P37
  P34 --> P37
  P36 --> P37
  P05[P05 capability]
  P13[P13 reporting]
  P14[P14 residual mutations]
  P22[P22 Curve]
  P23[P23 redemption]
  P24[P24 Morpho]
  P25[P25 Balancer]
  P27[P27 margin]
  P28[P28 insurance]
  P31[P31 adapters]
  P32[P32 environments]
```

No calendar or token estimates follow from 37 units.

## Standing gates for every `Pnn`

- Exact frozen input, requested/reported model, and tool identity.
- Nonempty positive and negative inventories. Empty checks are blocked (exit 3).
- Actual compiled production mutants; timeout/setup/compile errors are blocked, not detections.
- Proof inventory: complete statements, premises, transitive axioms; no `sorry`, custom axioms, or `native_decide`.
- Changed modules plus affected consumers; exact unchanged-dependency reuse allowed.
- One independent GPT-6 review plus targeted rereview default. Author exit is not acceptance.
- Parent-owned integration/push/readback to `semantic-kernel-pivot` only. No `main` merge.
- Cleanup requires consumer/root/build/CLI evidence and must be reversible.

## P01 — M4 recovery r2 closeout

- **Dependencies:** none. Default first coherent item.
- **Legacy:** Sprint12/M4; `openspec/changes/operational-tree-regrouping/tasks.md` 4.1–4.6; archive `9b700c0f6ff4a49d008cb3e5eb6a6d9a6b10ad9366b8a63f0c2619eb205c7741`.
- **Outputs:** independent review of `lean/DefiKernel/Nary/Tree/{Compatibility,Recovery,RecoveryChecks}.lean`; evidence under proposed `review/semantic-kernel/m4-recovery/p01/`.
- **Claim boundary:** compatible isolated recovery and canonical complete-schedule equality. Not remaining fixtures/monitors.
- **Checks:** nonempty-write success and refusal; F15 opposite-order competition; F05/F06 complete schedules; no vacuous compatibility.
- **Commands:** from `lean/`: `lake env lean DefiKernel/Nary/Tree/Compatibility.lean` and Recovery/RecoveryChecks. Missing artifacts are setup failure.
- **Stop:** missing assigned theorem, circular premise, empty inventory.
- **Acceptance/delivery:** independent GPT-6 on exact bytes; parent-owned publish only if accepted.

## P02 — Remaining M4 contracts, monitors, fixtures, mutations, integration

- **Dependencies:** P01.
- **Legacy:** operational-tree-regrouping tasks 5.1–7.5.
- **Outputs:** proposed `Contracts.lean`, `MonitorRuntime.lean`, `Fixtures.lean`, `Verify.lean`; twenty fixtures; ninety complete `(2,2,2)` schedules; eighteen compiled mutants; proposed `review/semantic-kernel/m4-remainder/p02/`.
- **Claim boundary:** transported M3/M2 contracts and causal monitors. Not nested transactions.
- **Checks:** F16 dropped-cross-edge; F17 paired-debit prefixes; F18 funded provenance; designated mutant false oracles with protected positives.
- **Stop:** whole-run equality as a premise; inherited controls dropped.
- **Acceptance/delivery:** independent review then `semantic-kernel-pivot`. Whole M4 delivered only after P02.

## P03 — Official M5 active extension

- **Dependencies:** P02 (delivered M4).
- **Legacy:** Sprint13/M5; `openspec/changes/operational-active-extension/tasks.md` 1.1–5.7. Provisional r2 is not official freeze.
- **Outputs:** proposed `lean/DefiKernel/Extension/`; refreshed `api-refresh.json` bindings; proposed `review/semantic-kernel/m5-active-extension/p03/`.
- **Claim boundary:** old observations under named projection. Not Atomic extension.
- **Checks:** mixed-ID restriction; omitted-cell negatives; sixteen compiled mutants; no peer-success premise.
- **Stop:** speculative names; configuration mutation during execution.
- **Acceptance/delivery:** new same-candidate planning reviews after API refresh, then implementation review.

## P04 — M6 atomic metatheory transfer

- **Dependencies:** P02 and P03.
- **Legacy:** Sprint14/M6; `openspec/changes/atomic-metatheory-transfer/tasks.md` 1.1–5.7.
- **Outputs:** proposed `lean/DefiKernel/AtomicNary/`; proposed `review/semantic-kernel/m6-atomic-transfer/p04/`.
- **Claim boundary:** one outer Atomic boundary and first-abort policy. Not new-lane settlement.
- **Checks:** rollback, residual, first-supply, publication, boundary-reassociation counterexamples; eighteen compiled mutants.
- **Stop:** flattened execution substitute; desired commit as a premise.
- **Acceptance/delivery:** independent review; remaining obligations named.

## P05 — Capability provenance and isolation

- **Dependencies:** none. Not a blanket M4 dependent.
- **Legacy:** `openspec/changes/capability-provenance-isolation/tasks.md` 1.1–6.7; archive `7fc31431a2b5d6f0198f8a182fcd31a35b90d323c076c1c0bc000c9a3b30c52a`.
- **Outputs:** proposed `lean/DefiKernel/CapabilityProvenance/`; proposed `review/semantic-kernel/capability-provenance/p05/`.
- **Claim boundary:** initialized sequential provenance and supported frames. Not general confidentiality.
- **Checks:** resolve CF1 revoked-ID and CF2 22-versus-23; F01–F20; fourteen query mutants; 65 inherited controls.
- **Stop:** final-state legitimacy premise; unresolved CF1/CF2.
- **Acceptance/delivery:** independent review of initialized proofs then whole package.

## P06 — Claims generic partial recovery

- **Dependencies:** none.
- **Legacy:** claims-liability-lifecycle tasks 4.2, 4.3, 4.7; cancelled archive `6fdca9817bc2a4bba52b5a58c6c605a16aacb7fb9c0b46100ff8b3bf26239ee3`.
- **Outputs:** inspection record of `PaymentSoundness`/`Conservative`/`Preservation`; one chosen bounded obligation or explicit residual; proposed `review/semantic-kernel/claims-partial/p06/`.
- **Claim boundary:** only the chosen recovered obligation.
- **Checks:** cancellation is not completion; preserve partial bytes.
- **Stop:** indiscriminate restart; rewriting World/Right.
- **Acceptance/delivery:** independent review of the chosen obligation.

## P07 — Claims full lifecycle

- **Dependencies:** P06.
- **Legacy:** claims-liability-lifecycle tasks 2.1–5.8.
- **Outputs:** proposed `lean/DefiKernel/Claims/`; `scripts/claims_gate.py`; `mutations/claims.json`; proposed `review/semantic-kernel/claims-lifecycle/p07/`.
- **Claim boundary:** fixed-principal lifecycle with repayment and non-erasure. Not indexed payoffs or legal fidelity.
- **Checks:** F01–F24 including overpayment refusal, paymentMismatch, paid-versus-forgiven; twenty compiled mutants.
- **Stop:** treating debt-erasure regression as repayment.
- **Acceptance/delivery:** independent review; parent-owned delivery.

## P08 — Corpus capture/classification/span repair

- **Dependencies:** none. Independent of M4.
- **Legacy:** corpus-provenance-adjudication task 2.3; Audit04 findings.
- **Outputs:** repaired overlay records for EigenCloud challenge classification and CoW derived-span binding; proposed `review/semantic-kernel/corpus-repair/p08/`.
- **Claim boundary:** repair of confirmed misleading bindings. Not all 169 work items.
- **Checks:** challenge/404 have zero semantic support; span → derived artifact → extraction → original successful response.
- **Stop:** using defective records for library fidelity.
- **Acceptance/delivery:** independent review of the two repairs.

## P09 — 169 work, 75 identities, 29 disputes

- **Dependencies:** P08.
- **Legacy:** corpus tasks 3.1–3.2, 5.1–5.3, 5.5, 6.1–6.3.
- **Outputs:** identity ledger, 29-disagreement overlay, development/evaluation manifests; proposed `corpus/adjudicated/v1/generated/`.
- **Claim boundary:** development overlay. All 75 remain development.
- **Checks:** silence is not refutation; promotion controls fail.
- **Stop:** counting `review_pending` as complete.
- **Acceptance/delivery:** independent review; unresolved facts stay unresolved.

## P10 — Liquity challenge, dependencies, ambiguity, references

- **Dependencies:** P08.
- **Legacy:** corpus tasks 2.1–2.2, 3.3, 4.1–4.3, 5.4.
- **Outputs:** liquidation-challenge decision; `inputs/dependencies.json`; residue records; original-reference recovery or replacement.
- **Claim boundary:** source adjudication. Not P23 redemption library.
- **Checks:** separate liquidation versus redemption; reconstructed replacement does not claim recovered original.
- **Stop:** invented collector runs.
- **Acceptance/delivery:** independent review.

## P11 — H02/H12 scope and like-for-like measurements

- **Dependencies:** none.
- **Legacy:** historical-claim-reconciliation; archive `26ade3b9544924e782264e9fbcf37c93c88fb078cacbd7ab1098478e3ed4c0a6`.
- **Outputs:** repaired authority links; like-for-like table using `formal/v3/VERIFICATION.md` R∩W figures 50,223 / 50,611 / 50,276 and exhaustive 32,188,276 pairs / 396,437 failures where that universe applies.
- **Claim boundary:** scoped repair. Interface counterexample preserved.
- **Checks:** Convex review does not accept Independence/Interface; R-only 3,342 / 2,955 / 2,809 not advertised as R∩W.
- **Stop:** changing historical theorem statements.
- **Acceptance/delivery:** independent review.

## P12 — Full occurrence and claim reconciliation

- **Dependencies:** P11.
- **Legacy:** historical-claim-reconciliation tasks 2.1–5.6.
- **Outputs:** proposed `lean/DefiHistorical/Convex/`; `scripts/historical_claims.py`; claim/scenario map for 18 CLs.
- **Claim boundary:** selected historical claims and two unary instances. Not P37 paper rewrite.
- **Checks:** 26 controls; bound-aware JS execution; empty checks blocked.
- **Stop:** editing protected measurement environments.
- **Acceptance/delivery:** independent review; DefiHistorical stays out of kernel Verify closure.

## P13 — Reporting candidate and diagnostics

- **Dependencies:** none.
- **Legacy:** honest-gate-failure 1.1–7.4 remain completed; new candidate archive `6e2a7315945080c021c84b19a25a996991d77bfa547b3e48ef1a2901a6c45f07`; R43/R44.
- **Outputs:** accepted or rejected 210/0 candidate; malformed-input diagnostics; standalone schema constraints; package inventory; current-module-exclusion; audit-root fixtures.
- **Claim boundary:** honest reporting. Not a silent widening of totalgate predicates except as tasked.
- **Checks:** exit 0/1/3 discrimination; empty denominator blocked; positive and negative reporting polarities.
- **Stop:** author 210/0 as acceptance; merging blocked and false.
- **Acceptance/delivery:** independent review of the exact candidate.

## P14 — Duplicate-capability, vault-liquidity, actor/effect/supply, projection, wrong-world

- **Dependencies:** none.
- **Legacy:** R21, R45, R46, R47.
- **Outputs:** proposed duplicate-capability-list theorem; isolated vault-liquidity regression; older-wrapper actor/effect/supply mutants; attributed/macro/notation/deriving projection guards; separated wrong-world oracles; proposed `review/semantic-kernel/residual-mutations/p14/`.
- **Claim boundary:** named residuals. Sprint 7 sources stay accepted until these discharge recorded limits.
- **Checks:** isolated regression is a dedicated nonempty comparison; designated mutant detected; unaffected sibling true.
- **Stop:** comment in a shared wrapper in place of the isolated regression.
- **Acceptance/delivery:** independent review.

## P15 — Minimum reusable contracts

- **Dependencies:** none. Not blocked on full M4 or certificates.
- **Outputs:** proposed `openspec/changes/reusable-verification-platform-program/contracts/` later realized in `lean/DefiKernel/Platform/` if implementation is authorized: kernel/operator boundary, amount/rounding/error, adapter I/O, evidence packet, obligation classes.
- **Claim boundary:** shared contracts only.
- **Checks:** pure function omits invented ledger history; machine-width and fallback explicit.
- **Stop:** invented undeclared operator fields.
- **Acceptance/delivery:** independent review of the contract freeze.

## P16 — Pinned Uniswap token0, overflow-oracle repair, M09/F28 repair

- **Dependencies:** P15 for implementation; source-readiness may start earlier.
- **Legacy:** unaccepted `concentrated-liquidity-library`; pin v3-core `e3589b192d0be27e100cd0daaf6c97204fdb1899`; archive `e1cd08f9f8a843355f1b249a013c9de0d29e7e1ebf1d5a3e8716d6d7621baf77`.
- **Outputs:** proposed `lean/DefiKernel/ConcentratedLiquidity/` token0 slice; pinned solc/EVM run; repaired oracle and mutant plan; proposed `review/semantic-kernel/uniswap-token0/p16/`.
- **Claim boundary:** standalone next-price arithmetic and bounded source comparison. Not full traversal (P21). Not source refinement (P30). Python oracle is diagnostic only.
- **Checks:** ordinary, mul-overflow, sum-overflow, rounding, add/remove, zero, refusals; repaired F28 control; actual compiled mutant; exact returned values.
- **Stop:** unexplained source/model difference; Python-only mutation credit.
- **Acceptance/delivery:** independent review; refinement remains open.

## P17 — Vault source readiness and reuse gate

- **Dependencies:** P16 for the reuse experiment. Source-readiness inspection may start earlier.
- **Outputs:** actual vault pin record or `blocked_missing_source`; if pinned, proposed `lean/DefiKernel/Vault/`; named reused lemma/contract and executor/composition theorem; proposed `review/semantic-kernel/vault-reuse/p17/`.
- **Claim boundary:** two-case reuse or recorded source block. No second AMM substitute. No reviewed vault pin exists at planning time.
- **Checks:** ordinary conversion; reachable transfer/rounding refusal; shared evidence schema with P16.
- **Stop:** invented pin; fake workflow composition.
- **Acceptance/delivery:** independent review; reuse claim withheld if blocked.

## P18 — Bounded platform increment publication

- **Dependencies:** P16. Reuse claim additionally requires P17.
- **Outputs:** evidence packets; proposed `examples/platform-increment/`; proposed `review/semantic-kernel/platform-increment/p18/`; parent-owned `semantic-kernel-pivot` publish.
- **Claim boundary:** model-proved increment with bounded source evidence and refinement open. Not whole-program completion.
- **Checks:** changed modules plus affected consumers; transport/readback.
- **Stop:** codec cited as refinement; merge to main.
- **Acceptance/delivery:** independent review; no recursive administrative reviews.

## P19 — Typed sequential certificates

- **Dependencies:** none. Not a prerequisite to P16.
- **Legacy:** unaccepted `serialized-kernel-certificates`; archive `122118df438c8c05a09f48e5097fb6f6bfd3c19cedece4dee20aa32757c4bc13`.
- **Outputs:** proposed `lean/DefiKernel/Certificates/`; `scripts/run_certificate_mutations.py`; proposed `review/semantic-kernel/certificates/p19/`.
- **Claim boundary:** recomputing Typed/sequential checker. Not source refinement. Unsupported forms stay `unsupportedForm`.
- **Checks:** F01–F54 as in the candidate plan once that plan is independently accepted; claimed tags do not skip `Args.check`; M01–M16 compiled mutants.
- **Stop:** implementing Tree/Claims as complete; accepting envelope hashes as proof.
- **Acceptance/delivery:** planning gate first, then implementation review.

## P20 — Quantified representation correspondence and wider operators

- **Dependencies:** P19.
- **Outputs:** proposed `Correspondence.lean`; per-extension correspondence or `unsupportedForm`; Quint correspondence if Quint is introduced.
- **Claim boundary:** representation correspondence. Codec does not close P30.
- **Checks:** universal theorem for the supported domain; finite fixtures remain bounded evidence.
- **Stop:** fixtures treated as universal.
- **Acceptance/delivery:** independent review.

## P21 — Full concentrated liquidity and tick traversal

- **Dependencies:** P16. Resource gate: P17 reuse.
- **Outputs:** traversal modules under proposed `lean/DefiKernel/ConcentratedLiquidity/`; remainders `R-FULL-TRAVERSAL`, `G-FULLMATH-ASSEMBLY`, `G-NO-SOLC-DIFFERENTIAL` named until discharged.
- **Claim boundary:** declared traversal. Not deployed pool security.
- **Checks:** multi-word traversal fixtures; lock/callback remain named gaps unless pinned.
- **Stop:** one-word bitmap claimed as `Pool.swap`.
- **Acceptance/delivery:** independent review; R22 stays open until traversal is actually accepted.

## P22 — Curve iteration, nonconvergence, refusal

- **Dependencies:** none hard. Resource gate: P17.
- **Outputs:** pin record or `blocked_missing_source`; proposed `lean/DefiKernel/Curve/`; proposed `review/semantic-kernel/curve/p22/`.
- **Claim boundary:** iterative invariant within the pin. Pin is not established at planning time.
- **Checks:** success; nonconvergence; max-iteration refusal; characteristic mutant.
- **Stop:** omitting nonconvergence; inventing a pin.
- **Acceptance/delivery:** independent review or recorded block.

## P23 — Liquity ordered redemption

- **Dependencies:** none hard. Resource gate: P17. Separate from P10.
- **Outputs:** pin record or block; proposed `lean/DefiKernel/Redemption/`.
- **Claim boundary:** ordered redemption library, not the liquidation-source overlay.
- **Checks:** order, partial fill, empty redeemable-set refusal.
- **Stop:** using P10 as a library pin.
- **Acceptance/delivery:** independent review or recorded block.

## P24 — Morpho bad-debt loss allocation

- **Dependencies:** none hard. Resource gate: P17.
- **Outputs:** pin record or block; proposed `lean/DefiKernel/LossAllocation/`.
- **Claim boundary:** declared allocation rule, not generic solvency.
- **Checks:** reachable loss; no-bad-debt control; unaffected sibling market.
- **Stop:** marketing nonnegative balances as solvency.
- **Acceptance/delivery:** independent review or recorded block.

## P25 — Balancer vault, hooks, transient accounting

- **Dependencies:** none hard. Resource gate: P17.
- **Outputs:** pin record or block; proposed `lean/DefiKernel/SharedVault/`.
- **Claim boundary:** pinned vault/hooks/transient. Not a silent P17 substitute unless the pin identity is the same.
- **Checks:** hook revert does not publish transient state; shared accounting fixtures.
- **Stop:** publishing transient state on revert.
- **Acceptance/delivery:** independent review or recorded block.

## P26 — Async lifecycle

- **Dependencies:** none hard. Resource gate: P17.
- **Outputs:** proposed `lean/DefiKernel/Async/`; explicit oracle/custody/legal/sequencing/finality assumptions.
- **Claim boundary:** declared async workflow. Not P29 cross-domain completeness.
- **Checks:** finality, replay refusal, timeout, challenge, compensation.
- **Stop:** assuming synchronous rollback.
- **Acceptance/delivery:** independent review.

## P27 — Signed margin, funding, unsettled PnL, liquidation, bankruptcy

- **Dependencies:** none hard. Resource gate: P17.
- **Outputs:** pin record or block; proposed `lean/DefiKernel/Margin/`.
- **Claim boundary:** pinned derivatives accounting. Unsettled PnL is not cash unless the source says so.
- **Checks:** under-margin refusal; bankruptcy path; funding observation.
- **Stop:** inventing bankruptcy rules.
- **Acceptance/delivery:** independent review or recorded block.

## P28 — Conditional insurance and off-chain claims

- **Dependencies:** none hard. Resource gate: P17.
- **Outputs:** pin record or block; proposed `lean/DefiKernel/ConditionalClaims/`.
- **Claim boundary:** external conditional claims. Oracle truth remains an assumption where unproved.
- **Checks:** pay/refuse under attestation; explicit assumption class.
- **Stop:** treating oracle attestation as proved fact.
- **Acceptance/delivery:** independent review or recorded block.

## P29 — Complete cross-domain workflow

- **Dependencies:** P26. Resource gate: P17.
- **Outputs:** proposed `lean/DefiKernel/CrossDomain/`; one actual end-to-end workflow.
- **Claim boundary:** one supported workflow. No synchronous-rollback assumption. Not universal bridging.
- **Checks:** remote timeout triggers compensation or challenge; local committed state is not silently rolled back.
- **Stop:** single-chain stand-in counted as complete.
- **Acceptance/delivery:** independent review.

## P30 — Differential execution and selected source refinement

- **Dependencies:** P16. Required before P37 program closure.
- **Outputs:** proposed `scripts/differential_execution/`; selected refinement proofs; proposed `review/semantic-kernel/source-refinement/p30/`.
- **Claim boundary:** selected refinements over declared admissible states. Codec correspondence is not this obligation.
- **Checks:** identical sequences on implementation and model; refusals; characteristic mutants; refinement proof without desired-postcondition premises.
- **Stop:** citing P19/P20 as refinement discharge.
- **Acceptance/delivery:** independent review. Program remains open until this sprint accepts or is explicitly blocked.

## P31 — Moriarty, Compact, ZKIR, PCT adapters

- **Dependencies:** P15.
- **Outputs:** readiness records under proposed `review/semantic-kernel/adapters/readiness/p31/` for each of Moriarty, Compact, ZKIR, and proof-carrying transactions; implementation under proposed `lean/DefiKernel/Adapters/` only against verified pins; otherwise `blocked_unavailable`.
- **Claim boundary:** adapter boundary. Never invent semantics. Source-plan lines 1140–1142 are agenda input.
- **Checks:** named readiness task and named implementation task per system; blocked is not checked complete.
- **Stop:** kernel imports of imagined APIs; completion by deferral.
- **Acceptance/delivery:** independent review of readiness plus any actual integrations.

## P32 — Environment pins: EVM, Solana, Cosmos, Move/Sui, sovereign cross-chain, payment channels

- **Dependencies:** none. Evaluation of holdouts waits on P33; pins may start earlier.
- **Outputs:** per-environment readiness and pin or `blocked_unavailable` under proposed `review/semantic-kernel/environments/p32/`.
- **Claim boundary:** environment readiness. EVM token0 does not score other environments. Source-plan line 1116 is agenda input, not proof those toolchains exist here.
- **Checks:** six named environments each have a record; missing toolchain is blocked.
- **Stop:** inheriting EVM scores.
- **Acceptance/delivery:** independent review of the six records.

## P33 — Kernel/schema/library freeze and twelve-case replacement policy

- **Dependencies:** P18.
- **Outputs:** freeze manifest; replacement policy; development 75 remain development; proposed `review/semantic-kernel/evaluation/freeze/p33/`.
- **Claim boundary:** freeze and selection policy. Do not read held payloads. Prior twelve REPORT labels are exposure records with original IDs unknown.
- **Checks:** promotion controls fail; no 75+12 disjoint denominator.
- **Stop:** opening holdout payloads.
- **Acceptance/delivery:** independent review of freeze bytes.

## P34 — Independent untouched evaluation and separated metrics

- **Dependencies:** P33.
- **Outputs:** evaluator workflow; separated metrics (schema, behavioral, library reuse, new kernel concepts, new library templates, external assumptions, proof/checking effort); proposed `review/semantic-kernel/evaluation/untouched/p34/`.
- **Claim boundary:** untouched evaluation within freeze. Blocked environments are not scored.
- **Checks:** independent case selection; each metric has its own denominator.
- **Stop:** using development cases as holdouts.
- **Acceptance/delivery:** independent evaluator, not the author of the freeze.

## P35 — Atlas candidate and residual interaction

- **Dependencies:** none.
- **Legacy:** design-atlas-visualization tasks 7.4, 8.2, 8.3, 8.4; archive `56c3a1d532669f229e9c67f7e25f3253bedabd9baad5ae4942f306ef9c487db6`; CURRENT residuals search-list/badges/zoom/print/find.
- **Outputs:** independent verdict on the 238-check candidate; keyboard traversal; 200-percent zoom; reduced motion; readability; print/find.
- **Claim boundary:** existing Atlas residuals. Scientific refresh is P36.
- **Checks:** keyboard across reading orders; screenshot limits without interaction.
- **Stop:** author 238 checks as acceptance.
- **Acceptance/delivery:** independent review.

## P36 — Scientific Atlas and graph after stable schema

- **Dependencies:** P35.
- **Outputs:** schema-aligned Atlas; repository graph update; mapping statements; missing-denominator marks; proposed `graphify-out/platform-program/`.
- **Claim boundary:** visualization of accepted schema. Not periodic-law implication. Not graph-orphan deletion.
- **Checks:** mapping statement on every layout; no "periodic table" chrome.
- **Stop:** implying predictive closure.
- **Acceptance/delivery:** independent review.

## P37 — Paper, external developer package, verified delivery

- **Dependencies:** P18, P30, P34, P36. Other workstreams must be accepted or named blocked.
- **Outputs:** paper rewrite; proposed `dist/platform-developer/` or `examples/` package that instantiates an accepted library; verified `semantic-kernel-pivot` delivery; remainder list.
- **Claim boundary:** publication of accepted and blocked work as they stand. Not universal DeFi coverage. No `main` merge.
- **Checks:** developer package binds a pin and shows proved/measured/assumed obligations; blocked adapters/environments listed; P30 not silently skipped.
- **Stop:** counting blocked obligations completed; merge to main.
- **Acceptance/delivery:** independent review; parent-owned push/readback.

## Cleanup policy

Applied only with exact consumer/root/build/CLI evidence. Preserve historical proofs, negative results, partials, unique unintegrated candidates, and dirty worktrees. Graph isolation is not deletion evidence. Originals remain recoverable. This is not a separate sprint; it is a standing constraint on every sprint that touches files.
