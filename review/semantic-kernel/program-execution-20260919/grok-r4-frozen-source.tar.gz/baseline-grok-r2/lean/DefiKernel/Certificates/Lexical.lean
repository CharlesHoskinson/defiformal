import DefiKernel.Certificates.Roundtrip
import DefiKernel.Certificates.CompositionDepth
import Mathlib.Tactic.IntervalCases

namespace DefiKernel.Certificates

set_option linter.style.longLine false
set_option linter.style.setOption false
set_option linter.style.maxHeartbeats false
set_option maxHeartbeats 4000000

open Lean

/-! Continuation lemmas for `scanLexicalFuel` on canonical `TreeJson.encode` fragments.
    Strings consume one outer scanner step; numbers remain buffered until a delimiter. -/

/-- False precisely when the scanner is waiting for an object key. Matches the R28
    `scanLexicalFuel_step_str_val` hypothesis. -/
def notExpectKey (scopes : List LexScope) : Prop :=
  match scopes with
  | LexScope.inObj _ true :: _ => false
  | _ => true

theorem notExpectKey_nil : notExpectKey [] := rfl

theorem notExpectKey_arr (cnt : Nat) (rest : List LexScope) :
    notExpectKey (LexScope.inArr cnt :: rest) := rfl

theorem notExpectKey_obj_val (keys : List String) (rest : List LexScope) :
    notExpectKey (LexScope.inObj keys false :: rest) := rfl

mutual
  /-- Outer scanner steps consumed by a canonical encoding (strings cost 1). -/
  def scanCost : TreeJson → Nat
    | .null => 4
    | .bool true => 4
    | .bool false => 5
    | .num n => (toString n).length
    | .str _ => 1
    | .arr xs => 2 + scanCostList xs
    | .obj kvs => 2 + scanCostObj kvs

  def scanCostList : List TreeJson → Nat
    | [] => 0
    | [x] => scanCost x
    | x :: xs => scanCost x + 1 + scanCostList xs

  def scanCostObj : List (String × TreeJson) → Nat
    | [] => 0
    | [(_, v)] => 2 + scanCost v
    | (_, v) :: kvs => 3 + scanCost v + scanCostObj kvs
end

def numBuf : TreeJson → List Char
  | .num n => (toString n).toList
  | _ => []

theorem encode_null_toList (rest : List Char) :
    (TreeJson.encode .null).toList ++ rest = 'n' :: 'u' :: 'l' :: 'l' :: rest := rfl

theorem encode_bool_true_toList (rest : List Char) :
    (TreeJson.encode (.bool true)).toList ++ rest = 't' :: 'r' :: 'u' :: 'e' :: rest := rfl

theorem encode_bool_false_toList (rest : List Char) :
    (TreeJson.encode (.bool false)).toList ++ rest =
      'f' :: 'a' :: 'l' :: 's' :: 'e' :: rest := rfl

theorem encodeList_nil_toList (rest : List Char) :
    (TreeJson.encodeList []).toList ++ rest = rest := rfl

theorem encodeList_singleton_toList (x : TreeJson) (rest : List Char) :
    (TreeJson.encodeList [x]).toList ++ rest = (TreeJson.encode x).toList ++ rest := by
  dsimp [TreeJson.encodeList]

/-- Consume a non-structural, non-numeric, non-whitespace character with an empty numeric buffer. -/
theorem scanLexicalFuel_other (fuel : Nat) (c : Char) (rest : List Char) (depth : Nat)
    (scopes : List LexScope)
    (h_quote : (c == '"') = false) (h_lbrace : (c == '{') = false)
    (h_rbrace : (c == '}') = false) (h_lbracket : (c == '[') = false)
    (h_rbracket : (c == ']') = false) (h_comma : (c == ',') = false)
    (h_colon : (c == ':') = false)
    (h_num : (((decide (c ≥ '0') && decide (c ≤ '9')) || (c == '-')) || (c == '.')) = false)
    (h_space : isSpace c = false) :
    scanLexicalFuel (fuel + 1) (c :: rest) depth scopes [] false =
      scanLexicalFuel fuel rest depth scopes [] false := by
  dsimp [scanLexicalFuel, scanLexicalCheckNum]
  rw [h_quote, h_lbrace, h_rbrace, h_lbracket, h_rbracket, h_comma, h_colon]
  simp only [Bool.false_eq_true, ↓reduceIte, Bool.true_and]
  rw [h_num]
  simp only [Bool.false_eq_true, ↓reduceIte]
  rw [h_space]
  simp only [Bool.false_eq_true, ↓reduceIte]

theorem scanLexicalFuel_n (fuel : Nat) (rest : List Char) (depth : Nat) (scopes : List LexScope) :
    scanLexicalFuel (fuel + 1) ('n' :: rest) depth scopes [] false =
      scanLexicalFuel fuel rest depth scopes [] false :=
  scanLexicalFuel_other fuel 'n' rest depth scopes rfl rfl rfl rfl rfl rfl rfl rfl rfl

theorem scanLexicalFuel_u (fuel : Nat) (rest : List Char) (depth : Nat) (scopes : List LexScope) :
    scanLexicalFuel (fuel + 1) ('u' :: rest) depth scopes [] false =
      scanLexicalFuel fuel rest depth scopes [] false :=
  scanLexicalFuel_other fuel 'u' rest depth scopes rfl rfl rfl rfl rfl rfl rfl rfl rfl

theorem scanLexicalFuel_l (fuel : Nat) (rest : List Char) (depth : Nat) (scopes : List LexScope) :
    scanLexicalFuel (fuel + 1) ('l' :: rest) depth scopes [] false =
      scanLexicalFuel fuel rest depth scopes [] false :=
  scanLexicalFuel_other fuel 'l' rest depth scopes rfl rfl rfl rfl rfl rfl rfl rfl rfl

theorem scanLexicalFuel_t (fuel : Nat) (rest : List Char) (depth : Nat) (scopes : List LexScope) :
    scanLexicalFuel (fuel + 1) ('t' :: rest) depth scopes [] false =
      scanLexicalFuel fuel rest depth scopes [] false :=
  scanLexicalFuel_other fuel 't' rest depth scopes rfl rfl rfl rfl rfl rfl rfl rfl rfl

theorem scanLexicalFuel_r (fuel : Nat) (rest : List Char) (depth : Nat) (scopes : List LexScope) :
    scanLexicalFuel (fuel + 1) ('r' :: rest) depth scopes [] false =
      scanLexicalFuel fuel rest depth scopes [] false :=
  scanLexicalFuel_other fuel 'r' rest depth scopes rfl rfl rfl rfl rfl rfl rfl rfl rfl

theorem scanLexicalFuel_e (fuel : Nat) (rest : List Char) (depth : Nat) (scopes : List LexScope) :
    scanLexicalFuel (fuel + 1) ('e' :: rest) depth scopes [] false =
      scanLexicalFuel fuel rest depth scopes [] false :=
  scanLexicalFuel_other fuel 'e' rest depth scopes rfl rfl rfl rfl rfl rfl rfl rfl rfl

theorem scanLexicalFuel_f (fuel : Nat) (rest : List Char) (depth : Nat) (scopes : List LexScope) :
    scanLexicalFuel (fuel + 1) ('f' :: rest) depth scopes [] false =
      scanLexicalFuel fuel rest depth scopes [] false :=
  scanLexicalFuel_other fuel 'f' rest depth scopes rfl rfl rfl rfl rfl rfl rfl rfl rfl

theorem scanLexicalFuel_a (fuel : Nat) (rest : List Char) (depth : Nat) (scopes : List LexScope) :
    scanLexicalFuel (fuel + 1) ('a' :: rest) depth scopes [] false =
      scanLexicalFuel fuel rest depth scopes [] false :=
  scanLexicalFuel_other fuel 'a' rest depth scopes rfl rfl rfl rfl rfl rfl rfl rfl rfl

theorem scanLexicalFuel_s (fuel : Nat) (rest : List Char) (depth : Nat) (scopes : List LexScope) :
    scanLexicalFuel (fuel + 1) ('s' :: rest) depth scopes [] false =
      scanLexicalFuel fuel rest depth scopes [] false :=
  scanLexicalFuel_other fuel 's' rest depth scopes rfl rfl rfl rfl rfl rfl rfl rfl rfl

theorem scanLexicalFuel_null (fuel : Nat) (rest : List Char) (depth : Nat) (scopes : List LexScope) :
    scanLexicalFuel (fuel + 4) ('n' :: 'u' :: 'l' :: 'l' :: rest) depth scopes [] false =
      scanLexicalFuel fuel rest depth scopes [] false := by
  have h₁ := scanLexicalFuel_n (fuel + 3) ('u' :: 'l' :: 'l' :: rest) depth scopes
  have h₂ := scanLexicalFuel_u (fuel + 2) ('l' :: 'l' :: rest) depth scopes
  have h₃ := scanLexicalFuel_l (fuel + 1) ('l' :: rest) depth scopes
  have h₄ := scanLexicalFuel_l fuel rest depth scopes
  simp only [Nat.add_assoc] at h₁
  rw [h₁, h₂, h₃, h₄]

theorem scanLexicalFuel_true (fuel : Nat) (rest : List Char) (depth : Nat) (scopes : List LexScope) :
    scanLexicalFuel (fuel + 4) ('t' :: 'r' :: 'u' :: 'e' :: rest) depth scopes [] false =
      scanLexicalFuel fuel rest depth scopes [] false := by
  have h₁ := scanLexicalFuel_t (fuel + 3) ('r' :: 'u' :: 'e' :: rest) depth scopes
  have h₂ := scanLexicalFuel_r (fuel + 2) ('u' :: 'e' :: rest) depth scopes
  have h₃ := scanLexicalFuel_u (fuel + 1) ('e' :: rest) depth scopes
  have h₄ := scanLexicalFuel_e fuel rest depth scopes
  simp only [Nat.add_assoc] at h₁
  rw [h₁, h₂, h₃, h₄]

theorem scanLexicalFuel_false (fuel : Nat) (rest : List Char) (depth : Nat) (scopes : List LexScope) :
    scanLexicalFuel (fuel + 5) ('f' :: 'a' :: 'l' :: 's' :: 'e' :: rest) depth scopes [] false =
      scanLexicalFuel fuel rest depth scopes [] false := by
  have h₁ := scanLexicalFuel_f (fuel + 4) ('a' :: 'l' :: 's' :: 'e' :: rest) depth scopes
  have h₂ := scanLexicalFuel_a (fuel + 3) ('l' :: 's' :: 'e' :: rest) depth scopes
  have h₃ := scanLexicalFuel_l (fuel + 2) ('s' :: 'e' :: rest) depth scopes
  have h₄ := scanLexicalFuel_s (fuel + 1) ('e' :: rest) depth scopes
  have h₅ := scanLexicalFuel_e fuel rest depth scopes
  simp only [Nat.add_assoc] at h₁
  rw [h₁, h₂, h₃, h₄, h₅]

theorem scanLexicalFuel_encode_null (fuel : Nat) (rest : List Char) (depth : Nat)
    (scopes : List LexScope) :
    scanLexicalFuel (fuel + scanCost .null) ((TreeJson.encode .null).toList ++ rest) depth scopes [] false =
      scanLexicalFuel fuel rest depth scopes [] false := by
  dsimp [scanCost]
  rw [encode_null_toList]
  exact scanLexicalFuel_null fuel rest depth scopes

theorem scanLexicalFuel_encode_bool (fuel : Nat) (b : Bool) (rest : List Char) (depth : Nat)
    (scopes : List LexScope) :
    scanLexicalFuel (fuel + scanCost (.bool b))
        ((TreeJson.encode (.bool b)).toList ++ rest) depth scopes [] false =
      scanLexicalFuel fuel rest depth scopes [] false := by
  cases b with
  | true =>
    dsimp [scanCost]
    rw [encode_bool_true_toList]
    exact scanLexicalFuel_true fuel rest depth scopes
  | false =>
    dsimp [scanCost]
    rw [encode_bool_false_toList]
    exact scanLexicalFuel_false fuel rest depth scopes

theorem scanLexicalFuel_str_value (fuel : Nat) (s : String) (rest : List Char) (depth : Nat)
    (scopes : List LexScope) (h_not_key : notExpectKey scopes) :
    scanLexicalFuel (fuel + 1) ((escapeTreeString s).toList ++ rest) depth scopes [] false =
      scanLexicalFuel fuel rest depth scopes [] false := by
  rw [escapeTreeString_eq]
  have h_app : ('"' :: (escapeChars s.toList ++ ['"'])) ++ rest =
      '"' :: (escapeChars s.toList ++ ('"' :: rest)) := by
    simp [List.append_assoc]
  rw [h_app]
  have h_lex := lexString_escapeJsonString s rest
  exact scanLexicalFuel_step_str_val fuel s (escapeChars s.toList ++ ('"' :: rest)) rest depth scopes
    h_not_key h_lex

theorem scanLexicalFuel_str_key (fuel : Nat) (s : String) (rest : List Char) (depth : Nat)
    (keys : List String) (restScopes : List LexScope)
    (h_nodup : keys.contains s = false) :
    scanLexicalFuel (fuel + 1) ((escapeTreeString s).toList ++ rest)
        depth (LexScope.inObj keys true :: restScopes) [] false =
      scanLexicalFuel fuel rest depth (LexScope.inObj (s :: keys) false :: restScopes) [] false := by
  rw [escapeTreeString_eq]
  have h_app : ('"' :: (escapeChars s.toList ++ ['"'])) ++ rest =
      '"' :: (escapeChars s.toList ++ ('"' :: rest)) := by
    simp [List.append_assoc]
  rw [h_app]
  have h_lex := lexString_escapeJsonString s rest
  exact scanLexicalFuel_step_key fuel s (escapeChars s.toList ++ ('"' :: rest)) rest depth keys restScopes
    h_lex h_nodup

theorem scanLexicalFuel_encode_str (fuel : Nat) (s : String) (rest : List Char) (depth : Nat)
    (scopes : List LexScope) (h_not_key : notExpectKey scopes) :
    scanLexicalFuel (fuel + scanCost (.str s))
        ((TreeJson.encode (.str s)).toList ++ rest) depth scopes [] false =
      scanLexicalFuel fuel rest depth scopes [] false := by
  dsimp [scanCost, TreeJson.encode]
  exact scanLexicalFuel_str_value fuel s rest depth scopes h_not_key

/-- Start a numeric buffer from an empty buffer on a digit or minus. -/
theorem scanLexicalFuel_num_start (fuel : Nat) (c : Char) (rest : List Char) (depth : Nat)
    (scopes : List LexScope)
    (h_start : ((decide (c ≥ '0') && decide (c ≤ '9')) || (c == '-') || (c == '.')) = true)
    (h_quote : (c == '"') = false) (h_lbrace : (c == '{') = false)
    (h_rbrace : (c == '}') = false) (h_lbracket : (c == '[') = false)
    (h_rbracket : (c == ']') = false) (h_comma : (c == ',') = false)
    (h_colon : (c == ':') = false) :
    scanLexicalFuel (fuel + 1) (c :: rest) depth scopes [] false =
      scanLexicalFuel fuel rest depth scopes [c] false := by
  dsimp [scanLexicalFuel]
  rw [h_quote, h_lbrace, h_rbrace, h_lbracket, h_rbracket, h_comma, h_colon]
  simp only [Bool.false_eq_true, ↓reduceIte, Bool.true_and]
  rw [h_start]
  simp only [eq_self, ↓reduceIte]

/-- Continue a nonempty numeric buffer on a digit, sign, dot, or exponent character. -/
theorem scanLexicalFuel_num_cont (fuel : Nat) (c : Char) (buf : List Char) (rest : List Char)
    (depth : Nat) (scopes : List LexScope) (h_buf : buf ≠ [])
    (h_cont : ((decide (c ≥ '0') && decide (c ≤ '9')) || (c == '-') || (c == '+') ||
      (c == '.') || (c == 'e') || (c == 'E')) = true)
    (h_quote : (c == '"') = false) (h_lbrace : (c == '{') = false)
    (h_rbrace : (c == '}') = false) (h_lbracket : (c == '[') = false)
    (h_rbracket : (c == ']') = false) (h_comma : (c == ',') = false)
    (h_colon : (c == ':') = false) :
    scanLexicalFuel (fuel + 1) (c :: rest) depth scopes buf false =
      scanLexicalFuel fuel rest depth scopes (buf ++ [c]) false := by
  dsimp [scanLexicalFuel]
  rw [h_quote, h_lbrace, h_rbrace, h_lbracket, h_rbracket, h_comma, h_colon]
  have hne : buf.isEmpty = false := by
    cases buf with
    | nil => exact (h_buf rfl).elim
    | cons _ _ => rfl
  simp only [hne, Bool.false_eq_true, ↓reduceIte, Bool.not_false, Bool.false_and, Bool.true_and]
  rw [h_cont]
  simp only [eq_self, ↓reduceIte]

theorem digitChar_lt_10_isDigit (d : Nat) (h : d < 10) :
    ((decide (Nat.digitChar d ≥ '0') && decide (Nat.digitChar d ≤ '9'))) = true := by
  interval_cases d <;> simp [Nat.digitChar]

theorem isDigit_ge_le (c : Char) (h : c.isDigit = true) :
    (decide (c ≥ '0') && decide (c ≤ '9')) = true := by
  have hnat := Char.isDigit_iff_toNat.mp h
  have h0 : c ≥ '0' := by
    change '0'.val ≤ c.val
    rw [UInt32.le_iff_toNat_le, Char.toNat_val, Char.toNat_val]
    exact hnat.1
  have h9 : c ≤ '9' := by
    change c.val ≤ '9'.val
    rw [UInt32.le_iff_toNat_le, Char.toNat_val, Char.toNat_val]
    exact hnat.2
  simp [h0, h9]

theorem isDigit_num_start (c : Char) (h : c.isDigit = true) :
    ((decide (c ≥ '0') && decide (c ≤ '9')) || (c == '-') || (c == '.')) = true := by
  simp [isDigit_ge_le c h]

theorem isDigit_num_cont (c : Char) (h : c.isDigit = true) :
    ((decide (c ≥ '0') && decide (c ≤ '9')) || (c == '-') || (c == '+') ||
      (c == '.') || (c == 'e') || (c == 'E')) = true := by
  simp [isDigit_ge_le c h]

theorem isDigit_ne_nondigit (c d : Char) (hc : c.isDigit = true) (hd : d.isDigit = false) :
    (c == d) = false := by
  simp [beq_iff_eq]
  intro heq
  subst heq
  simp [hc] at hd

theorem isDigit_not_struct (c : Char) (h : c.isDigit = true) :
    (c == '"') = false ∧ (c == '{') = false ∧ (c == '}') = false ∧
    (c == '[') = false ∧ (c == ']') = false ∧ (c == ',') = false ∧
    (c == ':') = false := by
  refine ⟨?_, ?_, ?_, ?_, ?_, ?_, ?_⟩ <;>
    exact isDigit_ne_nondigit c _ h rfl

theorem minus_not_struct :
    (('-' == '"') = false) ∧ (('-' == '{') = false) ∧ (('-' == '}') = false) ∧
    (('-' == '[') = false) ∧ (('-' == ']') = false) ∧ (('-' == ',') = false) ∧
    (('-' == ':') = false) := ⟨rfl, rfl, rfl, rfl, rfl, rfl, rfl⟩

theorem minus_num_start :
    ((decide (('-' : Char) ≥ '0') && decide (('-' : Char) ≤ '9')) || ('-' == '-') ||
      ('-' == '.')) = true := rfl

theorem scanLexicalFuel_digit_start (fuel : Nat) (c : Char) (rest : List Char) (depth : Nat)
    (scopes : List LexScope) (h : c.isDigit = true) :
    scanLexicalFuel (fuel + 1) (c :: rest) depth scopes [] false =
      scanLexicalFuel fuel rest depth scopes [c] false := by
  have hs := isDigit_not_struct c h
  exact scanLexicalFuel_num_start fuel c rest depth scopes (isDigit_num_start c h)
    hs.1 hs.2.1 hs.2.2.1 hs.2.2.2.1 hs.2.2.2.2.1 hs.2.2.2.2.2.1 hs.2.2.2.2.2.2

theorem scanLexicalFuel_digit_cont (fuel : Nat) (c : Char) (buf rest : List Char) (depth : Nat)
    (scopes : List LexScope) (h_buf : buf ≠ []) (h : c.isDigit = true) :
    scanLexicalFuel (fuel + 1) (c :: rest) depth scopes buf false =
      scanLexicalFuel fuel rest depth scopes (buf ++ [c]) false := by
  have hs := isDigit_not_struct c h
  exact scanLexicalFuel_num_cont fuel c buf rest depth scopes h_buf (isDigit_num_cont c h)
    hs.1 hs.2.1 hs.2.2.1 hs.2.2.2.1 hs.2.2.2.2.1 hs.2.2.2.2.2.1 hs.2.2.2.2.2.2

theorem scanLexicalFuel_digits_cont (fuel : Nat) (ds : List Char) (buf rest : List Char)
    (depth : Nat) (scopes : List LexScope) (h_buf : buf ≠ [])
    (h_dig : ∀ c ∈ ds, c.isDigit = true) :
    scanLexicalFuel (fuel + ds.length) (ds ++ rest) depth scopes buf false =
      scanLexicalFuel fuel rest depth scopes (buf ++ ds) false := by
  induction ds generalizing fuel buf with
  | nil =>
    simp
  | cons c ds ih =>
    have hc : c.isDigit = true := h_dig c (List.Mem.head _)
    have hds : ∀ x ∈ ds, x.isDigit = true := fun x hx => h_dig x (List.Mem.tail _ hx)
    have hstep := scanLexicalFuel_digit_cont (fuel + ds.length) c buf (ds ++ rest) depth scopes
      h_buf hc
    simp only [List.length_cons, Nat.add_comm ds.length, Nat.add_assoc] at hstep ⊢
    rw [List.cons_append, hstep]
    have hbuf' : buf ++ [c] ≠ [] := by
      cases buf <;> simp
    have hrest := ih fuel (buf ++ [c]) hbuf' hds
    simpa [List.append_assoc] using hrest

theorem scanLexicalFuel_nat (fuel : Nat) (n : Nat) (rest : List Char) (depth : Nat)
    (scopes : List LexScope) :
    scanLexicalFuel (fuel + (toString n).length)
        ((toString n).toList ++ rest) depth scopes [] false =
      scanLexicalFuel fuel rest depth scopes (toString n).toList false := by
  have h_repr : (toString n).toList = Nat.toDigits 10 n := by
    change (Nat.repr n).toList = Nat.toDigits 10 n
    exact Nat.toList_repr
  rw [h_repr]
  rcases toDigits_nonempty n with ⟨c, tl, h_digits⟩
  rw [h_digits]
  have hl : ∀ x ∈ Nat.toDigits 10 n, x.isDigit = true := fun x hx =>
    Nat.isDigit_of_mem_toDigits (by decide) (by decide) hx
  have hc : c.isDigit = true := hl c (by simp [h_digits])
  have htl : ∀ x ∈ tl, x.isDigit = true := fun x hx =>
    hl x (by simp [h_digits, hx])
  have hlen : (toString n).length = (c :: tl).length := by
    rw [← String.length_toList, h_repr, h_digits]
  simp only [List.cons_append]
  have hstart := scanLexicalFuel_digit_start (fuel + tl.length) c (tl ++ rest) depth scopes hc
  have : fuel + (toString n).length = fuel + tl.length + 1 := by
    rw [hlen]
    simp [List.length_cons, Nat.add_assoc]
  rw [this, hstart]
  have hbuf : [c] ≠ [] := by simp
  have hcont := scanLexicalFuel_digits_cont fuel tl [c] rest depth scopes hbuf htl
  simpa [List.singleton_append] using hcont

theorem scanLexicalFuel_minus (fuel : Nat) (rest : List Char) (depth : Nat)
    (scopes : List LexScope) :
    scanLexicalFuel (fuel + 1) ('-' :: rest) depth scopes [] false =
      scanLexicalFuel fuel rest depth scopes ['-'] false := by
  have hs := minus_not_struct
  exact scanLexicalFuel_num_start fuel '-' rest depth scopes minus_num_start
    hs.1 hs.2.1 hs.2.2.1 hs.2.2.2.1 hs.2.2.2.2.1 hs.2.2.2.2.2.1 hs.2.2.2.2.2.2

theorem scanLexicalFuel_int (fuel : Nat) (i : Int) (rest : List Char) (depth : Nat)
    (scopes : List LexScope) :
    scanLexicalFuel (fuel + (toString i).length)
        ((toString i).toList ++ rest) depth scopes [] false =
      scanLexicalFuel fuel rest depth scopes (toString i).toList false := by
  cases i with
  | ofNat n =>
    exact scanLexicalFuel_nat fuel n rest depth scopes
  | negSucc n =>
    have h_repr : (toString (Int.negSucc n)).toList = '-' :: (Nat.repr (n + 1)).toList := by
      change ("-" ++ Nat.repr (n + 1)).toList = '-' :: (Nat.repr (n + 1)).toList
      rw [String.toList_append]
      rfl
    have h_nat : (Nat.repr (n + 1)).toList = Nat.toDigits 10 (n + 1) := Nat.toList_repr
    have hlen : (toString (Int.negSucc n)).length = (Nat.repr (n + 1)).length + 1 := by
      rw [← String.length_toList, h_repr]
      simp only [List.length_cons]
      rw [String.length_toList]
    rw [h_repr]
    simp only [List.cons_append]
    have : fuel + (toString (Int.negSucc n)).length = fuel + (Nat.repr (n + 1)).length + 1 := by
      rw [hlen, Nat.add_assoc]
    rw [this]
    have hminus := scanLexicalFuel_minus (fuel + (Nat.repr (n + 1)).length)
      ((Nat.repr (n + 1)).toList ++ rest) depth scopes
    rw [hminus]
    have hbuf : ['-'] ≠ [] := by simp
    have hl : ∀ x ∈ Nat.toDigits 10 (n + 1), x.isDigit = true := fun x hx =>
      Nat.isDigit_of_mem_toDigits (by decide) (by decide) hx
    have htl : ∀ x ∈ (Nat.repr (n + 1)).toList, x.isDigit = true := by
      intro x hx
      rw [h_nat] at hx
      exact hl x hx
    have hcont := scanLexicalFuel_digits_cont fuel (Nat.repr (n + 1)).toList ['-'] rest
      depth scopes hbuf htl
    rw [← String.length_toList]
    simpa [List.singleton_append] using hcont

theorem scanLexicalFuel_encode_num (fuel : Nat) (n : Int) (rest : List Char) (depth : Nat)
    (scopes : List LexScope) :
    scanLexicalFuel (fuel + scanCost (.num n))
        ((TreeJson.encode (.num n)).toList ++ rest) depth scopes [] false =
      scanLexicalFuel fuel rest depth scopes (toString n).toList false := by
  dsimp [scanCost, TreeJson.encode, numBuf]
  exact scanLexicalFuel_int fuel n rest depth scopes

theorem ofList_contains_false_of_not_mem (cs : List Char) (c : Char) (h : c ∉ cs) :
    (String.ofList cs).contains c = false := by
  rw [String.contains_char_eq, String.toList_ofList]
  simp [h]

theorem toDigits_not_mem_dot_e (n : Nat) :
    ('.' ∉ Nat.toDigits 10 n) ∧ ('e' ∉ Nat.toDigits 10 n) ∧ ('E' ∉ Nat.toDigits 10 n) := by
  have hl : ∀ x ∈ Nat.toDigits 10 n, x.isDigit = true := fun x hx =>
    Nat.isDigit_of_mem_toDigits (by decide) (by decide) hx
  refine ⟨?_, ?_, ?_⟩ <;> intro hmem <;>
    have := hl _ hmem <;> simp at this

theorem scanLexicalCheckNum_nat (n : Nat) :
    scanLexicalCheckNum (toString n).toList = .ok () := by
  have h_repr : (toString n).toList = Nat.toDigits 10 n := by
    change (Nat.repr n).toList = Nat.toDigits 10 n
    exact Nat.toList_repr
  dsimp [scanLexicalCheckNum]
  have hne : ((toString n).toList).isEmpty = false := by
    have : 1 ≤ (toString n).toList.length := toString_nat_length_ge_one n
    cases hcs : (toString n).toList with
    | nil =>
      rw [hcs] at this
      simp at this
    | cons _ _ => rfl
  simp only [hne, Bool.not_false]
  have ⟨hd, he, hE⟩ := toDigits_not_mem_dot_e n
  have hdot : (String.ofList (toString n).toList).contains '.' = false := by
    rw [h_repr]; exact ofList_contains_false_of_not_mem _ _ hd
  have he' : (String.ofList (toString n).toList).contains 'e' = false := by
    rw [h_repr]; exact ofList_contains_false_of_not_mem _ _ he
  have hE' : (String.ofList (toString n).toList).contains 'E' = false := by
    rw [h_repr]; exact ofList_contains_false_of_not_mem _ _ hE
  rw [hdot, he', hE']
  simp

theorem scanLexicalCheckNum_int (i : Int) :
    scanLexicalCheckNum (toString i).toList = .ok () := by
  cases i with
  | ofNat n => exact scanLexicalCheckNum_nat n
  | negSucc n =>
    have h_repr : (toString (Int.negSucc n)).toList = '-' :: (Nat.repr (n + 1)).toList := by
      change ("-" ++ Nat.repr (n + 1)).toList = '-' :: (Nat.repr (n + 1)).toList
      rw [String.toList_append]
      rfl
    have h_nat : (Nat.repr (n + 1)).toList = Nat.toDigits 10 (n + 1) := Nat.toList_repr
    dsimp [scanLexicalCheckNum]
    have hne : ((toString (Int.negSucc n)).toList).isEmpty = false := by
      rw [h_repr]; rfl
    simp only [hne, Bool.not_false]
    have ⟨hd, he, hE⟩ := toDigits_not_mem_dot_e (n + 1)
    have hmem (c : Char) (hc : c ∈ (toString (Int.negSucc n)).toList) :
        c = '-' ∨ c ∈ Nat.toDigits 10 (n + 1) := by
      rw [h_repr, h_nat] at hc
      simpa using hc
    have hdot : (String.ofList (toString (Int.negSucc n)).toList).contains '.' = false := by
      apply ofList_contains_false_of_not_mem
      intro hmem'
      have := hmem '.' hmem'
      rcases this with h | h
      · cases h
      · exact hd h
    have he' : (String.ofList (toString (Int.negSucc n)).toList).contains 'e' = false := by
      apply ofList_contains_false_of_not_mem
      intro hmem'
      have := hmem 'e' hmem'
      rcases this with h | h
      · cases h
      · exact he h
    have hE' : (String.ofList (toString (Int.negSucc n)).toList).contains 'E' = false := by
      apply ofList_contains_false_of_not_mem
      intro hmem'
      have := hmem 'E' hmem'
      rcases this with h | h
      · cases h
      · exact hE h
    rw [hdot, he', hE']
    simp

theorem scanLexicalCheckNum_numBuf (t : TreeJson) :
    scanLexicalCheckNum (numBuf t) = .ok () := by
  cases t with
  | num n => exact scanLexicalCheckNum_int n
  | null | bool _ | str _ | arr _ | obj _ => simp [numBuf, scanLexicalCheckNum]

theorem scanLexicalFuel_comma_arr_flush (fuel : Nat) (rest : List Char) (depth : Nat)
    (cnt : Nat) (h_cnt : cnt + 1 ≤ 4096) (restScopes : List LexScope) (buf : List Char)
    (h_ok : scanLexicalCheckNum buf = .ok ()) :
    scanLexicalFuel (fuel + 1) (',' :: rest) depth (LexScope.inArr cnt :: restScopes) buf false =
      scanLexicalFuel fuel rest depth (LexScope.inArr (cnt + 1) :: restScopes) [] false := by
  dsimp [scanLexicalFuel]
  rw [h_ok]
  dsimp
  have : ¬ (cnt + 1 > 4096) := by omega
  rw [if_neg this]

theorem scanLexicalFuel_comma_obj_flush (fuel : Nat) (rest : List Char) (depth : Nat)
    (keys : List String) (restScopes : List LexScope) (buf : List Char)
    (h_ok : scanLexicalCheckNum buf = .ok ()) :
    scanLexicalFuel (fuel + 1) (',' :: rest) depth (LexScope.inObj keys false :: restScopes) buf false =
      scanLexicalFuel fuel rest depth (LexScope.inObj keys true :: restScopes) [] false := by
  dsimp [scanLexicalFuel]
  rw [h_ok]

theorem scanLexicalFuel_rbrace_flush (fuel : Nat) (rest : List Char) (depth : Nat)
    (sc : LexScope) (scopes : List LexScope) (buf : List Char)
    (h_depth : depth > 0) (h_ok : scanLexicalCheckNum buf = .ok ()) :
    scanLexicalFuel (fuel + 1) ('}' :: rest) depth (sc :: scopes) buf false =
      scanLexicalFuel fuel rest (depth - 1) scopes [] false := by
  dsimp [scanLexicalFuel]
  rw [h_ok]
  dsimp
  have : (if depth > 0 then depth - 1 else 0) = depth - 1 := if_pos h_depth
  rw [this]

theorem scanLexicalFuel_rbracket_flush (fuel : Nat) (rest : List Char) (depth : Nat)
    (sc : LexScope) (scopes : List LexScope) (buf : List Char)
    (h_depth : depth > 0) (h_ok : scanLexicalCheckNum buf = .ok ()) :
    scanLexicalFuel (fuel + 1) (']' :: rest) depth (sc :: scopes) buf false =
      scanLexicalFuel fuel rest (depth - 1) scopes [] false := by
  dsimp [scanLexicalFuel]
  rw [h_ok]
  dsimp
  have : (if depth > 0 then depth - 1 else 0) = depth - 1 := if_pos h_depth
  rw [this]

theorem contains_eq_false_of_not_mem (keys : List String) (s : String) (h : s ∉ keys) :
    keys.contains s = false := by
  simpa [List.contains_iff_mem] using h

theorem scanCost_arr_nil : scanCost (.arr []) = 2 := rfl
theorem scanCost_obj_nil : scanCost (.obj []) = 2 := rfl

theorem scanLexicalFuel_encode_arr_nil (fuel : Nat) (rest : List Char) (depth : Nat)
    (scopes : List LexScope) (h_depth : depth + 1 ≤ 64) :
    scanLexicalFuel (fuel + scanCost (.arr []))
        ((TreeJson.encode (.arr [])).toList ++ rest) depth scopes [] false =
      scanLexicalFuel fuel rest depth scopes [] false := by
  rw [scanCost_arr_nil, encode_arr_toList, encodeList_nil_toList]
  have hopen := scanLexicalFuel_lbracket (fuel + 1) (']' :: rest) depth scopes h_depth
  rw [hopen]
  exact scanLexicalFuel_rbracket_flush fuel rest (depth + 1) (LexScope.inArr 0) scopes []
    (by omega) scanLexicalCheckNum_nil

theorem scanLexicalFuel_encode_obj_nil (fuel : Nat) (rest : List Char) (depth : Nat)
    (scopes : List LexScope) (h_depth : depth + 1 ≤ 64) :
    scanLexicalFuel (fuel + scanCost (.obj []))
        ((TreeJson.encode (.obj [])).toList ++ rest) depth scopes [] false =
      scanLexicalFuel fuel rest depth scopes [] false := by
  rw [scanCost_obj_nil, encode_obj_toList]
  have hempty : (TreeJson.encodeObj []).toList ++ ('}' :: rest) = '}' :: rest := rfl
  rw [hempty]
  have hopen := scanLexicalFuel_lbrace (fuel + 1) ('}' :: rest) depth scopes h_depth
  rw [hopen]
  exact scanLexicalFuel_rbrace_flush fuel rest (depth + 1) (LexScope.inObj [] true) scopes []
    (by omega) scanLexicalCheckNum_nil

/-- Scalar and empty-container continuation: numbers remain buffered; other scalars clear. -/
theorem scanLexicalFuel_encode_scalar (t : TreeJson) (fuel : Nat) (rest : List Char)
    (depth : Nat) (scopes : List LexScope) (h_not_key : notExpectKey scopes)
    (h_depth : depth + t.depth ≤ 64)
    (h_scalar : match t with | .arr (_ :: _) | .obj (_ :: _) => False | _ => True) :
    scanLexicalFuel (fuel + scanCost t) ((TreeJson.encode t).toList ++ rest) depth scopes [] false =
      scanLexicalFuel fuel rest depth scopes (numBuf t) false := by
  cases t with
  | null =>
    simpa [numBuf] using scanLexicalFuel_encode_null fuel rest depth scopes
  | bool b =>
    simpa [numBuf] using scanLexicalFuel_encode_bool fuel b rest depth scopes
  | num n =>
    simpa [numBuf] using scanLexicalFuel_encode_num fuel n rest depth scopes
  | str s =>
    simpa [numBuf] using scanLexicalFuel_encode_str fuel s rest depth scopes h_not_key
  | arr xs =>
    cases xs with
    | nil =>
      simpa [numBuf] using scanLexicalFuel_encode_arr_nil fuel rest depth scopes (by
        dsimp [TreeJson.depth] at h_depth; omega)
    | cons _ _ => exact h_scalar.elim
  | obj kvs =>
    cases kvs with
    | nil =>
      simpa [numBuf] using scanLexicalFuel_encode_obj_nil fuel rest depth scopes (by
        dsimp [TreeJson.depth] at h_depth; omega)
    | cons _ _ => exact h_scalar.elim

end DefiKernel.Certificates


