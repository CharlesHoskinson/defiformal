import DefiKernel.Arithmetic.Operations
import DefiKernel.Certificates.Schema

/-!
Actual Lean-checked library instantiation for P20 task 21.3.

Envelope `libraries` theorem-name tags never discharge LibraryTheoremsInstantiated.
Only a compiled identity with a recorded theorem from accepted Arithmetic counts.
-/
namespace DefiKernel.Certificates.LibraryInstantiation

open DefiKernel.Arithmetic

/-- Compiled instantiation of accepted Arithmetic checked-addition. -/
theorem instantiated_add_ok_iff {w : Nat} (a b q : Word w) :
    Operations.add a b = .ok q ↔ a.value + b.value = q.value :=
  Operations.add_ok_iff a b q

/-- Fully qualified names of theorems this certificate increment actually instantiated. -/
def instantiatedTheoremNames : List String :=
  ["DefiKernel.Arithmetic.Operations.add_ok_iff"]

/-- Theorem-name tags discharge nothing unless they name a compiled instantiation. -/
def namesDischarged (libs : List LibraryRefEnc) : Bool :=
  !libs.isEmpty && libs.all (fun l => instantiatedTheoremNames.contains l.theoremName)

end DefiKernel.Certificates.LibraryInstantiation
