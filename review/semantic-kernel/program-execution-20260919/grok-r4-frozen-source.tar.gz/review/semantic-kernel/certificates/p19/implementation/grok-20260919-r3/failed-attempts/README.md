# Failed attempts preserved from grok-20260919-r3

- `helpers-encodelist-v1` (recorded command, exit 1): first encodeList continuation compile. Errors were List.Disjoint implicit arguments, fuel association `fuel + 1 + cost` versus `fuel + cost + 1`, and `simp` on an already-closed nil goal. Receipt: `logs/helpers-encodelist-v1/`.
- Inline axiom helper `axiom-scan-inline` (exit 1): CompositionDepth 15/15 standard; Lexical 109 names found but unresolved without namespace (same helper coverage failure as R2). Complete audit is `logs/print-axioms-final/` with fully qualified `#print axioms`.
