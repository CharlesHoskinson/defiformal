# P19 grok-20260919-r4: remaining implementation/evidence gates

- **Attempt**: `grok-20260919-r4`
- **Author**: Grok 4.6 (native implementation)
- **Checker**: pending independent GPT-6 Astra medium
- **Disposition**: `PARTIAL`
- **Build**: `DefiKernel.Certificates.Verify` 948 jobs, forbidden axioms 0
- **Self-accepted**: no

## Accepted planning identity (not STATUS.json)

Recovered from existing evidence, not stale `gate_accepted=false` planning STATUS:

| Field | Value |
|---|---|
| Task accepted | 20.1 only |
| Archive SHA-256 | `e73a61d9c98256270696ead1c3c554b070f100075b76d594d4ec251636ee5e5a` |
| Independent review | `p19-r4-planning-review/REVIEW.md` SHA `5fab03cdac0d6e396b3e28fbde94d4f631c5c29d73d77ce1233c01c6dc24dddb` |
| Accepted inputs SHA-256 | `8c76c3d2ed88d16824d1beac6eaa044e58b1a00344421f26e3c70a9b666dea39` |
| Verdict | ACCEPT_WITH_LIMITATIONS |
| Reviewer | GPT-6 / gpt-6-astra |
| Author of that freeze | grok-4.6 |
| Frozen STATUS.gate_accepted | remains false |

Prior r1/r2/r3 planning verdicts are unchanged historical evidence.

## What this round implemented

1. **Overlay / expectedIR / canonical-rejection.** `scripts/run_certificate_fixtures.py` no longer defaults to the agy-r5 overlay and no longer replaces fixture inputs or expected fields from that overlay. Original F13/F28 bytes are preserved. Independently, unsorted `source_map` keys on originally-ok codec fixtures are expected as `noncanonicalWhitespace` (design D7 + `decodeBytes` encode-match). Other codec fixtures keep their earlier-precedence expected failures. `RunFixtures` decode-ok now emits the actual decoded IR, not `ir: null`.
2. **Trusted host / schema identity.** Compiled `TrustedHost.lean` plus `trusted-host-records.json` bind grammar/schema SHA-256 and Typed/Composition/pin path+sha256 records. Envelope `source_pin.git` is compared to the compiled trusted git constant, not treated as the record. Path+sha256 tokens are distinct from the git string. The fixture runner refuses if grammar/schema/dependency hashes mismatch.
3. **14-field Report.** `encodeReport` now encodes `unsupported` from the report instead of always `"null"`. `reportEq` already compared all 14 fields.
4. **Parallel.admit (P20 21.2).** `checkStep` / `checkRun` call `Parallel.admit` on the decoded catalog and invocation branches with footprints recomputed inside `admit`. Caller footprint labels are not inputs. Sequential step *errors* still report `compositionCompatible = false`. Success uses the admit result. Tree/Claims/Nary constructors remain `unsupportedForm`.
5. **Library instantiation (P20 21.3).** `LibraryInstantiation.instantiated_add_ok_iff` is a compiled identity of accepted `Arithmetic.Operations.add_ok_iff`. Envelope theorem-name tags do not discharge the family (M09 needle preserved).
6. **Campaigns.** 54/54 fixtures (fixtures-full-r2). 16/16 isolated mutants discriminated at `/tmp/p19-r4-mutants-all` with designated false plus protected positive; control comparisons=23 false=[]. 99 scenarios mapped. Fixture-runner path-safety tests passed.

R3 Lexical proofs were not redone. R1/R2 modules and 246 Roundtrip declarations were not rewritten.

## Remaining gates (honest)

- Independent Astra review of R3 universal codec is pending; this round does not accept it.
- `checkIR_execute_ok` / `_error` remain definitional routing lemmas. Real-domain execute correspondence is still the P20 21.1 quantified obligation.
- P20 operator extensions (Claims/Tree/Nary/atomic/Quint) stay `unsupportedForm`.
- Qualified certificate delivery, parent publish, and whole P19/P20/P37 acceptance remain open.
- Mutation runner used `--bind-working-tree` because this candidate is an uncommitted worktree (no commits). That binding is recorded; it is not a Git freeze.

## Failed attempts preserved

See `failed-attempts/README.md` and recorded commands `compile-verify-r1`, `compile-soundness-r2`, `fixtures-full-r1`, `mutant-m01`.

## Verification recorded this round

| Check | Result |
|---|---|
| `lake build DefiKernel.Certificates.Check` | exit 0, 935 jobs |
| `lake build DefiKernel.Certificates.Soundness` after gitSha simpa | exit 0, 938 jobs |
| `lake build DefiKernel.Certificates.Verify` | exit 0, 948 jobs, forbidden=0 |
| `#print axioms` new R4 names | standard only (`propext` / `Classical.choice` / `Quot.sound` or none) |
| fixtures-full-r2 | 54/54 pass, 54/54 negative controls |
| mutants M01–M16 | 16/16 discriminated; outside-repo `/tmp/p19-r4-mutants-all` |
| fixture-runner path safety | 7/7 pass |
| scenarios | 99 mapped, 0 failed |

Toolchain remains Lean/mathlib `v4.33.0-rc2`. No `lake update`.

This report does not accept the candidate.
