#!/usr/bin/env python3
"""Unrecorded R2 final seal. Writes REPORT/verdict/source-manifest first, then MANIFEST.
Never hash MANIFEST. Do not invoke the recorder after this script runs."""
from __future__ import annotations

import datetime
import hashlib
import json
from pathlib import Path

WORK = Path("/home/charl/defiformal-wt-p19-certificates-grok-opus-20260909")
EVIDENCE = WORK / "review/semantic-kernel/certificates/p19/implementation/grok-20260919-r2"
CERT = WORK / "lean/DefiKernel/Certificates"
TOOL = Path("/home/charl/.elan/toolchains/leanprover--lean4---v4.33.0-rc2/bin")
NOW = datetime.datetime.now(datetime.timezone.utc).isoformat()
GIT = "38de83c58e3f9315bf400807591d538d7565152e"


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def meta(path: Path) -> dict:
    data = path.read_bytes()
    return {"sha256": hashlib.sha256(data).hexdigest(), "bytes": len(data),
            "lines": data.decode("utf-8", errors="replace").count("\n")}


REPORT = r"""# P19 grok-20260919-r2: universal TreeJson depth and scanner continuation

- **Attempt**: `grok-20260919-r2`
- **Author**: Grok 4.6 (native implementation)
- **Checker**: pending independent GPT-6 Astra medium
- **Disposition**: `PARTIAL`
- **Build**: `DefiKernel.Certificates.Verify` compiled after new CompositionDepth and Lexical imports; 943 jobs, forbidden axioms 0

## What this round proved

R1 discharged `h_depth` for typed-execute only. This round completes the representation metric for composition-step and composition-run payloads (actual steps, invocation histories, and boundaries) using the existing R1 envelope/config/component metrics. Unchanged `StructurallyAdmissibleIR` / `WholeDocumentDepthBounded` then imply `TreeJson.depth (moduleToTreeJson ir) ≤ 64` for every supported IR. A new production theorem drops `h_depth` while preserving the old general signature.

Scanner work then starts the structural `scanLexicalFuel` continuation on canonical `TreeJson.encode`: strings cost one outer step via `lexString_escapeJsonString`; integer encodings fill the numeric buffer without `.`/`e`/`E`; empty arrays and objects open and close with depth and flush lemmas. Nonempty array/object key-list induction remains.

Core depth theorems:

```lean
theorem jsonDepthFuel_decodedIR (ir : DecodedIR) (fuel : Nat) :
    jsonDepthFuel fuel (decodedIRToJson ir) =
      jsonDepthFuel fuel (moduleToTreeJson ir).toJson

theorem moduleToTreeJson_depth_le_64 (ir : DecodedIR)
    (h_adm : StructurallyAdmissibleIR ir) :
    TreeJson.depth (moduleToTreeJson ir) ≤ 64
```

## Strongest new theorem

```lean
theorem decodeBytes_encodeModule_of_lex (ir : DecodedIR)
    (h_adm : StructurallyAdmissibleIR ir)
    (h_lex : scanLexical (encodeModule ir) = .ok ()) :
    decodeBytes (encodeModule ir) = .ok ir
```

`h_depth` is gone for every structurally admissible IR (typed-execute, composition-step, composition-run, including nonempty registries). The existing `decodeBytes_encodeModule_of_depth_and_lex` signature is unchanged. Axioms: `propext`, `Classical.choice`, `Quot.sound` only.

Specializations `decodeBytes_encodeModule_step_of_lex` and `decodeBytes_encodeModule_run_of_lex` match the R1 typed-only form.

## Still open

1. **`h_lex`**: `scanLexical (encodeModule ir) = .ok ()` remains open for the full grammar. This round compiled continuation lemmas for null/bool/number/string and empty array/object encodings, plus numeric-buffer flush on comma/brace/bracket. Nonempty `encodeList` / `encodeObj` induction (visited-key disjointness, array comma counts, sufficient fuel) is not closed, so the wrapper `scanLexical` theorem is not proved.
2. **`EncodeDecodeRoundtripStatement`**: still the explicit `def Prop` `∀ ir, StructurallyAdmissibleIR ir → decodeBytes (encodeModule ir) = .ok ir`. Not proved. After `h_depth` discharge the remaining premise is `h_lex`.
3. **P19/P20 acceptance**: not claimed. Unchanged 54/21/7 campaigns were not rerun.

## Source contract

- R1 `DepthBridge.lean` SHA `bd7e639f0cfb0f03504d0b7399c07f43644767af5495bf39a3c93841f6d0e365` preserved.
- R1 `IRDepth.lean` SHA `ae245b2f2bf92697b0a25551638d87a8bd641f0a9a3efe7e373fe89afb8aa0c8` preserved.
- Historical Roundtrip 246 declarations preserved. Roundtrip SHA `a12a00feade30877cc1bc18e06caf68f9e59cb47e49195a3e788c59bfbff94b1` unchanged.
- New modules: `lean/DefiKernel/Certificates/CompositionDepth.lean`, `lean/DefiKernel/Certificates/Lexical.lean`.
- `Verify.lean` imports both new modules. No existing theorem statements, signatures, or docstrings changed.
- No `sorry`, `native_decide`, custom axioms, `h_depth`/`h_lex` added to admission, or alternate codec.

## New compiled declarations

CompositionDepth: 15 theorems. Lexical: 60 top-level `def`/`theorem` matches plus mutual `scanCost`/`scanCostList`/`scanCostObj` (63 declarations). Combined 78 new declarations in those two modules. Inline helper resolved 15/15 CompositionDepth declarations as standard axioms; Lexical helper resolved 4/60 (file marked unverified by that helper). Recorded `#print axioms` on the strongest theorems, including `decodeBytes_encodeModule_of_lex`, `moduleToTreeJson_depth_le_64`, and `scanLexicalFuel_encode_scalar`, reports `propext`, `Classical.choice`, `Quot.sound` only. LSP `lean_verify` agrees.

## Verification recorded this round

| Check | Result |
|---|---|
| `lake build DefiKernel.Certificates.CompositionDepth` | exit 0, 936 jobs |
| `lake build DefiKernel.Certificates.Verify` after CompositionDepth import | exit 0, 941 jobs, forbidden=0 |
| Lexical compile iterations v1–v7 | failed attempts preserved |
| `lake build DefiKernel.Certificates.Lexical` v8 | exit 0, 938 jobs |
| `lake build DefiKernel.Certificates.Verify` after Lexical import | exit 0, 943 jobs, forbidden=0 |
| `#print axioms` probe of strongest theorems | standard axioms only |
| Inline axiom helper on CompositionDepth | 15/15 standard |
| Inline axiom helper on Lexical | 4/60 resolved, remainder not accessible to that helper |

Toolchain remains Lean/mathlib `v4.33.0-rc2`. No `lake update`.

Root `record-author-r2-command.py` still pointed at historical `agy-r27-proof`. This round used a local copy whose `EVIDENCE` path is `grok-20260919-r2`. R1 evidence was not rewritten.

## Evidence seal

All recorded compiler/probe commands finished before this report. REPORT, verdict, source-manifest, and MANIFEST were written by an unrecorded `seal-r2.py` after those commands. MANIFEST is self-excluded.
"""

VERDICT = {
    "timestamp_utc": NOW,
    "attempt": "grok-20260919-r2",
    "status": "PARTIAL",
    "disposition": "USABLE",
    "author": "grok-4.6",
    "auditor": "pending gpt-6-astra medium",
    "production_source_changed": True,
    "P19_accepted": False,
    "strongest_compiled_theorem": "decodeBytes_encodeModule_of_lex",
    "strongest_compiled_theorem_signature": (
        "theorem decodeBytes_encodeModule_of_lex (ir : DecodedIR) "
        "(h_adm : StructurallyAdmissibleIR ir) "
        "(h_lex : scanLexical (encodeModule ir) = .ok ()) : "
        "decodeBytes (encodeModule ir) = .ok ir"
    ),
    "strongest_general_theorem_unchanged": "decodeBytes_encodeModule_of_depth_and_lex",
    "strongest_general_theorem_signature": (
        "theorem decodeBytes_encodeModule_of_depth_and_lex (ir : DecodedIR) "
        "(h_adm : StructurallyAdmissibleIR ir) "
        "(h_depth : TreeJson.depth (moduleToTreeJson ir) ≤ 64) "
        "(h_lex : scanLexical (encodeModule ir) = .ok ()) : "
        "decodeBytes (encodeModule ir) = .ok ir"
    ),
    "h_depth_discharged": {
        "typed_execute_all_admissible_including_nonempty_registry": True,
        "composition_step_general": True,
        "composition_run_general": True,
        "all_structurally_admissible_IR": True,
        "empty_registry_typed_step_run": "historical R28, now subsumed",
        "canonicalWitnessIR_collisionIR": "historical R27",
    },
    "h_lex_discharged": False,
    "EncodeDecodeRoundtripStatement_proved": False,
    "unproved_hypotheses": [
        "h_lex: scanLexical (encodeModule ir) = .ok () over the full grammar; scalar/empty-container scanLexicalFuel continuation compiled; nonempty encodeList/encodeObj induction remains",
        "EncodeDecodeRoundtripStatement",
    ],
    "discharged_this_round": [
        "jsonDepthFuel metric for inputSource, invocation, step, outputObservation, compositionStepPayload, compositionRunPayload",
        "jsonDepthFuel_decodedIR for every DecodedIR constructor",
        "moduleToTreeJson_step_depth_le_64 and moduleToTreeJson_run_depth_le_64 from StructurallyAdmissibleIR / WholeDocumentDepthBounded",
        "moduleToTreeJson_depth_le_64 for every structurally admissible IR",
        "decodeBytes_encodeModule_of_lex: general roundtrip with only h_lex remaining; old of_depth_and_lex signature preserved",
        "scanLexicalFuel continuation for null/bool/num/str and empty array/object encodings",
        "scanLexicalCheckNum on canonical integer encodings; string key/value steps via lexString_escapeJsonString",
    ],
    "new_modules": [
        "lean/DefiKernel/Certificates/CompositionDepth.lean",
        "lean/DefiKernel/Certificates/Lexical.lean",
    ],
    "preserved_r1_modules": {
        "lean/DefiKernel/Certificates/DepthBridge.lean": "bd7e639f0cfb0f03504d0b7399c07f43644767af5495bf39a3c93841f6d0e365",
        "lean/DefiKernel/Certificates/IRDepth.lean": "ae245b2f2bf92697b0a25551638d87a8bd641f0a9a3efe7e373fe89afb8aa0c8",
        "lean/DefiKernel/Certificates/Roundtrip.lean": "a12a00feade30877cc1bc18e06caf68f9e59cb47e49195a3e788c59bfbff94b1",
    },
    "roundtrip_declarations_preserved": 246,
    "new_theorems_compositiondepth": 15,
    "new_declarations_lexical_top_level": 60,
    "new_declarations_lexical_mutual_scanCost": 3,
    "new_declarations_axiom_print": 12,
    "forbidden_axioms_count": 0,
    "sorry_count": 0,
    "native_decide_count": 0,
    "verify_jobs": 943,
    "fixtures_rerun": False,
    "unit_tests_rerun": False,
    "recorded_commands": 14,
    "git_head": GIT,
}


def main() -> None:
    sources = {}
    for path in sorted(CERT.glob("*.lean")):
        rel = str(path.relative_to(WORK))
        sources[rel] = meta(path)
    source_manifest = {
        "schema": "defiformal-p19-source-manifest/v2",
        "timestamp_utc": NOW,
        "git_head": GIT,
        "lean_version": "Lean (version 4.33.0-rc2, x86_64-unknown-linux-gnu, commit d8b18978322de05a8f3dba51ef03cf5461676c17, Release)",
        "lean_executable": str(TOOL / "lean"),
        "cwd": str(WORK / "lean"),
        "sources": sources,
        "r1_depthbridge_sha256_preserved": sources["lean/DefiKernel/Certificates/DepthBridge.lean"]["sha256"]
            == "bd7e639f0cfb0f03504d0b7399c07f43644767af5495bf39a3c93841f6d0e365",
        "r1_irdepth_sha256_preserved": sources["lean/DefiKernel/Certificates/IRDepth.lean"]["sha256"]
            == "ae245b2f2bf92697b0a25551638d87a8bd641f0a9a3efe7e373fe89afb8aa0c8",
        "roundtrip_sha256_preserved": sources["lean/DefiKernel/Certificates/Roundtrip.lean"]["sha256"]
            == "a12a00feade30877cc1bc18e06caf68f9e59cb47e49195a3e788c59bfbff94b1",
    }
    (EVIDENCE / "REPORT.md").write_text(REPORT)
    (EVIDENCE / "verdict.json").write_text(json.dumps(VERDICT, indent=2) + "\n")
    (EVIDENCE / "source-manifest.json").write_text(json.dumps(source_manifest, indent=2) + "\n")

    files = []
    for path in sorted(EVIDENCE.rglob("*")):
        if not path.is_file():
            continue
        if path.name == "MANIFEST.json":
            continue
        rel = str(path.relative_to(EVIDENCE))
        files.append({"path": rel, "sha256": sha(path), "bytes": path.stat().st_size})
    for path in [
        WORK / "lean/DefiKernel/Certificates/CompositionDepth.lean",
        WORK / "lean/DefiKernel/Certificates/Lexical.lean",
        WORK / "lean/DefiKernel/Certificates/Verify.lean",
        WORK / "lean/DefiKernel/Certificates/DepthBridge.lean",
        WORK / "lean/DefiKernel/Certificates/IRDepth.lean",
        WORK / "lean/DefiKernel/Certificates/Roundtrip.lean",
    ]:
        files.append({
            "path": str(path.relative_to(WORK)),
            "sha256": sha(path),
            "bytes": path.stat().st_size,
        })
    manifest = {
        "schema": "defiformal-p19-manifest/v2",
        "attempt": "grok-20260919-r2",
        "timestamp_utc": NOW,
        "git_head": GIT,
        "status": "PARTIAL",
        "disposition": "USABLE",
        "author": "grok-4.6",
        "auditor": "pending gpt-6-astra medium",
        "self_excluded": True,
        "seal_script": "seal-r2.py",
        "recorded_commands_finished_before_seal": True,
        "strongest_compiled_theorem": {
            "name": "DefiKernel.Certificates.decodeBytes_encodeModule_of_lex",
            "signature": VERDICT["strongest_compiled_theorem_signature"],
            "unproved_hypotheses": VERDICT["unproved_hypotheses"],
        },
        "files": files,
    }
    (EVIDENCE / "MANIFEST.json").write_text(json.dumps(manifest, indent=2) + "\n")
    print(json.dumps({
        "sealed_utc": NOW,
        "report": sha(EVIDENCE / "REPORT.md"),
        "verdict": sha(EVIDENCE / "verdict.json"),
        "source_manifest": sha(EVIDENCE / "source-manifest.json"),
        "manifest_bytes": (EVIDENCE / "MANIFEST.json").stat().st_size,
        "manifest_entries": len(files),
        "manifest_self_excluded": True,
    }, indent=2))


if __name__ == "__main__":
    main()
