# P19 grok-20260919-r2: universal TreeJson depth and scanner continuation

- **Attempt**: `grok-20260919-r2`
- **Author**: Grok 4.6 (native implementation)
- **Checker**: pending independent GPT-6 Astra medium
- **Disposition**: `PARTIAL`
- **Build**: `DefiKernel.Certificates.Verify` compiled after new CompositionDepth and Lexical imports; 943 jobs, forbidden axioms 0

## What this round proved

R1 discharged `h_depth` for typed-execute only. This round completes the representation metric for composition-step and composition-run payloads (actual steps, invocation histories, and boundaries) using the existing R1 envelope/config/component metrics. Unchanged `StructurallyAdmissibleIR` / `WholeDocumentDepthBounded` then imply `TreeJson.depth (moduleToTreeJson ir) ≤ 64` for every supported IR. A new production theorem drops `h_depth` while preserving the old general signature.

Scanner work then starts the structural `scanLexicalFuel` continuation on canonical `TreeJson.encode`: strings cost one outer step via `lexString_escapeJsonString`; integer encodings fill the numeric buffer without `.`/`e`/`E`; empty arrays and objects open and close with depth and flush lemmas. Nonempty array/object key-list induction remains.

Core depth theorems:

```lean
theorem jsonDepthFuel_decodedIR (ir : DecodedIR) (fuel : Nat) :
    jsonDepthFuel fuel (decodedIRToJson ir) =
      jsonDepthFuel fuel (moduleToTreeJson ir).toJson

theorem moduleToTreeJson_depth_le_64 (ir : DecodedIR)
    (h_adm : StructurallyAdmissibleIR ir) :
    TreeJson.depth (moduleToTreeJson ir) ≤ 64
```

## Strongest new theorem

```lean
theorem decodeBytes_encodeModule_of_lex (ir : DecodedIR)
    (h_adm : StructurallyAdmissibleIR ir)
    (h_lex : scanLexical (encodeModule ir) = .ok ()) :
    decodeBytes (encodeModule ir) = .ok ir
```

`h_depth` is gone for every structurally admissible IR (typed-execute, composition-step, composition-run, including nonempty registries). The existing `decodeBytes_encodeModule_of_depth_and_lex` signature is unchanged. Axioms: `propext`, `Classical.choice`, `Quot.sound` only.

Specializations `decodeBytes_encodeModule_step_of_lex` and `decodeBytes_encodeModule_run_of_lex` match the R1 typed-only form.

## Still open

1. **`h_lex`**: `scanLexical (encodeModule ir) = .ok ()` remains open for the full grammar. This round compiled continuation lemmas for null/bool/number/string and empty array/object encodings, plus numeric-buffer flush on comma/brace/bracket. Nonempty `encodeList` / `encodeObj` induction (visited-key disjointness, array comma counts, sufficient fuel) is not closed, so the wrapper `scanLexical` theorem is not proved.
2. **`EncodeDecodeRoundtripStatement`**: still the explicit `def Prop` `∀ ir, StructurallyAdmissibleIR ir → decodeBytes (encodeModule ir) = .ok ir`. Not proved. After `h_depth` discharge the remaining premise is `h_lex`.
3. **P19/P20 acceptance**: not claimed. Unchanged 54/21/7 campaigns were not rerun.

## Source contract

- R1 `DepthBridge.lean` SHA `bd7e639f0cfb0f03504d0b7399c07f43644767af5495bf39a3c93841f6d0e365` preserved.
- R1 `IRDepth.lean` SHA `ae245b2f2bf92697b0a25551638d87a8bd641f0a9a3efe7e373fe89afb8aa0c8` preserved.
- Historical Roundtrip 246 declarations preserved. Roundtrip SHA `a12a00feade30877cc1bc18e06caf68f9e59cb47e49195a3e788c59bfbff94b1` unchanged.
- New modules: `lean/DefiKernel/Certificates/CompositionDepth.lean`, `lean/DefiKernel/Certificates/Lexical.lean`.
- `Verify.lean` imports both new modules. No existing theorem statements, signatures, or docstrings changed.
- No `sorry`, `native_decide`, custom axioms, `h_depth`/`h_lex` added to admission, or alternate codec.

## New compiled declarations

CompositionDepth: 15 theorems. Lexical: 60 top-level `def`/`theorem` matches plus mutual `scanCost`/`scanCostList`/`scanCostObj` (63 declarations). Combined 78 new declarations in those two modules. Inline helper resolved 15/15 CompositionDepth declarations as standard axioms; Lexical helper resolved 4/60 (file marked unverified by that helper). Recorded `#print axioms` on the strongest theorems, including `decodeBytes_encodeModule_of_lex`, `moduleToTreeJson_depth_le_64`, and `scanLexicalFuel_encode_scalar`, reports `propext`, `Classical.choice`, `Quot.sound` only. LSP `lean_verify` agrees.

## Verification recorded this round

| Check | Result |
|---|---|
| `lake build DefiKernel.Certificates.CompositionDepth` | exit 0, 936 jobs |
| `lake build DefiKernel.Certificates.Verify` after CompositionDepth import | exit 0, 941 jobs, forbidden=0 |
| Lexical compile iterations v1–v7 | failed attempts preserved |
| `lake build DefiKernel.Certificates.Lexical` v8 | exit 0, 938 jobs |
| `lake build DefiKernel.Certificates.Verify` after Lexical import | exit 0, 943 jobs, forbidden=0 |
| `#print axioms` probe of strongest theorems | standard axioms only |
| Inline axiom helper on CompositionDepth | 15/15 standard |
| Inline axiom helper on Lexical | 4/60 resolved, remainder not accessible to that helper |

Toolchain remains Lean/mathlib `v4.33.0-rc2`. No `lake update`.

Root `record-author-r2-command.py` still pointed at historical `agy-r27-proof`. This round used a local copy whose `EVIDENCE` path is `grok-20260919-r2`. R1 evidence was not rewritten.

## Evidence seal

All recorded compiler/probe commands finished before this report. REPORT, verdict, source-manifest, and MANIFEST were written by an unrecorded `seal-r2.py` after those commands. MANIFEST is self-excluded.
