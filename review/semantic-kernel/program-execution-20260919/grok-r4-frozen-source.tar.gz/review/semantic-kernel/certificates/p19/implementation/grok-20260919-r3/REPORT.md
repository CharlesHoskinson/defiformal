# P19 grok-20260919-r3: universal scanner success and codec roundtrip

- **Attempt**: `grok-20260919-r3`
- **Author**: Grok 4.6 (native implementation)
- **Checker**: pending independent GPT-6 Astra medium
- **Disposition**: `PARTIAL`
- **Build**: `DefiKernel.Certificates.Verify` compiled after Lexical checker correspondence; 943 jobs, forbidden axioms 0

## What this round proved

R2 left `h_lex` open on nonempty `encodeList` / `encodeObj`. This round proves a structural `scanLexicalFuel` continuation for every `TreeJson.Valid` tree at depth `≤ 64` and array length `≤ 4096`, then specializes the wrapper `scanLexical` to production `encodeModule`. Unchanged `StructurallyAdmissibleIR` already supplies `SerializedByteBound` (1 MiB), `WholeDocumentDepthBounded`, `TreeJson.Valid`, and an opening object brace. The existing `EncodeDecodeRoundtripStatement` therefore holds. Checker routing `checkBytes (encodeModule ir) = checkIR ir` follows.

Core scanner theorems:

```lean
theorem scanLexicalFuel_encode (t : TreeJson) (fuel : Nat) (rest : List Char)
    (depth : Nat) (scopes : List LexScope)
    (h_not_key : notExpectKey scopes)
    (h_depth : depth + TreeJson.depth t ≤ 64)
    (h_valid : TreeJson.Valid t) :
    scanLexicalFuel (fuel + scanCost t) ((TreeJson.encode t).toList ++ rest)
        depth scopes [] false =
      scanLexicalFuel fuel rest depth scopes (numBuf t) false

theorem scanLexical_encodeModule (ir : DecodedIR)
    (h_adm : StructurallyAdmissibleIR ir) :
    scanLexical (encodeModule ir) = .ok ()
```

## Strongest new theorem

```lean
theorem encode_decode_roundtrip : EncodeDecodeRoundtripStatement
```

which is the existing statement

```lean
∀ (ir : DecodedIR), StructurallyAdmissibleIR ir →
  decodeBytes (encodeModule ir) = .ok ir
```

No extra `h_lex` or `h_depth` hypothesis. Admission is unchanged `StructurallyAdmissibleIR`. Axioms: `propext`, `Classical.choice`, `Quot.sound` only.

Checker correspondence:

```lean
theorem checkBytes_encodeModule (ir : DecodedIR)
    (h_adm : StructurallyAdmissibleIR ir) :
    checkBytes (encodeModule ir) = checkIR ir
```

with typed / step / run specializations to `checkTyped` / `checkStep` / `checkRun`.

## Still open

1. **P19 campaigns / host / schema overlay**: 99 scenarios and 16 mutants were not rerun (unchanged 54/21/7 campaigns forbidden). Overlay, schema-hash, expectedIR, and trusted-host gates were not newly verified this round.
2. **P20 21.2 / 21.3**: executable `Parallel.admit` / `checkCompatibility` on recomputed footprints, and Lean-checked library instantiation, remain.
3. **P19/P20 acceptance**: not claimed. Independent Astra review of this candidate is pending. This report does not accept the candidate.

## Source contract

- R1 `DepthBridge.lean` SHA `bd7e639f0cfb0f03504d0b7399c07f43644767af5495bf39a3c93841f6d0e365` preserved.
- R1 `IRDepth.lean` SHA `ae245b2f2bf92697b0a25551638d87a8bd641f0a9a3efe7e373fe89afb8aa0c8` preserved.
- Historical Roundtrip 246 declarations preserved. Roundtrip SHA `a12a00feade30877cc1bc18e06caf68f9e59cb47e49195a3e788c59bfbff94b1` unchanged.
- CompositionDepth SHA `7fc24af43b856514e97a60f721597ff04cad3e8a5477d65b303660837e097168` unchanged from R2.
- Production edits: `lean/DefiKernel/Certificates/Lexical.lean` only. `Verify.lean` already imported Lexical in R2.
- No existing theorem statements, signatures, or docstrings changed.
- No `sorry`, `native_decide`, custom axioms, `h_depth`/`h_lex` added to admission, or alternate codec.

## New compiled declarations

Lexical: 113 top-level `def`/`theorem` matches plus mutual `scanCost`/`scanCostList`/`scanCostObj` (116 declarations). R2 had 60 top-level plus 3 mutual (63). This round added 53 Lexical declarations. CompositionDepth remains 15 theorems, unchanged.

Explicit `#print axioms` on 121 fully qualified names (every Lexical declaration plus five CompositionDepth theorems) reports only `propext`, `Classical.choice`, `Quot.sound`, or no axioms. Zero unknown identifiers.

## Verification recorded this round

| Check | Result |
|---|---|
| `helpers-encodelist-v1` first encodeList compile | exit 1; Disjoint implicits and fuel association; preserved |
| `lake build DefiKernel.Certificates.Lexical` | exit 0, 938 jobs |
| `lake build DefiKernel.Certificates.Verify` | exit 0, 943 jobs, forbidden=0 |
| `#print axioms` Lexical snapshot before checker corollaries | exit 0, 117/117 names, standard axioms |
| Inline axiom helper on CompositionDepth and Lexical | CompositionDepth 15/15 standard; Lexical unresolved without namespace (exit 1; same helper coverage failure as R2) |
| `lake build DefiKernel.Certificates.Lexical` after `checkBytes_encodeModule` | exit 0, 938 jobs |
| `lake build DefiKernel.Certificates.Verify` final | exit 0, 943 jobs, forbidden=0, 287/287 theorems, 408/408 supplemental |
| `#print axioms` final 121 fully qualified names | exit 0, 121/121, standard axioms only |

Toolchain remains Lean/mathlib `v4.33.0-rc2`. No `lake update`.

Root recorder `record-author-r3-command.py` writes evidence under `grok-20260919-r3`. R1 and R2 evidence were not rewritten.

## Evidence seal

All recorded compiler/probe commands finished before this report. REPORT, verdict, source-manifest, and MANIFEST were written by an unrecorded `seal-r3.py` after those commands. MANIFEST is self-excluded.
