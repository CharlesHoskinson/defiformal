#!/usr/bin/env python3
"""Unrecorded R3 final seal. Writes REPORT/verdict/source-manifest first, then MANIFEST.
Never hash MANIFEST. Do not invoke the recorder after this script runs."""
from __future__ import annotations

import datetime
import hashlib
import json
from pathlib import Path

WORK = Path("/home/charl/defiformal-wt-p19-certificates-grok-opus-20260909")
EVIDENCE = WORK / "review/semantic-kernel/certificates/p19/implementation/grok-20260919-r3"
CERT = WORK / "lean/DefiKernel/Certificates"
TOOL = Path("/home/charl/.elan/toolchains/leanprover--lean4---v4.33.0-rc2/bin")
NOW = datetime.datetime.now(datetime.timezone.utc).isoformat()
GIT = "38de83c58e3f9315bf400807591d538d7565152e"


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def meta(path: Path) -> dict:
    data = path.read_bytes()
    return {"sha256": hashlib.sha256(data).hexdigest(), "bytes": len(data),
            "lines": data.decode("utf-8", errors="replace").count("\n")}


REPORT = r"""# P19 grok-20260919-r3: universal scanner success and codec roundtrip

- **Attempt**: `grok-20260919-r3`
- **Author**: Grok 4.6 (native implementation)
- **Checker**: pending independent GPT-6 Astra medium
- **Disposition**: `PARTIAL`
- **Build**: `DefiKernel.Certificates.Verify` compiled after Lexical checker correspondence; 943 jobs, forbidden axioms 0

## What this round proved

R2 left `h_lex` open on nonempty `encodeList` / `encodeObj`. This round proves a structural `scanLexicalFuel` continuation for every `TreeJson.Valid` tree at depth `≤ 64` and array length `≤ 4096`, then specializes the wrapper `scanLexical` to production `encodeModule`. Unchanged `StructurallyAdmissibleIR` already supplies `SerializedByteBound` (1 MiB), `WholeDocumentDepthBounded`, `TreeJson.Valid`, and an opening object brace. The existing `EncodeDecodeRoundtripStatement` therefore holds. Checker routing `checkBytes (encodeModule ir) = checkIR ir` follows.

Core scanner theorems:

```lean
theorem scanLexicalFuel_encode (t : TreeJson) (fuel : Nat) (rest : List Char)
    (depth : Nat) (scopes : List LexScope)
    (h_not_key : notExpectKey scopes)
    (h_depth : depth + TreeJson.depth t ≤ 64)
    (h_valid : TreeJson.Valid t) :
    scanLexicalFuel (fuel + scanCost t) ((TreeJson.encode t).toList ++ rest)
        depth scopes [] false =
      scanLexicalFuel fuel rest depth scopes (numBuf t) false

theorem scanLexical_encodeModule (ir : DecodedIR)
    (h_adm : StructurallyAdmissibleIR ir) :
    scanLexical (encodeModule ir) = .ok ()
```

## Strongest new theorem

```lean
theorem encode_decode_roundtrip : EncodeDecodeRoundtripStatement
```

which is the existing statement

```lean
∀ (ir : DecodedIR), StructurallyAdmissibleIR ir →
  decodeBytes (encodeModule ir) = .ok ir
```

No extra `h_lex` or `h_depth` hypothesis. Admission is unchanged `StructurallyAdmissibleIR`. Axioms: `propext`, `Classical.choice`, `Quot.sound` only.

Checker correspondence:

```lean
theorem checkBytes_encodeModule (ir : DecodedIR)
    (h_adm : StructurallyAdmissibleIR ir) :
    checkBytes (encodeModule ir) = checkIR ir
```

with typed / step / run specializations to `checkTyped` / `checkStep` / `checkRun`.

## Still open

1. **P19 campaigns / host / schema overlay**: 99 scenarios and 16 mutants were not rerun (unchanged 54/21/7 campaigns forbidden). Overlay, schema-hash, expectedIR, and trusted-host gates were not newly verified this round.
2. **P20 21.2 / 21.3**: executable `Parallel.admit` / `checkCompatibility` on recomputed footprints, and Lean-checked library instantiation, remain.
3. **P19/P20 acceptance**: not claimed. Independent Astra review of this candidate is pending. This report does not accept the candidate.

## Source contract

- R1 `DepthBridge.lean` SHA `bd7e639f0cfb0f03504d0b7399c07f43644767af5495bf39a3c93841f6d0e365` preserved.
- R1 `IRDepth.lean` SHA `ae245b2f2bf92697b0a25551638d87a8bd641f0a9a3efe7e373fe89afb8aa0c8` preserved.
- Historical Roundtrip 246 declarations preserved. Roundtrip SHA `a12a00feade30877cc1bc18e06caf68f9e59cb47e49195a3e788c59bfbff94b1` unchanged.
- CompositionDepth SHA `7fc24af43b856514e97a60f721597ff04cad3e8a5477d65b303660837e097168` unchanged from R2.
- Production edits: `lean/DefiKernel/Certificates/Lexical.lean` only. `Verify.lean` already imported Lexical in R2.
- No existing theorem statements, signatures, or docstrings changed.
- No `sorry`, `native_decide`, custom axioms, `h_depth`/`h_lex` added to admission, or alternate codec.

## New compiled declarations

Lexical: 113 top-level `def`/`theorem` matches plus mutual `scanCost`/`scanCostList`/`scanCostObj` (116 declarations). R2 had 60 top-level plus 3 mutual (63). This round added 53 Lexical declarations. CompositionDepth remains 15 theorems, unchanged.

Explicit `#print axioms` on 121 fully qualified names (every Lexical declaration plus five CompositionDepth theorems) reports only `propext`, `Classical.choice`, `Quot.sound`, or no axioms. Zero unknown identifiers.

## Verification recorded this round

| Check | Result |
|---|---|
| `helpers-encodelist-v1` first encodeList compile | exit 1; Disjoint implicits and fuel association; preserved |
| `lake build DefiKernel.Certificates.Lexical` | exit 0, 938 jobs |
| `lake build DefiKernel.Certificates.Verify` | exit 0, 943 jobs, forbidden=0 |
| `#print axioms` Lexical snapshot before checker corollaries | exit 0, 117/117 names, standard axioms |
| Inline axiom helper on CompositionDepth and Lexical | CompositionDepth 15/15 standard; Lexical unresolved without namespace (exit 1; same helper coverage failure as R2) |
| `lake build DefiKernel.Certificates.Lexical` after `checkBytes_encodeModule` | exit 0, 938 jobs |
| `lake build DefiKernel.Certificates.Verify` final | exit 0, 943 jobs, forbidden=0, 287/287 theorems, 408/408 supplemental |
| `#print axioms` final 121 fully qualified names | exit 0, 121/121, standard axioms only |

Toolchain remains Lean/mathlib `v4.33.0-rc2`. No `lake update`.

Root recorder `record-author-r3-command.py` writes evidence under `grok-20260919-r3`. R1 and R2 evidence were not rewritten.

## Evidence seal

All recorded compiler/probe commands finished before this report. REPORT, verdict, source-manifest, and MANIFEST were written by an unrecorded `seal-r3.py` after those commands. MANIFEST is self-excluded.
"""

VERDICT = {
    "timestamp_utc": NOW,
    "attempt": "grok-20260919-r3",
    "status": "PARTIAL",
    "disposition": "USABLE",
    "author": "grok-4.6",
    "auditor": "pending gpt-6-astra medium",
    "production_source_changed": True,
    "P19_accepted": False,
    "strongest_compiled_theorem": "encode_decode_roundtrip",
    "strongest_compiled_theorem_signature": (
        "theorem encode_decode_roundtrip : EncodeDecodeRoundtripStatement"
    ),
    "EncodeDecodeRoundtripStatement": (
        "∀ (ir : DecodedIR), StructurallyAdmissibleIR ir → "
        "decodeBytes (encodeModule ir) = .ok ir"
    ),
    "scanner_theorem": "scanLexical_encodeModule",
    "scanner_theorem_signature": (
        "theorem scanLexical_encodeModule (ir : DecodedIR) "
        "(h_adm : StructurallyAdmissibleIR ir) : "
        "scanLexical (encodeModule ir) = .ok ()"
    ),
    "checker_correspondence": "checkBytes_encodeModule",
    "checker_correspondence_signature": (
        "theorem checkBytes_encodeModule (ir : DecodedIR) "
        "(h_adm : StructurallyAdmissibleIR ir) : "
        "checkBytes (encodeModule ir) = checkIR ir"
    ),
    "strongest_general_theorem_unchanged": "decodeBytes_encodeModule_of_depth_and_lex",
    "h_depth_discharged": True,
    "h_lex_discharged": True,
    "EncodeDecodeRoundtripStatement_proved": True,
    "unproved_hypotheses": [],
    "remaining_outside_codec": [
        "P19 overlay/schema/hash/expectedIR/trustedhost and 99-scenario/16-mutant campaigns not rerun",
        "P20 21.2 executable Parallel.admit/checkCompatibility on recomputed footprints",
        "P20 21.3 Lean-checked library instantiation",
        "independent Astra review of this candidate",
        "remaining P37 sprint requirements",
    ],
    "discharged_this_round": [
        "scanCost / lastNumBuf / visited-key disjointness / array comma-count helpers",
        "scanLexicalFuel_encodeList nonempty induction with cnt + xs.length ≤ 4096",
        "scanLexicalFuel_encodeObj nonempty induction with Nodup and Disjoint visited keys",
        "scanLexicalFuel_encode for every TreeJson.Valid tree at depth + t.depth ≤ 64",
        "scanLexical_encodeModule for every StructurallyAdmissibleIR",
        "encode_decode_roundtrip = EncodeDecodeRoundtripStatement",
        "checkBytes_encodeModule and typed/step/run specializations",
    ],
    "new_modules": [
        "lean/DefiKernel/Certificates/CompositionDepth.lean",
        "lean/DefiKernel/Certificates/Lexical.lean",
    ],
    "production_files_edited_this_round": [
        "lean/DefiKernel/Certificates/Lexical.lean",
    ],
    "preserved_r1_modules": {
        "lean/DefiKernel/Certificates/DepthBridge.lean":
            "bd7e639f0cfb0f03504d0b7399c07f43644767af5495bf39a3c93841f6d0e365",
        "lean/DefiKernel/Certificates/IRDepth.lean":
            "ae245b2f2bf92697b0a25551638d87a8bd641f0a9a3efe7e373fe89afb8aa0c8",
        "lean/DefiKernel/Certificates/Roundtrip.lean":
            "a12a00feade30877cc1bc18e06caf68f9e59cb47e49195a3e788c59bfbff94b1",
    },
    "preserved_r2_compositiondepth":
        "7fc24af43b856514e97a60f721597ff04cad3e8a5477d65b303660837e097168",
    "roundtrip_declarations_preserved": 246,
    "new_theorems_compositiondepth": 15,
    "lexical_declarations_top_level": 113,
    "lexical_declarations_mutual_scanCost": 3,
    "lexical_declarations_total": 116,
    "lexical_declarations_added_this_round": 53,
    "axiom_print_names": 121,
    "axiom_print_resolved": 121,
    "forbidden_axioms_count": 0,
    "sorry_count": 0,
    "native_decide_count": 0,
    "verify_jobs": 943,
    "verify_theorems_audit": "287/287",
    "verify_supplemental_audit": "408/408",
    "fixtures_rerun": False,
    "unit_tests_rerun": False,
    "recorded_commands": 8,
    "recorded_commands_pass": [
        "build-lexical",
        "build-verify",
        "print-axioms-lexical",
        "build-lexical-checkbytes",
        "build-verify-final",
        "print-axioms-final",
    ],
    "recorded_commands_fail": [
        "helpers-encodelist-v1",
        "axiom-scan-inline",
    ],
    "git_head": GIT,
}


def main() -> None:
    sources = {}
    for path in sorted(CERT.glob("*.lean")):
        rel = str(path.relative_to(WORK))
        sources[rel] = meta(path)
    source_manifest = {
        "schema": "defiformal-p19-source-manifest/v2",
        "timestamp_utc": NOW,
        "git_head": GIT,
        "lean_version": (
            "Lean (version 4.33.0-rc2, x86_64-unknown-linux-gnu, "
            "commit d8b18978322de05a8f3dba51ef03cf5461676c17, Release)"
        ),
        "lean_executable": str(TOOL / "lean"),
        "cwd": str(WORK / "lean"),
        "sources": sources,
        "r1_depthbridge_sha256_preserved": sources["lean/DefiKernel/Certificates/DepthBridge.lean"]["sha256"]
            == "bd7e639f0cfb0f03504d0b7399c07f43644767af5495bf39a3c93841f6d0e365",
        "r1_irdepth_sha256_preserved": sources["lean/DefiKernel/Certificates/IRDepth.lean"]["sha256"]
            == "ae245b2f2bf92697b0a25551638d87a8bd641f0a9a3efe7e373fe89afb8aa0c8",
        "roundtrip_sha256_preserved": sources["lean/DefiKernel/Certificates/Roundtrip.lean"]["sha256"]
            == "a12a00feade30877cc1bc18e06caf68f9e59cb47e49195a3e788c59bfbff94b1",
        "r2_compositiondepth_sha256_preserved": sources["lean/DefiKernel/Certificates/CompositionDepth.lean"]["sha256"]
            == "7fc24af43b856514e97a60f721597ff04cad3e8a5477d65b303660837e097168",
    }
    (EVIDENCE / "REPORT.md").write_text(REPORT)
    (EVIDENCE / "verdict.json").write_text(json.dumps(VERDICT, indent=2) + "\n")
    (EVIDENCE / "source-manifest.json").write_text(json.dumps(source_manifest, indent=2) + "\n")

    files = []
    for path in sorted(EVIDENCE.rglob("*")):
        if not path.is_file():
            continue
        if path.name == "MANIFEST.json":
            continue
        rel = str(path.relative_to(EVIDENCE))
        files.append({"path": rel, "sha256": sha(path), "bytes": path.stat().st_size})
    for path in [
        WORK / "lean/DefiKernel/Certificates/CompositionDepth.lean",
        WORK / "lean/DefiKernel/Certificates/Lexical.lean",
        WORK / "lean/DefiKernel/Certificates/Verify.lean",
        WORK / "lean/DefiKernel/Certificates/DepthBridge.lean",
        WORK / "lean/DefiKernel/Certificates/IRDepth.lean",
        WORK / "lean/DefiKernel/Certificates/Roundtrip.lean",
    ]:
        files.append({
            "path": str(path.relative_to(WORK)),
            "sha256": sha(path),
            "bytes": path.stat().st_size,
        })
    manifest = {
        "schema": "defiformal-p19-manifest/v2",
        "attempt": "grok-20260919-r3",
        "timestamp_utc": NOW,
        "git_head": GIT,
        "status": "PARTIAL",
        "disposition": "USABLE",
        "author": "grok-4.6",
        "auditor": "pending gpt-6-astra medium",
        "self_excluded": True,
        "seal_script": "seal-r3.py",
        "recorded_commands_finished_before_seal": True,
        "strongest_compiled_theorem": {
            "name": "DefiKernel.Certificates.encode_decode_roundtrip",
            "signature": VERDICT["strongest_compiled_theorem_signature"],
            "statement": VERDICT["EncodeDecodeRoundtripStatement"],
            "unproved_hypotheses": VERDICT["unproved_hypotheses"],
        },
        "files": files,
    }
    (EVIDENCE / "MANIFEST.json").write_text(json.dumps(manifest, indent=2) + "\n")
    print(json.dumps({
        "sealed_utc": NOW,
        "report": sha(EVIDENCE / "REPORT.md"),
        "verdict": sha(EVIDENCE / "verdict.json"),
        "source_manifest": sha(EVIDENCE / "source-manifest.json"),
        "manifest_bytes": (EVIDENCE / "MANIFEST.json").stat().st_size,
        "manifest_entries": len(files),
        "manifest_self_excluded": True,
    }, indent=2))


if __name__ == "__main__":
    main()
