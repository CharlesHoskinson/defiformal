# Preserved failed attempts (grok-20260919-r4)

- `compile-verify-r1` / `compile-soundness-r2`: Soundness proofs broke when `checkTyped` gained a `recordsMatch` refusal after the git pin. Existing `checkTyped_execute_ok` / `_error` statements assume git equality is enough. Reverted that control-flow change; path+sha256 matching lives in `TrustedHost` plus the host runner.
- `mutant-m01` (exit 3): inherited runner required Git HEAD blobs. Uncommitted candidate files are absent from frozen revision. Retried with `--bind-working-tree`.
- `fixtures-full-r1` (exit 1): independent expected incorrectly rewrote every codec fixture with unsorted `source_map` keys to `noncanonicalWhitespace`, including earlier-precedence failures. Restricted the override to originally-ok codec fixtures (F13/F28). Sequential step errors restored `compositionCompatible = false`.
