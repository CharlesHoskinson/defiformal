import DefiKernel.Certificates.TrustedHost
import DefiKernel.Certificates.LibraryInstantiation
import DefiKernel.Certificates.Check
import DefiKernel.Certificates.Encode
import DefiKernel.Certificates.Tests

/-! Explicit `#print axioms` on new R4 declarations, including generated/private names
    reachable from the named theorems. -/

#print axioms DefiKernel.Certificates.TrustedHost.gitSha
#print axioms DefiKernel.Certificates.TrustedHost.leanToolchain
#print axioms DefiKernel.Certificates.TrustedHost.mathlibRev
#print axioms DefiKernel.Certificates.TrustedHost.grammarSha256
#print axioms DefiKernel.Certificates.TrustedHost.schemaSha256
#print axioms DefiKernel.Certificates.TrustedHost.recordToken
#print axioms DefiKernel.Certificates.TrustedHost.recordStringAdmissible
#print axioms DefiKernel.Certificates.TrustedHost.recordsMatch
#print axioms DefiKernel.Certificates.TrustedHost.gitMatches
#print axioms DefiKernel.Certificates.LibraryInstantiation.instantiated_add_ok_iff
#print axioms DefiKernel.Certificates.LibraryInstantiation.namesDischarged
#print axioms DefiKernel.Certificates.outstandingFamilies
#print axioms DefiKernel.Certificates.libraryJudgment
#print axioms DefiKernel.Certificates.sourceRefinementJudgment
#print axioms DefiKernel.Certificates.invokeSteps
#print axioms DefiKernel.Certificates.splitInvokeBranches
#print axioms DefiKernel.Certificates.recomputeAdmit
#print axioms DefiKernel.Certificates.compositionCompatibleOutcome
#print axioms DefiKernel.Certificates.checkTyped
#print axioms DefiKernel.Certificates.checkStep
#print axioms DefiKernel.Certificates.checkRun
#print axioms DefiKernel.Certificates.Tests.checkTrustedGitDistinct
#print axioms DefiKernel.Certificates.Tests.checkLibraryInstantiation
