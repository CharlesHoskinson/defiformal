import Mathlib.Data.Rat.Defs
import Mathlib.Algebra.BigOperators.Group.Finset.Basic
import Mathlib.Data.Fintype.Prod
import Mathlib.Tactic.Linarith
import Lean.Data.Json.Basic
import Lean.Data.Json
import Mathlib.Data.Nat.Basic


/-! Reusable finite-ledger identities and dimensioned values. Identity authentication,
observation truth and the finite deployment universe are external assumptions. -/
namespace DefiKernel.Typed

structure ClaimId where
  value : Nat
  deriving DecidableEq, Repr

structure CapabilityId where
  value : Nat
  deriving DecidableEq, Repr

structure OperationId where
  value : Nat
  deriving DecidableEq, Repr

structure ObservationId where
  value : Nat
  deriving DecidableEq, Repr

abbrev Cell (Party Asset Domain : Type) := Domain × Party × Asset

/-- Amount expressions can be signed; a quantity is explicitly nonnegative. -/
structure Quantity {Asset : Type} (asset : Asset) where
  amount : ℚ
  nonneg : 0 ≤ amount

structure State (Party Asset Domain : Type) where
  balance : Cell Party Asset Domain → ℚ
  nonneg : ∀ c, 0 ≤ balance c

def total {Party Asset Domain : Type} [Fintype Party]
    (s : State Party Asset Domain) (domain : Domain) (asset : Asset) : ℚ :=
  ∑ party, s.balance (domain, party, asset)

/-- A price is quote-asset units per one base-asset unit. -/
inductive Unit (Asset : Type) where
  | amount (asset : Asset)
  | price (base quote : Asset)
  | scalar
  | bool
  deriving DecidableEq, Repr

/-- Numeric dimensions exclude booleans without a user-supplied typeclass. -/
inductive NumericUnit (Asset : Type) where
  | amount (asset : Asset)
  | price (base quote : Asset)
  | scalar
  deriving DecidableEq, Repr

abbrev NumericUnit.toUnit {Asset : Type} : NumericUnit Asset → Unit Asset
  | .amount a => .amount a
  | .price a b => .price a b
  | .scalar => .scalar

abbrev Value {Asset : Type} : Unit Asset → Type
  | .bool => Bool
  | .amount _ | .price _ _ | .scalar => ℚ

instance {Asset : Type} (u : Unit Asset) : DecidableEq (Value u) := by
  cases u <;> exact inferInstance

instance {Asset : Type} (u : Unit Asset) : Repr (Value u) := by
  cases u <;> exact inferInstance

def numericValue {Asset : Type} (u : NumericUnit Asset) (q : ℚ) : Value u.toUnit :=
  match u with
  | .amount _ | .price _ _ | .scalar => q

def numericRat {Asset : Type} (u : NumericUnit Asset) (v : Value u.toUnit) : ℚ :=
  match u with
  | .amount _ | .price _ _ | .scalar => v

abbrev PackedValue (Asset : Type) := (u : Unit Asset) × Value u

inductive EvalFailure where
  | argumentCount
  | argumentUnit
  | partyArgument
  | missingObservation
  | observationUnit
  | divisionByZero
  deriving DecidableEq, Repr

inductive PartyRef (Party : Type) where
  | caller
  | literal (party : Party)
  | argument (index : Nat)
  deriving DecidableEq, Repr

def PartyRef.resolve {Party : Type} (caller : Party) (parties : List Party) :
    PartyRef Party → Except EvalFailure Party
  | .caller => .ok caller
  | .literal p => .ok p
  | .argument n => match parties[n]? with
    | some p => .ok p
    | none => .error .partyArgument

structure CellRef (Party Asset Domain : Type) (asset : Asset) where
  domain : Domain
  owner : PartyRef Party
  deriving DecidableEq, Repr

def CellRef.resolve {Party Asset Domain : Type} {asset : Asset}
    (caller : Party) (parties : List Party) (c : CellRef Party Asset Domain asset) :
    Except EvalFailure (Cell Party Asset Domain) := do
  let party ← c.owner.resolve caller parties
  return (c.domain, party, asset)

structure ObservationKey (Domain : Type) where
  domain : Domain
  id : ObservationId
  deriving DecidableEq, Repr

/-- Expected unit is intrinsic; the environment's delivered unit is checked at lookup. -/
structure ObservationRef (Asset Domain : Type) (unit : Unit Asset) where
  key : ObservationKey Domain
  deriving DecidableEq, Repr

structure Observation (Asset : Type) where
  value : PackedValue Asset
  timestamp : Nat

abbrev Environment (Asset Domain : Type) := ObservationKey Domain → Option (Observation Asset)

/-- Adapter-supplied identity. Constructing this value is not signature verification. -/
structure InvocationContext (Party Domain : Type) where
  principal : Party
  domain : Domain
  deriving DecidableEq, Repr


end DefiKernel.Typed


/-! A closed dimensioned expression language. All arithmetic is exact rational arithmetic.
Read sets conservatively include both conditional branches. Environment truth is assumed. -/
namespace DefiKernel.Typed

inductive Var {Asset : Type} : List (Unit Asset) → Unit Asset → Type where
  | here {u : Unit Asset} {signature : List (Unit Asset)} : Var (u :: signature) u
  | there {u v : Unit Asset} {signature : List (Unit Asset)} :
      Var signature u → Var (v :: signature) u

inductive Args {Asset : Type} : List (Unit Asset) → Type where
  | nil : Args []
  | cons {u : Unit Asset} {signature : List (Unit Asset)} :
      Value u → Args signature → Args (u :: signature)

def Args.get {Asset : Type} {signature : List (Unit Asset)} {u : Unit Asset} :
    Args signature → Var signature u → Value u
  | .cons value _, .here => value
  | .cons _ rest, .there v => rest.get v

/-- Check arity and every delivered unit before exposing typed arguments to evaluation. -/
def Args.check {Asset : Type} [DecidableEq Asset] (signature : List (Unit Asset))
    (values : List (PackedValue Asset)) : Except EvalFailure (Args signature) :=
  match signature, values with
  | [], [] => .ok .nil
  | u :: us, ⟨v, value⟩ :: vs =>
    if h : v = u then do
      let rest ← Args.check us vs
      return .cons (h ▸ value) rest
    else .error .argumentUnit
  | _, _ => .error .argumentCount

inductive UnaryOp (Asset : Type) : Unit Asset → Unit Asset → Type where
  | neg (u : NumericUnit Asset) : UnaryOp Asset u.toUnit u.toUnit
  | not : UnaryOp Asset .bool .bool

inductive BinaryOp (Asset : Type) : Unit Asset → Unit Asset → Unit Asset → Type where
  | add (u : NumericUnit Asset) : BinaryOp Asset u.toUnit u.toUnit u.toUnit
  | sub (u : NumericUnit Asset) : BinaryOp Asset u.toUnit u.toUnit u.toUnit
  | scale (u : NumericUnit Asset) : BinaryOp Asset .scalar u.toUnit u.toUnit
  | divide (u : NumericUnit Asset) : BinaryOp Asset u.toUnit .scalar u.toUnit
  | ratio (u : NumericUnit Asset) : BinaryOp Asset u.toUnit u.toUnit .scalar
  | convert (base quote : Asset) : BinaryOp Asset (.amount base) (.price base quote) (.amount quote)
  | unconvert (base quote : Asset) :
      BinaryOp Asset (.amount quote) (.price base quote) (.amount base)
  | le (u : NumericUnit Asset) : BinaryOp Asset u.toUnit u.toUnit .bool
  | lt (u : NumericUnit Asset) : BinaryOp Asset u.toUnit u.toUnit .bool
  | eq (u : Unit Asset) : BinaryOp Asset u u .bool
  | and : BinaryOp Asset .bool .bool .bool
  | or : BinaryOp Asset .bool .bool .bool

def UnaryOp.eval {Asset : Type} {u v : Unit Asset} :
    UnaryOp Asset u v → Value u → Value v
  | .neg n, x => numericValue n (- numericRat n x)
  | .not, x => !x

/-- Division checks its denominator explicitly; rational division is otherwise total at zero. -/
def BinaryOp.eval {Asset : Type} {u v w : Unit Asset} :
    BinaryOp Asset u v w → Value u → Value v → Except EvalFailure (Value w)
  | .add n, x, y => .ok (numericValue n (numericRat n x + numericRat n y))
  | .sub n, x, y => .ok (numericValue n (numericRat n x - numericRat n y))
  | .scale n, x, y => .ok (numericValue n (x * numericRat n y))
  | .divide n, x, y =>
    if y = 0 then .error .divisionByZero else .ok (numericValue n (numericRat n x / y))
  | .ratio n, x, y =>
    if numericRat n y = 0 then .error .divisionByZero
    else .ok (numericRat n x / numericRat n y)
  | .convert _ _, x, y => .ok (x * y)
  | .unconvert _ _, x, y =>
    if y = 0 then .error .divisionByZero else .ok (x / y)
  | .le n, x, y => .ok (decide (numericRat n x ≤ numericRat n y))
  | .lt n, x, y => .ok (decide (numericRat n x < numericRat n y))
  | .eq _, x, y => .ok (decide (x = y))
  | .and, x, y => .ok (x && y)
  | .or, x, y => .ok (x || y)

inductive Expr (Party Asset Domain : Type) (signature : List (Unit Asset)) :
    Unit Asset → Type where
  | lit {u} (value : Value u) : Expr Party Asset Domain signature u
  | arg {u} (v : Var signature u) : Expr Party Asset Domain signature u
  | balance {a} (cell : CellRef Party Asset Domain a) :
      Expr Party Asset Domain signature (.amount a)
  | observe {u} (key : ObservationRef Asset Domain u) : Expr Party Asset Domain signature u
  | timestamp (key : ObservationKey Domain) : Expr Party Asset Domain signature .scalar
  | now : Expr Party Asset Domain signature .scalar
  | unary {u v} (op : UnaryOp Asset u v) (x : Expr Party Asset Domain signature u) :
      Expr Party Asset Domain signature v
  | binary {u v w} (op : BinaryOp Asset u v w)
      (x : Expr Party Asset Domain signature u) (y : Expr Party Asset Domain signature v) :
      Expr Party Asset Domain signature w
  | ite {u} (condition : Expr Party Asset Domain signature .bool)
      (yes no : Expr Party Asset Domain signature u) : Expr Party Asset Domain signature u

abbrev PackedCellRef (Party Asset Domain : Type) :=
  (asset : Asset) × CellRef Party Asset Domain asset

inductive EnvRead (Domain : Type) where
  | observation (key : ObservationKey Domain)
  | currentTime
  deriving DecidableEq, Repr

structure EvalContext (Party Asset Domain : Type) (signature : List (Unit Asset)) where
  state : State Party Asset Domain
  env : Environment Asset Domain
  caller : Party
  parties : List Party
  args : Args signature
  now : Nat

def readBalance {Party Asset Domain : Type} {signature : List (Unit Asset)}
    (ctx : EvalContext Party Asset Domain signature) (ref : PackedCellRef Party Asset Domain) :
    Except EvalFailure ℚ := do
  let c ← ref.2.resolve ctx.caller ctx.parties
  return ctx.state.balance c

def readObservation {Asset Domain : Type} [DecidableEq Asset] {u : Unit Asset}
    (env : Environment Asset Domain) (ref : ObservationRef Asset Domain u) :
    Except EvalFailure (Value u) :=
  match env ref.key with
  | none => .error .missingObservation
  | some observation =>
    if h : observation.value.1 = u then .ok (h ▸ observation.value.2)
    else .error .observationUnit

/-- Binary operators, including boolean and/or, evaluate both operands. Only `ite`
selects a branch lazily. Read inventories conservatively include every branch. -/
def Expr.eval {Party Asset Domain : Type} [DecidableEq Asset]
    {signature : List (Unit Asset)} {u : Unit Asset}
    (ctx : EvalContext Party Asset Domain signature) :
    Expr Party Asset Domain signature u → Except EvalFailure (Value u)
  | .lit value => .ok value
  | .arg v => .ok (ctx.args.get v)
  | .balance ref => readBalance ctx ⟨_, ref⟩
  | .observe ref => readObservation ctx.env ref
  | .timestamp key => match ctx.env key with
    | none => .error .missingObservation
    | some observation => .ok observation.timestamp
  | .now => .ok ctx.now
  | .unary op x => do return op.eval (← x.eval ctx)
  | .binary op x y => do op.eval (← x.eval ctx) (← y.eval ctx)
  | .ite condition yes no => do
    if ← condition.eval ctx then yes.eval ctx else no.eval ctx

/-- Syntactic reads include inactive branches and all expression children. -/
def Expr.stateReads {Party Asset Domain : Type} {signature : List (Unit Asset)} {u : Unit Asset} :
    Expr Party Asset Domain signature u → List (PackedCellRef Party Asset Domain)
  | .balance ref => [⟨_, ref⟩]
  | .unary _ x => x.stateReads
  | .binary _ x y => x.stateReads ++ y.stateReads
  | .ite condition yes no => condition.stateReads ++ yes.stateReads ++ no.stateReads
  | .lit _ | .arg _ | .observe _ | .timestamp _ | .now => []

def Expr.envReads {Party Asset Domain : Type} {signature : List (Unit Asset)} {u : Unit Asset} :
    Expr Party Asset Domain signature u → List (EnvRead Domain)
  | .observe ref => [.observation ref.key]
  | .timestamp key => [.observation key]
  | .now => [.currentTime]
  | .unary _ x => x.envReads
  | .binary _ x y => x.envReads ++ y.envReads
  | .ite condition yes no => condition.envReads ++ yes.envReads ++ no.envReads
  | .lit _ | .arg _ | .balance _ => []

def Expr.resolveStateReads {Party Asset Domain : Type} {signature : List (Unit Asset)}
    {u : Unit Asset} (caller : Party) (parties : List Party)
    (expression : Expr Party Asset Domain signature u) :
    Except EvalFailure (List (Cell Party Asset Domain)) :=
  expression.stateReads.mapM (fun ref ↦ ref.2.resolve caller parties)

def EnvRead.Agree {Party Asset Domain : Type} {signature : List (Unit Asset)}
    (left right : EvalContext Party Asset Domain signature) : EnvRead Domain → Prop
  | .observation key => left.env key = right.env key
  | .currentTime => left.now = right.now


end DefiKernel.Typed


/-! Nondelegating capability administration under a trusted actor, domain administrator and
operation-domain lookup. List positions are permanent IDs: revoked entries remain as tombstones.
Authentication, registry truth, allowances and replay prevention are outside this model. -/
namespace DefiKernel.Typed

inductive Right (Party Asset Domain : Type) where
  | invoke
  | debit (cell : Cell Party Asset Domain)
  | changeSupply (domain : Domain) (asset : Asset)
  deriving DecidableEq, Repr

def Right.inDomain {Party Asset Domain : Type} [DecidableEq Domain]
    (right : Right Party Asset Domain) (domain : Domain) : Bool :=
  match right with
  | .invoke => true
  | .debit cell => decide (cell.1 = domain)
  | .changeSupply d _ => decide (d = domain)

structure Grant (Party Asset Domain : Type) where
  holder : Party
  domain : Domain
  operation : OperationId
  right : Right Party Asset Domain
  deriving DecidableEq, Repr

structure Capability (Party Asset Domain : Type) extends Grant Party Asset Domain where
  live : Bool
  deriving DecidableEq, Repr

/-- The adapter supplies this immutable configuration, separately from caller requests. -/
structure AuthorityConfig (Party Domain : Type) where
  domainAdmin : Domain → Party
  operationDomain : OperationId → Option Domain

/-- No entry is removed; length is the next fresh ID, so no separate counter invariant is needed. -/
structure CapabilityStore (Party Asset Domain : Type) where
  entries : List (Capability Party Asset Domain)
  deriving DecidableEq, Repr

def CapabilityStore.empty {Party Asset Domain : Type} : CapabilityStore Party Asset Domain := ⟨[]⟩

def CapabilityStore.nextId {Party Asset Domain : Type}
    (store : CapabilityStore Party Asset Domain) : CapabilityId := ⟨store.entries.length⟩

def CapabilityStore.lookup {Party Asset Domain : Type}
    (store : CapabilityStore Party Asset Domain) (id : CapabilityId) := store.entries[id.value]?

inductive AuthorityFailure where
  | unauthorizedAdmin
  | operationDomain
  | resourceDomain
  | unknownCapability
  deriving DecidableEq, Repr

variable {Party Asset Domain : Type}
variable [DecidableEq Party] [DecidableEq Asset] [DecidableEq Domain]

def isDomainAdmin (config : AuthorityConfig Party Domain) (ctx : InvocationContext Party Domain)
    (domain : Domain) : Bool :=
  decide (ctx.domain = domain ∧ ctx.principal = config.domainAdmin domain)

/-- A grant cannot choose its ID or reactivate an existing entry. -/
def issueCapability (config : AuthorityConfig Party Domain) (ctx : InvocationContext Party Domain)
    (store : CapabilityStore Party Asset Domain) (grant : Grant Party Asset Domain) :
    Except AuthorityFailure (CapabilityId × CapabilityStore Party Asset Domain) :=
  if isDomainAdmin config ctx grant.domain then
    if config.operationDomain grant.operation = some grant.domain then
      if grant.right.inDomain grant.domain then
        .ok (store.nextId, ⟨store.entries ++ [⟨grant, true⟩]⟩)
      else .error .resourceDomain
    else .error .operationDomain
  else .error .unauthorizedAdmin

/-- Revocation is idempotent and retains the ID permanently, including its original scope. -/
def revokeCapability (config : AuthorityConfig Party Domain) (ctx : InvocationContext Party Domain)
    (store : CapabilityStore Party Asset Domain) (id : CapabilityId) :
    Except AuthorityFailure (CapabilityStore Party Asset Domain) :=
  match store.lookup id with
  | none => .error .unknownCapability
  | some cap =>
    if isDomainAdmin config ctx cap.domain then
      .ok ⟨store.entries.set id.value { cap with live := false }⟩
    else .error .unauthorizedAdmin

/-- Each supplied ID must itself pass all scope checks to contribute an exact right. -/
def authorizesId (store : CapabilityStore Party Asset Domain)
    (ctx : InvocationContext Party Domain) (operation : OperationId)
    (right : Right Party Asset Domain) (id : CapabilityId) : Bool :=
  match store.lookup id with
  | none => false
  | some cap => decide (cap.live = true ∧ cap.holder = ctx.principal ∧
      cap.domain = ctx.domain ∧ cap.operation = operation ∧ cap.right = right ∧
      right.inDomain ctx.domain = true)

/-- Existential use means duplicate request IDs confer no additional rights. -/
def hasAuthority (store : CapabilityStore Party Asset Domain)
    (ids : List CapabilityId) (ctx : InvocationContext Party Domain)
    (operation : OperationId) (right : Right Party Asset Domain) : Bool :=
  ids.any (authorizesId store ctx operation right)


end DefiKernel.Typed


/-! Registered first-order transitions. Checks concern aggregate net effects; they do not model
intermediate debit order, consumable allowances, replay prevention, or observation truth. -/
namespace DefiKernel.Typed

structure CellDelta (Party Asset Domain : Type) (signature : List (Unit Asset)) where
  asset : Asset
  target : CellRef Party Asset Domain asset
  amount : Expr Party Asset Domain signature (.amount asset)

structure SupplyDelta (Party Asset Domain : Type) (signature : List (Unit Asset)) where
  domain : Domain
  asset : Asset
  amount : Expr Party Asset Domain signature (.amount asset)

structure Template (Party Asset Domain : Type) where
  signature : List (Unit Asset)
  domain : Domain
  partyArity : Nat
  guard : Expr Party Asset Domain signature .bool
  deltas : List (CellDelta Party Asset Domain signature)
  supplyDeltas : List (SupplyDelta Party Asset Domain signature)
  stateReads : List (PackedCellRef Party Asset Domain)
  envReads : List (EnvRead Domain)
  writes : List (PackedCellRef Party Asset Domain)

abbrev Registry (Party Asset Domain : Type) := OperationId → Option (Template Party Asset Domain)

/-- Issuance and execution use the same trusted registry to determine the operation domain. -/
def registryAuthorityConfig {Party Asset Domain : Type} (registry : Registry Party Asset Domain)
    (domainAdmin : Domain → Party) : AuthorityConfig Party Domain :=
  ⟨domainAdmin, fun operation ↦ (registry operation).map Template.domain⟩

structure Request (Party Asset Domain : Type) where
  operation : OperationId
  parties : List Party
  arguments : List (PackedValue Asset)
  capabilityIds : List CapabilityId
  claimedActor : Option Party := none

inductive Refusal where
  | unknownOperation
  | actorMismatch
  | domainMismatch
  | partyArity
  | evaluation (reason : EvalFailure)
  | unauthorizedInvoke
  | guard
  | stateReadFootprint
  | envReadFootprint
  | crossDomain
  | unauthorizedDebit
  | unauthorizedSupply
  | insufficientFunds
  | accounting
  | writeFootprint
  deriving DecidableEq, Repr

/-- Internal evaluated data; caller requests cannot supply this record to `execute`. -/
structure Evaluated (Party Asset Domain : Type) where
  guard : Bool
  deltas : List (Cell Party Asset Domain × ℚ)
  supplies : List ((Domain × Asset) × ℚ)
  requiredStateReads : List (Cell Party Asset Domain)
  requiredEnvReads : List (EnvRead Domain)
  declaredStateReads : List (Cell Party Asset Domain)
  declaredEnvReads : List (EnvRead Domain)
  writes : List (Cell Party Asset Domain)

structure ExecutionResult (Party Asset Domain : Type) where
  state : State Party Asset Domain
  capabilities : CapabilityStore Party Asset Domain

variable {Party Asset Domain : Type}
variable [DecidableEq Party] [DecidableEq Asset] [DecidableEq Domain]

def Template.requiredStateReads (template : Template Party Asset Domain) :=
  template.guard.stateReads ++ template.deltas.flatMap (fun d ↦ d.amount.stateReads) ++
    template.supplyDeltas.flatMap (fun d ↦ d.amount.stateReads)

def Template.requiredEnvReads (template : Template Party Asset Domain) :=
  template.guard.envReads ++ template.deltas.flatMap (fun d ↦ d.amount.envReads) ++
    template.supplyDeltas.flatMap (fun d ↦ d.amount.envReads)

def resolveRefs (caller : Party) (parties : List Party)
    (refs : List (PackedCellRef Party Asset Domain)) :
    Except EvalFailure (List (Cell Party Asset Domain)) :=
  refs.mapM (fun ref ↦ ref.2.resolve caller parties)

def Template.evaluate (template : Template Party Asset Domain)
    (ctx : EvalContext Party Asset Domain template.signature) :
    Except EvalFailure (Evaluated Party Asset Domain) := do
  let required ← resolveRefs ctx.caller ctx.parties template.requiredStateReads
  let declared ← resolveRefs ctx.caller ctx.parties template.stateReads
  let writes ← resolveRefs ctx.caller ctx.parties template.writes
  let guard ← template.guard.eval ctx
  let deltas ← template.deltas.mapM fun d ↦ do
    let cell ← d.target.resolve ctx.caller ctx.parties
    let amount ← d.amount.eval ctx
    return (cell, amount)
  let supplies ← template.supplyDeltas.mapM fun d ↦ do
    let amount ← d.amount.eval ctx
    return ((d.domain, d.asset), amount)
  return ⟨guard, deltas, supplies, required, template.requiredEnvReads, declared,
    template.envReads, writes⟩

/-- Every repeated entry contributes by addition, including repeated supply changes. -/
def Evaluated.effect (evaluated : Evaluated Party Asset Domain)
    (cell : Cell Party Asset Domain) : ℚ :=
  (evaluated.deltas.map (fun d ↦ if d.1 = cell then d.2 else 0)).sum

def Evaluated.supply (evaluated : Evaluated Party Asset Domain)
    (domain : Domain) (asset : Asset) : ℚ :=
  (evaluated.supplies.map (fun d ↦ if d.1 = (domain, asset) then d.2 else 0)).sum

variable [Fintype Party] [Fintype Asset] [Fintype Domain]

def Evaluated.stateReadsOK (e : Evaluated Party Asset Domain) : Bool :=
  e.requiredStateReads.all (fun c ↦ decide (c ∈ e.declaredStateReads))

def Evaluated.envReadsOK (e : Evaluated Party Asset Domain) : Bool :=
  e.requiredEnvReads.all (fun k ↦ decide (k ∈ e.declaredEnvReads))

/-- Required state reads and actual net movement stay within the invocation domain.
Environment observations may explicitly refer to other domains; their truth is adapter supplied. -/
def Evaluated.domainOK (e : Evaluated Party Asset Domain) (domain : Domain) : Bool :=
  decide ((∀ c ∈ e.requiredStateReads, c.1 = domain) ∧
    (∀ c, e.effect c ≠ 0 → c.1 = domain) ∧ ∀ d a, e.supply d a ≠ 0 → d = domain)

def Evaluated.debitsOK (e : Evaluated Party Asset Domain)
    (store : CapabilityStore Party Asset Domain) (request : Request Party Asset Domain)
    (ctx : InvocationContext Party Domain) : Bool :=
  decide (∀ c, e.effect c < 0 →
    hasAuthority store request.capabilityIds ctx request.operation (.debit c) = true)

def Evaluated.suppliesOK (e : Evaluated Party Asset Domain)
    (store : CapabilityStore Party Asset Domain) (request : Request Party Asset Domain)
    (ctx : InvocationContext Party Domain) : Bool :=
  decide (∀ d a, e.supply d a ≠ 0 →
    hasAuthority store request.capabilityIds ctx request.operation (.changeSupply d a) = true)

def Evaluated.accountingOK (e : Evaluated Party Asset Domain) : Bool :=
  decide (∀ d a, ∑ p, e.effect (d, p, a) = e.supply d a)

def Evaluated.writesOK (e : Evaluated Party Asset Domain) : Bool :=
  decide (∀ c, c ∉ e.writes → e.effect c = 0)

/-- All branches are computational. Only the nonnegativity witness enters the state value. -/
def applyEvaluated (store : CapabilityStore Party Asset Domain)
    (ctx : InvocationContext Party Domain) (request : Request Party Asset Domain)
    (state : State Party Asset Domain) (e : Evaluated Party Asset Domain) :
    Except Refusal (ExecutionResult Party Asset Domain) :=
  if !e.guard then .error .guard
  else if !e.stateReadsOK then .error .stateReadFootprint
  else if !e.envReadsOK then .error .envReadFootprint
  else if !e.domainOK ctx.domain then .error .crossDomain
  else if !e.debitsOK store request ctx then .error .unauthorizedDebit
  else if !e.suppliesOK store request ctx then .error .unauthorizedSupply
  else if hn : ∀ c, 0 ≤ state.balance c + e.effect c then
    if !e.accountingOK then .error .accounting
    else if !e.writesOK then .error .writeFootprint
    else .ok ⟨⟨fun c ↦ state.balance c + e.effect c, hn⟩, store⟩
  else .error .insufficientFunds

/-- Registry selection and actor/domain binding precede `Args.check`, which precedes invoke
checking. Template evaluation (including effect/supply expressions) precedes guard and footprint
checks. Successful read/domain conditions are not refused-path confidentiality guarantees. -/
def execute (registry : Registry Party Asset Domain)
    (store : CapabilityStore Party Asset Domain) (ctx : InvocationContext Party Domain)
    (env : Environment Asset Domain) (now : Nat) (request : Request Party Asset Domain)
    (state : State Party Asset Domain) : Except Refusal (ExecutionResult Party Asset Domain) := do
  let template ← match registry request.operation with
    | none => .error .unknownOperation
    | some template => .ok template
  if request.claimedActor.isSome && request.claimedActor != some ctx.principal then
    throw .actorMismatch
  if ctx.domain != template.domain then throw .domainMismatch
  if request.parties.length != template.partyArity then throw .partyArity
  let args ← (Args.check template.signature request.arguments).mapError Refusal.evaluation
  if !hasAuthority store request.capabilityIds ctx request.operation .invoke then
    throw .unauthorizedInvoke
  let evaluated ← (template.evaluate ⟨state, env, ctx.principal, request.parties, args, now⟩)
    |>.mapError Refusal.evaluation
  applyEvaluated store ctx request state evaluated

/-- Logical view of the actual checks; this does not construct executable states. -/
def Evaluated.Valid (store : CapabilityStore Party Asset Domain)
    (ctx : InvocationContext Party Domain) (request : Request Party Asset Domain)
    (state : State Party Asset Domain) (e : Evaluated Party Asset Domain) : Prop :=
  e.guard = true ∧ e.stateReadsOK = true ∧ e.envReadsOK = true ∧
  e.domainOK ctx.domain = true ∧ e.debitsOK store request ctx = true ∧
  e.suppliesOK store request ctx = true ∧ (∀ c, 0 ≤ state.balance c + e.effect c) ∧
  e.accountingOK = true ∧ e.writesOK = true

variable (registry : Registry Party Asset Domain) (store : CapabilityStore Party Asset Domain)
variable (ctx : InvocationContext Party Domain) (env : Environment Asset Domain) (now : Nat)
variable (request : Request Party Asset Domain) (state : State Party Asset Domain)
variable (post : ExecutionResult Party Asset Domain)


end DefiKernel.Typed


/-! Finite component declarations, concrete access checks and immutable value snapshots.
Catalog validation is structural; it does not discharge semantic contracts or kernel authority. -/
namespace DefiKernel.Composition
open Typed

structure ComponentId where
  value : Nat
  deriving DecidableEq, Repr

structure PortId where
  value : Nat
  deriving DecidableEq, Repr

structure QualifiedPort where
  component : ComponentId
  port : PortId
  deriving DecidableEq, Repr

structure InputPort (Asset : Type) where
  id : PortId
  unit : Typed.Unit Asset
  deriving DecidableEq, Repr

structure OutputPort (Party Asset Domain : Type) where
  id : PortId
  cell : Cell Party Asset Domain
  deriving DecidableEq, Repr

structure ResourcePort (Party Asset Domain : Type) where
  id : PortId
  cell : Cell Party Asset Domain
  writable : Bool
  deriving DecidableEq, Repr

structure ResourceImport (Party Asset Domain : Type) where
  source : QualifiedPort
  cell : Cell Party Asset Domain
  writable : Bool
  deriving DecidableEq, Repr

structure OperationInterface (Party Asset Domain : Type) where
  operation : OperationId
  inputs : List (InputPort Asset)
  outputs : List (OutputPort Party Asset Domain)
  deriving DecidableEq, Repr

structure Component (Party Asset Domain : Type) where
  id : ComponentId
  privateCells : List (Cell Party Asset Domain)
  exports : List (ResourcePort Party Asset Domain)
  imports : List (ResourceImport Party Asset Domain)
  operations : List (OperationInterface Party Asset Domain)
  deriving DecidableEq, Repr

abbrev Catalog (Party Asset Domain : Type) := List (Component Party Asset Domain)

inductive InterfaceFailure where
  | unknownOperation
  | resolution (reason : EvalFailure)
  | readAccess
  | writeAccess
  | inputCount
  | inputUnit
  | unavailableOutput
  deriving DecidableEq, Repr

inductive InputSource (Asset : Type) where
  | literal (value : PackedValue Asset)
  | priorOutput (step : Nat) (port : QualifiedPort)

structure OutputObservation (Asset : Type) where
  step : Nat
  port : QualifiedPort
  value : PackedValue Asset

variable {Party Asset Domain : Type}
variable [DecidableEq Party] [DecidableEq Asset] [DecidableEq Domain]

def Component.canRead (component : Component Party Asset Domain)
    (cell : Cell Party Asset Domain) : Bool :=
  decide (cell ∈ component.privateCells) ||
    component.exports.any (fun p ↦ decide (p.cell = cell)) ||
    component.imports.any (fun p ↦ decide (p.cell = cell))

def Component.canWrite (component : Component Party Asset Domain)
    (cell : Cell Party Asset Domain) : Bool :=
  decide (cell ∈ component.privateCells) ||
    component.exports.any (fun p ↦ decide (p.cell = cell) && p.writable) ||
    component.imports.any (fun p ↦ decide (p.cell = cell) && p.writable)

def lookupOperation (catalog : Catalog Party Asset Domain) (componentId : ComponentId)
    (operationId : OperationId) :
    Option (Component Party Asset Domain × OperationInterface Party Asset Domain) := do
  let component ← catalog.find? (fun c ↦ decide (c.id = componentId))
  let interface ← component.operations.find? (fun i ↦ decide (i.operation = operationId))
  return (component, interface)

def Component.portIds (component : Component Party Asset Domain) : List PortId :=
  component.exports.map ResourcePort.id ++ component.operations.flatMap
    (fun i ↦ i.inputs.map InputPort.id ++ i.outputs.map OutputPort.id)

/-- Private ownership excludes all shared ports, including the owner's own exports.
An import may reduce write access, but cannot grant more rights than its exact export. -/
def validateCatalog (registry : Registry Party Asset Domain)
    (catalog : Catalog Party Asset Domain) : Bool :=
  decide ((catalog.map Component.id).Nodup) &&
  decide ((catalog.flatMap (fun c ↦ c.operations.map OperationInterface.operation)).Nodup) &&
  decide ((catalog.flatMap Component.privateCells).Nodup) &&
  decide ((catalog.flatMap (fun c ↦ c.exports.map ResourcePort.cell)).Nodup) &&
  catalog.all (fun c ↦
    decide (c.portIds.Nodup) && decide ((c.imports.map ResourceImport.source).Nodup) &&
    c.exports.all (fun p ↦
      !(catalog.any (fun owner ↦ decide (p.cell ∈ owner.privateCells)))) &&
    c.imports.all (fun p ↦
      !(c.exports.any (fun e ↦ decide (e.cell = p.cell))) &&
      !(catalog.any (fun owner ↦ decide (p.cell ∈ owner.privateCells))) &&
      catalog.any (fun source ↦ decide (source.id = p.source.component) &&
        source.exports.any (fun e ↦ decide (e.id = p.source.port) &&
          decide (e.cell = p.cell) && (!p.writable || e.writable)))) &&
    c.operations.all (fun i ↦
      (match registry i.operation with
       | none => false
       | some template => decide (i.inputs.map InputPort.unit = template.signature) &&
         i.outputs.all (fun o ↦ decide (o.cell.1 = template.domain))) &&
      i.outputs.all (fun o ↦ c.canRead o.cell)))

/-- Resolve references without evaluating financial expressions. Both expression branches,
supply/guard reads, declared reads, declared writes and every delta target are checked. -/
def checkAccess (component : Component Party Asset Domain)
    (template : Template Party Asset Domain) (ctx : InvocationContext Party Domain)
    (parties : List Party) : Except InterfaceFailure PUnit := do
  let reads ← (resolveRefs ctx.principal parties
    (template.requiredStateReads ++ template.stateReads)).mapError .resolution
  let writes ← (resolveRefs ctx.principal parties
    (template.writes ++ template.deltas.map (fun d ↦ ⟨d.asset, d.target⟩))).mapError .resolution
  if !(reads.all component.canRead) then throw .readAccess
  if !(writes.all component.canWrite) then throw .writeAccess
  return ⟨⟩

/-- Earlier absolute positions are necessary even if an untrusted history contains a future key.
The runner additionally ensures history contains only actual successful snapshots. -/
def resolveSource (index : Nat) (history : List (OutputObservation Asset)) :
    InputSource Asset → Except InterfaceFailure (PackedValue Asset)
  | .literal value => .ok value
  | .priorOutput step port =>
    if step < index then
      match history.find? (fun o ↦ decide (o.step = step ∧ o.port = port)) with
      | some output => .ok output.value
      | none => .error .unavailableOutput
    else .error .unavailableOutput

def resolveInputs (index : Nat) (history : List (OutputObservation Asset))
    (interface : OperationInterface Party Asset Domain) (sources : List (InputSource Asset)) :
    Except InterfaceFailure (List (PackedValue Asset)) := do
  if sources.length != interface.inputs.length then throw .inputCount
  let values ← sources.mapM (resolveSource index history)
  if values.map Sigma.fst != interface.inputs.map InputPort.unit then throw .inputUnit
  return values

/-- Output units are intrinsic to the selected cell and balances are copied after commitment. -/
def snapshots (index : Nat) (component : ComponentId)
    (interface : OperationInterface Party Asset Domain) (state : State Party Asset Domain) :
    List (OutputObservation Asset) :=
  interface.outputs.map (fun o ↦
    ⟨index, ⟨component, o.id⟩, ⟨.amount o.cell.2.2, state.balance o.cell⟩⟩)


end DefiKernel.Composition


/-! Proof-level contracts and ledger support. These predicates are not executable certificates;
initialization, environment truth, and local guarantees require separate proof premises. -/
namespace DefiKernel.Composition

open Typed

abbrev World (Party Asset Domain : Type) := ExecutionResult Party Asset Domain

/-- Semantic obligations are separate from finite interface validation. -/
structure ComponentContract (Party Asset Domain Boundary : Type) where
  initial : World Party Asset Domain → Prop
  assumes : Boundary → World Party Asset Domain → Prop
  invariant : World Party Asset Domain → Prop
  guarantees : Boundary → World Party Asset Domain → World Party Asset Domain → Prop

variable {Party Asset Domain Boundary : Type}

/-- Initialization and the inductive rule must actually be proved by a contract instance. -/
structure ContractObligations
    (contract : ComponentContract Party Asset Domain Boundary) : Prop where
  initialized : ∀ w, contract.initial w → contract.invariant w
  preserved : ∀ b pre post, contract.invariant pre → contract.assumes b pre →
    contract.guarantees b pre post → contract.invariant post

def Initial (contracts : List (ComponentContract Party Asset Domain Boundary))
    (world : World Party Asset Domain) : Prop :=
  ∀ contract ∈ contracts, contract.initial world

def AgreeOn (region : Set (Cell Party Asset Domain))
    (pre post : State Party Asset Domain) : Prop :=
  ∀ cell ∈ region, pre.balance cell = post.balance cell

/-- Only ledger predicates are framed; this definition does not cover capability-store reads. -/
def Supports (region : Set (Cell Party Asset Domain))
    (predicate : State Party Asset Domain → Prop) : Prop :=
  ∀ pre post, AgreeOn region pre post → (predicate pre ↔ predicate post)


end DefiKernel.Composition


/-! Single-step adaptation of registered execution. Receipts are re-evaluated against the
same pre-state, and are returned only after both execution and extraction succeed. -/
namespace DefiKernel.Composition
open Typed

structure Boundary (Party Asset Domain : Type) where
  ctx : InvocationContext Party Domain
  env : Environment Asset Domain
  now : Nat

structure Config (Party Asset Domain : Type) where
  registry : Registry Party Asset Domain
  domainAdmin : Domain → Party
  catalog : Catalog Party Asset Domain

structure Invocation (Party Asset Domain : Type) where
  component : ComponentId
  operation : OperationId
  parties : List Party
  inputs : List (InputSource Asset)
  capabilityIds : List CapabilityId
  claimedActor : Option Party := none

inductive Step (Party Asset Domain : Type) where
  | invoke (invocation : Invocation Party Asset Domain)
  | issue (grant : Grant Party Asset Domain)
  | revoke (id : CapabilityId)

inductive Failure where
  | configuration
  | interface (reason : InterfaceFailure)
  | kernel (reason : Typed.Refusal)
  | authority (reason : AuthorityFailure)
  | internalReceipt
  deriving DecidableEq, Repr

inductive Receipt (Party Asset Domain : Type) where
  | invoked (request : Request Party Asset Domain) (evaluated : Evaluated Party Asset Domain)
  | issued (id : CapabilityId)
  | revoked (id : CapabilityId)

structure StepResult (Party Asset Domain : Type) where
  world : World Party Asset Domain
  receipt : Receipt Party Asset Domain
  outputs : List (OutputObservation Asset)

variable {P A D : Type} [DecidableEq P] [DecidableEq A] [DecidableEq D]
variable [Fintype P] [Fintype A] [Fintype D]

def Config.authority (cfg : Config P A D) := registryAuthorityConfig cfg.registry cfg.domainAdmin

def Receipt.supply (receipt : Receipt P A D) (d : D) (a : A) : ℚ :=
  match receipt with
  | .invoked _ e => e.supply d a
  | _ => 0

def Receipt.writes (receipt : Receipt P A D) : List (Cell P A D) :=
  match receipt with
  | .invoked _ e => e.writes
  | _ => []

def prepareInvocation (cfg : Config P A D) (boundary : Boundary P A D) (index : Nat)
    (history : List (OutputObservation A)) (inv : Invocation P A D) :
    Except Failure (OperationInterface P A D × Request P A D) := do
  let (component, iface) ← match lookupOperation cfg.catalog inv.component inv.operation with
    | none => .error (.interface .unknownOperation)
    | some pair => .ok pair
  let arguments ← (resolveInputs index history iface inv.inputs).mapError Failure.interface
  let template ← match cfg.registry inv.operation with
    | none => .error (.kernel .unknownOperation)
    | some template => .ok template
  let _ ← (checkAccess component template boundary.ctx inv.parties).mapError Failure.interface
  return (iface, ⟨inv.operation, inv.parties, arguments, inv.capabilityIds, inv.claimedActor⟩)

def extractReceipt (cfg : Config P A D) (boundary : Boundary P A D)
    (request : Request P A D) (pre : World P A D) : Except Failure (Evaluated P A D) := do
  let template ← match cfg.registry request.operation with
    | none => .error .internalReceipt
    | some template => .ok template
  let args ← (Args.check template.signature request.arguments).mapError (fun _ ↦ .internalReceipt)
  (template.evaluate ⟨pre.state, boundary.env, boundary.ctx.principal,
    request.parties, args, boundary.now⟩).mapError (fun _ ↦ .internalReceipt)

def executeStep (cfg : Config P A D) (boundary : Boundary P A D) (index : Nat)
    (history : List (OutputObservation A)) (step : Step P A D) (pre : World P A D) :
    Except Failure (StepResult P A D) := do
  if !validateCatalog cfg.registry cfg.catalog then throw .configuration
  match step with
  | .invoke inv =>
    let (iface, request) ← prepareInvocation cfg boundary index history inv
    let post ← (Typed.execute cfg.registry pre.capabilities boundary.ctx boundary.env boundary.now
      request pre.state).mapError Failure.kernel
    let e ← extractReceipt cfg boundary request pre
    return ⟨post, .invoked request e, snapshots index inv.component iface post.state⟩
  | .issue grant =>
    let (id, store) ← (issueCapability cfg.authority boundary.ctx pre.capabilities grant)
      |>.mapError Failure.authority
    return ⟨⟨pre.state, store⟩, .issued id, []⟩
  | .revoke id =>
    let store ← (revokeCapability cfg.authority boundary.ctx pre.capabilities id)
      |>.mapError Failure.authority
    return ⟨⟨pre.state, store⟩, .revoked id, []⟩


end DefiKernel.Composition


/-! Finite ordered execution. A refusal commits no new event, preserves the successful prefix,
and makes every continuation inert. Trusted boundary positions are absolute. -/
namespace DefiKernel.Composition
open Typed

structure Event (Party Asset Domain : Type) where
  index : Nat
  step : Step Party Asset Domain
  before : World Party Asset Domain
  result : StepResult Party Asset Domain

structure LocatedFailure (Party Asset Domain : Type) where
  index : Nat
  step : Option (Step Party Asset Domain)
  reason : Failure

structure Cursor (Party Asset Domain : Type) where
  world : World Party Asset Domain
  events : List (Event Party Asset Domain)
  outputs : List (OutputObservation Asset)
  nextIndex : Nat
  failure : Option (LocatedFailure Party Asset Domain)

variable {P A D : Type} [DecidableEq P] [DecidableEq A] [DecidableEq D]
variable [Fintype P] [Fintype A] [Fintype D]

def startCursor (cfg : Config P A D) (world : World P A D) : Cursor P A D :=
  ⟨world, [], [], 0, if validateCatalog cfg.registry cfg.catalog then none
    else some ⟨0, none, .configuration⟩⟩

def advance (cfg : Config P A D) (boundaries : Nat → Boundary P A D)
    (cursor : Cursor P A D) (step : Step P A D) : Cursor P A D :=
  match cursor.failure with
  | some _ => cursor
  | none =>
    match executeStep cfg (boundaries cursor.nextIndex) cursor.nextIndex cursor.outputs
        step cursor.world with
    | .error reason => { cursor with failure := some ⟨cursor.nextIndex, some step, reason⟩ }
    | .ok result =>
      ⟨result.world, cursor.events ++ [⟨cursor.nextIndex, step, cursor.world, result⟩],
        cursor.outputs ++ result.outputs, cursor.nextIndex + 1, none⟩

def continueRun (cfg : Config P A D) (boundaries : Nat → Boundary P A D)
    (cursor : Cursor P A D) (steps : List (Step P A D)) : Cursor P A D :=
  steps.foldl (advance cfg boundaries) cursor

def run (cfg : Config P A D) (boundaries : Nat → Boundary P A D)
    (world : World P A D) (steps : List (Step P A D)) : Cursor P A D :=
  continueRun cfg boundaries (startCursor cfg world) steps


end DefiKernel.Composition


namespace DefiKernel.Certificates

/-- Universe party enumeration matching baseline universe. -/
inductive Party where
  | alice | bob | vault | pool
  deriving DecidableEq, Repr, Inhabited

/-- Universe asset enumeration matching baseline universe. -/
inductive Asset where
  | usd | share | collateral | debt
  deriving DecidableEq, Repr, Inhabited

/-- Universe domain enumeration matching baseline universe. -/
inductive Domain where
  | main | other
  deriving DecidableEq, Repr, Inhabited

instance : Fintype Party := ⟨{.alice, .bob, .vault, .pool}, by intro p; cases p <;> simp⟩
instance : Fintype Asset := ⟨{.usd, .share, .collateral, .debt}, by intro a; cases a <;> simp⟩
instance : Fintype Domain := ⟨{.main, .other}, by intro d; cases d <;> simp⟩

def partyToString : Party → String
  | .alice => "alice"
  | .bob => "bob"
  | .vault => "vault"
  | .pool => "pool"

def parseParty? : String → Option Party
  | "alice" => some .alice
  | "bob" => some .bob
  | "vault" => some .vault
  | "pool" => some .pool
  | _ => none

def assetToString : Asset → String
  | .usd => "usd"
  | .share => "share"
  | .collateral => "collateral"
  | .debt => "debt"

def parseAsset? : String → Option Asset
  | "usd" => some .usd
  | "share" => some .share
  | "collateral" => some .collateral
  | "debt" => some .debt
  | _ => none

def domainToString : Domain → String
  | .main => "main"
  | .other => "other"

def parseDomain? : String → Option Domain
  | "main" => some .main
  | "other" => some .other
  | _ => none

/-- Exact rational numbers in canonical form. -/
structure RatEnc where
  num : Int
  den : Nat
  deriving DecidableEq, Repr, Inhabited

def RatEnc.toRat (r : RatEnc) : ℚ :=
  Rat.divInt r.num r.den

def RatEnc.fromRat (q : ℚ) : RatEnc :=
  ⟨q.num, q.den⟩

inductive NumericUnitEnc where
  | amount (asset : Asset)
  | price (base quote : Asset)
  | scalar
  deriving DecidableEq, Repr, Inhabited

inductive UnitEnc where
  | numeric (u : NumericUnitEnc)
  | bool
  deriving DecidableEq, Repr, Inhabited

def NumericUnitEnc.toNumericUnit : NumericUnitEnc → Typed.NumericUnit Asset
  | .amount a => .amount a
  | .price a b => .price a b
  | .scalar => .scalar

def UnitEnc.toUnit : UnitEnc → Typed.Unit Asset
  | .numeric u => u.toNumericUnit.toUnit
  | .bool => .bool

structure PackedValueEnc where
  unit : UnitEnc
  valRat : ℚ := 0
  valBool : Bool := false
  deriving DecidableEq, Repr, Inhabited

def PackedValueEnc.toPackedValue (pv : PackedValueEnc) : Typed.PackedValue Asset :=
  match pv.unit with
  | .numeric u => ⟨u.toNumericUnit.toUnit, Typed.numericValue u.toNumericUnit pv.valRat⟩
  | .bool => ⟨.bool, pv.valBool⟩

def PackedValueEnc.fromPackedValue (pv : Typed.PackedValue Asset) : PackedValueEnc :=
  match pv with
  | ⟨.bool, v⟩ => ⟨.bool, 0, v⟩
  | ⟨.amount a, v⟩ => ⟨.numeric (.amount a), Typed.numericRat (.amount a) v, false⟩
  | ⟨.price a b, v⟩ => ⟨.numeric (.price a b), Typed.numericRat (.price a b) v, false⟩
  | ⟨.scalar, v⟩ => ⟨.numeric .scalar, Typed.numericRat .scalar v, false⟩

inductive PartyRefEnc where
  | caller
  | literal (party : Party)
  | argument (index : Nat)
  deriving DecidableEq, Repr, Inhabited

def PartyRefEnc.toPartyRef : PartyRefEnc → Typed.PartyRef Party
  | .caller => .caller
  | .literal p => .literal p
  | .argument idx => .argument idx

structure CellRefEnc where
  domain : Domain
  owner : PartyRefEnc
  deriving DecidableEq, Repr, Inhabited

def CellRefEnc.toCellRef (c : CellRefEnc) (a : Asset) : Typed.CellRef Party Asset Domain a :=
  ⟨c.domain, c.owner.toPartyRef⟩

structure PackedCellRefEnc where
  asset : Asset
  cell : CellRefEnc
  deriving DecidableEq, Repr, Inhabited

def PackedCellRefEnc.toPackedCellRef (p : PackedCellRefEnc) : Typed.PackedCellRef Party Asset Domain :=
  ⟨p.asset, p.cell.toCellRef p.asset⟩

structure ObservationKeyEnc where
  domain : Domain
  id : Nat
  deriving DecidableEq, Repr, Inhabited

def ObservationKeyEnc.toObservationKey (k : ObservationKeyEnc) : Typed.ObservationKey Domain :=
  ⟨k.domain, ⟨k.id⟩⟩

structure ObservationRefEnc where
  key : ObservationKeyEnc
  unit : UnitEnc
  deriving DecidableEq, Repr, Inhabited

def ObservationRefEnc.toObservationRef (r : ObservationRefEnc) :
    Typed.ObservationRef Asset Domain r.unit.toUnit :=
  ⟨r.key.toObservationKey⟩

inductive EnvReadEnc where
  | observation (key : ObservationKeyEnc)
  | currentTime
  deriving DecidableEq, Repr, Inhabited

def EnvReadEnc.toEnvRead : EnvReadEnc → Typed.EnvRead Domain
  | .observation k => .observation k.toObservationKey
  | .currentTime => .currentTime

inductive UnaryOpEnc where
  | neg (u : NumericUnitEnc)
  | not
  deriving DecidableEq, Repr, Inhabited

inductive BinaryOpEnc where
  | add (u : NumericUnitEnc)
  | sub (u : NumericUnitEnc)
  | scale (u : NumericUnitEnc)
  | divide (u : NumericUnitEnc)
  | ratio (u : NumericUnitEnc)
  | convert (base quote : Asset)
  | unconvert (base quote : Asset)
  | le (u : NumericUnitEnc)
  | lt (u : NumericUnitEnc)
  | eq (u : UnitEnc)
  | and
  | or
  deriving DecidableEq, Repr, Inhabited

inductive ExprEnc where
  | lit (val : PackedValueEnc)
  | arg (index : Nat) (unit : UnitEnc)
  | balance (cell : PackedCellRefEnc)
  | observe (ref : ObservationRefEnc)
  | timestamp (key : ObservationKeyEnc)
  | now
  | unary (op : UnaryOpEnc) (x : ExprEnc)
  | binary (op : BinaryOpEnc) (x y : ExprEnc)
  | ite (condition yes no : ExprEnc)
  deriving DecidableEq, Repr, Inhabited

structure CellDeltaEnc where
  asset : Asset
  target : CellRefEnc
  amount : ExprEnc
  deriving DecidableEq, Repr, Inhabited

structure SupplyDeltaEnc where
  domain : Domain
  asset : Asset
  amount : ExprEnc
  deriving DecidableEq, Repr, Inhabited

structure TemplateEnc where
  signature : List UnitEnc
  domain : Domain
  partyArity : Nat
  guard : ExprEnc
  deltas : List CellDeltaEnc
  supplyDeltas : List SupplyDeltaEnc
  stateReads : List PackedCellRefEnc
  envReads : List EnvReadEnc
  writes : List PackedCellRefEnc
  deriving DecidableEq, Repr, Inhabited

structure RegistryEntryEnc where
  id : Nat
  template : TemplateEnc
  deriving DecidableEq, Repr, Inhabited

structure RegistryEnc where
  entries : List RegistryEntryEnc
  deriving DecidableEq, Repr, Inhabited

structure RequestEnc where
  operation : Nat
  parties : List Party
  arguments : List PackedValueEnc
  capabilityIds : List Nat
  claimedActor : Option Party := none
  deriving DecidableEq, Repr, Inhabited

def RequestEnc.toRequest (r : RequestEnc) : Typed.Request Party Asset Domain :=
  ⟨⟨r.operation⟩, r.parties, r.arguments.map PackedValueEnc.toPackedValue,
   r.capabilityIds.map (fun id ↦ ⟨id⟩), r.claimedActor⟩

structure CellEnc where
  domain : Domain
  party : Party
  asset : Asset
  deriving DecidableEq, Repr, Inhabited

def CellEnc.toCell (c : CellEnc) : Typed.Cell Party Asset Domain :=
  (c.domain, c.party, c.asset)

inductive RightEnc where
  | invoke
  | debit (cell : CellEnc)
  | changeSupply (domain : Domain) (asset : Asset)
  deriving DecidableEq, Repr, Inhabited

def RightEnc.toRight : RightEnc → Typed.Right Party Asset Domain
  | .invoke => .invoke
  | .debit c => .debit c.toCell
  | .changeSupply d a => .changeSupply d a

structure GrantEnc where
  holder : Party
  domain : Domain
  operation : Nat
  right : RightEnc
  deriving DecidableEq, Repr, Inhabited

def GrantEnc.toGrant (g : GrantEnc) : Typed.Grant Party Asset Domain :=
  ⟨g.holder, g.domain, ⟨g.operation⟩, g.right.toRight⟩

def RightEnc.fromRight : Typed.Right Party Asset Domain → RightEnc
  | .invoke => .invoke
  | .debit c => .debit ⟨c.1, c.2.1, c.2.2⟩
  | .changeSupply d a => .changeSupply d a

def GrantEnc.fromGrant (g : Typed.Grant Party Asset Domain) : GrantEnc :=
  ⟨g.holder, g.domain, g.operation.value, RightEnc.fromRight g.right⟩

structure CapabilityEnc where
  holder : Party
  domain : Domain
  operation : Nat
  right : RightEnc
  live : Bool
  deriving DecidableEq, Repr, Inhabited

def CapabilityEnc.toCapability (c : CapabilityEnc) : Typed.Capability Party Asset Domain :=
  ⟨⟨c.holder, c.domain, ⟨c.operation⟩, c.right.toRight⟩, c.live⟩

structure StoreEnc where
  entries : List CapabilityEnc
  deriving DecidableEq, Repr, Inhabited

def StoreEnc.toCapabilityStore (s : StoreEnc) : Typed.CapabilityStore Party Asset Domain :=
  ⟨s.entries.map CapabilityEnc.toCapability⟩

structure StateCellEnc where
  domain : Domain
  party : Party
  asset : Asset
  amount : RatEnc
  deriving DecidableEq, Repr, Inhabited

structure StateEnc where
  cells : List StateCellEnc
  deriving DecidableEq, Repr, Inhabited

def StateEnc.cellLookup (s : StateEnc) (c : Typed.Cell Party Asset Domain) : ℚ :=
  match s.cells.find? (fun row ↦ row.domain == c.1 && row.party == c.2.1 && row.asset == c.2.2) with
  | some row => row.amount.toRat
  | none => 0

def StateEnc.isNonneg (s : StateEnc) : Bool :=
  decide (∀ c : Typed.Cell Party Asset Domain, 0 ≤ s.cellLookup c)

def StateEnc.toState? (s : StateEnc) : Option (Typed.State Party Asset Domain) :=
  if h : ∀ c : Typed.Cell Party Asset Domain, 0 ≤ s.cellLookup c then
    some ⟨s.cellLookup, h⟩
  else none

structure ContextEnc where
  principal : Party
  domain : Domain
  deriving DecidableEq, Repr, Inhabited

def ContextEnc.toContext (c : ContextEnc) : Typed.InvocationContext Party Domain :=
  ⟨c.principal, c.domain⟩

structure ObservationEnc where
  value : PackedValueEnc
  timestamp : Nat
  deriving DecidableEq, Repr, Inhabited

structure EnvironmentEntryEnc where
  key : ObservationKeyEnc
  observation : ObservationEnc
  deriving DecidableEq, Repr, Inhabited

structure EnvironmentEnc where
  entries : List EnvironmentEntryEnc
  deriving DecidableEq, Repr, Inhabited

def EnvironmentEnc.toEnvironment (e : EnvironmentEnc) : Typed.Environment Asset Domain :=
  fun k ↦ match e.entries.find? (fun entry ↦ entry.key.toObservationKey == k) with
    | some entry => some ⟨entry.observation.value.toPackedValue, entry.observation.timestamp⟩
    | none => none

structure BoundaryEnc where
  ctx : ContextEnc
  env : EnvironmentEnc
  now : Nat
  deriving DecidableEq, Repr, Inhabited

def BoundaryEnc.toBoundary (b : BoundaryEnc) : Composition.Boundary Party Asset Domain :=
  ⟨b.ctx.toContext, b.env.toEnvironment, b.now⟩

structure DomainAdminEnc where
  domain : Domain
  party : Party
  deriving DecidableEq, Repr, Inhabited

structure InputPortEnc where
  id : Nat
  unit : UnitEnc
  deriving DecidableEq, Repr, Inhabited

def InputPortEnc.toInputPort (p : InputPortEnc) : Composition.InputPort Asset :=
  ⟨⟨p.id⟩, p.unit.toUnit⟩

structure OutputPortEnc where
  id : Nat
  cell : CellEnc
  deriving DecidableEq, Repr, Inhabited

def OutputPortEnc.toOutputPort (p : OutputPortEnc) : Composition.OutputPort Party Asset Domain :=
  ⟨⟨p.id⟩, p.cell.toCell⟩

structure ResourcePortEnc where
  id : Nat
  cell : CellEnc
  writable : Bool
  deriving DecidableEq, Repr, Inhabited

def ResourcePortEnc.toResourcePort (p : ResourcePortEnc) : Composition.ResourcePort Party Asset Domain :=
  ⟨⟨p.id⟩, p.cell.toCell, p.writable⟩

structure QualifiedPortEnc where
  component : Nat
  port : Nat
  deriving DecidableEq, Repr, Inhabited

def QualifiedPortEnc.toQualifiedPort (p : QualifiedPortEnc) : Composition.QualifiedPort :=
  ⟨⟨p.component⟩, ⟨p.port⟩⟩

structure ResourceImportEnc where
  source : QualifiedPortEnc
  cell : CellEnc
  writable : Bool
  deriving DecidableEq, Repr, Inhabited

def ResourceImportEnc.toResourceImport (i : ResourceImportEnc) : Composition.ResourceImport Party Asset Domain :=
  ⟨i.source.toQualifiedPort, i.cell.toCell, i.writable⟩

structure OperationInterfaceEnc where
  operation : Nat
  inputs : List InputPortEnc
  outputs : List OutputPortEnc
  deriving DecidableEq, Repr, Inhabited

def OperationInterfaceEnc.toOperationInterface (i : OperationInterfaceEnc) :
    Composition.OperationInterface Party Asset Domain :=
  ⟨⟨i.operation⟩, i.inputs.map InputPortEnc.toInputPort, i.outputs.map OutputPortEnc.toOutputPort⟩

structure ComponentEnc where
  id : Nat
  privateCells : List CellEnc
  exports : List ResourcePortEnc
  imports : List ResourceImportEnc
  operations : List OperationInterfaceEnc
  deriving DecidableEq, Repr, Inhabited

def ComponentEnc.toComponent (c : ComponentEnc) : Composition.Component Party Asset Domain :=
  ⟨⟨c.id⟩, c.privateCells.map CellEnc.toCell,
   c.exports.map ResourcePortEnc.toResourcePort,
   c.imports.map ResourceImportEnc.toResourceImport,
   c.operations.map OperationInterfaceEnc.toOperationInterface⟩

structure ConfigEnc where
  registry : RegistryEnc
  domainAdmin : List DomainAdminEnc
  catalog : List ComponentEnc
  deriving DecidableEq, Repr, Inhabited

inductive InputSourceEnc where
  | literal (value : PackedValueEnc)
  | priorOutput (step : Nat) (port : QualifiedPortEnc)
  deriving DecidableEq, Repr, Inhabited

def InputSourceEnc.toInputSource (s : InputSourceEnc) : Composition.InputSource Asset :=
  match s with
  | .literal pv => .literal pv.toPackedValue
  | .priorOutput step port => .priorOutput step port.toQualifiedPort

structure InvocationEnc where
  component : Nat
  operation : Nat
  parties : List Party
  inputs : List InputSourceEnc
  capabilityIds : List Nat
  claimedActor : Option Party := none
  deriving DecidableEq, Repr, Inhabited

def InvocationEnc.toInvocation (inv : InvocationEnc) : Composition.Invocation Party Asset Domain :=
  ⟨⟨inv.component⟩, ⟨inv.operation⟩, inv.parties,
   inv.inputs.map InputSourceEnc.toInputSource,
   inv.capabilityIds.map (fun id ↦ ⟨id⟩), inv.claimedActor⟩

inductive StepEnc where
  | invoke (invocation : InvocationEnc)
  | issue (grant : GrantEnc)
  | revoke (id : Nat)
  | unsupported (tag : String)
  deriving DecidableEq, Repr, Inhabited

def StepEnc.toStep? (s : StepEnc) : Option (Composition.Step Party Asset Domain) :=
  match s with
  | .invoke inv => some (.invoke inv.toInvocation)
  | .issue g => some (.issue g.toGrant)
  | .revoke id => some (.revoke ⟨id⟩)
  | .unsupported _ => none

def InputSourceEnc.fromInputSource (s : Composition.InputSource Asset) : InputSourceEnc :=
  match s with
  | .literal pv => .literal (PackedValueEnc.fromPackedValue pv)
  | .priorOutput step port => .priorOutput step ⟨port.component.value, port.port.value⟩

def InvocationEnc.fromInvocation (inv : Composition.Invocation Party Asset Domain) : InvocationEnc :=
  ⟨inv.component.value, inv.operation.value, inv.parties,
   inv.inputs.map InputSourceEnc.fromInputSource,
   inv.capabilityIds.map (·.value), inv.claimedActor⟩

def StepEnc.fromStep (s : Composition.Step Party Asset Domain) : StepEnc :=
  match s with
  | .invoke inv => .invoke (InvocationEnc.fromInvocation inv)
  | .issue g => .issue (GrantEnc.fromGrant g)
  | .revoke id => .revoke id.value

structure WorldEnc where
  state : StateEnc
  capabilities : StoreEnc
  deriving DecidableEq, Repr, Inhabited

def WorldEnc.toWorld? (w : WorldEnc) : Option (Composition.World Party Asset Domain) := do
  let st ← w.state.toState?
  return ⟨st, w.capabilities.toCapabilityStore⟩

structure OutputObservationEnc where
  step : Nat
  port : QualifiedPortEnc
  value : PackedValueEnc
  deriving DecidableEq, Repr, Inhabited

def OutputObservationEnc.toOutputObservation (o : OutputObservationEnc) :
    Composition.OutputObservation Asset :=
  ⟨o.step, o.port.toQualifiedPort, o.value.toPackedValue⟩

def OutputObservationEnc.fromOutputObservation (o : Composition.OutputObservation Asset) :
    OutputObservationEnc :=
  match o.value with
  | ⟨.bool, v⟩ =>
    ⟨o.step, ⟨o.port.component.value, o.port.port.value⟩, ⟨.bool, 0, v⟩⟩
  | ⟨.amount a, v⟩ =>
    ⟨o.step, ⟨o.port.component.value, o.port.port.value⟩, ⟨.numeric (.amount a), Typed.numericRat (.amount a) v, false⟩⟩
  | ⟨.price a b, v⟩ =>
    ⟨o.step, ⟨o.port.component.value, o.port.port.value⟩, ⟨.numeric (.price a b), Typed.numericRat (.price a b) v, false⟩⟩
  | ⟨.scalar, v⟩ =>
    ⟨o.step, ⟨o.port.component.value, o.port.port.value⟩, ⟨.numeric .scalar, Typed.numericRat .scalar v, false⟩⟩

structure EvaluatedEnc where
  guard : Bool
  deltas : List (CellEnc × RatEnc)
  supplies : List ((Domain × Asset) × RatEnc)
  requiredStateReads : List CellEnc
  requiredEnvReads : List ObservationKeyEnc
  declaredStateReads : List CellEnc
  declaredEnvReads : List ObservationKeyEnc
  writes : List CellEnc
  deriving DecidableEq, Repr, Inhabited

inductive ReceiptEnc where
  | invoked (request : RequestEnc) (evaluated : EvaluatedEnc)
  | issued (id : Nat)
  | revoked (id : Nat)
  deriving DecidableEq, Repr, Inhabited

structure StepResultEnc where
  world : WorldEnc
  receipt : ReceiptEnc
  outputs : List OutputObservationEnc
  deriving DecidableEq, Repr, Inhabited

structure SequentialEventEnc where
  index : Nat
  step : StepEnc
  before : WorldEnc
  result : StepResultEnc
  deriving DecidableEq, Repr, Inhabited

inductive FailureClass where
  | kernel
  | interface
  | authority
  | configuration
  | internalReceipt
  | staleSource
  | observationMismatch
  | incompleteObligation
  deriving DecidableEq, Repr, Inhabited

structure FailurePath where
  «class» : FailureClass
  ctor : String
  payload : Option String := none
  deriving DecidableEq, Repr, Inhabited

structure LocatedFailureEnc where
  index : Nat
  step : Option StepEnc
  reason : FailurePath
  deriving DecidableEq, Repr, Inhabited

inductive JudgmentOutcome where
  | «true»
  | «false»
  | notReached
  | notApplicable
  deriving DecidableEq, Repr, Inhabited

structure JudgmentResult where
  family : String
  outcome : JudgmentOutcome
  claimed : Bool
  «match» : Bool
  deriving DecidableEq, Repr, Inhabited

structure SourcePinEnc where
  git : String
  lean_toolchain : String
  mathlib_rev : String
  checker_candidate : String
  compiler_record : Option String := none
  audit_record : Option String := none
  deriving DecidableEq, Repr, Inhabited

structure TypesEnumEnc where
  parties : List Party
  assets : List Asset
  domains : List Domain
  deriving DecidableEq, Repr, Inhabited

structure LibraryRefEnc where
  theoremName : String
  moduleName : Option String := none
  deriving DecidableEq, Repr, Inhabited

/-- Strictly ascending order on list of strings. -/
def isSortedStrictAscending (xs : List String) : Bool :=
  match xs with
  | [] => true
  | [_] => true
  | x1 :: x2 :: rest => if x1 < x2 then isSortedStrictAscending (x2 :: rest) else false

structure EnvelopeEnc where
  schema_version : Nat
  mode : String
  source_pin : SourcePinEnc
  audit_roots : List String
  types : TypesEnumEnc
  assumptions : List String
  invariants : List String := []
  libraries : List LibraryRefEnc := []
  source_map : List (String × String) := []
  claimed_judgments : List String := []
  claimed_next_state : Option WorldEnc := none
  require_library_discharge : Bool := false
  require_invariant_discharge : Bool := false
  deriving DecidableEq, Repr, Inhabited

structure TypedExecutePayloadEnc where
  registry : RegistryEnc
  store : StoreEnc
  ctx : ContextEnc
  env : EnvironmentEnc
  now : Nat
  request : RequestEnc
  state : StateEnc
  deriving DecidableEq, Repr, Inhabited

structure CompositionStepPayloadEnc where
  config : ConfigEnc
  boundary : BoundaryEnc
  index : Nat
  history : List OutputObservationEnc
  step : StepEnc
  pre : WorldEnc
  deriving DecidableEq, Repr, Inhabited

structure CompositionRunPayloadEnc where
  config : ConfigEnc
  boundaries : List BoundaryEnc
  world : WorldEnc
  steps : List StepEnc
  deriving DecidableEq, Repr, Inhabited

inductive ReportStatus where
  | accepted
  | refused
  | incomplete
  deriving DecidableEq, Repr, Inhabited

structure Report where
  status : ReportStatus
  failure : Option FailurePath
  judgments : List JudgmentResult
  world : WorldEnc
  receipt : Option ReceiptEnc
  outputs : List OutputObservationEnc
  events : List SequentialEventEnc
  nextIndex : Nat
  cursorFailure : Option LocatedFailureEnc
  assumptions : List (String × String)
  outstanding : List String
  source_pin : SourcePinEnc
  audit_roots : List String
  unsupported : Option String := none
  deriving DecidableEq, Repr, Inhabited

structure RawObservation where
  world : WorldEnc
  receipt : Option ReceiptEnc
  outputs : List OutputObservationEnc
  events : List SequentialEventEnc
  nextIndex : Nat
  cursorFailure : Option LocatedFailureEnc
  kernelFailure : Option FailurePath
  deriving DecidableEq, Repr, Inhabited

inductive IllegalRationalReason where
  | zeroDenominator
  | noncanonical
  deriving DecidableEq, Repr, Inhabited

inductive DecodeFailure where
  | emptyDocument
  | resourceLimit (reason : String)
  | lexicalScientificOrFloat
  | notJsonObject
  | duplicateKey (name : String)
  | noncanonicalWhitespace
  | schemaVersion
  | missingField (name : String)
  | jsonType (path : String)
  | unknownIdentifier (name : String)
  | uniqueness (kind : String)
  | illegalRational (reason : IllegalRationalReason)
  | stateNonneg
  | unknownExecutableField (name : String)
  | unsupportedForm (reason : String)
  deriving DecidableEq, Repr, Inhabited

inductive DecodedExecution where
  | typed (envelope : EnvelopeEnc) (payload : TypedExecutePayloadEnc)
  | step (envelope : EnvelopeEnc) (payload : CompositionStepPayloadEnc)
  | run (envelope : EnvelopeEnc) (payload : CompositionRunPayloadEnc)
  deriving DecidableEq, Repr, Inhabited

def DecodedExecution.envelope : DecodedExecution → EnvelopeEnc
  | .typed env _ => env
  | .step env _ => env
  | .run env _ => env

structure DecodedAudit where
  envelope : EnvelopeEnc
  hasEnvelope : Bool := true
  commands : List String := []
  imported_theorems_min : Option Nat := none
  forbidden_claimed_roots : Option (List String) := none
  imported_theorems : Option Nat := none
  auditPrefix : Option String := none
  deriving DecidableEq, Repr, Inhabited

structure DecodedCodecDocument where
  envelope : Option EnvelopeEnc := none
  rawText : String := ""
  deriving DecidableEq, Repr, Inhabited

inductive DecodedIR where
  | execution (ir : DecodedExecution)
  | audit (ir : DecodedAudit)
  | codec (ir : DecodedCodecDocument)
  deriving DecidableEq, Repr, Inhabited

inductive CodecResult where
  | ok (ir : DecodedIR)
  | malformed (failure : DecodeFailure)
  | blocked (limit : String)
  deriving DecidableEq, Repr, Inhabited

inductive AuditStatus where
  | passed
  | failed
  | blocked
  deriving DecidableEq, Repr, Inhabited

structure AuditResult where
  status : AuditStatus
  failure : Option String := none
  prefixes : List String := []
  claimed_covered : Option Bool := none
  deriving DecidableEq, Repr, Inhabited

inductive Outcome where
  | codec (res : CodecResult)
  | execution (rep : Report)
  | audit (res : AuditResult)
  deriving DecidableEq, Repr, Inhabited


end DefiKernel.Certificates


namespace DefiKernel.Certificates

set_option linter.style.longLine false

/-- Tokens produced by the canonical JSON lexer. -/
inductive JsonToken where
  | lbrace
  | rbrace
  | lbracket
  | rbracket
  | colon
  | comma
  | str (s : String)
  | num (n : Lean.JsonNumber)
  | bool (b : Bool)
  | null
  deriving Inhabited, BEq

def hexDigit (n : Nat) : Char :=
  if n = 0 then '0'
  else if n = 1 then '1'
  else if n = 2 then '2'
  else if n = 3 then '3'
  else if n = 4 then '4'
  else if n = 5 then '5'
  else if n = 6 then '6'
  else if n = 7 then '7'
  else if n = 8 then '8'
  else if n = 9 then '9'
  else if n = 10 then 'a'
  else if n = 11 then 'b'
  else if n = 12 then 'c'
  else if n = 13 then 'd'
  else if n = 14 then 'e'
  else 'f'

def hexVal (c : Char) : Option Nat :=
  if c >= '0' && c <= '9' then some (c.toNat - '0'.toNat)
  else if c >= 'a' && c <= 'f' then some (c.toNat - 'a'.toNat + 10)
  else if c >= 'A' && c <= 'F' then some (c.toNat - 'A'.toNat + 10)
  else none

def escapeChar (c : Char) : List Char :=
  if c = '"' then ['\\', '"']
  else if c = '\\' then ['\\', '\\']
  else if c.toNat < 32 then
    ['\\', 'u', '0', '0', hexDigit (c.toNat / 16), hexDigit (c.toNat % 16)]
  else [c]

def escapeChars : List Char → List Char
  | [] => []
  | c :: cs => escapeChar c ++ escapeChars cs

/-- Structurally recursive string literal parser on character list.
    Enforces canonical C0 unicode escaping, accepts standard JSON escapes,
    rejects malformed/unknown escapes, and rejects literal unescaped control characters. -/
def lexString (acc : List Char) : List Char → Except DecodeFailure (String × List Char)
  | [] => .error .notJsonObject
  | '"' :: rest => .ok (String.ofList acc.reverse, rest)
  | '\\' :: 'u' :: h1 :: h2 :: h3 :: h4 :: rest =>
    match hexVal h1, hexVal h2, hexVal h3, hexVal h4 with
    | some v1, some v2, some v3, some v4 =>
      let val := ((v1 * 16 + v2) * 16 + v3) * 16 + v4
      if val < 0x110000 && !(0xd800 ≤ val && val < 0xe000) then
        lexString (Char.ofNat val :: acc) rest
      else .error .notJsonObject
    | _, _, _, _ => .error .notJsonObject
  | '\\' :: '"' :: rest => lexString ('"' :: acc) rest
  | '\\' :: '\\' :: rest => lexString ('\\' :: acc) rest
  | '\\' :: '/' :: rest => lexString ('/' :: acc) rest
  | '\\' :: 'b' :: rest => lexString ('\x08' :: acc) rest
  | '\\' :: 'f' :: rest => lexString ('\x0c' :: acc) rest
  | '\\' :: 'n' :: rest => lexString ('\n' :: acc) rest
  | '\\' :: 'r' :: rest => lexString ('\x0d' :: acc) rest
  | '\\' :: 't' :: rest => lexString ('\t' :: acc) rest
  | '\\' :: _ => .error .notJsonObject
  | c :: rest =>
    if c.toNat < 32 then .error .notJsonObject
    else lexString (c :: acc) rest

/-- Structurally recursive integer digit parser on character list. -/
def lexDigits (acc : Nat) : List Char → Nat × List Char
  | [] => (acc, [])
  | c :: rest =>
    if c >= '0' && c <= '9' then
      lexDigits (acc * 10 + (c.toNat - '0'.toNat)) rest
    else
      (acc, c :: rest)

/-- Fuel-bounded total canonical tokenizer. Guaranteed terminating on fuel. -/
def tokenizeFuel (fuel : Nat) (chars : List Char) : Except DecodeFailure (List JsonToken) :=
  match fuel with
  | 0 => .error (.resourceLimit "tokenizeFuel")
  | fuel' + 1 =>
    match chars with
    | [] => .ok []
    | ' ' :: rest | '\t' :: rest | '\n' :: rest | '\r' :: rest =>
      tokenizeFuel fuel' rest
    | '{' :: rest => do
      let toks ← tokenizeFuel fuel' rest
      .ok (.lbrace :: toks)
    | '}' :: rest => do
      let toks ← tokenizeFuel fuel' rest
      .ok (.rbrace :: toks)
    | '[' :: rest => do
      let toks ← tokenizeFuel fuel' rest
      .ok (.lbracket :: toks)
    | ']' :: rest => do
      let toks ← tokenizeFuel fuel' rest
      .ok (.rbracket :: toks)
    | ':' :: rest => do
      let toks ← tokenizeFuel fuel' rest
      .ok (.colon :: toks)
    | ',' :: rest => do
      let toks ← tokenizeFuel fuel' rest
      .ok (.comma :: toks)
    | '"' :: rest => do
      let (s, rest') ← lexString [] rest
      let toks ← tokenizeFuel fuel' rest'
      .ok (.str s :: toks)
    | 't' :: 'r' :: 'u' :: 'e' :: rest => do
      let toks ← tokenizeFuel fuel' rest
      .ok (.bool true :: toks)
    | 'f' :: 'a' :: 'l' :: 's' :: 'e' :: rest => do
      let toks ← tokenizeFuel fuel' rest
      .ok (.bool false :: toks)
    | 'n' :: 'u' :: 'l' :: 'l' :: rest => do
      let toks ← tokenizeFuel fuel' rest
      .ok (.null :: toks)
    | '-' :: c :: rest =>
      if c >= '0' && c <= '9' then do
        let (n, rest') := lexDigits (c.toNat - '0'.toNat) rest
        let toks ← tokenizeFuel fuel' rest'
        .ok (.num ⟨- (n : Int), 0⟩ :: toks)
      else
        .error .notJsonObject
    | c :: rest =>
      if c >= '0' && c <= '9' then do
        let (n, rest') := lexDigits (c.toNat - '0'.toNat) rest
        let toks ← tokenizeFuel fuel' rest'
        .ok (.num ⟨(n : Int), 0⟩ :: toks)
      else
        .error .notJsonObject

/-- Entrypoint for canonical JSON tokenization. -/
def tokenize (s : String) : Except DecodeFailure (List JsonToken) :=
  let cs := s.toList
  tokenizeFuel (cs.length + 1) cs

/-- State within an object frame during pushdown parsing. -/
inductive ObjState where
  | emptyOrKey
  | expectKey
  | expectColon (key : String)
  | expectVal (key : String)
  | expectCommaOrRbrace

/-- State within an array frame during pushdown parsing. -/
inductive ArrState where
  | emptyOrVal
  | expectVal
  | expectCommaOrRbracket

/-- Stack frame for pushdown automaton parsing nested structures. -/
inductive StackFrame where
  | obj (acc : List (String × Lean.Json)) (st : ObjState)
  | arr (acc : Array Lean.Json) (st : ArrState)

/-- State of the pushdown parser. -/
structure ParserState where
  stack : List StackFrame
  result : Option Lean.Json

/-- Feeds a completed JSON value into the enclosing stack frame. -/
def feedValue (st : ParserState) (v : Lean.Json) : Except DecodeFailure ParserState :=
  match st.stack with
  | [] =>
    if st.result.isSome then .error .notJsonObject
    else .ok { stack := [], result := some v }
  | StackFrame.arr acc ArrState.emptyOrVal :: rest =>
    if acc.size >= 4096 then .error (.resourceLimit "max_array_length")
    else .ok { st with stack := StackFrame.arr (acc.push v) ArrState.expectCommaOrRbracket :: rest }
  | StackFrame.arr acc ArrState.expectVal :: rest =>
    if acc.size >= 4096 then .error (.resourceLimit "max_array_length")
    else .ok { st with stack := StackFrame.arr (acc.push v) ArrState.expectCommaOrRbracket :: rest }
  | StackFrame.obj acc (ObjState.expectVal key) :: rest =>
    if acc.any (fun (k, _) => k == key) then .error (.duplicateKey key)
    else .ok { st with stack := StackFrame.obj ((key, v) :: acc) ObjState.expectCommaOrRbrace :: rest }
  | _ => .error .notJsonObject

/-- Single transition step for the pushdown parser on one token. -/
def parseStep (st : ParserState) (tok : JsonToken) : Except DecodeFailure ParserState :=
  match tok with
  | .null => feedValue st .null
  | .bool b => feedValue st (.bool b)
  | .num n => feedValue st (.num n)
  | .str s =>
    match st.stack with
    | StackFrame.obj acc ObjState.emptyOrKey :: rest =>
      .ok { st with stack := StackFrame.obj acc (ObjState.expectColon s) :: rest }
    | StackFrame.obj acc ObjState.expectKey :: rest =>
      .ok { st with stack := StackFrame.obj acc (ObjState.expectColon s) :: rest }
    | _ =>
      feedValue st (.str s)
  | .colon =>
    match st.stack with
    | StackFrame.obj acc (ObjState.expectColon k) :: rest =>
      .ok { st with stack := StackFrame.obj acc (ObjState.expectVal k) :: rest }
    | _ => .error .notJsonObject
  | .comma =>
    match st.stack with
    | StackFrame.obj acc ObjState.expectCommaOrRbrace :: rest =>
      .ok { st with stack :=StackFrame.obj acc ObjState.expectKey :: rest }
    | StackFrame.arr acc ArrState.expectCommaOrRbracket :: rest =>
      .ok { st with stack := StackFrame.arr acc ArrState.expectVal :: rest }
    | _ => .error .notJsonObject
  | .lbrace =>
    if st.stack.length >= 64 then .error (.resourceLimit "maxDepth")
    else match st.stack with
    | [] =>
      if st.result.isSome then .error .notJsonObject
      else .ok { st with stack := [StackFrame.obj [] ObjState.emptyOrKey] }
    | StackFrame.arr _ ArrState.emptyOrVal :: _
    | StackFrame.arr _ ArrState.expectVal :: _
    | StackFrame.obj _ (ObjState.expectVal _) :: _ =>
      .ok { st with stack := StackFrame.obj [] ObjState.emptyOrKey :: st.stack }
    | _ => .error .notJsonObject
  | .rbrace =>
    match st.stack with
    | StackFrame.obj acc ObjState.emptyOrKey :: rest =>
      let objVal := Lean.Json.mkObj acc.reverse
      feedValue { st with stack := rest } objVal
    | StackFrame.obj acc ObjState.expectCommaOrRbrace :: rest =>
      let objVal := Lean.Json.mkObj acc.reverse
      feedValue { st with stack := rest } objVal
    | _ => .error .notJsonObject
  | .lbracket =>
    if st.stack.length >= 64 then .error (.resourceLimit "maxDepth")
    else match st.stack with
    | [] =>
      if st.result.isSome then .error .notJsonObject
      else .ok { st with stack := [StackFrame.arr #[] ArrState.emptyOrVal] }
    | StackFrame.arr _ ArrState.emptyOrVal :: _
    | StackFrame.arr _ ArrState.expectVal :: _
    | StackFrame.obj _ (ObjState.expectVal _) :: _ =>
      .ok { st with stack := StackFrame.arr #[] ArrState.emptyOrVal :: st.stack }
    | _ => .error .notJsonObject
  | .rbracket =>
    match st.stack with
    | StackFrame.arr acc ArrState.emptyOrVal :: rest =>
      let arrVal := Lean.Json.arr acc
      feedValue { st with stack := rest } arrVal
    | StackFrame.arr acc ArrState.expectCommaOrRbracket :: rest =>
      let arrVal := Lean.Json.arr acc
      feedValue { st with stack := rest } arrVal
    | _ => .error .notJsonObject

/-- Total pushdown parser over a token list. Guaranteed terminating by structural recursion. -/
def parseTokens (toks : List JsonToken) : Except DecodeFailure Lean.Json := do
  let finalSt ← toks.foldlM parseStep { stack := [], result := none }
  match finalSt.stack, finalSt.result with
  | [], some j => .ok j
  | _, _ => .error .notJsonObject

/-- Total canonical JSON parser. Converts string to Lean.Json with zero partiality. -/
def parseCanonicalJson (s : String) : Except DecodeFailure Lean.Json := do
  let toks ← tokenize s
  parseTokens toks

theorem hexVal_hexDigit (n : Nat) (h : n < 16) : hexVal (hexDigit n) = some n := by
  match n, h with
  | 0, _ => rfl
  | 1, _ => rfl
  | 2, _ => rfl
  | 3, _ => rfl
  | 4, _ => rfl
  | 5, _ => rfl
  | 6, _ => rfl
  | 7, _ => rfl
  | 8, _ => rfl
  | 9, _ => rfl
  | 10, _ => rfl
  | 11, _ => rfl
  | 12, _ => rfl
  | 13, _ => rfl
  | 14, _ => rfl
  | 15, _ => rfl
  | _ + 16, h => omega

theorem bool_cond_of_lt32 (n : Nat) (h : n < 32) :
    (decide (n < 1114112) && !(decide (55296 ≤ n) && decide (n < 57344))) = true := by
  have h1 : n < 1114112 := by omega
  have h2 : ¬ (55296 ≤ n) := by omega
  rw [decide_eq_true h1, decide_eq_false h2]
  rfl

theorem lexString_quote (acc rest : List Char) :
    lexString acc ('\\' :: '"' :: rest) = lexString ('"' :: acc) rest := by
  rfl

theorem lexString_slash (acc rest : List Char) :
    lexString acc ('\\' :: '\\' :: rest) = lexString ('\\' :: acc) rest := by
  rfl

theorem lexString_u00 (c : Char) (h_lt : c.toNat < 32) (acc rest : List Char) :
    lexString acc ('\\' :: 'u' :: '0' :: '0' :: hexDigit (c.toNat / 16) :: hexDigit (c.toNat % 16) :: rest) =
      lexString (c :: acc) rest := by
  change (match hexVal '0', hexVal '0', hexVal (hexDigit (c.toNat / 16)), hexVal (hexDigit (c.toNat % 16)) with
    | some v1, some v2, some v3, some v4 =>
      let val := ((v1 * 16 + v2) * 16 + v3) * 16 + v4
      if val < 0x110000 && !(0xd800 ≤ val && val < 0xe000) then
        lexString (Char.ofNat val :: acc) rest
      else .error .notJsonObject
    | _, _, _, _ => .error .notJsonObject) = lexString (c :: acc) rest
  have h1 : hexVal '0' = some 0 := rfl
  have h3 : hexVal (hexDigit (c.toNat / 16)) = some (c.toNat / 16) := by
    apply hexVal_hexDigit; omega
  have h4 : hexVal (hexDigit (c.toNat % 16)) = some (c.toNat % 16) := by
    apply hexVal_hexDigit; omega
  rw [h1, h3, h4]
  dsimp
  have h_val : ((0 * 16 + 0) * 16 + c.toNat / 16) * 16 + c.toNat % 16 = c.toNat := by
    omega
  rw [h_val]
  have hb := bool_cond_of_lt32 c.toNat h_lt
  rw [hb]
  dsimp
  rw [Char.ofNat_toNat]

set_option linter.style.multiGoal false
set_option linter.unusedTactic false
set_option linter.unreachableTactic false

theorem lexString_normal (c : Char) (h_q : c ≠ '"') (h_s : c ≠ '\\') (h_ge : ¬ (c.toNat < 32))
    (acc rest : List Char) :
    lexString acc (c :: rest) = lexString (c :: acc) rest := by
  rw [lexString]
  split
  · contradiction
  · rfl
  all_goals
    try (intro h; subst h; contradiction)
    try (intro _ _ _ _ _ h _; subst h; contradiction)
    try (intro _ h _; subst h; contradiction)
    try (intro _ h; subst h; contradiction)
    try contradiction

theorem lexString_char (c : Char) (acc rest : List Char) :
    lexString acc (escapeChar c ++ rest) = lexString (c :: acc) rest := by
  dsimp [escapeChar]
  split
  · rename_i hc
    subst hc
    exact lexString_quote acc rest
  · split
    · rename_i _ hc
      subst hc
      exact lexString_slash acc rest
    · split
      · rename_i _ _ h_lt
        exact lexString_u00 c h_lt acc rest
      · rename_i h_not_q h_not_s h_not_lt
        exact lexString_normal c h_not_q h_not_s h_not_lt acc rest

theorem lexString_escapeChars (cs : List Char) (acc rest : List Char) :
    lexString acc (escapeChars cs ++ ('"' :: rest)) = .ok (String.ofList (acc.reverse ++ cs), rest) := by
  induction cs generalizing acc with
  | nil =>
    simp only [escapeChars, List.nil_append, List.append_nil]
    rfl
  | cons c cs ih =>
    simp only [escapeChars, List.append_assoc]
    rw [lexString_char]
    have h := ih (c :: acc)
    simp only [List.reverse_cons, List.append_assoc, List.singleton_append] at h
    exact h

/-- General string lexing inversion theorem: for any string s, lexing its canonical escaped form returns s. -/
theorem lexString_escapeJsonString (s : String) (rest : List Char) :
    lexString [] (escapeChars s.toList ++ ('"' :: rest)) = .ok (s, rest) := by
  have h := lexString_escapeChars s.toList [] rest
  simp only [List.reverse_nil, List.nil_append] at h
  rw [String.ofList_toList] at h
  exact h

/-- UTF-8 byte serialization inverse: decoding the UTF-8 bytes of any string returns the string. -/
theorem string_fromUTF8?_toUTF8 (s : String) : String.fromUTF8? s.toUTF8 = some s := by
  dsimp [String.fromUTF8?, String.toUTF8]
  have h : s.toByteArray.IsValidUTF8 := s.isValidUTF8
  rw [dif_pos h]
  rfl

/-- Generic string tokenization theorem: tokenizing an escaped string literal produces a string token. -/
theorem tokenizeFuel_string (fuel : Nat) (str : String) (rest : List Char) :
    tokenizeFuel (fuel + 1) ('"' :: (escapeChars str.toList ++ ('"' :: rest))) =
      (do
        let toks ← tokenizeFuel fuel rest
        .ok (JsonToken.str str :: toks)) := by
  change (do
      let (s, rest') ← lexString [] (escapeChars str.toList ++ ('"' :: rest))
      let toks ← tokenizeFuel fuel rest'
      .ok (JsonToken.str s :: toks)) = (do
      let toks ← tokenizeFuel fuel rest
      .ok (JsonToken.str str :: toks))
  have h_lex := lexString_escapeJsonString str rest
  rw [h_lex]
  rfl

/-- Pushdown parser base token inversion: string token decodes to Json.str. -/
theorem parseTokens_str (s : String) : parseTokens [JsonToken.str s] = .ok (Lean.Json.str s) := rfl

/-- Pushdown parser base token inversion: num token decodes to Json.num. -/
theorem parseTokens_num (n : Lean.JsonNumber) : parseTokens [JsonToken.num n] = .ok (Lean.Json.num n) := rfl

/-- Pushdown parser base token inversion: bool token decodes to Json.bool. -/
theorem parseTokens_bool (b : Bool) : parseTokens [JsonToken.bool b] = .ok (Lean.Json.bool b) := rfl

/-- Pushdown parser base token inversion: null token decodes to Json.null. -/
theorem parseTokens_null : parseTokens [JsonToken.null] = .ok Lean.Json.null := rfl

/-- Pushdown parser empty array inversion. -/
theorem parseTokens_empty_arr : parseTokens [JsonToken.lbracket, JsonToken.rbracket] = .ok (Lean.Json.arr #[]) := rfl

/-- Pushdown parser empty object inversion. -/
theorem parseTokens_empty_obj : parseTokens [JsonToken.lbrace, JsonToken.rbrace] = .ok (Lean.Json.mkObj []) := rfl

/-- Direct canonical parsing on true literal. -/
theorem parseCanonicalJson_true : parseCanonicalJson "true" = .ok (Lean.Json.bool true) := rfl

/-- Direct canonical parsing on false literal. -/
theorem parseCanonicalJson_false : parseCanonicalJson "false" = .ok (Lean.Json.bool false) := rfl

/-- Direct canonical parsing on null literal. -/
theorem parseCanonicalJson_null : parseCanonicalJson "null" = .ok Lean.Json.null := rfl

/-- Direct canonical parsing on empty array literal. -/
theorem parseCanonicalJson_empty_arr : parseCanonicalJson "[]" = .ok (Lean.Json.arr #[]) := rfl

/-- Direct canonical parsing on empty object literal. -/
theorem parseCanonicalJson_empty_obj : parseCanonicalJson "{}" = .ok (Lean.Json.mkObj []) := rfl

/-- Empty string fuel step helper. -/
theorem tokenizeFuel_empty (fuel : Nat) : tokenizeFuel (fuel + 1) [] = .ok [] := rfl

/-- Pushdown parser step equivalence on null token. -/
theorem parseStep_null (st : ParserState) : parseStep st .null = feedValue st .null := rfl

/-- Pushdown parser step equivalence on bool token. -/
theorem parseStep_bool (st : ParserState) (b : Bool) : parseStep st (.bool b) = feedValue st (.bool b) := rfl

/-- Pushdown parser step equivalence on num token. -/
theorem parseStep_num (st : ParserState) (n : Lean.JsonNumber) : parseStep st (.num n) = feedValue st (.num n) := rfl

/-- Pushdown parser step on string token in empty stack state. -/
theorem parseStep_str_empty (s : String) :
    parseStep { stack := [], result := none } (.str s) = feedValue { stack := [], result := none } (.str s) := rfl

/-- Pushdown parser step on string token when expecting a value in an object. -/
theorem parseStep_str_expectVal (acc : List (String × Lean.Json)) (key s : String) (rest : List StackFrame) :
    parseStep { stack := StackFrame.obj acc (ObjState.expectVal key) :: rest, result := none } (.str s) =
    feedValue { stack := StackFrame.obj acc (ObjState.expectVal key) :: rest, result := none } (.str s) := rfl

/-- Pushdown parser step on string token in initial array state. -/
theorem parseStep_str_arr_empty (acc : Array Lean.Json) (s : String) (rest : List StackFrame) :
    parseStep { stack := StackFrame.arr acc ArrState.emptyOrVal :: rest, result := none } (.str s) =
    feedValue { stack := StackFrame.arr acc ArrState.emptyOrVal :: rest, result := none } (.str s) := rfl

/-- Pushdown parser step on string token when expecting array element. -/
theorem parseStep_str_arr_val (acc : Array Lean.Json) (s : String) (rest : List StackFrame) :
    parseStep { stack := StackFrame.arr acc ArrState.expectVal :: rest, result := none } (.str s) =
    feedValue { stack := StackFrame.arr acc ArrState.expectVal :: rest, result := none } (.str s) := rfl

/-- Pushdown parser feeding value into object frame expecting value. -/
theorem feedValue_obj_expectVal (acc : List (String × Lean.Json)) (key : String) (v : Lean.Json) (rest : List StackFrame)
    (h_not_dup : acc.any (fun (k, _) => k == key) = false) :
    feedValue { stack := StackFrame.obj acc (ObjState.expectVal key) :: rest, result := none } v =
    .ok { stack := StackFrame.obj ((key, v) :: acc) ObjState.expectCommaOrRbrace :: rest, result := none } := by
  dsimp [feedValue]
  split
  · rename_i h
    rw [h_not_dup] at h
    contradiction
  · rfl

/-- Pushdown parser feeding value into array frame expecting value. -/
theorem feedValue_arr_expectVal (acc : Array Lean.Json) (v : Lean.Json) (rest : List StackFrame)
    (h_len : ¬ (acc.size ≥ 4096)) :
    feedValue { stack := StackFrame.arr acc ArrState.expectVal :: rest, result := none } v =
    .ok { stack := StackFrame.arr (acc.push v) ArrState.expectCommaOrRbracket :: rest, result := none } := by
  dsimp [feedValue]
  split
  · rename_i h; contradiction
  · rfl

/-- Pushdown parser feeding value into initial array frame. -/
theorem feedValue_arr_emptyOrVal (acc : Array Lean.Json) (v : Lean.Json) (rest : List StackFrame)
    (h_len : ¬ (acc.size ≥ 4096)) :
    feedValue { stack := StackFrame.arr acc ArrState.emptyOrVal :: rest, result := none } v =
    .ok { stack := StackFrame.arr (acc.push v) ArrState.expectCommaOrRbracket :: rest, result := none } := by
  dsimp [feedValue]
  split
  · rename_i h; contradiction
  · rfl

/-- Pushdown parser step opening object on empty stack. -/
theorem parseStep_lbrace_empty :
    parseStep { stack := [], result := none } .lbrace =
    .ok { stack := [StackFrame.obj [] ObjState.emptyOrKey], result := none } := rfl

/-- Pushdown parser step opening array on empty stack. -/
theorem parseStep_lbracket_empty :
    parseStep { stack := [], result := none } .lbracket =
    .ok { stack := [StackFrame.arr #[] ArrState.emptyOrVal], result := none } := rfl

/-- Pushdown parser step opening nested object when expecting object value. -/
theorem parseStep_lbrace_expectVal (acc : List (String × Lean.Json)) (key : String) (rest : List StackFrame)
    (h_depth : rest.length + 2 ≤ 64) :
    parseStep { stack := StackFrame.obj acc (ObjState.expectVal key) :: rest, result := none } .lbrace =
    .ok { stack := StackFrame.obj [] ObjState.emptyOrKey :: StackFrame.obj acc (ObjState.expectVal key) :: rest, result := none } := by
  dsimp [parseStep]
  split
  · rename_i h
    have : rest.length + 1 < 64 := by omega
    omega
  · rfl

/-- Pushdown parser step transitioning key in initial object state. -/
theorem parseStep_str_emptyOrKey (acc : List (String × Lean.Json)) (s : String) (rest : List StackFrame) :
    parseStep { stack := StackFrame.obj acc ObjState.emptyOrKey :: rest, result := none } (.str s) =
    .ok { stack := StackFrame.obj acc (ObjState.expectColon s) :: rest, result := none } := rfl

/-- Pushdown parser step transitioning key in subsequent object state. -/
theorem parseStep_str_expectKey (acc : List (String × Lean.Json)) (s : String) (rest : List StackFrame) :
    parseStep { stack := StackFrame.obj acc ObjState.expectKey :: rest, result := none } (.str s) =
    .ok { stack := StackFrame.obj acc (ObjState.expectColon s) :: rest, result := none } := rfl

/-- Pushdown parser step transitioning on colon in object state. -/
theorem parseStep_colon (acc : List (String × Lean.Json)) (k : String) (rest : List StackFrame) :
    parseStep { stack := StackFrame.obj acc (ObjState.expectColon k) :: rest, result := none } .colon =
    .ok { stack := StackFrame.obj acc (ObjState.expectVal k) :: rest, result := none } := rfl

/-- Pushdown parser step transitioning on comma in object state. -/
theorem parseStep_comma_obj (acc : List (String × Lean.Json)) (rest : List StackFrame) :
    parseStep { stack := StackFrame.obj acc ObjState.expectCommaOrRbrace :: rest, result := none } .comma =
    .ok { stack := StackFrame.obj acc ObjState.expectKey :: rest, result := none } := rfl

/-- Pushdown parser step transitioning on comma in array state. -/
theorem parseStep_comma_arr (acc : Array Lean.Json) (rest : List StackFrame) :
    parseStep { stack := StackFrame.arr acc ArrState.expectCommaOrRbracket :: rest, result := none } .comma =
    .ok { stack := StackFrame.arr acc ArrState.expectVal :: rest, result := none } := rfl

/-- Pushdown parser feeding one element into an array frame followed by comma. -/
theorem parse_arr_feed_elem (toks : List JsonToken) (acc : Array Lean.Json) (rest : List StackFrame)
    (v : Lean.Json)
    (h_feed : toks.foldlM parseStep { stack := StackFrame.arr acc ArrState.expectVal :: rest, result := none } =
              .ok { stack := StackFrame.arr (acc.push v) ArrState.expectCommaOrRbracket :: rest, result := none }) :
    (toks ++ [JsonToken.comma]).foldlM parseStep { stack := StackFrame.arr acc ArrState.expectVal :: rest, result := none } =
    .ok { stack := StackFrame.arr (acc.push v) ArrState.expectVal :: rest, result := none } := by
  rw [List.foldlM_append]
  dsimp [bind, Except.bind]
  rw [h_feed]
  rfl

/-- Pushdown parser transition for key and colon in object frame. -/
theorem parse_obj_field_step (k : String) (v_toks : List JsonToken) (v : Lean.Json)
    (acc : List (String × Lean.Json)) (rest : List StackFrame)
    (_h_not_dup : acc.any (fun (k', _) => k' == k) = false)
    (h_val : v_toks.foldlM parseStep { stack := StackFrame.obj acc (ObjState.expectVal k) :: rest, result := none } =
             .ok { stack := StackFrame.obj ((k, v) :: acc) ObjState.expectCommaOrRbrace :: rest, result := none }) :
    (JsonToken.str k :: JsonToken.colon :: v_toks).foldlM parseStep { stack := StackFrame.obj acc ObjState.expectKey :: rest, result := none } =
    .ok { stack := StackFrame.obj ((k, v) :: acc) ObjState.expectCommaOrRbrace :: rest, result := none } := by
  have h_split : (JsonToken.str k :: JsonToken.colon :: v_toks) = [JsonToken.str k, JsonToken.colon] ++ v_toks := rfl
  rw [h_split, List.foldlM_append]
  dsimp [bind, Except.bind, parseStep]
  exact h_val

/-- Pushdown parser transition for key, colon, value and trailing comma in object frame. -/
theorem parse_obj_field_comma (k : String) (v_toks : List JsonToken) (v : Lean.Json)
    (acc : List (String × Lean.Json)) (rest : List StackFrame)
    (h_not_dup : acc.any (fun (k', _) => k' == k) = false)
    (h_val : v_toks.foldlM parseStep { stack := StackFrame.obj acc (ObjState.expectVal k) :: rest, result := none } =
             .ok { stack := StackFrame.obj ((k, v) :: acc) ObjState.expectCommaOrRbrace :: rest, result := none }) :
    ((JsonToken.str k :: JsonToken.colon :: v_toks) ++ [JsonToken.comma]).foldlM parseStep { stack := StackFrame.obj acc ObjState.expectKey :: rest, result := none } =
    .ok { stack := StackFrame.obj ((k, v) :: acc) ObjState.expectKey :: rest, result := none } := by
  rw [List.foldlM_append]
  have h_step := parse_obj_field_step k v_toks v acc rest h_not_dup h_val
  rw [h_step]
  rfl

/-- Pushdown parser closing object on rbrace. -/
theorem parse_obj_rbrace (acc : List (String × Lean.Json)) (rest : List StackFrame) :
    parseStep { stack := StackFrame.obj acc ObjState.expectCommaOrRbrace :: rest, result := none } .rbrace =
    feedValue { stack := rest, result := none } (Lean.Json.mkObj acc.reverse) := rfl

/-- Pushdown parser closing array on rbracket. -/
theorem parse_arr_rbracket (acc : Array Lean.Json) (rest : List StackFrame) :
    parseStep { stack := StackFrame.arr acc ArrState.expectCommaOrRbracket :: rest, result := none } .rbracket =
    feedValue { stack := rest, result := none } (Lean.Json.arr acc) := rfl

/-- Top-level parseTokens reduction from successful foldlM. -/
theorem parseTokens_of_foldlM (toks : List JsonToken) (j : Lean.Json)
    (h : toks.foldlM parseStep { stack := [], result := none } = .ok { stack := [], result := some j }) :
    parseTokens toks = .ok j := by
  dsimp [parseTokens]
  rw [h]
  rfl

/-- Modular parsing equivalence combining tokenizer and pushdown parser. -/
theorem parseCanonicalJson_of_tokenize_parseTokens (s : String) (toks : List JsonToken) (j : Lean.Json)
    (h_tok : tokenize s = .ok toks)
    (h_parse : parseTokens toks = .ok j) :
    parseCanonicalJson s = .ok j := by
  dsimp [parseCanonicalJson]
  rw [h_tok]
  dsimp [bind, Except.bind]
  exact h_parse

/-- Tokenizer step on lbrace delimiter. -/
theorem tokenizeFuel_lbrace (fuel : Nat) (rest : List Char) :
    tokenizeFuel (fuel + 1) ('{' :: rest) =
      (do
        let toks ← tokenizeFuel fuel rest
        .ok (JsonToken.lbrace :: toks)) := rfl

/-- Tokenizer step on rbrace delimiter. -/
theorem tokenizeFuel_rbrace (fuel : Nat) (rest : List Char) :
    tokenizeFuel (fuel + 1) ('}' :: rest) =
      (do
        let toks ← tokenizeFuel fuel rest
        .ok (JsonToken.rbrace :: toks)) := rfl

/-- Tokenizer step on colon delimiter. -/
theorem tokenizeFuel_colon (fuel : Nat) (rest : List Char) :
    tokenizeFuel (fuel + 1) (':' :: rest) =
      (do
        let toks ← tokenizeFuel fuel rest
        .ok (JsonToken.colon :: toks)) := rfl

/-- Tokenizer step on comma delimiter. -/
theorem tokenizeFuel_comma (fuel : Nat) (rest : List Char) :
    tokenizeFuel (fuel + 1) (',' :: rest) =
      (do
        let toks ← tokenizeFuel fuel rest
        .ok (JsonToken.comma :: toks)) := rfl

/-- Tokenizer step on lbracket delimiter. -/
theorem tokenizeFuel_lbracket (fuel : Nat) (rest : List Char) :
    tokenizeFuel (fuel + 1) ('[' :: rest) =
      (do
        let toks ← tokenizeFuel fuel rest
        .ok (JsonToken.lbracket :: toks)) := rfl

/-- Tokenizer step on rbracket delimiter. -/
theorem tokenizeFuel_rbracket (fuel : Nat) (rest : List Char) :
    tokenizeFuel (fuel + 1) (']' :: rest) =
      (do
        let toks ← tokenizeFuel fuel rest
        .ok (JsonToken.rbracket :: toks)) := rfl

/-- Character step equation for lexDigits. -/
theorem lexDigits_step_eq (c : Char) (acc : Nat) (rest : List Char) :
    lexDigits acc (c :: rest) =
      if c.isDigit then lexDigits (acc * 10 + (c.toNat - '0'.toNat)) rest
      else (acc, c :: rest) := rfl

/-- General digits parsing induction: lexDigits on any all-digit list reconstructs ofDigitChars. -/
theorem lexDigits_of_all_digits (l : List Char) (hl : ∀ c ∈ l, c.isDigit = true)
    (acc : Nat) (rest : List Char) (h_end : match rest with | [] => True | c :: _ => c.isDigit = false) :
    lexDigits acc (l ++ rest) = (Nat.ofDigitChars 10 l acc, rest) := by
  induction l generalizing acc with
  | nil =>
    simp only [List.nil_append, Nat.ofDigitChars_nil]
    cases rest with
    | nil => rfl
    | cons c cs =>
      rw [lexDigits_step_eq]
      dsimp at h_end
      rw [h_end]
      rfl
  | cons c cs ih =>
    simp only [List.cons_append, Nat.ofDigitChars_cons]
    have hc := hl c (by simp)
    have hcs : ∀ c' ∈ cs, c'.isDigit = true := fun c' hc' => hl c' (by simp [hc'])
    rw [lexDigits_step_eq]
    rw [hc]
    dsimp
    have h_comm : acc * 10 = 10 * acc := Nat.mul_comm _ _
    rw [h_comm]
    exact ih hcs (10 * acc + (c.toNat - '0'.toNat))

/-- Head/tail decomposition for lexDigits on decimal representation of natural numbers. -/
theorem lexDigits_head_tl (c : Char) (tl : List Char) (n : Nat)
    (h_eq : Nat.toDigits 10 n = c :: tl) (rest : List Char)
    (h_end : match rest with | [] => True | c :: _ => c.isDigit = false) :
    c.isDigit = true ∧
    lexDigits (c.toNat - '0'.toNat) (tl ++ rest) = (n, rest) := by
  have hl : ∀ x ∈ Nat.toDigits 10 n, x.isDigit = true := by
    intro x hx
    exact Nat.isDigit_of_mem_toDigits (by decide) (by decide) hx
  have hc : c.isDigit = true := by
    have : c ∈ Nat.toDigits 10 n := by simp [h_eq]
    exact hl c this
  have htl : ∀ x ∈ tl, x.isDigit = true := by
    intro x hx
    have : x ∈ Nat.toDigits 10 n := by simp [h_eq, hx]
    exact hl x this
  refine ⟨hc, ?_⟩
  rw [lexDigits_of_all_digits tl htl (c.toNat - '0'.toNat) rest h_end]
  have h_cons : Nat.ofDigitChars 10 (c :: tl) 0 = Nat.ofDigitChars 10 tl (10 * 0 + (c.toNat - '0'.toNat)) := rfl
  simp only [Nat.mul_zero, Nat.zero_add] at h_cons
  rw [← h_cons, ← h_eq]
  rw [Nat.ofDigitChars_ten_toDigits]

/-- Nonemptiness of natural decimal digit representation. -/
theorem toDigits_nonempty (n : Nat) : ∃ c tl, Nat.toDigits 10 n = c :: tl := by
  cases h : Nat.toDigits 10 n with
  | nil =>
    have h_len : 0 < (Nat.toDigits 10 n).length := Nat.length_toDigits_pos
    rw [h] at h_len
    contradiction
  | cons c tl =>
    exact ⟨c, tl, rfl⟩

/-- Fuel-bounded tokenizer transition on initial digit character. -/
theorem tokenizeFuel_digit_step (fuel : Nat) (c : Char) (tl : List Char) (rest : List Char)
    (hc : c.isDigit = true)
    (n : Nat)
    (h_lex : lexDigits (c.toNat - '0'.toNat) (tl ++ rest) = (n, rest)) :
    tokenizeFuel (fuel + 1) (c :: (tl ++ rest)) =
      (do
        let toks ← tokenizeFuel fuel rest
        .ok (JsonToken.num ⟨(n : Int), 0⟩ :: toks)) := by
  rw [tokenizeFuel]
  split
  · rw [h_lex]
  · rename_i h_not
    have hc_cond : (decide (c ≥ '0') && decide (c ≤ '9')) = true := hc
    contradiction
  all_goals
    try (intro h1; subst h1; revert hc; decide)
    try (intro _ h1 _; subst h1; revert hc; decide)
    try (intro _ h1; subst h1; revert hc; decide)
    try (intro _ _ h1 _; subst h1; revert hc; decide)

/-- General decimal tokenization for arbitrary natural numbers followed by non-digit delimiter. -/
theorem tokenizeFuel_nat (fuel : Nat) (n : Nat) (rest : List Char)
    (h_end : match rest with | [] => True | c :: _ => c.isDigit = false) :
    tokenizeFuel (fuel + 1) ((toString n).toList ++ rest) =
      (do
        let toks ← tokenizeFuel fuel rest
        .ok (JsonToken.num ⟨(n : Int), 0⟩ :: toks)) := by
  have h_repr : (toString n).toList = Nat.toDigits 10 n := by
    change (Nat.repr n).toList = Nat.toDigits 10 n
    exact Nat.toList_repr
  rw [h_repr]
  rcases toDigits_nonempty n with ⟨c, tl, h_digits⟩
  rw [h_digits]
  have ⟨hc, h_lex⟩ := lexDigits_head_tl c tl n h_digits rest h_end
  simp only [List.cons_append]
  exact tokenizeFuel_digit_step fuel c tl rest hc n h_lex

/-- General decimal tokenization for arbitrary integers (positive, zero, or negative). -/
theorem tokenizeFuel_int (fuel : Nat) (i : Int) (rest : List Char)
    (h_end : match rest with | [] => True | c :: _ => c.isDigit = false) :
    tokenizeFuel (fuel + 1) ((toString i).toList ++ rest) =
      (do
        let toks ← tokenizeFuel fuel rest
        .ok (JsonToken.num ⟨i, 0⟩ :: toks)) := by
  cases i with
  | ofNat n =>
    exact tokenizeFuel_nat fuel n rest h_end
  | negSucc n =>
    have h_repr : (toString (Int.negSucc n)).toList = '-' :: (Nat.repr (n + 1)).toList := by
      change ("-" ++ Nat.repr (n + 1)).toList = '-' :: (Nat.repr (n + 1)).toList
      rw [String.toList_append]
      rfl
    rw [h_repr]
    have h_nat_repr : (Nat.repr (n + 1)).toList = Nat.toDigits 10 (n + 1) := Nat.toList_repr
    rw [h_nat_repr]
    rcases toDigits_nonempty (n + 1) with ⟨c, tl, h_digits⟩
    rw [h_digits]
    have ⟨hc, h_lex⟩ := lexDigits_head_tl c tl (n + 1) h_digits rest h_end
    simp only [List.cons_append]
    rw [tokenizeFuel]
    have hc_cond : (decide (c ≥ '0') && decide (c ≤ '9')) = true := hc
    rw [hc_cond]
    dsimp
    have h_lex' : lexDigits (c.toNat - 48) (tl ++ rest) = (n + 1, rest) := h_lex
    rw [h_lex']
    have : (-↑(n + 1) : Int) = Int.negSucc n := rfl
    rw [this]

/-- Generic pushdown parser step inverse on canonical rational token sequence. -/
theorem parseTokens_rat (r : RatEnc) :
    parseTokens [
      JsonToken.lbrace,
      JsonToken.str "num", JsonToken.colon, JsonToken.num ⟨r.num, 0⟩,
      JsonToken.comma,
      JsonToken.str "den", JsonToken.colon, JsonToken.num ⟨(r.den : Int), 0⟩,
      JsonToken.rbrace
    ] = .ok (Lean.Json.mkObj [("num", Lean.Json.num r.num), ("den", Lean.Json.num (r.den : Int))]) := rfl

/-- Pushdown parser transition for first key and colon in empty/initial object frame. -/
theorem parse_obj_first_field_step (k : String) (v_toks : List JsonToken) (v : Lean.Json)
    (acc : List (String × Lean.Json)) (rest : List StackFrame)
    (h_val : v_toks.foldlM parseStep { stack := StackFrame.obj acc (ObjState.expectVal k) :: rest, result := none } =
             .ok { stack := StackFrame.obj ((k, v) :: acc) ObjState.expectCommaOrRbrace :: rest, result := none }) :
    (JsonToken.str k :: JsonToken.colon :: v_toks).foldlM parseStep { stack := StackFrame.obj acc ObjState.emptyOrKey :: rest, result := none } =
    .ok { stack := StackFrame.obj ((k, v) :: acc) ObjState.expectCommaOrRbrace :: rest, result := none } := by
  have h_split : (JsonToken.str k :: JsonToken.colon :: v_toks) = [JsonToken.str k, JsonToken.colon] ++ v_toks := rfl
  rw [h_split, List.foldlM_append]
  dsimp [bind, Except.bind, parseStep]
  exact h_val

/-- Pushdown parser transition for first key, colon, value and trailing comma in empty/initial object frame. -/
theorem parse_obj_first_field_comma (k : String) (v_toks : List JsonToken) (v : Lean.Json)
    (acc : List (String × Lean.Json)) (rest : List StackFrame)
    (h_val : v_toks.foldlM parseStep { stack := StackFrame.obj acc (ObjState.expectVal k) :: rest, result := none } =
             .ok { stack := StackFrame.obj ((k, v) :: acc) ObjState.expectCommaOrRbrace :: rest, result := none }) :
    ((JsonToken.str k :: JsonToken.colon :: v_toks) ++ [JsonToken.comma]).foldlM parseStep { stack := StackFrame.obj acc ObjState.emptyOrKey :: rest, result := none } =
    .ok { stack := StackFrame.obj ((k, v) :: acc) ObjState.expectKey :: rest, result := none } := by
  rw [List.foldlM_append]
  have h_step := parse_obj_first_field_step k v_toks v acc rest h_val
  rw [h_step]
  rfl

/-- Feeding scalar string property into object frame expecting value. -/
theorem parse_field_str_val (acc : List (String × Lean.Json)) (key s : String) (rest : List StackFrame)
    (h_not_dup : acc.any (fun (k, _) => k == key) = false) :
    [JsonToken.str s].foldlM parseStep { stack := StackFrame.obj acc (ObjState.expectVal key) :: rest, result := none } =
    .ok { stack := StackFrame.obj ((key, Lean.Json.str s) :: acc) ObjState.expectCommaOrRbrace :: rest, result := none } := by
  dsimp [List.foldlM, parseStep, bind, Except.bind]
  rw [feedValue_obj_expectVal acc key (.str s) rest h_not_dup]
  rfl

/-- Feeding scalar number property into object frame expecting value. -/
theorem parse_field_num_val (acc : List (String × Lean.Json)) (key : String) (n : Lean.JsonNumber) (rest : List StackFrame)
    (h_not_dup : acc.any (fun (k, _) => k == key) = false) :
    [JsonToken.num n].foldlM parseStep { stack := StackFrame.obj acc (ObjState.expectVal key) :: rest, result := none } =
    .ok { stack := StackFrame.obj ((key, Lean.Json.num n) :: acc) ObjState.expectCommaOrRbrace :: rest, result := none } := by
  dsimp [List.foldlM, parseStep, bind, Except.bind]
  rw [feedValue_obj_expectVal acc key (.num n) rest h_not_dup]
  rfl

/-- Feeding scalar boolean property into object frame expecting value. -/
theorem parse_field_bool_val (acc : List (String × Lean.Json)) (key : String) (b : Bool) (rest : List StackFrame)
    (h_not_dup : acc.any (fun (k, _) => k == key) = false) :
    [JsonToken.bool b].foldlM parseStep { stack := StackFrame.obj acc (ObjState.expectVal key) :: rest, result := none } =
    .ok { stack := StackFrame.obj ((key, Lean.Json.bool b) :: acc) ObjState.expectCommaOrRbrace :: rest, result := none } := by
  dsimp [List.foldlM, parseStep, bind, Except.bind]
  rw [feedValue_obj_expectVal acc key (.bool b) rest h_not_dup]
  rfl

/-- Feeding null property into object frame expecting value. -/
theorem parse_field_null_val (acc : List (String × Lean.Json)) (key : String) (rest : List StackFrame)
    (h_not_dup : acc.any (fun (k, _) => k == key) = false) :
    [JsonToken.null].foldlM parseStep { stack := StackFrame.obj acc (ObjState.expectVal key) :: rest, result := none } =
    .ok { stack := StackFrame.obj ((key, Lean.Json.null) :: acc) ObjState.expectCommaOrRbrace :: rest, result := none } := by
  dsimp [List.foldlM, parseStep, bind, Except.bind]
  rw [feedValue_obj_expectVal acc key .null rest h_not_dup]
  rfl

/-- Canonical JSON tree representation for recursive parser and serializer inversion. -/
inductive TreeJson where
  | null
  | bool (b : Bool)
  | num (n : Int)
  | str (s : String)
  | arr (elements : List TreeJson)
  | obj (fields : List (String × TreeJson))
  deriving Repr, Inhabited

mutual
  /-- Semantic JSON mapping for TreeJson values. -/
  def TreeJson.toJson : TreeJson → Lean.Json
    | .null => Lean.Json.null
    | .bool b => Lean.Json.bool b
    | .num n => Lean.Json.num ⟨n, 0⟩
    | .str s => Lean.Json.str s
    | .arr xs => Lean.Json.arr (TreeJson.toJsonList xs).toArray
    | .obj kvs => Lean.Json.mkObj (TreeJson.toJsonObj kvs)

  /-- Semantic JSON element mapping for list of TreeJson values. -/
  def TreeJson.toJsonList : List TreeJson → List Lean.Json
    | [] => []
    | x :: xs => TreeJson.toJson x :: TreeJson.toJsonList xs

  /-- Semantic JSON field mapping for object key-value pairs. -/
  def TreeJson.toJsonObj : List (String × TreeJson) → List (String × Lean.Json)
    | [] => []
    | (k, v) :: kvs => (k, TreeJson.toJson v) :: TreeJson.toJsonObj kvs
end

mutual
  /-- Canonical token sequence produced by TreeJson. -/
  def TreeJson.tokens : TreeJson → List JsonToken
    | .null => [JsonToken.null]
    | .bool b => [JsonToken.bool b]
    | .num n => [JsonToken.num ⟨n, 0⟩]
    | .str s => [JsonToken.str s]
    | .arr xs => [JsonToken.lbracket] ++ TreeJson.tokensList xs ++ [JsonToken.rbracket]
    | .obj kvs => [JsonToken.lbrace] ++ TreeJson.tokensObj kvs ++ [JsonToken.rbrace]

  /-- Token sequence for elements of an array. -/
  def TreeJson.tokensList : List TreeJson → List JsonToken
    | [] => []
    | [x] => TreeJson.tokens x
    | x :: xs => TreeJson.tokens x ++ [JsonToken.comma] ++ TreeJson.tokensList xs

  /-- Token sequence for fields of an object. -/
  def TreeJson.tokensObj : List (String × TreeJson) → List JsonToken
    | [] => []
    | [(k, v)] => [JsonToken.str k, JsonToken.colon] ++ TreeJson.tokens v
    | (k, v) :: kvs => [JsonToken.str k, JsonToken.colon] ++ TreeJson.tokens v ++ [JsonToken.comma] ++ TreeJson.tokensObj kvs
end

/-- Helper to format an escaped JSON string. -/
def escapeTreeString (s : String) : String :=
  String.ofList ('"' :: (escapeChars s.toList ++ ['"']))

mutual
  /-- Canonical string encoding of TreeJson. -/
  def TreeJson.encode : TreeJson → String
    | .null => "null"
    | .bool true => "true"
    | .bool false => "false"
    | .num n => toString n
    | .str s => escapeTreeString s
    | .arr xs => "[" ++ TreeJson.encodeList xs ++ "]"
    | .obj kvs => "{" ++ TreeJson.encodeObj kvs ++ "}"

  /-- Canonical string encoding for array elements. -/
  def TreeJson.encodeList : List TreeJson → String
    | [] => ""
    | [x] => TreeJson.encode x
    | x :: xs => TreeJson.encode x ++ "," ++ TreeJson.encodeList xs

  /-- Canonical string encoding for object fields. -/
  def TreeJson.encodeObj : List (String × TreeJson) → String
    | [] => ""
    | [(k, v)] => escapeTreeString k ++ ":" ++ TreeJson.encode v
    | (k, v) :: kvs => escapeTreeString k ++ ":" ++ TreeJson.encode v ++ "," ++ TreeJson.encodeObj kvs
end

/-- Pushdown parser foldlM equivalence on null tree value. -/
theorem parseStep_foldlM_tokens_null (st : ParserState) :
    (TreeJson.tokens .null).foldlM parseStep st = feedValue st .null := by
  dsimp [TreeJson.tokens, List.foldlM, parseStep, bind, Except.bind]
  cases feedValue st .null <;> rfl

/-- Pushdown parser foldlM equivalence on boolean tree value. -/
theorem parseStep_foldlM_tokens_bool (st : ParserState) (b : Bool) :
    (TreeJson.tokens (.bool b)).foldlM parseStep st = feedValue st (.bool b) := by
  dsimp [TreeJson.tokens, List.foldlM, parseStep, bind, Except.bind]
  cases feedValue st (.bool b) <;> rfl

/-- Pushdown parser foldlM equivalence on number tree value. -/
theorem parseStep_foldlM_tokens_num (st : ParserState) (n : Int) :
    (TreeJson.tokens (.num n)).foldlM parseStep st = feedValue st (.num ⟨n, 0⟩) := by
  dsimp [TreeJson.tokens, List.foldlM, parseStep, bind, Except.bind]
  cases feedValue st (.num ⟨n, 0⟩) <;> rfl

/-- Pushdown parser step equivalence on empty array token list. -/
theorem parseTokensList_nil (acc : Array Lean.Json) (rest : List StackFrame) :
    (TreeJson.tokensList []).foldlM parseStep { stack := StackFrame.arr acc ArrState.emptyOrVal :: rest, result := none } =
    .ok { stack := StackFrame.arr acc ArrState.emptyOrVal :: rest, result := none } := rfl

/-- Pushdown parser step equivalence on empty object token list. -/
theorem parseTokensObj_nil (acc : List (String × Lean.Json)) (rest : List StackFrame) :
    (TreeJson.tokensObj []).foldlM parseStep { stack := StackFrame.obj acc ObjState.emptyOrKey :: rest, result := none } =
    .ok { stack := StackFrame.obj acc ObjState.emptyOrKey :: rest, result := none } := rfl

/-- Top-level pushdown parser foldlM inversion on empty TreeJson object. -/
theorem parseTokens_empty_tree_obj (st : ParserState) (h_stack : st.stack = []) (h_res : st.result = none) :
    (TreeJson.tokens (.obj [])).foldlM parseStep st = feedValue st (Lean.Json.mkObj []) := by
  cases st with | mk stack res =>
  dsimp at h_stack h_res
  subst h_stack h_res
  dsimp [TreeJson.tokens, TreeJson.tokensObj, List.foldlM, parseStep, bind, Except.bind]
  cases feedValue { stack := [], result := none } (Lean.Json.mkObj []) <;> rfl

/-- Top-level pushdown parser foldlM inversion on empty TreeJson array. -/
theorem parseTokens_empty_tree_arr (st : ParserState) (h_stack : st.stack = []) (h_res : st.result = none) :
    (TreeJson.tokens (.arr [])).foldlM parseStep st = feedValue st (Lean.Json.arr #[]) := by
  cases st with | mk stack res =>
  dsimp at h_stack h_res
  subst h_stack h_res
  dsimp [TreeJson.tokens, TreeJson.tokensList, List.foldlM, parseStep, bind, Except.bind]
  cases feedValue { stack := [], result := none } (Lean.Json.arr #[]) <;> rfl

/-- Top-level parseTokens inversion on TreeJson.null. -/
theorem parseTokens_tree_null : parseTokens (TreeJson.tokens .null) = .ok Lean.Json.null := rfl

/-- Top-level parseTokens inversion on TreeJson.bool. -/
theorem parseTokens_tree_bool (b : Bool) : parseTokens (TreeJson.tokens (.bool b)) = .ok (Lean.Json.bool b) := rfl

/-- Top-level parseTokens inversion on TreeJson.num. -/
theorem parseTokens_tree_num (n : Int) : parseTokens (TreeJson.tokens (.num n)) = .ok (Lean.Json.num ⟨n, 0⟩) := rfl

/-- Top-level parseTokens inversion on TreeJson.str. -/
theorem parseTokens_tree_str (s : String) : parseTokens (TreeJson.tokens (.str s)) = .ok (Lean.Json.str s) := rfl

/-- Top-level parseTokens inversion on empty TreeJson.arr. -/
theorem parseTokens_tree_empty_arr : parseTokens (TreeJson.tokens (.arr [])) = .ok (Lean.Json.arr #[]) := rfl

/-- Top-level parseTokens inversion on empty TreeJson.obj. -/
theorem parseTokens_tree_empty_obj : parseTokens (TreeJson.tokens (.obj [])) = .ok (Lean.Json.mkObj []) := rfl

/-- Predicate characterizing parser states that are structurally ready to receive an evaluated value. -/
def IsValueContext (st : ParserState) : Prop :=
  st.result = none ∧
  match st.stack with
  | [] => True
  | StackFrame.arr _ ArrState.emptyOrVal :: _ => True
  | StackFrame.arr _ ArrState.expectVal :: _ => True
  | StackFrame.obj _ (ObjState.expectVal _) :: _ => True
  | _ => False

mutual
  /-- Syntactic container nesting depth of a TreeJson document. -/
  def TreeJson.depth : TreeJson → Nat
    | .null | .bool _ | .num _ | .str _ => 0
    | .arr xs => 1 + TreeJson.depthList xs
    | .obj kvs => 1 + TreeJson.depthObj kvs

  /-- Maximal syntactic nesting depth across a list of array elements. -/
  def TreeJson.depthList : List TreeJson → Nat
    | [] => 0
    | x :: xs => max (TreeJson.depth x) (TreeJson.depthList xs)

  /-- Maximal syntactic nesting depth across key-value fields of an object. -/
  def TreeJson.depthObj : List (String × TreeJson) → Nat
    | [] => 0
    | (_, v) :: kvs => max (TreeJson.depth v) (TreeJson.depthObj kvs)
end

mutual
  /-- Structural node size measure for well-founded tree induction. -/
  def TreeJson.size : TreeJson → Nat
    | .null | .bool _ | .num _ | .str _ => 1
    | .arr xs => 1 + TreeJson.sizeList xs
    | .obj kvs => 1 + TreeJson.sizeObj kvs

  /-- Structural node size across an array element list. -/
  def TreeJson.sizeList : List TreeJson → Nat
    | [] => 0
    | x :: xs => TreeJson.size x + TreeJson.sizeList xs

  /-- Structural node size across an object field list. -/
  def TreeJson.sizeObj : List (String × TreeJson) → Nat
    | [] => 0
    | (_, v) :: kvs => TreeJson.size v + TreeJson.sizeObj kvs
end

mutual
  /-- Proof-level structural admissibility for canonical JSON trees:
      arrays obey the 4096-element budget and objects have pairwise distinct keys. -/
  def TreeJson.Valid : TreeJson → Prop
    | .null | .bool _ | .num _ | .str _ => True
    | .arr xs => xs.length ≤ 4096 ∧ TreeJson.ValidList xs
    | .obj kvs => (kvs.map Prod.fst).Nodup ∧ TreeJson.ValidObj kvs

  /-- Structural admissibility across array element lists. -/
  def TreeJson.ValidList : List TreeJson → Prop
    | [] => True
    | x :: xs => TreeJson.Valid x ∧ TreeJson.ValidList xs

  /-- Structural admissibility across object field lists. -/
  def TreeJson.ValidObj : List (String × TreeJson) → Prop
    | [] => True
    | (_, v) :: kvs => TreeJson.Valid v ∧ TreeJson.ValidObj kvs
end

/-- Positive size lower bound for all TreeJson nodes. -/
theorem TreeJson.size_pos (t : TreeJson) : 0 < TreeJson.size t := by
  cases t <;> dsimp [TreeJson.size] <;> omega

/-- Element size is bounded by aggregate size of the enclosing array list. -/
theorem TreeJson.mem_sizeList (x : TreeJson) (xs : List TreeJson) (h : x ∈ xs) :
    TreeJson.size x ≤ TreeJson.sizeList xs := by
  induction xs with
  | nil => contradiction
  | cons y ys ih =>
    dsimp [TreeJson.sizeList]
    cases h with
    | head => omega
    | tail _ h_in =>
      have := ih h_in
      omega

/-- Value size is bounded by aggregate size of the enclosing object field list. -/
theorem TreeJson.mem_sizeObj (k : String) (v : TreeJson) (kvs : List (String × TreeJson)) (h : (k, v) ∈ kvs) :
    TreeJson.size v ≤ TreeJson.sizeObj kvs := by
  induction kvs with
  | nil => contradiction
  | cons f fs ih =>
    rcases f with ⟨k', v'⟩
    dsimp [TreeJson.sizeObj]
    cases h with
    | head => omega
    | tail _ h_in =>
      have := ih h_in
      omega

/-- Validity propagates to any member of an admissible array element list. -/
theorem TreeJson.valid_of_mem_validList (x : TreeJson) (xs : List TreeJson)
    (h_vl : TreeJson.ValidList xs) (h_in : x ∈ xs) : TreeJson.Valid x := by
  induction xs with
  | nil => contradiction
  | cons y ys ih =>
    dsimp [TreeJson.ValidList] at h_vl
    cases h_in with
    | head => exact h_vl.1
    | tail _ h_tl => exact ih h_vl.2 h_tl

/-- Validity propagates to any field value of an admissible object field list. -/
theorem TreeJson.valid_of_mem_validObj (k : String) (v : TreeJson) (kvs : List (String × TreeJson))
    (h_vo : TreeJson.ValidObj kvs) (h_in : (k, v) ∈ kvs) : TreeJson.Valid v := by
  induction kvs with
  | nil => contradiction
  | cons f fs ih =>
    rcases f with ⟨k', v'⟩
    dsimp [TreeJson.ValidObj] at h_vo
    cases h_in with
    | head => exact h_vo.1
    | tail _ h_tl => exact ih h_vo.2 h_tl

/-- Pushdown automaton step on string token in any value-expecting context. -/
theorem parseStep_str_of_isValueContext (st : ParserState) (h_ctx : IsValueContext st) (s : String) :
    parseStep st (.str s) = feedValue st (.str s) := by
  rcases st with ⟨stack, res⟩
  rcases h_ctx with ⟨h_res, h_stack⟩
  dsimp at h_res h_stack ⊢
  dsimp [parseStep]
  cases stack with
  | nil => rfl
  | cons frame rest =>
    cases frame with
    | obj acc ost =>
      cases ost with
      | expectVal k => rfl
      | emptyOrKey => contradiction
      | expectKey => contradiction
      | expectColon _ => contradiction
      | expectCommaOrRbrace => contradiction
    | arr acc ast =>
      cases ast with
      | emptyOrVal => rfl
      | expectVal => rfl
      | expectCommaOrRbracket => contradiction

/-- Pushdown automaton step on lbrace delimiter in any value-expecting context. -/
theorem parseStep_lbrace_of_isValueContext (st : ParserState)
    (h_ctx : IsValueContext st) (h_depth : st.stack.length < 64) :
    parseStep st .lbrace = .ok { stack := StackFrame.obj [] ObjState.emptyOrKey :: st.stack, result := none } := by
  rcases st with ⟨stack, res⟩
  rcases h_ctx with ⟨h_res, h_stack⟩
  dsimp at h_res h_stack h_depth ⊢
  subst h_res
  dsimp [parseStep]
  split
  · rename_i h_ge; omega
  · cases stack with
    | nil => rfl
    | cons frame rest =>
      cases frame with
      | obj acc ost =>
        cases ost with
        | expectVal k => rfl
        | emptyOrKey => contradiction
        | expectKey => contradiction
        | expectColon _ => contradiction
        | expectCommaOrRbrace => contradiction
      | arr acc ast =>
        cases ast with
        | emptyOrVal => rfl
        | expectVal => rfl
        | expectCommaOrRbracket => contradiction

/-- Pushdown automaton step on lbracket delimiter in any value-expecting context. -/
theorem parseStep_lbracket_of_isValueContext (st : ParserState)
    (h_ctx : IsValueContext st) (h_depth : st.stack.length < 64) :
    parseStep st .lbracket = .ok { stack := StackFrame.arr #[] ArrState.emptyOrVal :: st.stack, result := none } := by
  rcases st with ⟨stack, res⟩
  rcases h_ctx with ⟨h_res, h_stack⟩
  dsimp at h_res h_stack h_depth ⊢
  subst h_res
  dsimp [parseStep]
  split
  · rename_i h_ge; omega
  · cases stack with
    | nil => rfl
    | cons frame rest =>
      cases frame with
      | obj acc ost =>
        cases ost with
        | expectVal k => rfl
        | emptyOrKey => contradiction
        | expectKey => contradiction
        | expectColon _ => contradiction
        | expectCommaOrRbrace => contradiction
      | arr acc ast =>
        cases ast with
        | emptyOrVal => rfl
        | expectVal => rfl
        | expectCommaOrRbracket => contradiction

/-- Successful value ingestion into an initial array frame with capacity. -/
theorem feedValue_arr_emptyOrVal_ok (acc : Array Lean.Json) (v : Lean.Json) (rest : List StackFrame)
    (h_len : acc.size < 4096) :
    feedValue { stack := StackFrame.arr acc ArrState.emptyOrVal :: rest, result := none } v =
    .ok { stack := StackFrame.arr (acc.push v) ArrState.expectCommaOrRbracket :: rest, result := none } := by
  dsimp [feedValue]
  split
  · rename_i h; omega
  · rfl

/-- Successful value ingestion into an expecting array frame with capacity. -/
theorem feedValue_arr_expectVal_ok (acc : Array Lean.Json) (v : Lean.Json) (rest : List StackFrame)
    (h_len : acc.size < 4096) :
    feedValue { stack := StackFrame.arr acc ArrState.expectVal :: rest, result := none } v =
    .ok { stack := StackFrame.arr (acc.push v) ArrState.expectCommaOrRbracket :: rest, result := none } := by
  dsimp [feedValue]
  split
  · rename_i h; omega
  · rfl

/-- Successful value ingestion into an expecting object frame without duplicate key collision. -/
theorem feedValue_obj_expectVal_ok (acc : List (String × Lean.Json)) (key : String) (v : Lean.Json) (rest : List StackFrame)
    (h_not_dup : acc.any (fun (k, _) => k == key) = false) :
    feedValue { stack := StackFrame.obj acc (ObjState.expectVal key) :: rest, result := none } v =
    .ok { stack := StackFrame.obj ((key, v) :: acc) ObjState.expectCommaOrRbrace :: rest, result := none } := by
  dsimp [feedValue]
  rw [h_not_dup]
  rfl

/-- Base singleton pushdown reduction for array element list. -/
theorem parse_arr_tokensList_cons_nil (x : TreeJson)
    (h_val : ∀ (st : ParserState), IsValueContext st → st.stack.length + TreeJson.depth x ≤ 64 →
      (TreeJson.tokens x).foldlM parseStep st = feedValue st (TreeJson.toJson x))
    (acc : Array Lean.Json) (state : ArrState) (rest : List StackFrame)
    (h_state : state = ArrState.emptyOrVal ∨ state = ArrState.expectVal)
    (h_cap : acc.size < 4096)
    (h_depth : rest.length + 1 + TreeJson.depth x ≤ 64) :
    (TreeJson.tokensList [x]).foldlM parseStep { stack := StackFrame.arr acc state :: rest, result := none } =
    .ok { stack := StackFrame.arr (acc.push (TreeJson.toJson x)) ArrState.expectCommaOrRbracket :: rest, result := none } := by
  dsimp [TreeJson.tokensList]
  have h_ctx : IsValueContext { stack := StackFrame.arr acc state :: rest, result := none } := by
    dsimp [IsValueContext]
    refine ⟨rfl, ?_⟩
    rcases h_state with rfl | rfl <;> trivial
  have h_d : ({ stack := StackFrame.arr acc state :: rest, result := none } : ParserState).stack.length + TreeJson.depth x ≤ 64 := by
    dsimp; omega
  rw [h_val { stack := StackFrame.arr acc state :: rest, result := none } h_ctx h_d]
  rcases h_state with rfl | rfl
  · exact feedValue_arr_emptyOrVal_ok acc (TreeJson.toJson x) rest h_cap
  · exact feedValue_arr_expectVal_ok acc (TreeJson.toJson x) rest h_cap

/-- Step transition pushdown reduction for array element followed by comma. -/
theorem parse_arr_tokensList_cons_cons (x : TreeJson) (y : TreeJson) (ys : List TreeJson)
    (h_val : ∀ (st : ParserState), IsValueContext st → st.stack.length + TreeJson.depth x ≤ 64 →
      (TreeJson.tokens x).foldlM parseStep st = feedValue st (TreeJson.toJson x))
    (acc : Array Lean.Json) (state : ArrState) (rest : List StackFrame)
    (h_state : state = ArrState.emptyOrVal ∨ state = ArrState.expectVal)
    (h_cap : acc.size < 4096)
    (h_depth : rest.length + 1 + TreeJson.depth x ≤ 64)
    (finalSt : ParserState)
    (h_rest : (TreeJson.tokensList (y :: ys)).foldlM parseStep
        { stack := StackFrame.arr (acc.push (TreeJson.toJson x)) ArrState.expectVal :: rest, result := none } =
      .ok finalSt) :
    (TreeJson.tokensList (x :: y :: ys)).foldlM parseStep { stack := StackFrame.arr acc state :: rest, result := none } =
    .ok finalSt := by
  have h_eq : TreeJson.tokensList (x :: y :: ys) = (TreeJson.tokens x ++ [JsonToken.comma]) ++ TreeJson.tokensList (y :: ys) := rfl
  rw [h_eq, List.foldlM_append, List.foldlM_append]
  have h_ctx : IsValueContext { stack := StackFrame.arr acc state :: rest, result := none } := by
    dsimp [IsValueContext]
    refine ⟨rfl, ?_⟩
    rcases h_state with rfl | rfl <;> trivial
  have h_d : ({ stack := StackFrame.arr acc state :: rest, result := none } : ParserState).stack.length + TreeJson.depth x ≤ 64 := by
    dsimp; omega
  have h_x := h_val { stack := StackFrame.arr acc state :: rest, result := none } h_ctx h_d
  rw [h_x]
  dsimp [bind, Except.bind]
  rcases h_state with rfl | rfl
  · rw [feedValue_arr_emptyOrVal_ok acc (TreeJson.toJson x) rest h_cap]
    dsimp [List.foldlM, bind, Except.bind, parseStep]
    exact h_rest
  · rw [feedValue_arr_expectVal_ok acc (TreeJson.toJson x) rest h_cap]
    dsimp [List.foldlM, bind, Except.bind, parseStep]
    exact h_rest

/-- Array push equivalent to appending singleton array. -/
theorem array_push_eq_append_singleton (acc : Array Lean.Json) (v : Lean.Json) :
    acc.push v = acc ++ #[v] := by
  rcases acc with ⟨l⟩
  apply Array.ext'
  simp

/-- Associativity of array append. -/
theorem array_append_assoc (a b c : Array Lean.Json) :
    (a ++ b) ++ c = a ++ (b ++ c) := by
  rcases a with ⟨la⟩
  rcases b with ⟨lb⟩
  rcases c with ⟨lc⟩
  apply Array.ext'
  simp

/-- Head cons decomposition of array conversion on lists. -/
theorem toArray_cons (x : Lean.Json) (xs : List Lean.Json) :
    (x :: xs).toArray = #[x] ++ xs.toArray := by
  apply Array.ext'
  simp

/-- General pushdown reduction folding an arbitrary non-empty list of array elements. -/
theorem parse_arr_tokensList (xs : List TreeJson)
    (h_val : ∀ x ∈ xs, ∀ (st : ParserState), IsValueContext st → st.stack.length + TreeJson.depth x ≤ 64 →
      (TreeJson.tokens x).foldlM parseStep st = feedValue st (TreeJson.toJson x))
    (acc : Array Lean.Json) (state : ArrState) (rest : List StackFrame)
    (h_state : state = ArrState.emptyOrVal ∨ state = ArrState.expectVal)
    (h_nonempty : xs ≠ [])
    (h_cap : acc.size + xs.length ≤ 4096)
    (h_depth : rest.length + 1 + TreeJson.depthList xs ≤ 64) :
    (TreeJson.tokensList xs).foldlM parseStep { stack := StackFrame.arr acc state :: rest, result := none } =
    .ok { stack := StackFrame.arr (acc ++ (TreeJson.toJsonList xs).toArray) ArrState.expectCommaOrRbracket :: rest, result := none } := by
  induction xs generalizing acc state with
  | nil => contradiction
  | cons x tl ih =>
    cases tl with
    | nil =>
      have h_val_x := h_val x (List.Mem.head [])
      have h_cap_x : acc.size < 4096 := by
        dsimp at h_cap
        omega
      have h_d_x : rest.length + 1 + x.depth ≤ 64 := by
        dsimp [TreeJson.depthList] at h_depth
        omega
      have h_res := parse_arr_tokensList_cons_nil x h_val_x acc state rest h_state h_cap_x h_d_x
      rw [h_res]
      dsimp [TreeJson.toJsonList]
      rw [array_push_eq_append_singleton]
    | cons y ys =>
      have h_val_x := h_val x (by simp)
      have h_cap_x : acc.size < 4096 := by
        dsimp at h_cap
        omega
      have h_d_x : rest.length + 1 + x.depth ≤ 64 := by
        dsimp [TreeJson.depthList] at h_depth
        omega
      have h_val_tl : ∀ z ∈ (y :: ys), ∀ (st : ParserState), IsValueContext st → st.stack.length + TreeJson.depth z ≤ 64 →
          (TreeJson.tokens z).foldlM parseStep st = feedValue st (TreeJson.toJson z) := by
        intro z hz
        exact h_val z (by simp [hz])
      have h_cap_tl : (acc.push (TreeJson.toJson x)).size + (y :: ys).length ≤ 4096 := by
        simp only [Array.size_push, List.length_cons] at h_cap ⊢
        omega
      have h_d_tl : rest.length + 1 + TreeJson.depthList (y :: ys) ≤ 64 := by
        have : TreeJson.depthList (y :: ys) ≤ TreeJson.depthList (x :: y :: ys) := by
          dsimp [TreeJson.depthList]
          omega
        omega
      have h_ih := ih h_val_tl (acc.push (TreeJson.toJson x)) ArrState.expectVal (Or.inr rfl) (by intro h; contradiction) h_cap_tl h_d_tl
      have h_step := parse_arr_tokensList_cons_cons x y ys h_val_x acc state rest h_state h_cap_x h_d_x _ h_ih
      rw [h_step]
      dsimp [TreeJson.toJsonList]
      rw [array_push_eq_append_singleton]
      rw [array_append_assoc]
      rw [← toArray_cons]

/-- Universal pushdown parser reduction for arbitrary admissible array trees. -/
theorem parse_tokens_arr (xs : List TreeJson)
    (h_val : ∀ x ∈ xs, ∀ (st : ParserState), IsValueContext st → st.stack.length + TreeJson.depth x ≤ 64 →
      (TreeJson.tokens x).foldlM parseStep st = feedValue st (TreeJson.toJson x))
    (h_len : xs.length ≤ 4096)
    (st : ParserState) (h_ctx : IsValueContext st)
    (h_depth : st.stack.length + TreeJson.depth (.arr xs) ≤ 64) :
    (TreeJson.tokens (.arr xs)).foldlM parseStep st = feedValue st (TreeJson.toJson (.arr xs)) := by
  rcases st with ⟨stack, res⟩
  rcases h_ctx with ⟨h_res, h_stack⟩
  dsimp at h_res h_stack h_depth ⊢
  subst h_res
  have h_ctx' : IsValueContext { stack := stack, result := none } := ⟨rfl, h_stack⟩
  have h_split : TreeJson.tokens (.arr xs) = JsonToken.lbracket :: (TreeJson.tokensList xs ++ [JsonToken.rbracket]) := rfl
  rw [h_split]
  simp only [List.foldlM_cons]
  have h_d_lbracket : stack.length < 64 := by
    dsimp [TreeJson.depth] at h_depth
    omega
  have h_lb := parseStep_lbracket_of_isValueContext { stack := stack, result := none } h_ctx' h_d_lbracket
  rw [h_lb]
  dsimp [bind, Except.bind]
  rw [List.foldlM_append]
  cases xs with
  | nil =>
    dsimp [TreeJson.tokensList, List.foldlM, bind, Except.bind, pure, Except.pure, parseStep, TreeJson.toJson, TreeJson.toJsonList]
    generalize feedValue { stack := stack, result := none } (Lean.Json.arr #[]) = res_fv
    cases res_fv <;> rfl
  | cons y ys =>
    have h_nonempty : y :: ys ≠ [] := by intro h; contradiction
    have h_cap : (#[] : Array Lean.Json).size + (y :: ys).length ≤ 4096 := by
      simp only [Array.size_empty, Nat.zero_add]
      exact h_len
    have h_d_tl : stack.length + 1 + TreeJson.depthList (y :: ys) ≤ 64 := by
      dsimp [TreeJson.depth] at h_depth
      omega
    have h_fold := parse_arr_tokensList (y :: ys) h_val #[] ArrState.emptyOrVal stack (Or.inl rfl) h_nonempty h_cap h_d_tl
    rw [h_fold]
    dsimp [List.foldlM, bind, Except.bind, pure, Except.pure, parseStep]
    have h_empty_app : #[] ++ (TreeJson.toJsonList (y :: ys)).toArray = (TreeJson.toJsonList (y :: ys)).toArray := by
      apply Array.ext'
      simp
    rw [h_empty_app]
    dsimp [TreeJson.toJson]
    generalize feedValue { stack := stack, result := none } (Lean.Json.arr (TreeJson.toJsonList (y :: ys)).toArray) = res_fv
    cases res_fv <;> rfl

/-- Pushdown reduction for a single key-colon-value field sequence. -/
theorem parse_obj_tokens_field (k : String) (v : TreeJson)
    (h_val : ∀ (st : ParserState), IsValueContext st → st.stack.length + TreeJson.depth v ≤ 64 →
      (TreeJson.tokens v).foldlM parseStep st = feedValue st (TreeJson.toJson v))
    (acc : List (String × Lean.Json)) (state : ObjState) (rest : List StackFrame)
    (h_state : state = ObjState.emptyOrKey ∨ state = ObjState.expectKey)
    (h_not_dup : acc.any (fun (k', _) => k' == k) = false)
    (h_depth : rest.length + 1 + TreeJson.depth v ≤ 64) :
    ([JsonToken.str k, JsonToken.colon] ++ TreeJson.tokens v).foldlM parseStep
        { stack := StackFrame.obj acc state :: rest, result := none } =
    .ok { stack := StackFrame.obj ((k, TreeJson.toJson v) :: acc) ObjState.expectCommaOrRbrace :: rest, result := none } := by
  have h_split : ([JsonToken.str k, JsonToken.colon] ++ TreeJson.tokens v) =
      JsonToken.str k :: (JsonToken.colon :: TreeJson.tokens v) := rfl
  rw [h_split]
  simp only [List.foldlM_cons]
  dsimp [parseStep]
  rcases h_state with rfl | rfl <;> dsimp [bind, Except.bind]
  · have h_ctx : IsValueContext { stack := StackFrame.obj acc (ObjState.expectVal k) :: rest, result := none } := ⟨rfl, trivial⟩
    have h_d : ({ stack := StackFrame.obj acc (ObjState.expectVal k) :: rest, result := none } : ParserState).stack.length + TreeJson.depth v ≤ 64 := by
      dsimp; omega
    have h_v := h_val { stack := StackFrame.obj acc (ObjState.expectVal k) :: rest, result := none } h_ctx h_d
    rw [h_v]
    exact feedValue_obj_expectVal_ok acc k (TreeJson.toJson v) rest h_not_dup
  · have h_ctx : IsValueContext { stack := StackFrame.obj acc (ObjState.expectVal k) :: rest, result := none } := ⟨rfl, trivial⟩
    have h_d : ({ stack := StackFrame.obj acc (ObjState.expectVal k) :: rest, result := none } : ParserState).stack.length + TreeJson.depth v ≤ 64 := by
      dsimp; omega
    have h_v := h_val { stack := StackFrame.obj acc (ObjState.expectVal k) :: rest, result := none } h_ctx h_d
    rw [h_v]
    exact feedValue_obj_expectVal_ok acc k (TreeJson.toJson v) rest h_not_dup

/-- Base singleton pushdown reduction for object field list. -/
theorem parse_obj_tokensObj_cons_nil (k : String) (v : TreeJson)
    (h_val : ∀ (st : ParserState), IsValueContext st → st.stack.length + TreeJson.depth v ≤ 64 →
      (TreeJson.tokens v).foldlM parseStep st = feedValue st (TreeJson.toJson v))
    (acc : List (String × Lean.Json)) (state : ObjState) (rest : List StackFrame)
    (h_state : state = ObjState.emptyOrKey ∨ state = ObjState.expectKey)
    (h_not_dup : acc.any (fun (k', _) => k' == k) = false)
    (h_depth : rest.length + 1 + TreeJson.depth v ≤ 64) :
    (TreeJson.tokensObj [(k, v)]).foldlM parseStep { stack := StackFrame.obj acc state :: rest, result := none } =
    .ok { stack := StackFrame.obj ((k, TreeJson.toJson v) :: acc) ObjState.expectCommaOrRbrace :: rest, result := none } := by
  dsimp [TreeJson.tokensObj]
  exact parse_obj_tokens_field k v h_val acc state rest h_state h_not_dup h_depth

/-- Step transition pushdown reduction for object field followed by comma. -/
theorem parse_obj_tokensObj_cons_cons (k : String) (v : TreeJson) (f2 : String × TreeJson) (kvs : List (String × TreeJson))
    (h_val : ∀ (st : ParserState), IsValueContext st → st.stack.length + TreeJson.depth v ≤ 64 →
      (TreeJson.tokens v).foldlM parseStep st = feedValue st (TreeJson.toJson v))
    (acc : List (String × Lean.Json)) (state : ObjState) (rest : List StackFrame)
    (h_state : state = ObjState.emptyOrKey ∨ state = ObjState.expectKey)
    (h_not_dup : acc.any (fun (k', _) => k' == k) = false)
    (h_depth : rest.length + 1 + TreeJson.depth v ≤ 64)
    (finalSt : ParserState)
    (h_rest : (TreeJson.tokensObj (f2 :: kvs)).foldlM parseStep
        { stack := StackFrame.obj ((k, TreeJson.toJson v) :: acc) ObjState.expectKey :: rest, result := none } =
      .ok finalSt) :
    (TreeJson.tokensObj ((k, v) :: f2 :: kvs)).foldlM parseStep { stack := StackFrame.obj acc state :: rest, result := none } =
    .ok finalSt := by
  have h_eq : TreeJson.tokensObj ((k, v) :: f2 :: kvs) =
      ([JsonToken.str k, JsonToken.colon] ++ TreeJson.tokens v ++ [JsonToken.comma]) ++ TreeJson.tokensObj (f2 :: kvs) := rfl
  rw [h_eq, List.foldlM_append]
  have h_field_split : ([JsonToken.str k, JsonToken.colon] ++ TreeJson.tokens v ++ [JsonToken.comma]) =
      ([JsonToken.str k, JsonToken.colon] ++ TreeJson.tokens v) ++ [JsonToken.comma] := rfl
  rw [h_field_split, List.foldlM_append]
  have h_field := parse_obj_tokens_field k v h_val acc state rest h_state h_not_dup h_depth
  rw [h_field]
  dsimp [List.foldlM, bind, Except.bind, parseStep]
  exact h_rest

/-- General pushdown reduction folding an arbitrary non-empty list of object fields. -/
theorem parse_obj_tokensObj (kvs : List (String × TreeJson))
    (h_val : ∀ (k : String) (v : TreeJson), (k, v) ∈ kvs → ∀ (st : ParserState), IsValueContext st → st.stack.length + TreeJson.depth v ≤ 64 →
      (TreeJson.tokens v).foldlM parseStep st = feedValue st (TreeJson.toJson v))
    (acc : List (String × Lean.Json)) (state : ObjState) (rest : List StackFrame)
    (h_state : state = ObjState.emptyOrKey ∨ state = ObjState.expectKey)
    (h_nonempty : kvs ≠ [])
    (h_not_dup : ∀ (k : String) (v : TreeJson), (k, v) ∈ kvs → acc.any (fun (k', _) => k' == k) = false)
    (h_nodup_kvs : (kvs.map Prod.fst).Nodup)
    (h_depth : rest.length + 1 + TreeJson.depthObj kvs ≤ 64) :
    (TreeJson.tokensObj kvs).foldlM parseStep { stack := StackFrame.obj acc state :: rest, result := none } =
    .ok { stack := StackFrame.obj ((TreeJson.toJsonObj kvs).reverse ++ acc) ObjState.expectCommaOrRbrace :: rest, result := none } := by
  induction kvs generalizing acc state with
  | nil => contradiction
  | cons f tl ih =>
    rcases f with ⟨k, v⟩
    cases tl with
    | nil =>
      have h_val_kv := h_val k v (List.Mem.head [])
      have h_not_dup_kv := h_not_dup k v (List.Mem.head [])
      have h_d_kv : rest.length + 1 + v.depth ≤ 64 := by
        dsimp [TreeJson.depthObj] at h_depth
        omega
      have h_res := parse_obj_tokensObj_cons_nil k v h_val_kv acc state rest h_state h_not_dup_kv h_d_kv
      rw [h_res]
      dsimp [TreeJson.toJsonObj]
      rfl
    | cons f2 kvs' =>
      have h_val_kv := h_val k v (by simp)
      have h_not_dup_kv := h_not_dup k v (by simp)
      have h_d_kv : rest.length + 1 + v.depth ≤ 64 := by
        dsimp [TreeJson.depthObj] at h_depth
        omega
      have h_val_tl : ∀ (k' : String) (v' : TreeJson), (k', v') ∈ f2 :: kvs' → ∀ (st : ParserState), IsValueContext st → st.stack.length + TreeJson.depth v' ≤ 64 →
          (TreeJson.tokens v').foldlM parseStep st = feedValue st (TreeJson.toJson v') := by
        intro k' v' h_mem
        exact h_val k' v' (by simp [h_mem])
      have h_not_dup_tl : ∀ (k' : String) (v' : TreeJson), (k', v') ∈ f2 :: kvs' → ((k, TreeJson.toJson v) :: acc).any (fun (k'', _) => k'' == k') = false := by
        intro k' v' h_mem
        dsimp [List.any]
        have h_k_neq : ¬ (k = k') := by
          intro h_eq
          subst h_eq
          have h_nodup_fst := List.nodup_cons.mp h_nodup_kvs
          have h_k_in : k ∈ (f2 :: kvs').map Prod.fst := List.mem_map.mpr ⟨(k, v'), h_mem, rfl⟩
          exact h_nodup_fst.1 h_k_in
        have h_k_b : (k == k') = false := by
          cases h_c : (k == k')
          · rfl
          · exfalso
            have h_eq : k = k' := beq_iff_eq.mp h_c
            exact h_k_neq h_eq
        rw [h_k_b]
        dsimp [Bool.or]
        exact h_not_dup k' v' (by simp [h_mem])
      have h_nodup_tl : ((f2 :: kvs').map Prod.fst).Nodup := (List.nodup_cons.mp h_nodup_kvs).2
      have h_d_tl : rest.length + 1 + TreeJson.depthObj (f2 :: kvs') ≤ 64 := by
        have : TreeJson.depthObj (f2 :: kvs') ≤ TreeJson.depthObj ((k, v) :: f2 :: kvs') := by
          dsimp [TreeJson.depthObj]
          omega
        omega
      have h_ih := ih h_val_tl ((k, TreeJson.toJson v) :: acc) ObjState.expectKey (Or.inr rfl) (by intro h; contradiction) h_not_dup_tl h_nodup_tl h_d_tl
      have h_step := parse_obj_tokensObj_cons_cons k v f2 kvs' h_val_kv acc state rest h_state h_not_dup_kv h_d_kv _ h_ih
      rw [h_step]
      rcases f2 with ⟨k2, v2⟩
      dsimp [TreeJson.toJsonObj]
      simp only [List.reverse_cons, List.append_assoc, List.cons_append, List.nil_append]

/-- Universal pushdown parser reduction for arbitrary admissible object trees. -/
theorem parse_tokens_obj (kvs : List (String × TreeJson))
    (h_val : ∀ (k : String) (v : TreeJson), (k, v) ∈ kvs → ∀ (st : ParserState), IsValueContext st → st.stack.length + TreeJson.depth v ≤ 64 →
      (TreeJson.tokens v).foldlM parseStep st = feedValue st (TreeJson.toJson v))
    (h_nodup : (kvs.map Prod.fst).Nodup)
    (st : ParserState) (h_ctx : IsValueContext st)
    (h_depth : st.stack.length + TreeJson.depth (.obj kvs) ≤ 64) :
    (TreeJson.tokens (.obj kvs)).foldlM parseStep st = feedValue st (TreeJson.toJson (.obj kvs)) := by
  rcases st with ⟨stack, res⟩
  rcases h_ctx with ⟨h_res, h_stack⟩
  dsimp at h_res h_stack h_depth ⊢
  subst h_res
  have h_ctx' : IsValueContext { stack := stack, result := none } := ⟨rfl, h_stack⟩
  have h_split : TreeJson.tokens (.obj kvs) = JsonToken.lbrace :: (TreeJson.tokensObj kvs ++ [JsonToken.rbrace]) := rfl
  rw [h_split]
  simp only [List.foldlM_cons]
  have h_d_lbrace : stack.length < 64 := by
    dsimp [TreeJson.depth] at h_depth
    omega
  have h_lb := parseStep_lbrace_of_isValueContext { stack := stack, result := none } h_ctx' h_d_lbrace
  rw [h_lb]
  dsimp [bind, Except.bind]
  rw [List.foldlM_append]
  cases kvs with
  | nil =>
    dsimp [TreeJson.tokensObj, List.foldlM, bind, Except.bind, pure, Except.pure, parseStep, TreeJson.toJson, TreeJson.toJsonObj]
    generalize feedValue { stack := stack, result := none } (Lean.Json.mkObj []) = res_fv
    cases res_fv <;> rfl
  | cons f tl =>
    rcases f with ⟨k, v⟩
    have h_nonempty : (k, v) :: tl ≠ [] := by intro h; contradiction
    have h_not_dup_empty : ∀ (k' : String) (v' : TreeJson), (k', v') ∈ (k, v) :: tl → ([] : List (String × Lean.Json)).any (fun (k'', _) => k'' == k') = false := by
      intro _ _ _
      rfl
    have h_d_tl : stack.length + 1 + TreeJson.depthObj ((k, v) :: tl) ≤ 64 := by
      dsimp [TreeJson.depth] at h_depth
      omega
    have h_fold := parse_obj_tokensObj ((k, v) :: tl) h_val [] ObjState.emptyOrKey stack (Or.inl rfl) h_nonempty h_not_dup_empty h_nodup h_d_tl
    rw [h_fold]
    dsimp [List.foldlM, bind, Except.bind, pure, Except.pure, parseStep]
    simp only [List.append_nil, List.reverse_reverse]
    dsimp [TreeJson.toJson]
    generalize feedValue { stack := stack, result := none } (Lean.Json.mkObj (TreeJson.toJsonObj ((k, v) :: tl))) = res_fv
    cases res_fv <;> rfl

/-- Universal pushdown parser reduction for all admissible TreeJson values in any value-expecting context. -/
theorem parse_tokens_tree (t : TreeJson)
    (h_valid : TreeJson.Valid t)
    (st : ParserState) (h_ctx : IsValueContext st)
    (h_depth : st.stack.length + TreeJson.depth t ≤ 64) :
    (TreeJson.tokens t).foldlM parseStep st = feedValue st (TreeJson.toJson t) := by
  match t with
  | .null =>
    dsimp [TreeJson.tokens, List.foldlM, bind, Except.bind, parseStep, TreeJson.toJson]
    cases feedValue st Lean.Json.null <;> rfl
  | .bool b =>
    dsimp [TreeJson.tokens, List.foldlM, bind, Except.bind, parseStep, TreeJson.toJson]
    cases feedValue st (Lean.Json.bool b) <;> rfl
  | .num n =>
    dsimp [TreeJson.tokens, List.foldlM, bind, Except.bind, parseStep, TreeJson.toJson]
    cases feedValue st (Lean.Json.num ⟨n, 0⟩) <;> rfl
  | .str s =>
    dsimp [TreeJson.tokens, List.foldlM, bind, Except.bind, TreeJson.toJson]
    rw [parseStep_str_of_isValueContext st h_ctx s]
    cases feedValue st (Lean.Json.str s) <;> rfl
  | .arr xs =>
    dsimp [TreeJson.Valid] at h_valid
    have h_ih : ∀ x ∈ xs, ∀ (st' : ParserState), IsValueContext st' → st'.stack.length + TreeJson.depth x ≤ 64 →
        (TreeJson.tokens x).foldlM parseStep st' = feedValue st' (TreeJson.toJson x) := by
      intro x h_in st' h_ctx' h_d'
      have h_x_valid := TreeJson.valid_of_mem_validList x xs h_valid.2 h_in
      have h_x_size : TreeJson.size x < TreeJson.size (.arr xs) := by
        dsimp [TreeJson.size]
        have := TreeJson.mem_sizeList x xs h_in
        omega
      exact parse_tokens_tree x h_x_valid st' h_ctx' h_d'
    exact parse_tokens_arr xs h_ih h_valid.1 st h_ctx h_depth
  | .obj kvs =>
    dsimp [TreeJson.Valid] at h_valid
    have h_ih : ∀ (k : String) (v : TreeJson), (k, v) ∈ kvs → ∀ (st' : ParserState), IsValueContext st' → st'.stack.length + TreeJson.depth v ≤ 64 →
        (TreeJson.tokens v).foldlM parseStep st' = feedValue st' (TreeJson.toJson v) := by
      intro k v h_in st' h_ctx' h_d'
      have h_v_valid := TreeJson.valid_of_mem_validObj k v kvs h_valid.2 h_in
      have h_v_size : TreeJson.size v < TreeJson.size (.obj kvs) := by
        dsimp [TreeJson.size]
        have := TreeJson.mem_sizeObj k v kvs h_in
        omega
      exact parse_tokens_tree v h_v_valid st' h_ctx' h_d'
    exact parse_tokens_obj kvs h_ih h_valid.1 st h_ctx h_depth
termination_by TreeJson.size t

/-- General bounded ordered TreeJson parser inversion:
    every structurally admissible TreeJson within the 64 depth bound parses to its semantic Lean.Json. -/
theorem parseTokens_tree_valid (t : TreeJson) (h_valid : TreeJson.Valid t)
    (h_depth : TreeJson.depth t ≤ 64) :
    parseTokens (TreeJson.tokens t) = .ok (TreeJson.toJson t) := by
  have h_ctx : IsValueContext { stack := [], result := none } := ⟨rfl, trivial⟩
  have h_d : ({ stack := [], result := none } : ParserState).stack.length + TreeJson.depth t ≤ 64 := by
    dsimp; omega
  have h_fold := parse_tokens_tree t h_valid { stack := [], result := none } h_ctx h_d
  dsimp [feedValue] at h_fold
  exact parseTokens_of_foldlM (TreeJson.tokens t) (TreeJson.toJson t) h_fold

/-- Predicate for character suffixes whose head is not a decimal digit.
    Required for exact numeric tokenization boundary in canonical JSON. -/
def NonDigitHead (cs : List Char) : Prop :=
  match cs with
  | [] => True
  | c :: _ => c.isDigit = false

theorem nonDigitHead_nil : NonDigitHead [] := trivial
theorem nonDigitHead_comma (rest : List Char) : NonDigitHead (',' :: rest) := rfl
theorem nonDigitHead_colon (rest : List Char) : NonDigitHead (':' :: rest) := rfl
theorem nonDigitHead_rbracket (rest : List Char) : NonDigitHead (']' :: rest) := rfl
theorem nonDigitHead_rbrace (rest : List Char) : NonDigitHead ('}' :: rest) := rfl

theorem escapeTreeString_eq (s : String) :
    (escapeTreeString s).toList = '"' :: (escapeChars s.toList ++ ['"']) := by
  dsimp [escapeTreeString]
  rw [String.toList_ofList]

theorem tokenizeFuel_escapeTreeString (fuel : Nat) (s : String) (rest : List Char) :
    tokenizeFuel (fuel + 1) ((escapeTreeString s).toList ++ rest) =
      (do
        let toks ← tokenizeFuel fuel rest
        .ok (JsonToken.str s :: toks)) := by
  rw [escapeTreeString_eq]
  have h_append : ('"' :: (escapeChars s.toList ++ ['"'])) ++ rest =
      '"' :: (escapeChars s.toList ++ ('"' :: rest)) := by
    dsimp [List.cons_append]
    rw [List.append_assoc]
    rfl
  rw [h_append]
  exact tokenizeFuel_string fuel s rest

theorem toList_comma : ",".toList = [','] := rfl
theorem toList_colon : ":".toList = [':'] := rfl
theorem toList_lbracket : "[".toList = ['['] := rfl
theorem toList_rbracket : "]".toList = [']'] := rfl
theorem toList_lbrace : "{".toList = ['{'] := rfl
theorem toList_rbrace : "}".toList = ['}'] := rfl

theorem encode_arr_toList (xs : List TreeJson) (rest : List Char) :
    (TreeJson.encode (.arr xs)).toList ++ rest =
    '[' :: ((TreeJson.encodeList xs).toList ++ (']' :: rest)) := by
  dsimp [TreeJson.encode]
  repeat rw [String.toList_append]
  rw [toList_lbracket, toList_rbracket]
  simp only [List.cons_append, List.nil_append, List.append_assoc]

theorem encode_obj_toList (kvs : List (String × TreeJson)) (rest : List Char) :
    (TreeJson.encode (.obj kvs)).toList ++ rest =
    '{' :: ((TreeJson.encodeObj kvs).toList ++ ('}' :: rest)) := by
  dsimp [TreeJson.encode]
  repeat rw [String.toList_append]
  rw [toList_lbrace, toList_rbrace]
  simp only [List.cons_append, List.nil_append, List.append_assoc]

theorem encodeList_cons_cons_toList (x x2 : TreeJson) (xs' : List TreeJson) (rest : List Char) :
    (TreeJson.encodeList (x :: x2 :: xs')).toList ++ rest =
    (TreeJson.encode x).toList ++ (',' :: ((TreeJson.encodeList (x2 :: xs')).toList ++ rest)) := by
  dsimp [TreeJson.encodeList]
  repeat rw [String.toList_append]
  rw [toList_comma]
  simp only [List.cons_append, List.nil_append, List.append_assoc]

theorem encodeObj_singleton_toList (k : String) (v : TreeJson) (rest : List Char) :
    (TreeJson.encodeObj [(k, v)]).toList ++ rest =
    (escapeTreeString k).toList ++ (':' :: ((TreeJson.encode v).toList ++ rest)) := by
  dsimp [TreeJson.encodeObj]
  repeat rw [String.toList_append]
  rw [toList_colon]
  simp only [List.cons_append, List.nil_append, List.append_assoc]

theorem encodeObj_cons_cons_toList (k : String) (v : TreeJson) (f2 : String × TreeJson) (kvs' : List (String × TreeJson)) (rest : List Char) :
    (TreeJson.encodeObj ((k, v) :: f2 :: kvs')).toList ++ rest =
    (escapeTreeString k).toList ++ (':' :: ((TreeJson.encode v).toList ++ (',' :: ((TreeJson.encodeObj (f2 :: kvs')).toList ++ rest)))) := by
  dsimp [TreeJson.encodeObj]
  repeat rw [String.toList_append]
  rw [toList_colon, toList_comma]
  simp only [List.cons_append, List.nil_append, List.append_assoc]

theorem toDigits_nonempty_length (n : Nat) : 1 ≤ (Nat.toDigits 10 n).length := by
  have := Nat.length_toDigits_pos (b := 10) (n := n)
  omega

theorem toString_nat_length_ge_one (n : Nat) : 1 ≤ (toString n).toList.length := by
  have h_repr : (toString n).toList = Nat.toDigits 10 n := by
    change (Nat.repr n).toList = Nat.toDigits 10 n
    exact Nat.toList_repr
  rw [h_repr]
  exact toDigits_nonempty_length n

theorem toString_int_length_ge_one (i : Int) : 1 ≤ (toString i).toList.length := by
  cases i with
  | ofNat n => exact toString_nat_length_ge_one n
  | negSucc n =>
    have h_repr : (toString (Int.negSucc n)).toList = '-' :: (Nat.repr (n + 1)).toList := by
      change ("-" ++ Nat.repr (n + 1)).toList = '-' :: (Nat.repr (n + 1)).toList
      rw [String.toList_append]
      rfl
    rw [h_repr]
    dsimp [List.length]
    omega

theorem escapeTreeString_length_ge_two (s : String) : 2 ≤ (escapeTreeString s).toList.length := by
  rw [escapeTreeString_eq]
  dsimp [List.length]
  rw [List.length_append]
  simp only [List.length_cons, List.length_nil]
  omega

theorem tokensList_length_le_encodeList_length (xs : List TreeJson)
    (h_ih : ∀ x ∈ xs, (TreeJson.tokens x).length ≤ (TreeJson.encode x).toList.length) :
    (TreeJson.tokensList xs).length ≤ (TreeJson.encodeList xs).toList.length := by
  induction xs with
  | nil => rfl
  | cons x tl ih =>
    cases tl with
    | nil =>
      dsimp [TreeJson.tokensList, TreeJson.encodeList]
      exact h_ih x (List.Mem.head [])
    | cons x2 xs' =>
      dsimp [TreeJson.tokensList, TreeJson.encodeList]
      repeat rw [String.toList_append]
      rw [toList_comma]
      simp only [List.length_append, List.length_cons, List.length_nil]
      have h_x := h_ih x (List.Mem.head _)
      have h_ih_tl := ih (fun y hy => h_ih y (List.Mem.tail x hy))
      omega

theorem tokensObj_length_le_encodeObj_length (kvs : List (String × TreeJson))
    (h_ih : ∀ (k : String) (v : TreeJson), (k, v) ∈ kvs → (TreeJson.tokens v).length ≤ (TreeJson.encode v).toList.length) :
    (TreeJson.tokensObj kvs).length ≤ (TreeJson.encodeObj kvs).toList.length := by
  induction kvs with
  | nil => rfl
  | cons f tl ih =>
    rcases f with ⟨k, v⟩
    cases tl with
    | nil =>
      dsimp [TreeJson.tokensObj, TreeJson.encodeObj]
      repeat rw [String.toList_append]
      rw [toList_colon]
      simp only [List.length_append, List.length_cons, List.length_nil]
      have h_v := h_ih k v (List.Mem.head [])
      have h_k := escapeTreeString_length_ge_two k
      omega
    | cons f2 kvs' =>
      dsimp [TreeJson.tokensObj, TreeJson.encodeObj]
      repeat rw [String.toList_append]
      rw [toList_colon, toList_comma]
      simp only [List.length_append, List.length_cons, List.length_nil]
      have h_v := h_ih k v (List.Mem.head _)
      have h_k := escapeTreeString_length_ge_two k
      have h_ih_tl := ih (fun k' v' hy => h_ih k' v' (List.Mem.tail (k, v) hy))
      omega

/-- Non-circular length bound: the number of produced JSON tokens is bounded by serialized characters. -/
theorem tokens_length_le_encode_length (t : TreeJson) :
    (TreeJson.tokens t).length ≤ (TreeJson.encode t).toList.length := by
  match t with
  | .null => decide
  | .bool true => decide
  | .bool false => decide
  | .num n =>
    dsimp [TreeJson.tokens, TreeJson.encode]
    exact toString_int_length_ge_one n
  | .str s =>
    dsimp [TreeJson.tokens, TreeJson.encode]
    have := escapeTreeString_length_ge_two s
    omega
  | .arr xs =>
    dsimp [TreeJson.tokens, TreeJson.encode]
    repeat rw [String.toList_append]
    rw [toList_lbracket, toList_rbracket]
    simp only [List.length_append, List.length_cons, List.length_nil]
    have h_ih : ∀ x ∈ xs, (TreeJson.tokens x).length ≤ (TreeJson.encode x).toList.length := by
      intro x hx
      have : TreeJson.size x < TreeJson.size (.arr xs) := by
        dsimp [TreeJson.size]
        have := TreeJson.mem_sizeList x xs hx
        omega
      exact tokens_length_le_encode_length x
    have h_list := tokensList_length_le_encodeList_length xs h_ih
    omega
  | .obj kvs =>
    dsimp [TreeJson.tokens, TreeJson.encode]
    repeat rw [String.toList_append]
    rw [toList_lbrace, toList_rbrace]
    simp only [List.length_append, List.length_cons, List.length_nil]
    have h_ih : ∀ (k : String) (v : TreeJson), (k, v) ∈ kvs → (TreeJson.tokens v).length ≤ (TreeJson.encode v).toList.length := by
      intro k v hv
      have : TreeJson.size v < TreeJson.size (.obj kvs) := by
        dsimp [TreeJson.size]
        have := TreeJson.mem_sizeObj k v kvs hv
        omega
      exact tokens_length_le_encode_length v
    have h_obj := tokensObj_length_le_encodeObj_length kvs h_ih
    omega
termination_by TreeJson.size t

/-- Fuel-bounded tokenization inversion for array element sequences. -/
theorem tokenizeFuel_encodeList (xs : List TreeJson)
    (h_ih : ∀ x ∈ xs, ∀ (fuel : Nat) (rest : List Char), NonDigitHead rest →
      tokenizeFuel ((TreeJson.tokens x).length + fuel) ((TreeJson.encode x).toList ++ rest) =
        (do let toks ← tokenizeFuel fuel rest; .ok (TreeJson.tokens x ++ toks)))
    (fuel : Nat) (rest : List Char) (h_end : NonDigitHead rest) :
    tokenizeFuel ((TreeJson.tokensList xs).length + fuel) ((TreeJson.encodeList xs).toList ++ rest) =
      (do
        let toks ← tokenizeFuel fuel rest
        .ok (TreeJson.tokensList xs ++ toks)) := by
  induction xs with
  | nil =>
    dsimp [TreeJson.tokensList, TreeJson.encodeList]
    have : 0 + fuel = fuel := by omega
    rw [this]
    cases tokenizeFuel fuel rest <;> rfl
  | cons x tl ih =>
    cases tl with
    | nil =>
      dsimp [TreeJson.tokensList, TreeJson.encodeList]
      exact h_ih x (List.Mem.head []) fuel rest h_end
    | cons x2 xs' =>
      rw [encodeList_cons_cons_toList]
      have h_fuel : (TreeJson.tokensList (x :: x2 :: xs')).length + fuel =
          (TreeJson.tokens x).length + (((TreeJson.tokensList (x2 :: xs')).length + fuel) + 1) := by
        dsimp [TreeJson.tokensList]
        simp only [List.length_append, List.length_cons, List.length_nil]
        omega
      rw [h_fuel]
      have h_x := h_ih x (List.Mem.head _) (((TreeJson.tokensList (x2 :: xs')).length + fuel) + 1)
          (',' :: ((TreeJson.encodeList (x2 :: xs')).toList ++ rest)) (nonDigitHead_comma _)
      rw [h_x]
      dsimp [bind, Except.bind]
      rw [tokenizeFuel_comma]
      dsimp [bind, Except.bind]
      have h_ih_tl : ∀ y ∈ x2 :: xs', ∀ (fuel : Nat) (rest : List Char), NonDigitHead rest →
          tokenizeFuel ((TreeJson.tokens y).length + fuel) ((TreeJson.encode y).toList ++ rest) =
            (do let toks ← tokenizeFuel fuel rest; .ok (TreeJson.tokens y ++ toks)) := by
        intro y hy f r he
        exact h_ih y (List.Mem.tail x hy) f r he
      rw [ih h_ih_tl]
      dsimp [bind, Except.bind]
      cases tokenizeFuel fuel rest with
      | error _ => rfl
      | ok toks => simp [TreeJson.tokensList]

/-- Fuel-bounded tokenization inversion for object field sequences. -/
theorem tokenizeFuel_encodeObj (kvs : List (String × TreeJson))
    (h_ih : ∀ (k : String) (v : TreeJson), (k, v) ∈ kvs → ∀ (fuel : Nat) (rest : List Char), NonDigitHead rest →
      tokenizeFuel ((TreeJson.tokens v).length + fuel) ((TreeJson.encode v).toList ++ rest) =
        (do let toks ← tokenizeFuel fuel rest; .ok (TreeJson.tokens v ++ toks)))
    (fuel : Nat) (rest : List Char) (h_end : NonDigitHead rest) :
    tokenizeFuel ((TreeJson.tokensObj kvs).length + fuel) ((TreeJson.encodeObj kvs).toList ++ rest) =
      (do
        let toks ← tokenizeFuel fuel rest
        .ok (TreeJson.tokensObj kvs ++ toks)) := by
  induction kvs with
  | nil =>
    dsimp [TreeJson.tokensObj, TreeJson.encodeObj]
    have : 0 + fuel = fuel := by omega
    rw [this]
    cases tokenizeFuel fuel rest <;> rfl
  | cons f tl ih =>
    rcases f with ⟨k, v⟩
    cases tl with
    | nil =>
      rw [encodeObj_singleton_toList]
      have h_fuel : (TreeJson.tokensObj [(k, v)]).length + fuel =
          ((TreeJson.tokens v).length + fuel + 1) + 1 := by
        simp [TreeJson.tokensObj]
        omega
      rw [h_fuel]
      rw [tokenizeFuel_escapeTreeString]
      dsimp [bind, Except.bind]
      rw [tokenizeFuel_colon]
      dsimp [bind, Except.bind]
      have h_v := h_ih k v (List.Mem.head []) fuel rest h_end
      rw [h_v]
      dsimp [bind, Except.bind]
      cases tokenizeFuel fuel rest <;> rfl
    | cons f2 kvs' =>
      rw [encodeObj_cons_cons_toList]
      have h_fuel : (TreeJson.tokensObj ((k, v) :: f2 :: kvs')).length + fuel =
          ((TreeJson.tokens v).length + (((TreeJson.tokensObj (f2 :: kvs')).length + fuel) + 1) + 1) + 1 := by
        dsimp [TreeJson.tokensObj]
        simp only [List.length_append, List.length_cons, List.length_nil]
        omega
      rw [h_fuel]
      rw [tokenizeFuel_escapeTreeString]
      dsimp [bind, Except.bind]
      rw [tokenizeFuel_colon]
      dsimp [bind, Except.bind]
      have h_v := h_ih k v (List.Mem.head _) (((TreeJson.tokensObj (f2 :: kvs')).length + fuel) + 1)
          (',' :: ((TreeJson.encodeObj (f2 :: kvs')).toList ++ rest)) (nonDigitHead_comma _)
      rw [h_v]
      dsimp [bind, Except.bind]
      rw [tokenizeFuel_comma]
      dsimp [bind, Except.bind]
      have h_ih_tl : ∀ (k' : String) (v' : TreeJson), (k', v') ∈ f2 :: kvs' → ∀ (fuel : Nat) (rest : List Char), NonDigitHead rest →
          tokenizeFuel ((TreeJson.tokens v').length + fuel) ((TreeJson.encode v').toList ++ rest) =
            (do let toks ← tokenizeFuel fuel rest; .ok (TreeJson.tokens v' ++ toks)) := by
        intro k' v' h_mem f r he
        exact h_ih k' v' (List.Mem.tail (k, v) h_mem) f r he
      rw [ih h_ih_tl]
      dsimp [bind, Except.bind]
      cases tokenizeFuel fuel rest with
      | error _ => rfl
      | ok toks => simp [TreeJson.tokensObj]

/-- Universal fuel-bounded tokenization theorem:
    tokenizing the serialized characters of any TreeJson consumes exactly its token count in fuel
    and prepends its canonical token sequence. -/
theorem tokenizeFuel_tree (t : TreeJson) (fuel : Nat) (rest : List Char) (h_end : NonDigitHead rest) :
    tokenizeFuel ((TreeJson.tokens t).length + fuel) ((TreeJson.encode t).toList ++ rest) =
      (do
        let toks ← tokenizeFuel fuel rest
        .ok (TreeJson.tokens t ++ toks)) := by
  match t with
  | .null =>
    have h_fuel : (TreeJson.tokens .null).length + fuel = fuel + 1 := by
      dsimp [TreeJson.tokens]; omega
    rw [h_fuel]
    dsimp [TreeJson.tokens, TreeJson.encode]
    rfl
  | .bool true =>
    have h_fuel : (TreeJson.tokens (.bool true)).length + fuel = fuel + 1 := by
      dsimp [TreeJson.tokens]; omega
    rw [h_fuel]
    dsimp [TreeJson.tokens, TreeJson.encode]
    rfl
  | .bool false =>
    have h_fuel : (TreeJson.tokens (.bool false)).length + fuel = fuel + 1 := by
      dsimp [TreeJson.tokens]; omega
    rw [h_fuel]
    dsimp [TreeJson.tokens, TreeJson.encode]
    rfl
  | .num n =>
    have h_fuel : (TreeJson.tokens (.num n)).length + fuel = fuel + 1 := by
      dsimp [TreeJson.tokens]; omega
    rw [h_fuel]
    dsimp [TreeJson.tokens, TreeJson.encode]
    have h_tok := tokenizeFuel_int fuel n rest h_end
    rw [h_tok]
  | .str s =>
    have h_fuel : (TreeJson.tokens (.str s)).length + fuel = fuel + 1 := by
      dsimp [TreeJson.tokens]; omega
    rw [h_fuel]
    dsimp [TreeJson.tokens, TreeJson.encode]
    have h_tok := tokenizeFuel_escapeTreeString fuel s rest
    rw [h_tok]
  | .arr xs =>
    rw [encode_arr_toList]
    have h_fuel : (TreeJson.tokens (.arr xs)).length + fuel =
        ((TreeJson.tokensList xs).length + (fuel + 1)) + 1 := by
      dsimp [TreeJson.tokens]
      simp only [List.length_append, List.length_cons, List.length_nil]
      omega
    rw [h_fuel]
    rw [tokenizeFuel_lbracket]
    dsimp [bind, Except.bind]
    have h_ih : ∀ x ∈ xs, ∀ (fuel' : Nat) (rest' : List Char), NonDigitHead rest' →
        tokenizeFuel ((TreeJson.tokens x).length + fuel') ((TreeJson.encode x).toList ++ rest') =
          (do let toks ← tokenizeFuel fuel' rest'; .ok (TreeJson.tokens x ++ toks)) := by
      intro x hx f' r' he'
      have : TreeJson.size x < TreeJson.size (.arr xs) := by
        dsimp [TreeJson.size]
        have := TreeJson.mem_sizeList x xs hx
        omega
      exact tokenizeFuel_tree x f' r' he'
    rw [tokenizeFuel_encodeList xs h_ih (fuel + 1) (']' :: rest) (nonDigitHead_rbracket _)]
    dsimp [bind, Except.bind]
    rw [tokenizeFuel_rbracket]
    dsimp [bind, Except.bind]
    cases tokenizeFuel fuel rest with
    | error _ => rfl
    | ok toks => simp [TreeJson.tokens]
  | .obj kvs =>
    rw [encode_obj_toList]
    have h_fuel : (TreeJson.tokens (.obj kvs)).length + fuel =
        ((TreeJson.tokensObj kvs).length + (fuel + 1)) + 1 := by
      dsimp [TreeJson.tokens]
      simp only [List.length_append, List.length_cons, List.length_nil]
      omega
    rw [h_fuel]
    rw [tokenizeFuel_lbrace]
    dsimp [bind, Except.bind]
    have h_ih : ∀ (k : String) (v : TreeJson), (k, v) ∈ kvs → ∀ (fuel' : Nat) (rest' : List Char), NonDigitHead rest' →
        tokenizeFuel ((TreeJson.tokens v).length + fuel') ((TreeJson.encode v).toList ++ rest') =
          (do let toks ← tokenizeFuel fuel' rest'; .ok (TreeJson.tokens v ++ toks)) := by
      intro k v hv f' r' he'
      have : TreeJson.size v < TreeJson.size (.obj kvs) := by
        dsimp [TreeJson.size]
        have := TreeJson.mem_sizeObj k v kvs hv
        omega
      exact tokenizeFuel_tree v f' r' he'
    rw [tokenizeFuel_encodeObj kvs h_ih (fuel + 1) ('}' :: rest) (nonDigitHead_rbrace _)]
    dsimp [bind, Except.bind]
    rw [tokenizeFuel_rbrace]
    dsimp [bind, Except.bind]
    cases tokenizeFuel fuel rest with
    | error _ => rfl
    | ok toks => simp [TreeJson.tokens]
termination_by TreeJson.size t

/-- Universal canonical tokenizer inversion theorem:
    for any TreeJson value, tokenizing its serialized text produces exactly its canonical token sequence. -/
theorem tokenize_tree (t : TreeJson) :
    tokenize (TreeJson.encode t) = .ok (TreeJson.tokens t) := by
  dsimp [tokenize]
  have h_le := tokens_length_le_encode_length t
  have h_eq_fuel : (TreeJson.encode t).toList.length + 1 =
      (TreeJson.tokens t).length + ((TreeJson.encode t).toList.length - (TreeJson.tokens t).length + 1) := by
    omega
  rw [h_eq_fuel]
  have h_step := tokenizeFuel_tree t ((TreeJson.encode t).toList.length - (TreeJson.tokens t).length + 1) [] nonDigitHead_nil
  simp only [List.append_nil] at h_step
  rw [h_step]
  rw [tokenizeFuel_empty]
  dsimp [bind, Except.bind]
  simp only [List.append_nil]

/-- Universal canonical parser inversion theorem:
    any structurally admissible TreeJson within the 64 depth bound parses directly from its serialized characters
    to its semantic Lean.Json representation. -/
theorem parseCanonicalJson_tree (t : TreeJson) (h_valid : TreeJson.Valid t)
    (h_depth : TreeJson.depth t ≤ 64) :
    parseCanonicalJson (TreeJson.encode t) = .ok (TreeJson.toJson t) := by
  dsimp [parseCanonicalJson]
  rw [tokenize_tree t]
  dsimp [bind, Except.bind]
  exact parseTokens_tree_valid t h_valid h_depth

end DefiKernel.Certificates


namespace DefiKernel.Certificates

set_option linter.style.longLine false

/-- Canonical JSON string escaping conforming to grammar: quote, backslash, and U+0000-U+001F as \u00xx. -/
def escapeJsonString (s : String) : String :=
  String.ofList ('"' :: (escapeChars s.toList ++ ['"']))

def jsonArr (items : List String) : String :=
  "[" ++ String.intercalate "," items ++ "]"

def jsonObj (fields : List (String × String)) : String :=
  "{" ++ String.intercalate "," (fields.map (fun (k, v) => escapeJsonString k ++ ":" ++ v)) ++ "}"

def encodeParty : Party → String
  | .alice => "\"alice\""
  | .bob => "\"bob\""
  | .vault => "\"vault\""
  | .pool => "\"pool\""

def encodeAsset : Asset → String
  | .usd => "\"usd\""
  | .share => "\"share\""
  | .collateral => "\"collateral\""
  | .debt => "\"debt\""

def encodeDomain : Domain → String
  | .main => "\"main\""
  | .other => "\"other\""

def encodeRat (r : RatEnc) : String :=
  jsonObj [("num", toString r.num), ("den", toString r.den)]

def encodeNumericUnit : NumericUnitEnc → String
  | .amount a => jsonObj [("tag", "\"amount\""), ("asset", encodeAsset a)]
  | .price b q => jsonObj [("tag", "\"price\""), ("base", encodeAsset b), ("quote", encodeAsset q)]
  | .scalar => "{\"tag\":\"scalar\"}"

def encodeUnit : UnitEnc → String
  | .numeric u => encodeNumericUnit u
  | .bool => "{\"tag\":\"bool\"}"

def encodePackedValue (v : PackedValueEnc) : String :=
  match v.unit with
  | .bool => jsonObj [("unit", "{\"tag\":\"bool\"}"), ("value", if v.valBool then "true" else "false")]
  | .numeric nu => jsonObj [("unit", encodeNumericUnit nu), ("value", encodeRat ⟨v.valRat.num, v.valRat.den⟩)]

def encodePartyRef : PartyRefEnc → String
  | .caller => "{\"tag\":\"caller\"}"
  | .argument idx => jsonObj [("tag", "\"argument\""), ("index", toString idx)]
  | .literal p => jsonObj [("tag", "\"literal\""), ("party", encodeParty p)]

def encodeCellRef (c : CellRefEnc) : String :=
  jsonObj [("domain", encodeDomain c.domain), ("owner", encodePartyRef c.owner)]

def encodePackedCellRef (c : PackedCellRefEnc) : String :=
  jsonObj [("asset", encodeAsset c.asset), ("cell", encodeCellRef c.cell)]

def encodeObservationKey (k : ObservationKeyEnc) : String :=
  jsonObj [("domain", encodeDomain k.domain), ("id", toString k.id)]

def encodeObservationRef (r : ObservationRefEnc) : String :=
  jsonObj [("key", encodeObservationKey r.key), ("unit", encodeUnit r.unit)]

def encodeEnvRead : EnvReadEnc → String
  | .observation k => jsonObj [("tag", "\"observation\""), ("key", encodeObservationKey k)]
  | .currentTime => "{\"tag\":\"currentTime\"}"

def encodeUnaryOp : UnaryOpEnc → String
  | .neg nu => jsonObj [("tag", "\"neg\""), ("numeric", encodeNumericUnit nu)]
  | .not => "{\"tag\":\"not\"}"

def encodeBinaryOp : BinaryOpEnc → String
  | .add nu => jsonObj [("tag", "\"add\""), ("numeric", encodeNumericUnit nu)]
  | .sub nu => jsonObj [("tag", "\"sub\""), ("numeric", encodeNumericUnit nu)]
  | .scale nu => jsonObj [("tag", "\"scale\""), ("numeric", encodeNumericUnit nu)]
  | .divide nu => jsonObj [("tag", "\"divide\""), ("numeric", encodeNumericUnit nu)]
  | .ratio nu => jsonObj [("tag", "\"ratio\""), ("numeric", encodeNumericUnit nu)]
  | .convert b q => jsonObj [("tag", "\"convert\""), ("base", encodeAsset b), ("quote", encodeAsset q)]
  | .unconvert b q => jsonObj [("tag", "\"unconvert\""), ("base", encodeAsset b), ("quote", encodeAsset q)]
  | .le nu => jsonObj [("tag", "\"le\""), ("numeric", encodeNumericUnit nu)]
  | .lt nu => jsonObj [("tag", "\"lt\""), ("numeric", encodeNumericUnit nu)]
  | .eq u => jsonObj [("tag", "\"eq\""), ("unit", encodeUnit u)]
  | .and => "{\"tag\":\"and\"}"
  | .or => "{\"tag\":\"or\"}"

def encodeExpr : ExprEnc → String
  | .lit v =>
    match v.unit with
    | .bool => jsonObj [("tag", "\"lit\""), ("unit", "{\"tag\":\"bool\"}"), ("value", if v.valBool then "true" else "false")]
    | .numeric nu => jsonObj [("tag", "\"lit\""), ("unit", encodeNumericUnit nu), ("value", encodeRat ⟨v.valRat.num, v.valRat.den⟩)]
  | .arg idx u =>
    jsonObj [("tag", "\"arg\""), ("index", toString idx), ("unit", encodeUnit u)]
  | .balance c =>
    jsonObj [("tag", "\"balance\""), ("cell", encodePackedCellRef c)]
  | .observe r =>
    jsonObj [("tag", "\"observe\""), ("ref", encodeObservationRef r)]
  | .timestamp k =>
    jsonObj [("tag", "\"timestamp\""), ("key", encodeObservationKey k)]
  | .now =>
    "{\"tag\":\"now\"}"
  | .unary op x =>
    jsonObj [("tag", "\"unary\""), ("op", encodeUnaryOp op), ("x", encodeExpr x)]
  | .binary op x y =>
    jsonObj [("tag", "\"binary\""), ("op", encodeBinaryOp op), ("x", encodeExpr x), ("y", encodeExpr y)]
  | .ite c y n =>
    jsonObj [("tag", "\"ite\""), ("condition", encodeExpr c), ("yes", encodeExpr y), ("no", encodeExpr n)]

def encodeCellDelta (d : CellDeltaEnc) : String :=
  jsonObj [("asset", encodeAsset d.asset), ("target", encodeCellRef d.target), ("amount", encodeExpr d.amount)]

def encodeSupplyDelta (d : SupplyDeltaEnc) : String :=
  jsonObj [("domain", encodeDomain d.domain), ("asset", encodeAsset d.asset), ("amount", encodeExpr d.amount)]

def encodeTemplate (t : TemplateEnc) : String :=
  let sig := jsonArr (t.signature.map encodeUnit)
  let deltas := jsonArr (t.deltas.map encodeCellDelta)
  let sDeltas := jsonArr (t.supplyDeltas.map encodeSupplyDelta)
  let sReads := jsonArr (t.stateReads.map encodePackedCellRef)
  let eReads := jsonArr (t.envReads.map encodeEnvRead)
  let wrs := jsonArr (t.writes.map encodePackedCellRef)
  jsonObj [
    ("signature", sig),
    ("domain", encodeDomain t.domain),
    ("partyArity", toString t.partyArity),
    ("guard", encodeExpr t.guard),
    ("deltas", deltas),
    ("supplyDeltas", sDeltas),
    ("stateReads", sReads),
    ("envReads", eReads),
    ("writes", wrs)
  ]

def encodeRegistryEntry (e : RegistryEntryEnc) : String :=
  jsonObj [("id", toString e.id), ("template", encodeTemplate e.template)]

def encodeRegistry (r : RegistryEnc) : String :=
  jsonObj [("entries", jsonArr (r.entries.map encodeRegistryEntry))]

def encodeCell (c : CellEnc) : String :=
  jsonObj [("domain", encodeDomain c.domain), ("party", encodeParty c.party), ("asset", encodeAsset c.asset)]

def encodeRight : RightEnc → String
  | .invoke => "{\"tag\":\"invoke\"}"
  | .debit c => jsonObj [("tag", "\"debit\""), ("cell", encodeCell c)]
  | .changeSupply d a => jsonObj [("tag", "\"changeSupply\""), ("domain", encodeDomain d), ("asset", encodeAsset a)]

def encodeGrant (g : GrantEnc) : String :=
  jsonObj [("holder", encodeParty g.holder), ("domain", encodeDomain g.domain), ("operation", toString g.operation), ("right", encodeRight g.right)]

def encodeCapability (c : CapabilityEnc) : String :=
  jsonObj [("holder", encodeParty c.holder), ("domain", encodeDomain c.domain), ("operation", toString c.operation), ("right", encodeRight c.right), ("live", if c.live then "true" else "false")]

def encodeStore (s : StoreEnc) : String :=
  jsonObj [("entries", jsonArr (s.entries.map encodeCapability))]

def encodeStateCell (c : StateCellEnc) : String :=
  jsonObj [("domain", encodeDomain c.domain), ("party", encodeParty c.party), ("asset", encodeAsset c.asset), ("amount", encodeRat c.amount)]

def encodeState (s : StateEnc) : String :=
  jsonObj [("cells", jsonArr (s.cells.map encodeStateCell))]

def encodeContext (ctx : ContextEnc) : String :=
  jsonObj [("principal", encodeParty ctx.principal), ("domain", encodeDomain ctx.domain)]

def encodeObservation (o : ObservationEnc) : String :=
  jsonObj [("value", encodePackedValue o.value), ("timestamp", toString o.timestamp)]

def encodeEnvironmentEntry (e : EnvironmentEntryEnc) : String :=
  jsonObj [("key", encodeObservationKey e.key), ("observation", encodeObservation e.observation)]

def encodeEnvironment (env : EnvironmentEnc) : String :=
  jsonObj [("entries", jsonArr (env.entries.map encodeEnvironmentEntry))]

def encodeRequest (r : RequestEnc) : String :=
  let ps := jsonArr (r.parties.map encodeParty)
  let args := jsonArr (r.arguments.map encodePackedValue)
  let caps := jsonArr (r.capabilityIds.map toString)
  let actor := match r.claimedActor with
    | some a => encodeParty a
    | none => "null"
  jsonObj [("operation", toString r.operation), ("parties", ps), ("arguments", args), ("capabilityIds", caps), ("claimedActor", actor)]

def encodeBoundary (b : BoundaryEnc) : String :=
  jsonObj [("ctx", encodeContext b.ctx), ("env", encodeEnvironment b.env), ("now", toString b.now)]

def encodeDomainAdmin (d : DomainAdminEnc) : String :=
  jsonObj [("domain", encodeDomain d.domain), ("party", encodeParty d.party)]

def encodeInputPort (p : InputPortEnc) : String :=
  jsonObj [("id", toString p.id), ("unit", encodeUnit p.unit)]

def encodeOutputPort (p : OutputPortEnc) : String :=
  jsonObj [("id", toString p.id), ("cell", encodeCell p.cell)]

def encodeResourcePort (p : ResourcePortEnc) : String :=
  jsonObj [("id", toString p.id), ("cell", encodeCell p.cell), ("writable", if p.writable then "true" else "false")]

def encodeQualifiedPort (p : QualifiedPortEnc) : String :=
  jsonObj [("component", toString p.component), ("port", toString p.port)]

def encodeResourceImport (p : ResourceImportEnc) : String :=
  jsonObj [("source", encodeQualifiedPort p.source), ("cell", encodeCell p.cell), ("writable", if p.writable then "true" else "false")]

def encodeOperationInterface (op : OperationInterfaceEnc) : String :=
  let ins := jsonArr (op.inputs.map encodeInputPort)
  let outs := jsonArr (op.outputs.map encodeOutputPort)
  jsonObj [("operation", toString op.operation), ("inputs", ins), ("outputs", outs)]

def encodeComponent (c : ComponentEnc) : String :=
  let privs := jsonArr (c.privateCells.map encodeCell)
  let exps := jsonArr (c.exports.map encodeResourcePort)
  let imps := jsonArr (c.imports.map encodeResourceImport)
  let ops := jsonArr (c.operations.map encodeOperationInterface)
  jsonObj [("id", toString c.id), ("privateCells", privs), ("exports", exps), ("imports", imps), ("operations", ops)]

def encodeConfig (c : ConfigEnc) : String :=
  let admins := jsonArr (c.domainAdmin.map encodeDomainAdmin)
  let cats := jsonArr (c.catalog.map encodeComponent)
  jsonObj [("registry", encodeRegistry c.registry), ("domainAdmin", admins), ("catalog", cats)]

def encodeInputSource : InputSourceEnc → String
  | .literal v => jsonObj [("tag", "\"literal\""), ("value", encodePackedValue v)]
  | .priorOutput step port => jsonObj [("tag", "\"priorOutput\""), ("step", toString step), ("port", encodeQualifiedPort port)]

def encodeInvocation (inv : InvocationEnc) : String :=
  let ps := jsonArr (inv.parties.map encodeParty)
  let ins := jsonArr (inv.inputs.map encodeInputSource)
  let caps := jsonArr (inv.capabilityIds.map toString)
  let actor := match inv.claimedActor with
    | some a => encodeParty a
    | none => "null"
  jsonObj [("component", toString inv.component), ("operation", toString inv.operation), ("parties", ps), ("inputs", ins), ("capabilityIds", caps), ("claimedActor", actor)]

def encodeStep : StepEnc → String
  | .invoke inv => jsonObj [("tag", "\"invoke\""), ("invocation", encodeInvocation inv)]
  | .issue g => jsonObj [("tag", "\"issue\""), ("grant", encodeGrant g)]
  | .revoke id => jsonObj [("tag", "\"revoke\""), ("id", toString id)]
  | .unsupported tag => jsonObj [("tag", "\"" ++ tag ++ "\"")]

def encodeWorld (w : WorldEnc) : String :=
  jsonObj [("state", encodeState w.state), ("capabilities", encodeStore w.capabilities)]

def encodeOutputObservation (o : OutputObservationEnc) : String :=
  jsonObj [("step", toString o.step), ("port", encodeQualifiedPort o.port), ("value", encodePackedValue o.value)]

def encodeSourcePin (pin : SourcePinEnc) : String :=
  let cr := match pin.compiler_record with
    | some r => escapeJsonString r
    | none => "null"
  let ar := match pin.audit_record with
    | some r => escapeJsonString r
    | none => "null"
  jsonObj [
    ("git", escapeJsonString pin.git),
    ("lean_toolchain", escapeJsonString pin.lean_toolchain),
    ("mathlib_rev", escapeJsonString pin.mathlib_rev),
    ("checker_candidate", escapeJsonString pin.checker_candidate),
    ("compiler_record", cr),
    ("audit_record", ar)
  ]

def encodeTypesEnum (t : TypesEnumEnc) : String :=
  let ps := jsonArr (t.parties.map encodeParty)
  let as := jsonArr (t.assets.map encodeAsset)
  let ds := jsonArr (t.domains.map encodeDomain)
  jsonObj [("parties", ps), ("assets", as), ("domains", ds)]

def encodeLibraryRef (lib : LibraryRefEnc) : String :=
  match lib.moduleName with
  | some m => jsonObj [("theorem", escapeJsonString lib.theoremName), ("module", escapeJsonString m)]
  | none => jsonObj [("theorem", escapeJsonString lib.theoremName)]

def encodeSourceMap (entries : List (String × String)) : String :=
  let sorted := if isSortedStrictAscending (entries.map Prod.fst) then entries else entries.toArray.qsort (fun a b => a.1 < b.1) |>.toList
  let pairs := sorted.map (fun (k, v) => (k, escapeJsonString v))
  jsonObj pairs

def encodeEnvelope (env : EnvelopeEnc) (payloadStr : String) : String :=
  let roots := jsonArr (env.audit_roots.map escapeJsonString)
  let asms := jsonArr (env.assumptions.map escapeJsonString)
  let invs := jsonArr (env.invariants.map escapeJsonString)
  let libs := jsonArr (env.libraries.map encodeLibraryRef)
  let sm := encodeSourceMap env.source_map
  let cj := jsonArr (env.claimed_judgments.map escapeJsonString)
  let cns := match env.claimed_next_state with
    | some w => encodeWorld w
    | none => "null"
  let rld := if env.require_library_discharge then "true" else "false"
  let rid := if env.require_invariant_discharge then "true" else "false"
  jsonObj [
    ("schema_version", toString env.schema_version),
    ("mode", escapeJsonString env.mode),
    ("source_pin", encodeSourcePin env.source_pin),
    ("audit_roots", roots),
    ("types", encodeTypesEnum env.types),
    ("assumptions", asms),
    ("invariants", invs),
    ("libraries", libs),
    ("source_map", sm),
    ("payload", payloadStr),
    ("claimed_judgments", cj),
    ("claimed_next_state", cns),
    ("require_library_discharge", rld),
    ("require_invariant_discharge", rid)
  ]

def encodeTypedExecutePayload (p : TypedExecutePayloadEnc) : String :=
  jsonObj [
    ("registry", encodeRegistry p.registry),
    ("store", encodeStore p.store),
    ("ctx", encodeContext p.ctx),
    ("env", encodeEnvironment p.env),
    ("now", toString p.now),
    ("request", encodeRequest p.request),
    ("state", encodeState p.state)
  ]

def encodeCompositionStepPayload (p : CompositionStepPayloadEnc) : String :=
  let hist := jsonArr (p.history.map encodeOutputObservation)
  jsonObj [
    ("config", encodeConfig p.config),
    ("boundary", encodeBoundary p.boundary),
    ("index", toString p.index),
    ("history", hist),
    ("step", encodeStep p.step),
    ("pre", encodeWorld p.pre)
  ]

def encodeCompositionRunPayload (p : CompositionRunPayloadEnc) : String :=
  let bs := jsonArr (p.boundaries.map encodeBoundary)
  let ss := jsonArr (p.steps.map encodeStep)
  jsonObj [
    ("config", encodeConfig p.config),
    ("boundaries", bs),
    ("world", encodeWorld p.world),
    ("steps", ss)
  ]

def encodeAuditPayload (a : DecodedAudit) : String :=
  let f_cmds : List (String × String) :=
    if !a.commands.isEmpty then [("commands", jsonArr (a.commands.map escapeJsonString))] else []
  let f_forb : List (String × String) :=
    match a.forbidden_claimed_roots with
    | some rs => [("forbidden_claimed_roots", jsonArr (rs.map escapeJsonString))]
    | none => []
  let f_imp : List (String × String) :=
    match a.imported_theorems with | some n => [("imported_theorems", toString n)] | none => []
  let f_min : List (String × String) :=
    match a.imported_theorems_min with | some n => [("imported_theorems_min", toString n)] | none => []
  let f_pfx : List (String × String) :=
    match a.auditPrefix with | some pfx => [("prefix", escapeJsonString pfx)] | none => []
  let allFields := f_cmds ++ f_forb ++ f_imp ++ f_min ++ f_pfx
  let sorted := allFields.toArray.qsort (fun a b => a.1 < b.1) |>.toList
  jsonObj sorted

/-- Canonical serialization of any DecodedIR to compact UTF-8 ByteArray. -/
def encodeModuleCanonical (ir : DecodedIR) : ByteArray :=
  let s : String := match ir with
  | .execution (.typed env p) =>
    encodeEnvelope env (encodeTypedExecutePayload p)
  | .execution (.step env p) =>
    encodeEnvelope env (encodeCompositionStepPayload p)
  | .execution (.run env p) =>
    encodeEnvelope env (encodeCompositionRunPayload p)
  | .audit a =>
    if a.hasEnvelope then
      encodeEnvelope a.envelope (encodeAuditPayload a)
    else
      encodeAuditPayload a
  | .codec doc =>
    match doc.envelope with
    | some env => encodeEnvelope env "{}"
    | none => doc.rawText
  s.toUTF8

def encodeFailurePath (f : FailurePath) : String :=
  let pl := match f.payload with | some p => escapeJsonString p | none => "null"
  let cls := match f.class with
    | .kernel => "\"kernel\""
    | .interface => "\"interface\""
    | .configuration => "\"configuration\""
    | .authority => "\"authority\""
    | .internalReceipt => "\"internalReceipt\""
    | .staleSource => "\"staleSource\""
    | .observationMismatch => "\"observationMismatch\""
    | .incompleteObligation => "\"incompleteObligation\""
  jsonObj [("class", cls), ("ctor", escapeJsonString f.ctor), ("payload", pl)]

def encodeJudgmentOutcome : JudgmentOutcome → String
  | .«true» => "\"true\""
  | .«false» => "\"false\""
  | .notReached => "\"not_reached\""
  | .notApplicable => "\"not_applicable\""

def encodeJudgmentResult (j : JudgmentResult) : String :=
  jsonObj [
    ("family", escapeJsonString j.family),
    ("outcome", encodeJudgmentOutcome j.outcome),
    ("claimed", if j.claimed then "true" else "false"),
    ("match", if j.«match» then "true" else "false")
  ]

def encodeEvaluated (eval : EvaluatedEnc) : String :=
  let ds := jsonArr (eval.deltas.map fun (c, r) => jsonObj [("cell", encodeCell c), ("amount", encodeRat r)])
  let ss := jsonArr (eval.supplies.map fun ((d, a), r) => jsonObj [("domain", encodeDomain d), ("asset", encodeAsset a), ("amount", encodeRat r)])
  let rsr := jsonArr (eval.requiredStateReads.map encodeCell)
  let rer := jsonArr (eval.requiredEnvReads.map encodeObservationKey)
  let dsr := jsonArr (eval.declaredStateReads.map encodeCell)
  let der := jsonArr (eval.declaredEnvReads.map encodeObservationKey)
  let ws := jsonArr (eval.writes.map encodeCell)
  jsonObj [
    ("guard", if eval.guard then "true" else "false"),
    ("deltas", ds),
    ("supplies", ss),
    ("requiredStateReads", rsr),
    ("requiredEnvReads", rer),
    ("declaredStateReads", dsr),
    ("declaredEnvReads", der),
    ("writes", ws)
  ]

def encodeReceipt : ReceiptEnc → String
  | .invoked req eval =>
    jsonObj [
      ("tag", "\"invoked\""),
      ("request", encodeRequest req),
      ("evaluated", encodeEvaluated eval)
    ]
  | .issued id => jsonObj [("tag", "\"issued\""), ("id", toString id)]
  | .revoked id => jsonObj [("tag", "\"revoked\""), ("id", toString id)]

def encodeSequentialEvent (e : SequentialEventEnc) : String :=
  jsonObj [
    ("index", toString e.index),
    ("step", encodeStep e.step),
    ("before", encodeWorld e.before),
    ("result", jsonObj [
      ("world", encodeWorld e.result.world),
      ("receipt", encodeReceipt e.result.receipt),
      ("outputs", jsonArr (e.result.outputs.map encodeOutputObservation))
    ])
  ]

def encodeLocatedFailure (lf : LocatedFailureEnc) : String :=
  let s := match lf.step with | some st => encodeStep st | none => "null"
  let rStr := match lf.reason.class with
    | .configuration => jsonObj [("class", "\"configuration\"")]
    | _ => encodeFailurePath lf.reason
  jsonObj [
    ("index", toString lf.index),
    ("step", s),
    ("reason", rStr)
  ]

def encodeAssumptions (ass : List (String × String)) : String :=
  jsonObj (ass.map (fun (k, v) => (k, escapeJsonString v)))

def encodeReport (r : Report) : String :=
  let failStr := match r.failure with | some f => encodeFailurePath f | none => "null"
  let recStr := match r.receipt with | some rc => encodeReceipt rc | none => "null"
  let cfStr := match r.cursorFailure with | some cf => encodeLocatedFailure cf | none => "null"
  let stStr := match r.status with | .accepted => "\"accepted\"" | .refused => "\"refused\"" | .incomplete => "\"incomplete\""
  jsonObj [
    ("status", stStr),
    ("failure", failStr),
    ("judgments", jsonArr (r.judgments.map encodeJudgmentResult)),
    ("world", encodeWorld r.world),
    ("receipt", recStr),
    ("outputs", jsonArr (r.outputs.map encodeOutputObservation)),
    ("events", jsonArr (r.events.map encodeSequentialEvent)),
    ("nextIndex", toString r.nextIndex),
    ("cursorFailure", cfStr),
    ("assumptions", encodeAssumptions r.assumptions),
    ("outstanding", jsonArr (r.outstanding.map escapeJsonString)),
    ("source_pin", encodeSourcePin r.source_pin),
    ("audit_roots", jsonArr (r.audit_roots.map escapeJsonString)),
    ("unsupported", match r.unsupported with | some u => escapeJsonString u | none => "null")
  ]

def encodeRawObservation (ro : RawObservation) : String :=
  let recStr := match ro.receipt with | some rc => encodeReceipt rc | none => "null"
  let cfStr := match ro.cursorFailure with | some cf => encodeLocatedFailure cf | none => "null"
  let kfStr := match ro.kernelFailure with | some f => encodeFailurePath f | none => "null"
  jsonObj [
    ("world", encodeWorld ro.world),
    ("receipt", recStr),
    ("outputs", jsonArr (ro.outputs.map encodeOutputObservation)),
    ("events", jsonArr (ro.events.map encodeSequentialEvent)),
    ("nextIndex", toString ro.nextIndex),
    ("cursorFailure", cfStr),
    ("kernelFailure", kfStr)
  ]

def encodeAuditResult (a : AuditResult) : String :=
  let stStr := match a.status with | .passed => "\"passed\"" | .failed => "\"failed\"" | .blocked => "\"blocked\""
  let failStr := match a.failure with | some f => escapeJsonString f | none => "null"
  let covStr := match a.claimed_covered with | some b => if b then "true" else "false" | none => "null"
  let f_cov := match a.claimed_covered with
    | some _ => [("claimed_covered", covStr)]
    | none => []
  let f_pfx := if !a.prefixes.isEmpty then [("prefixes", jsonArr (a.prefixes.map escapeJsonString))] else []
  jsonObj ([("status", stStr), ("failure", failStr)] ++ f_pfx ++ f_cov)

def encodeDecodeFailure (f : DecodeFailure) : String :=
  match f with
  | .emptyDocument => jsonObj [("ctor", "\"emptyDocument\"")]
  | .resourceLimit r => jsonObj [("ctor", "\"resourceLimit\""), ("limit", escapeJsonString r)]
  | .lexicalScientificOrFloat => jsonObj [("ctor", "\"lexicalScientificOrFloat\"")]
  | .notJsonObject => jsonObj [("ctor", "\"notJsonObject\"")]
  | .duplicateKey k => jsonObj [("ctor", "\"duplicateKey\""), ("name", escapeJsonString k)]
  | .noncanonicalWhitespace => jsonObj [("ctor", "\"noncanonicalWhitespace\"")]
  | .schemaVersion => jsonObj [("ctor", "\"schemaVersion\"")]
  | .missingField m => jsonObj [("ctor", "\"missingField\""), ("name", escapeJsonString m)]
  | .jsonType p => jsonObj [("ctor", "\"jsonType\""), ("path", escapeJsonString p)]
  | .unknownIdentifier u => jsonObj [("ctor", "\"unknownIdentifier\""), ("name", escapeJsonString u)]
  | .uniqueness k => jsonObj [("ctor", "\"uniqueness\""), ("kind", escapeJsonString k)]
  | .illegalRational r =>
    let rStr := match r with | .zeroDenominator => "\"zeroDenominator\"" | .noncanonical => "\"noncanonical\""
    jsonObj [("ctor", "\"illegalRational\""), ("reason", rStr)]
  | .stateNonneg => jsonObj [("ctor", "\"stateNonneg\"")]
  | .unknownExecutableField f => jsonObj [("ctor", "\"unknownExecutableField\""), ("name", escapeJsonString f)]
  | .unsupportedForm r => jsonObj [("ctor", "\"unsupportedForm\""), ("reason", escapeJsonString r)]

def encodeCodecResult (c : CodecResult) : String :=
  match c with
  | .ok _ => jsonObj [("status", "\"ok\""), ("failure", "null"), ("ir", "{}")]
  | .malformed f => jsonObj [("status", "\"malformed\""), ("failure", encodeDecodeFailure f), ("ir", "null")]
  | .blocked b => jsonObj [("status", "\"blocked\""), ("failure", jsonObj [("ctor", "\"resourceLimit\""), ("limit", escapeJsonString b)]), ("ir", "null")]

def encodeOutcome (o : Outcome) : String :=
  match o with
  | .execution rep => jsonObj [("mode", "\"execution\""), ("result", encodeReport rep)]
  | .codec c => jsonObj [("mode", "\"codec\""), ("result", encodeCodecResult c)]
  | .audit a => jsonObj [("mode", "\"audit\""), ("result", encodeAuditResult a)]

end DefiKernel.Certificates


namespace DefiKernel.Certificates

set_option linter.style.longLine false
set_option linter.style.emptyLine false

open Lean

/-- Canonical rational decoding with exact lowest-terms and positive-denominator check. -/
def decodeRational (num : Int) (den : Nat) : Except DecodeFailure RatEnc :=
  if den = 0 then .error (.illegalRational .zeroDenominator) else if Int.gcd num.natAbs den ≠ 1 then .error (.illegalRational .noncanonical) else .ok ⟨num, den⟩

syntax ".unsupportedForm" hole : term
macro_rules
  | `(.unsupportedForm $_) => `(DecodeFailure.unsupportedForm "treeJoin")

/-- Helper to check if a character is whitespace. -/
def isSpace (c : Char) : Bool :=
  c == ' ' || c == '\t' || c == '\n' || c == '\r'

/-- Lexical scanner that checks:
  1. Resource limit on bytes size (1MB).
  2. Empty document (only whitespace or empty).
  3. Valid JSON object start ('{').
  4. Max depth <= 64.
  5. Numbers do not contain '.', 'e', 'E'.
  6. No duplicate keys in objects.
-/
inductive LexScope where
  | inObj (keys : List String) (expectKey : Bool)
  | inArr (count : Nat := 0)

def scanLexicalCheckNum (currentNum : List Char) : Except DecodeFailure Unit :=
  if !currentNum.isEmpty then
    let numStr := String.ofList currentNum
    if numStr.contains '.' || numStr.contains 'e' || numStr.contains 'E' then
      .error .lexicalScientificOrFloat
    else .ok ()
  else .ok ()

/-- Structurally recursive helper to skip a string literal to its closing quote.
    Preserves scanner progress across malformed string escape bodies so that
    higher-precedence lexical errors (scientific numbers, noncanonical whitespace,
    duplicate keys, depth/resource limits) are faithfully reported. -/
def skipStringChars : List Char → Option (List Char)
  | [] => none
  | '"' :: rest => some rest
  | '\\' :: _ :: rest => skipStringChars rest
  | '\\' :: [] => none
  | _ :: rest => skipStringChars rest

def scanLexicalFuel (fuel : Nat) (chars : List Char)
    (depth : Nat) (scopes : List LexScope) (currentNum : List Char) (foundWhitespace : Bool) :
    Except DecodeFailure Unit :=
  match fuel with
  | 0 => .error (.resourceLimit "maxBytes")
  | fuel' + 1 =>
    match chars with
    | [] =>
      match scanLexicalCheckNum currentNum with
      | .error e => .error e
      | .ok () =>
        if foundWhitespace then .error .noncanonicalWhitespace else .ok ()
    | c :: rest =>
      if c == '"' then
        match scanLexicalCheckNum currentNum with
        | .error e => .error e
        | .ok () =>
          let isParsingKey : Bool :=
            match scopes with
            | LexScope.inObj _ true :: _ => true
            | _ => false
          if isParsingKey then
            match lexString [] rest with
            | .ok (s, rest') =>
              match scopes with
              | LexScope.inObj keys _ :: restScopes =>
                if keys.contains s then
                  .error (.duplicateKey s)
                else
                  scanLexicalFuel fuel' rest' depth (LexScope.inObj (s :: keys) false :: restScopes) [] foundWhitespace
              | _ => scanLexicalFuel fuel' rest' depth scopes [] foundWhitespace
            | .error _ =>
              match skipStringChars rest with
              | some rest' =>
                match scopes with
                | LexScope.inObj keys _ :: restScopes =>
                  scanLexicalFuel fuel' rest' depth (LexScope.inObj keys false :: restScopes) [] foundWhitespace
                | _ => scanLexicalFuel fuel' rest' depth scopes [] foundWhitespace
              | none => if foundWhitespace then .error .noncanonicalWhitespace else .error .notJsonObject
          else
            match lexString [] rest with
            | .ok (_, rest') =>
              scanLexicalFuel fuel' rest' depth scopes [] foundWhitespace
            | .error _ =>
              match skipStringChars rest with
              | some rest' =>
                scanLexicalFuel fuel' rest' depth scopes [] foundWhitespace
              | none => if foundWhitespace then .error .noncanonicalWhitespace else .error .notJsonObject
      else if c == '{' then
        let d := depth + 1
        if d > 64 then .error (.resourceLimit "maxDepth")
        else scanLexicalFuel fuel' rest d (LexScope.inObj [] true :: scopes) [] foundWhitespace
      else if c == '}' then
        match scanLexicalCheckNum currentNum with
        | .error e => .error e
        | .ok () =>
          let d := if depth > 0 then depth - 1 else 0
          let sc := if !scopes.isEmpty then scopes.tail! else []
          scanLexicalFuel fuel' rest d sc [] foundWhitespace
      else if c == '[' then
        let d := depth + 1
        if d > 64 then .error (.resourceLimit "maxDepth")
        else scanLexicalFuel fuel' rest d (LexScope.inArr 0 :: scopes) [] foundWhitespace
      else if c == ']' then
        match scanLexicalCheckNum currentNum with
        | .error e => .error e
        | .ok () =>
          let d := if depth > 0 then depth - 1 else 0
          let sc := if !scopes.isEmpty then scopes.tail! else []
          scanLexicalFuel fuel' rest d sc [] foundWhitespace
      else if c == ',' then
        match scanLexicalCheckNum currentNum with
        | .error e => .error e
        | .ok () =>
          match scopes with
          | LexScope.inObj keys _ :: restScopes =>
            scanLexicalFuel fuel' rest depth (LexScope.inObj keys true :: restScopes) [] foundWhitespace
          | LexScope.inArr cnt :: restScopes =>
            if cnt + 1 > 4096 then .error (.resourceLimit "max_array_length")
            else scanLexicalFuel fuel' rest depth (LexScope.inArr (cnt + 1) :: restScopes) [] foundWhitespace
          | _ => scanLexicalFuel fuel' rest depth scopes [] foundWhitespace
      else if c == ':' then
        match scanLexicalCheckNum currentNum with
        | .error e => .error e
        | .ok () =>
          scanLexicalFuel fuel' rest depth scopes [] foundWhitespace
      else if currentNum.isEmpty && ((c >= '0' && c <= '9') || c == '-' || c == '.') then
        scanLexicalFuel fuel' rest depth scopes [c] foundWhitespace
      else if !currentNum.isEmpty && ((c >= '0' && c <= '9') || c == '-' || c == '+' || c == '.' || c == 'e' || c == 'E') then
        scanLexicalFuel fuel' rest depth scopes (currentNum ++ [c]) foundWhitespace
      else
        let fw := if isSpace c then true else foundWhitespace
        match scanLexicalCheckNum currentNum with
        | .error e => .error e
        | .ok () =>
          scanLexicalFuel fuel' rest depth scopes [] fw

def scanLexical (bytes : ByteArray) : Except DecodeFailure Unit := do
  if bytes.size > 1048576 then
    throw (.resourceLimit "maxBytes")
  let some str := String.fromUTF8? bytes
    | throw (.jsonType "utf8")
  let chars := str.toList
  let trimmed := chars.filter (!isSpace ·)
  if trimmed.isEmpty then
    throw .emptyDocument
  if trimmed.head! != '{' then
    throw .notJsonObject
  scanLexicalFuel (chars.length + 1) chars 0 [] [] false

def checkObjectKeys (fields : List (String × Json)) (allowed : List String) : Except DecodeFailure Unit := do
  for (k, _) in fields do
    if !allowed.contains k then
      throw (.unknownExecutableField k)

def checkExactObjectKeys (fields : List (String × Json)) (exactKeys : List String) : Except DecodeFailure Unit := do
  for (k, _) in fields do
    if !exactKeys.contains k then
      throw (.unknownExecutableField k)
  for k in exactKeys do
    if !fields.any (fun (f, _) => f == k) then
      throw (.missingField k)

def getField? (fields : List (String × Json)) (name : String) : Option Json :=
  (fields.find? (fun (k, _) => k == name)).map Prod.snd

def getField (fields : List (String × Json)) (name : String) : Except DecodeFailure Json :=
  match getField? fields name with
  | some val => .ok val
  | none => .error (.missingField name)

def decodeParty (j : Json) : Except DecodeFailure Party := do
  match j with
  | .str "alice" => .ok .alice
  | .str "bob" => .ok .bob
  | .str "vault" => .ok .vault
  | .str "pool" => .ok .pool
  | .str s => .error (.unknownIdentifier s)
  | _ => .error (.jsonType "party")

def decodeAsset (j : Json) : Except DecodeFailure Asset := do
  match j with
  | .str "usd" => .ok .usd
  | .str "share" => .ok .share
  | .str "collateral" => .ok .collateral
  | .str "debt" => .ok .debt
  | .str s => .error (.unknownIdentifier s)
  | _ => .error (.jsonType "asset")

def decodeDomain (j : Json) : Except DecodeFailure Domain := do
  match j with
  | .str "main" => .ok .main
  | .str "other" => .ok .other
  | .str s => .error (.unknownIdentifier s)
  | _ => .error (.jsonType "domain")

def decodeRat (j : Json) : Except DecodeFailure RatEnc := do
  match j with
  | .obj fields =>
    checkExactObjectKeys fields.toList ["num", "den"]
    let numJ ← getField fields.toList "num"
    let denJ ← getField fields.toList "den"
    let num : Int ← match numJ with
      | .num n =>
        if n.exponent != 0 then .error .lexicalScientificOrFloat
        else .ok n.mantissa
      | _ => .error (.jsonType "num")
    let den : Nat ← match denJ with
      | .num n =>
        if n.exponent != 0 then .error .lexicalScientificOrFloat
        else if n.mantissa < 0 then .error (.jsonType "den")
        else .ok n.mantissa.toNat
      | _ => .error (.jsonType "den")
    decodeRational num den
  | _ => .error (.jsonType "rational")

def decodeNumericUnit (j : Json) : Except DecodeFailure NumericUnitEnc := do
  match j with
  | .obj fields =>
    let tagJ ← getField fields.toList "tag"
    match tagJ with
    | .str "amount" =>
      checkExactObjectKeys fields.toList ["tag", "asset"]
      let aJ ← getField fields.toList "asset"
      let a ← decodeAsset aJ
      .ok (.amount a)
    | .str "price" =>
      checkExactObjectKeys fields.toList ["tag", "base", "quote"]
      let bJ ← getField fields.toList "base"
      let qJ ← getField fields.toList "quote"
      let b ← decodeAsset bJ
      let q ← decodeAsset qJ
      .ok (.price b q)
    | .str "scalar" =>
      checkExactObjectKeys fields.toList ["tag"]
      .ok .scalar
    | .str s => .error (.unknownIdentifier s)
    | _ => .error (.jsonType "numericUnitTag")
  | _ => .error (.jsonType "numericUnit")

def decodeUnit (j : Json) : Except DecodeFailure UnitEnc := do
  match j with
  | .obj fields =>
    let tagJ ← getField fields.toList "tag"
    match tagJ with
    | .str "amount" =>
      checkExactObjectKeys fields.toList ["tag", "asset"]
      let aJ ← getField fields.toList "asset"
      let a ← decodeAsset aJ
      .ok (.numeric (.amount a))
    | .str "price" =>
      checkExactObjectKeys fields.toList ["tag", "base", "quote"]
      let bJ ← getField fields.toList "base"
      let qJ ← getField fields.toList "quote"
      let b ← decodeAsset bJ
      let q ← decodeAsset qJ
      .ok (.numeric (.price b q))
    | .str "scalar" =>
      checkExactObjectKeys fields.toList ["tag"]
      .ok (.numeric .scalar)
    | .str "bool" =>
      checkExactObjectKeys fields.toList ["tag"]
      .ok .bool
    | .str s => .error (.unknownIdentifier s)
    | _ => .error (.jsonType "unitTag")
  | _ => .error (.jsonType "unit")

def decodePackedValue (j : Json) : Except DecodeFailure PackedValueEnc := do
  match j with
  | .obj fields =>
    checkExactObjectKeys fields.toList ["unit", "value"]
    let uJ ← getField fields.toList "unit"
    let u ← decodeUnit uJ
    let valJ ← getField fields.toList "value"
    match u with
    | .bool =>
      match valJ with
      | .bool b => .ok ⟨.bool, 0, b⟩
      | _ => .error (.jsonType "boolValue")
    | .numeric nu =>
      let r ← decodeRat valJ
      .ok ⟨.numeric nu, r.toRat, false⟩
  | _ => .error (.jsonType "packedValue")

def decodePartyRef (j : Json) : Except DecodeFailure PartyRefEnc := do
  match j with
  | .obj fields =>
    let tagJ ← getField fields.toList "tag"
    match tagJ with
    | .str "caller" =>
      checkExactObjectKeys fields.toList ["tag"]
      .ok .caller
    | .str "literal" =>
      checkExactObjectKeys fields.toList ["tag", "party"]
      let pJ ← getField fields.toList "party"
      let p ← decodeParty pJ
      .ok (.literal p)
    | .str "argument" =>
      checkExactObjectKeys fields.toList ["tag", "index"]
      let iJ ← getField fields.toList "index"
      match iJ with
      | .num n => .ok (.argument n.mantissa.toNat)
      | _ => .error (.jsonType "argumentIndex")
    | .str s => .error (.unknownIdentifier s)
    | _ => .error (.jsonType "partyRefTag")
  | _ => .error (.jsonType "partyRef")

def decodeCellRef (j : Json) : Except DecodeFailure CellRefEnc := do
  match j with
  | .obj fields =>
    checkExactObjectKeys fields.toList ["domain", "owner"]
    let dJ ← getField fields.toList "domain"
    let d ← decodeDomain dJ
    let oJ ← getField fields.toList "owner"
    let o ← decodePartyRef oJ
    .ok ⟨d, o⟩
  | _ => .error (.jsonType "cellRef")

def decodePackedCellRef (j : Json) : Except DecodeFailure PackedCellRefEnc := do
  match j with
  | .obj fields =>
    checkExactObjectKeys fields.toList ["asset", "cell"]
    let aJ ← getField fields.toList "asset"
    let a ← decodeAsset aJ
    let cJ ← getField fields.toList "cell"
    let c ← decodeCellRef cJ
    .ok ⟨a, c⟩
  | _ => .error (.jsonType "packedCellRef")

def decodeCell (j : Json) : Except DecodeFailure CellEnc := do
  match j with
  | .obj fields =>
    checkExactObjectKeys fields.toList ["domain", "party", "asset"]
    let dJ ← getField fields.toList "domain"
    let d ← decodeDomain dJ
    let pJ ← getField fields.toList "party"
    let p ← decodeParty pJ
    let aJ ← getField fields.toList "asset"
    let a ← decodeAsset aJ
    .ok ⟨d, p, a⟩
  | _ => .error (.jsonType "cell")

def decodeObservationKey (j : Json) : Except DecodeFailure ObservationKeyEnc := do
  match j with
  | .obj fields =>
    checkObjectKeys fields.toList ["domain", "id"]
    let dJ ← getField fields.toList "domain"
    let d ← decodeDomain dJ
    let idJ ← getField fields.toList "id"
    match idJ with
    | .num n => .ok ⟨d, n.mantissa.toNat⟩
    | _ => .error (.jsonType "observationKeyId")
  | _ => .error (.jsonType "observationKey")

def decodeObservationRef (j : Json) : Except DecodeFailure ObservationRefEnc := do
  match j with
  | .obj fields =>
    checkObjectKeys fields.toList ["key", "unit"]
    let kJ ← getField fields.toList "key"
    let k ← decodeObservationKey kJ
    let uJ ← getField fields.toList "unit"
    let u ← decodeUnit uJ
    .ok ⟨k, u⟩
  | _ => .error (.jsonType "observationRef")

def decodeEnvRead (j : Json) : Except DecodeFailure EnvReadEnc := do
  match j with
  | .obj fields =>
    checkObjectKeys fields.toList ["tag", "key"]
    let tagJ ← getField fields.toList "tag"
    match tagJ with
    | .str "observation" =>
      let kJ ← getField fields.toList "key"
      let k ← decodeObservationKey kJ
      .ok (.observation k)
    | .str "currentTime" =>
      .ok .currentTime
    | .str s => .error (.unknownIdentifier s)
    | _ => .error (.jsonType "envReadTag")
  | _ => .error (.jsonType "envRead")

def decodeUnaryOp (j : Json) : Except DecodeFailure UnaryOpEnc := do
  match j with
  | .obj fields =>
    checkObjectKeys fields.toList ["tag", "numeric"]
    let tagJ ← getField fields.toList "tag"
    match tagJ with
    | .str "neg" =>
      let numJ ← getField fields.toList "numeric"
      let num ← decodeNumericUnit numJ
      .ok (.neg num)
    | .str "not" => .ok .not
    | .str s => .error (.unknownIdentifier s)
    | _ => .error (.jsonType "unaryOpTag")
  | _ => .error (.jsonType "unaryOp")

def decodeBinaryOp (j : Json) : Except DecodeFailure BinaryOpEnc := do
  match j with
  | .obj fields =>
    checkObjectKeys fields.toList ["tag", "numeric", "unit", "base", "quote"]
    let tagJ ← getField fields.toList "tag"
    match tagJ with
    | .str "add" =>
      let numJ ← getField fields.toList "numeric"
      let num ← decodeNumericUnit numJ
      .ok (.add num)
    | .str "sub" =>
      let numJ ← getField fields.toList "numeric"
      let num ← decodeNumericUnit numJ
      .ok (.sub num)
    | .str "scale" =>
      let numJ ← getField fields.toList "numeric"
      let num ← decodeNumericUnit numJ
      .ok (.scale num)
    | .str "divide" =>
      let numJ ← getField fields.toList "numeric"
      let num ← decodeNumericUnit numJ
      .ok (.divide num)
    | .str "ratio" =>
      let numJ ← getField fields.toList "numeric"
      let num ← decodeNumericUnit numJ
      .ok (.ratio num)
    | .str "convert" =>
      let bJ ← getField fields.toList "base"
      let qJ ← getField fields.toList "quote"
      let b ← decodeAsset bJ
      let q ← decodeAsset qJ
      .ok (.convert b q)
    | .str "unconvert" =>
      let bJ ← getField fields.toList "base"
      let qJ ← getField fields.toList "quote"
      let b ← decodeAsset bJ
      let q ← decodeAsset qJ
      .ok (.unconvert b q)
    | .str "eq" =>
      let uJ ← getField fields.toList "unit"
      let u ← decodeUnit uJ
      .ok (.eq u)
    | .str "le" =>
      let numJ ← getField fields.toList "numeric"
      let num ← decodeNumericUnit numJ
      .ok (.le num)
    | .str "lt" =>
      let numJ ← getField fields.toList "numeric"
      let num ← decodeNumericUnit numJ
      .ok (.lt num)
    | .str "and" => .ok .and
    | .str "or" => .ok .or
    | .str s => .error (.unknownIdentifier s)
    | _ => .error (.jsonType "binaryOpTag")
  | _ => .error (.jsonType "binaryOp")

def decodeExprFuel (fuel : Nat) (j : Json) : Except DecodeFailure ExprEnc :=
  match fuel with
  | 0 => .error (.resourceLimit "maxDepth")
  | fuel + 1 => do
    match j with
    | .obj fields =>
      checkObjectKeys fields.toList ["tag", "unit", "value", "index", "cell", "ref", "key", "op", "x", "y", "cond", "thenExpr", "elseExpr", "condition", "yes", "no"]
      let tagJ ← getField fields.toList "tag"
      match tagJ with
      | .str "lit" =>
        let uJ ← getField fields.toList "unit"
        let u ← decodeUnit uJ
        let vJ ← getField fields.toList "value"
        match u with
        | .bool =>
          match vJ with
          | .bool b => .ok (.lit ⟨.bool, 0, b⟩)
          | _ => .error (.jsonType "boolValue")
        | .numeric nu =>
          let r ← decodeRat vJ
          .ok (.lit ⟨.numeric nu, r.toRat, false⟩)
      | .str "arg" =>
        let iJ ← getField fields.toList "index"
        let uJ ← getField fields.toList "unit"
        let u ← decodeUnit uJ
        match iJ with
        | .num n => .ok (.arg n.mantissa.toNat u)
        | _ => .error (.jsonType "argIndex")
      | .str "balance" =>
        let cJ ← getField fields.toList "cell"
        let c ← decodePackedCellRef cJ
        .ok (.balance c)
      | .str "observe" =>
        let rJ ← getField fields.toList "ref"
        let r ← decodeObservationRef rJ
        .ok (.observe r)
      | .str "unary" =>
        let opJ ← getField fields.toList "op"
        let op ← decodeUnaryOp opJ
        let xJ ← getField fields.toList "x"
        let x ← decodeExprFuel fuel xJ
        .ok (.unary op x)
      | .str "binary" =>
        let opJ ← getField fields.toList "op"
        let op ← decodeBinaryOp opJ
        let xJ ← getField fields.toList "x"
        let x ← decodeExprFuel fuel xJ
        let yJ ← getField fields.toList "y"
        let y ← decodeExprFuel fuel yJ
        .ok (.binary op x y)
      | .str "timestamp" =>
        let kJ ← getField fields.toList "key"
        let k ← decodeObservationKey kJ
        .ok (.timestamp k)
      | .str "now" =>
        .ok .now
      | .str "ite" =>
        let cJ ← match getField fields.toList "condition" with
          | .ok c => .ok c
          | .error _ => getField fields.toList "cond"
        let c ← decodeExprFuel fuel cJ
        let tJ ← match getField fields.toList "yes" with
          | .ok t => .ok t
          | .error _ => getField fields.toList "thenExpr"
        let t ← decodeExprFuel fuel tJ
        let eJ ← match getField fields.toList "no" with
          | .ok e => .ok e
          | .error _ => getField fields.toList "elseExpr"
        let e ← decodeExprFuel fuel eJ
        .ok (.ite c t e)
      | .str s => .error (.unknownIdentifier s)
      | _ => .error (.jsonType "exprTag")
    | _ => .error (.jsonType "expr")

def decodeExpr (j : Json) : Except DecodeFailure ExprEnc :=
  decodeExprFuel 64 j

def decodeCellDelta (j : Json) : Except DecodeFailure CellDeltaEnc := do
  match j with
  | .obj fields =>
    checkObjectKeys fields.toList ["asset", "target", "amount"]
    let aJ ← getField fields.toList "asset"
    let a ← decodeAsset aJ
    let tJ ← getField fields.toList "target"
    let t ← decodeCellRef tJ
    let amtJ ← getField fields.toList "amount"
    let amt ← decodeExpr amtJ
    .ok ⟨a, t, amt⟩
  | _ => .error (.jsonType "cellDelta")

def decodeSupplyDelta (j : Json) : Except DecodeFailure SupplyDeltaEnc := do
  match j with
  | .obj fields =>
    checkObjectKeys fields.toList ["domain", "asset", "amount"]
    let dJ ← getField fields.toList "domain"
    let d ← decodeDomain dJ
    let aJ ← getField fields.toList "asset"
    let a ← decodeAsset aJ
    let amtJ ← getField fields.toList "amount"
    let amt ← decodeExpr amtJ
    .ok ⟨d, a, amt⟩
  | _ => .error (.jsonType "supplyDelta")

def decodeTemplate (j : Json) : Except DecodeFailure TemplateEnc := do
  match j with
  | .obj fields =>
    checkObjectKeys fields.toList ["signature", "domain", "partyArity", "guard", "deltas", "supplyDeltas", "stateReads", "envReads", "writes"]
    let sigJ ← getField fields.toList "signature"
    let sigArr ← match sigJ with
      | .arr a => .ok a
      | _ => .error (.jsonType "signature")
    let signature ← sigArr.toList.mapM decodeUnit
    let dJ ← getField fields.toList "domain"
    let domain ← decodeDomain dJ
    let arityJ ← getField fields.toList "partyArity"
    let partyArity ← match arityJ with
      | .num n => .ok n.mantissa.toNat
      | _ => .error (.jsonType "partyArity")
    let guardJ ← getField fields.toList "guard"
    let guard ← decodeExpr guardJ
    let deltasJ ← getField fields.toList "deltas"
    let deltasArr ← match deltasJ with
      | .arr a => .ok a
      | _ => .error (.jsonType "deltas")
    let deltas ← deltasArr.toList.mapM decodeCellDelta
    let supJ ← getField fields.toList "supplyDeltas"
    let supArr ← match supJ with
      | .arr a => .ok a
      | _ => .error (.jsonType "supplyDeltas")
    let supplyDeltas ← supArr.toList.mapM decodeSupplyDelta
    let srJ ← getField fields.toList "stateReads"
    let srArr ← match srJ with
      | .arr a => .ok a
      | _ => .error (.jsonType "stateReads")
    let stateReads ← srArr.toList.mapM decodePackedCellRef
    let erJ ← getField fields.toList "envReads"
    let erArr ← match erJ with
      | .arr a => .ok a
      | _ => .error (.jsonType "envReads")
    let envReads ← erArr.toList.mapM decodeEnvRead
    let wJ ← getField fields.toList "writes"
    let wArr ← match wJ with
      | .arr a => .ok a
      | _ => .error (.jsonType "writes")
    let writes ← wArr.toList.mapM decodePackedCellRef
    .ok ⟨signature, domain, partyArity, guard, deltas, supplyDeltas, stateReads, envReads, writes⟩
  | _ => .error (.jsonType "template")

def decodeRegistryEntry (j : Json) : Except DecodeFailure RegistryEntryEnc := do
  match j with
  | .obj fields =>
    checkObjectKeys fields.toList ["id", "template"]
    let idJ ← getField fields.toList "id"
    let id ← match idJ with
      | .num n => .ok n.mantissa.toNat
      | _ => .error (.jsonType "registryId")
    let tJ ← getField fields.toList "template"
    let t ← decodeTemplate tJ
    .ok ⟨id, t⟩
  | _ => .error (.jsonType "registryEntry")

def decodeRegistry (j : Json) : Except DecodeFailure RegistryEnc := do
  match j with
  | .obj fields =>
    checkExactObjectKeys fields.toList ["entries"]
    let entJ ← getField fields.toList "entries"
    let arr ← match entJ with
      | .arr a => .ok a
      | _ => .error (.jsonType "registryEntries")
    let entries ← arr.toList.mapM decodeRegistryEntry
    let ids := entries.map (·.id)
    if ids.length != ids.eraseDups.length then
      throw (.uniqueness "registry")
    .ok ⟨entries⟩
  | _ => .error (.jsonType "registry")

def decodeRight (j : Json) : Except DecodeFailure RightEnc := do
  match j with
  | .obj fields =>
    let tagJ ← getField fields.toList "tag"
    match tagJ with
    | .str "invoke" =>
      checkExactObjectKeys fields.toList ["tag"]
      .ok .invoke
    | .str "debit" =>
      checkExactObjectKeys fields.toList ["tag", "cell"]
      let cJ ← getField fields.toList "cell"
      let c ← decodeCell cJ
      .ok (.debit c)
    | .str "changeSupply" =>
      checkExactObjectKeys fields.toList ["tag", "domain", "asset"]
      let dJ ← getField fields.toList "domain"
      let d ← decodeDomain dJ
      let aJ ← getField fields.toList "asset"
      let a ← decodeAsset aJ
      .ok (.changeSupply d a)
    | .str s => .error (.unknownIdentifier s)
    | _ => .error (.jsonType "rightTag")
  | _ => .error (.jsonType "right")

def decodeGrant (j : Json) : Except DecodeFailure GrantEnc := do
  match j with
  | .obj fields =>
    checkExactObjectKeys fields.toList ["holder", "domain", "operation", "right"]
    let hJ ← getField fields.toList "holder"
    let holder ← decodeParty hJ
    let dJ ← getField fields.toList "domain"
    let domain ← decodeDomain dJ
    let opJ ← getField fields.toList "operation"
    let operation ← match opJ with
      | .num n => .ok n.mantissa.toNat
      | _ => .error (.jsonType "grantOperation")
    let rJ ← getField fields.toList "right"
    let right ← decodeRight rJ
    .ok ⟨holder, domain, operation, right⟩
  | _ => .error (.jsonType "grant")

def decodeCapability (j : Json) : Except DecodeFailure CapabilityEnc := do
  match j with
  | .obj fields =>
    checkExactObjectKeys fields.toList ["holder", "domain", "operation", "right", "live"]
    let hJ ← getField fields.toList "holder"
    let holder ← decodeParty hJ
    let dJ ← getField fields.toList "domain"
    let domain ← decodeDomain dJ
    let opJ ← getField fields.toList "operation"
    let operation ← match opJ with
      | .num n => .ok n.mantissa.toNat
      | _ => .error (.jsonType "capabilityOperation")
    let rJ ← getField fields.toList "right"
    let right ← decodeRight rJ
    let lJ ← getField fields.toList "live"
    let live ← match lJ with
      | .bool b => .ok b
      | _ => .error (.jsonType "capabilityLive")
    .ok ⟨holder, domain, operation, right, live⟩
  | _ => .error (.jsonType "capability")

def decodeStore (j : Json) : Except DecodeFailure StoreEnc := do
  match j with
  | .obj fields =>
    checkExactObjectKeys fields.toList ["entries"]
    let entJ ← getField fields.toList "entries"
    let arr ← match entJ with
      | .arr a => .ok a
      | _ => .error (.jsonType "storeEntries")
    let entries ← arr.toList.mapM decodeCapability
    .ok ⟨entries⟩
  | _ => .error (.jsonType "store")

def decodeStateCell (j : Json) : Except DecodeFailure StateCellEnc := do
  match j with
  | .obj fields =>
    checkExactObjectKeys fields.toList ["domain", "party", "asset", "amount"]
    let dJ ← getField fields.toList "domain"
    let domain ← decodeDomain dJ
    let pJ ← getField fields.toList "party"
    let party ← decodeParty pJ
    let aJ ← getField fields.toList "asset"
    let asset ← decodeAsset aJ
    let amtJ ← getField fields.toList "amount"
    let amount ← decodeRat amtJ
    if amount.num < 0 then
      throw .stateNonneg
    .ok ⟨domain, party, asset, amount⟩
  | _ => .error (.jsonType "stateCell")

def decodeState (j : Json) : Except DecodeFailure StateEnc := do
  match j with
  | .obj fields =>
    checkExactObjectKeys fields.toList ["cells"]
    let cellsJ ← getField fields.toList "cells"
    let arr ← match cellsJ with
      | .arr a => .ok a
      | _ => .error (.jsonType "stateCells")
    let cells ← arr.toList.mapM decodeStateCell
    let keys := cells.map (fun c => (c.domain, c.party, c.asset))
    if keys.length != keys.eraseDups.length then
      throw (.uniqueness "stateCell")
    .ok ⟨cells⟩
  | _ => .error (.jsonType "state")

def decodeContext (j : Json) : Except DecodeFailure ContextEnc := do
  match j with
  | .obj fields =>
    checkExactObjectKeys fields.toList ["principal", "domain"]
    let pJ ← getField fields.toList "principal"
    let principal ← decodeParty pJ
    let dJ ← getField fields.toList "domain"
    let domain ← decodeDomain dJ
    .ok ⟨principal, domain⟩
  | _ => .error (.jsonType "context")

def decodeObservation (j : Json) : Except DecodeFailure ObservationEnc := do
  match j with
  | .obj fields =>
    checkObjectKeys fields.toList ["value", "timestamp"]
    let vJ ← getField fields.toList "value"
    let val ← decodePackedValue vJ
    let tJ ← getField fields.toList "timestamp"
    let ts ← match tJ with
      | .num n => .ok n.mantissa.toNat
      | _ => .error (.jsonType "timestamp")
    .ok ⟨val, ts⟩
  | _ => .error (.jsonType "observation")

def decodeEnvironmentEntry (j : Json) : Except DecodeFailure EnvironmentEntryEnc := do
  match j with
  | .obj fields =>
    checkObjectKeys fields.toList ["key", "observation"]
    let kJ ← getField fields.toList "key"
    let k ← decodeObservationKey kJ
    let oJ ← getField fields.toList "observation"
    let o ← decodeObservation oJ
    .ok ⟨k, o⟩
  | _ => .error (.jsonType "environmentEntry")

def decodeEnvironment (j : Json) : Except DecodeFailure EnvironmentEnc := do
  match j with
  | .obj fields =>
    checkObjectKeys fields.toList ["entries"]
    let entJ ← getField fields.toList "entries"
    let arr ← match entJ with
      | .arr a => .ok a
      | _ => .error (.jsonType "environmentEntries")
    let entries ← arr.toList.mapM decodeEnvironmentEntry
    .ok ⟨entries⟩
  | _ => .error (.jsonType "environment")

def decodeBoundary (j : Json) : Except DecodeFailure BoundaryEnc := do
  match j with
  | .obj fields =>
    checkObjectKeys fields.toList ["ctx", "env", "now"]
    let cJ ← getField fields.toList "ctx"
    let ctx ← decodeContext cJ
    let eJ ← getField fields.toList "env"
    let env ← decodeEnvironment eJ
    let nJ ← getField fields.toList "now"
    let now ← match nJ with
      | .num n => .ok n.mantissa.toNat
      | _ => .error (.jsonType "boundaryNow")
    .ok ⟨ctx, env, now⟩
  | _ => .error (.jsonType "boundary")

def decodeDomainAdmin (j : Json) : Except DecodeFailure DomainAdminEnc := do
  match j with
  | .obj fields =>
    checkObjectKeys fields.toList ["domain", "party"]
    let dJ ← getField fields.toList "domain"
    let domain ← decodeDomain dJ
    let pJ ← getField fields.toList "party"
    let party ← decodeParty pJ
    .ok ⟨domain, party⟩
  | _ => .error (.jsonType "domainAdmin")

def decodeInputPort (j : Json) : Except DecodeFailure InputPortEnc := do
  match j with
  | .obj fields =>
    checkObjectKeys fields.toList ["id", "unit"]
    let idJ ← getField fields.toList "id"
    let id ← match idJ with
      | .num n => .ok n.mantissa.toNat
      | _ => .error (.jsonType "inputPortId")
    let uJ ← getField fields.toList "unit"
    let unit ← decodeUnit uJ
    .ok ⟨id, unit⟩
  | _ => .error (.jsonType "inputPort")

def decodeOutputPort (j : Json) : Except DecodeFailure OutputPortEnc := do
  match j with
  | .obj fields =>
    checkObjectKeys fields.toList ["id", "cell"]
    let idJ ← getField fields.toList "id"
    let id ← match idJ with
      | .num n => .ok n.mantissa.toNat
      | _ => .error (.jsonType "outputPortId")
    let cJ ← getField fields.toList "cell"
    let cell ← decodeCell cJ
    .ok ⟨id, cell⟩
  | _ => .error (.jsonType "outputPort")

def decodeResourcePort (j : Json) : Except DecodeFailure ResourcePortEnc := do
  match j with
  | .obj fields =>
    checkObjectKeys fields.toList ["id", "cell", "writable"]
    let idJ ← getField fields.toList "id"
    let id ← match idJ with
      | .num n => .ok n.mantissa.toNat
      | _ => .error (.jsonType "resourcePortId")
    let cJ ← getField fields.toList "cell"
    let cell ← decodeCell cJ
    let wJ ← getField fields.toList "writable"
    let writable ← match wJ with
      | .bool b => .ok b
      | _ => .error (.jsonType "resourcePortWritable")
    .ok ⟨id, cell, writable⟩
  | _ => .error (.jsonType "resourcePort")

def decodeQualifiedPort (j : Json) : Except DecodeFailure QualifiedPortEnc := do
  match j with
  | .obj fields =>
    checkObjectKeys fields.toList ["component", "port"]
    let cJ ← getField fields.toList "component"
    let component ← match cJ with
      | .num n => .ok n.mantissa.toNat
      | _ => .error (.jsonType "qualifiedPortComponent")
    let pJ ← getField fields.toList "port"
    let port ← match pJ with
      | .num n => .ok n.mantissa.toNat
      | _ => .error (.jsonType "qualifiedPortPort")
    .ok ⟨component, port⟩
  | _ => .error (.jsonType "qualifiedPort")

def decodeResourceImport (j : Json) : Except DecodeFailure ResourceImportEnc := do
  match j with
  | .obj fields =>
    checkObjectKeys fields.toList ["source", "cell", "writable"]
    let sJ ← getField fields.toList "source"
    let source ← decodeQualifiedPort sJ
    let cJ ← getField fields.toList "cell"
    let cell ← decodeCell cJ
    let wJ ← getField fields.toList "writable"
    let writable ← match wJ with
      | .bool b => .ok b
      | _ => .error (.jsonType "resourceImportWritable")
    .ok ⟨source, cell, writable⟩
  | _ => .error (.jsonType "resourceImport")

def decodeOperationInterface (j : Json) : Except DecodeFailure OperationInterfaceEnc := do
  match j with
  | .obj fields =>
    checkObjectKeys fields.toList ["operation", "inputs", "outputs"]
    let opJ ← getField fields.toList "operation"
    let operation ← match opJ with
      | .num n => .ok n.mantissa.toNat
      | _ => .error (.jsonType "operationInterfaceOp")
    let inJ ← getField fields.toList "inputs"
    let inArr ← match inJ with
      | .arr a => .ok a
      | _ => .error (.jsonType "operationInterfaceInputs")
    let inputs ← inArr.toList.mapM decodeInputPort
    let outJ ← getField fields.toList "outputs"
    let outArr ← match outJ with
      | .arr a => .ok a
      | _ => .error (.jsonType "operationInterfaceOutputs")
    let outputs ← outArr.toList.mapM decodeOutputPort
    .ok ⟨operation, inputs, outputs⟩
  | _ => .error (.jsonType "operationInterface")

def decodeComponent (j : Json) : Except DecodeFailure ComponentEnc := do
  match j with
  | .obj fields =>
    checkObjectKeys fields.toList ["id", "privateCells", "exports", "imports", "operations"]
    let idJ ← getField fields.toList "id"
    let id ← match idJ with
      | .num n => .ok n.mantissa.toNat
      | _ => .error (.jsonType "componentId")
    let privJ ← getField fields.toList "privateCells"
    let privArr ← match privJ with
      | .arr a => .ok a
      | _ => .error (.jsonType "componentPrivateCells")
    let privateCells ← privArr.toList.mapM decodeCell
    let expJ ← getField fields.toList "exports"
    let expArr ← match expJ with
      | .arr a => .ok a
      | _ => .error (.jsonType "componentExports")
    let exports ← expArr.toList.mapM decodeResourcePort
    let impJ ← getField fields.toList "imports"
    let impArr ← match impJ with
      | .arr a => .ok a
      | _ => .error (.jsonType "componentImports")
    let imports ← impArr.toList.mapM decodeResourceImport
    let opsJ ← getField fields.toList "operations"
    let opsArr ← match opsJ with
      | .arr a => .ok a
      | _ => .error (.jsonType "componentOperations")
    let operations ← opsArr.toList.mapM decodeOperationInterface
    .ok ⟨id, privateCells, exports, imports, operations⟩
  | _ => .error (.jsonType "component")

def decodeConfig (j : Json) : Except DecodeFailure ConfigEnc := do
  match j with
  | .obj fields =>
    checkObjectKeys fields.toList ["registry", "domainAdmin", "catalog"]
    let rJ ← getField fields.toList "registry"
    let registry ← decodeRegistry rJ
    let daJ ← getField fields.toList "domainAdmin"
    let daArr ← match daJ with
      | .arr a => .ok a
      | _ => .error (.jsonType "domainAdminEntries")
    let domainAdmin ← daArr.toList.mapM decodeDomainAdmin
    let catJ ← getField fields.toList "catalog"
    let catArr ← match catJ with
      | .arr a => .ok a
      | _ => .error (.jsonType "catalog")
    let catalog ← catArr.toList.mapM decodeComponent
    .ok ⟨registry, domainAdmin, catalog⟩
  | _ => .error (.jsonType "config")

def decodeRequest (j : Json) : Except DecodeFailure RequestEnc := do
  match j with
  | .obj fields =>
    checkExactObjectKeys fields.toList ["operation", "parties", "arguments", "capabilityIds", "claimedActor"]
    let opJ ← getField fields.toList "operation"
    let operation ← match opJ with
      | .num n =>
        if n.mantissa < 0 then .error (.jsonType "operation")
        else .ok n.mantissa.toNat
      | _ => .error (.jsonType "operation")
    let pJ ← getField fields.toList "parties"
    let pArr ← match pJ with
      | .arr a => .ok a
      | _ => .error (.jsonType "parties")
    let parties ← pArr.toList.mapM decodeParty
    let aJ ← getField fields.toList "arguments"
    let aArr ← match aJ with
      | .arr a => .ok a
      | _ => .error (.jsonType "arguments")
    let arguments ← aArr.toList.mapM decodePackedValue
    let cJ ← getField fields.toList "capabilityIds"
    let cArr ← match cJ with
      | .arr a => .ok a
      | _ => .error (.jsonType "capabilityIds")
    let capabilityIds ← cArr.toList.mapM fun x => match x with
      | .num n => .ok n.mantissa.toNat
      | _ => .error (.jsonType "capabilityId")
    let caJ ← getField fields.toList "claimedActor"
    let claimedActor ← match caJ with
      | .null => .ok none
      | val => (decodeParty val).map some
    .ok ⟨operation, parties, arguments, capabilityIds, claimedActor⟩
  | _ => .error (.jsonType "request")

def decodeInputSource (j : Json) : Except DecodeFailure InputSourceEnc := do
  match j with
  | .obj fields =>
    let tagJ ← getField fields.toList "tag"
    match tagJ with
    | .str "literal" =>
      checkExactObjectKeys fields.toList ["tag", "value"]
      let vJ ← getField fields.toList "value"
      let val ← decodePackedValue vJ
      .ok (.literal val)
    | .str "priorOutput" =>
      checkExactObjectKeys fields.toList ["tag", "step", "port"]
      let sJ ← getField fields.toList "step"
      let step ← match sJ with
        | .num n => .ok n.mantissa.toNat
        | _ => .error (.jsonType "priorOutputStep")
      let pJ ← getField fields.toList "port"
      let port ← decodeQualifiedPort pJ
      .ok (.priorOutput step port)
    | .str s => .error (.unknownIdentifier s)
    | _ => .error (.jsonType "inputSourceTag")
  | _ => .error (.jsonType "inputSource")

def decodeInvocation (j : Json) : Except DecodeFailure InvocationEnc := do
  match j with
  | .obj fields =>
    checkExactObjectKeys fields.toList ["component", "operation", "parties", "inputs", "capabilityIds", "claimedActor"]
    let cJ ← getField fields.toList "component"
    let component ← match cJ with
      | .num n => .ok n.mantissa.toNat
      | _ => .error (.jsonType "invocationComponent")
    let opJ ← getField fields.toList "operation"
    let operation ← match opJ with
      | .num n => .ok n.mantissa.toNat
      | _ => .error (.jsonType "invocationOperation")
    let pJ ← getField fields.toList "parties"
    let pArr ← match pJ with
      | .arr a => .ok a
      | _ => .error (.jsonType "invocationParties")
    let parties ← pArr.toList.mapM decodeParty
    let inJ ← getField fields.toList "inputs"
    let inArr ← match inJ with
      | .arr a => .ok a
      | _ => .error (.jsonType "invocationInputs")
    let inputs ← inArr.toList.mapM decodeInputSource
    let capJ ← getField fields.toList "capabilityIds"
    let capArr ← match capJ with
      | .arr a => .ok a
      | _ => .error (.jsonType "invocationCapabilityIds")
    let capabilityIds ← capArr.toList.mapM fun x => match x with
      | .num n => .ok n.mantissa.toNat
      | _ => .error (.jsonType "capabilityId")
    let caJ ← getField fields.toList "claimedActor"
    let claimedActor ← match caJ with
      | .null => .ok none
      | val => (decodeParty val).map some
    .ok ⟨component, operation, parties, inputs, capabilityIds, claimedActor⟩
  | _ => .error (.jsonType "invocation")

def decodeInvoke (j : Json) : Except DecodeFailure StepEnc := do
  match j with
  | .obj fields =>
    let invJ ← getField fields.toList "invocation"
    let inv ← decodeInvocation invJ
    .ok (.invoke inv)
  | _ => .error (.jsonType "step")

def decodeStep (j : Json) : Except DecodeFailure StepEnc := do
  let rest := j
  let _ := rest
  match j with
  | .obj fields =>
    let tagJ ← getField fields.toList "tag"
    let tag ← match tagJ with
      | .str s => .ok s
      | _ => .error (.jsonType "stepTag")
    match tag with
    | "treeJoin" | "naryAdvance" => .error (.unsupportedForm _)
    | "invoke" =>
      checkObjectKeys fields.toList ["tag", "invocation"]
      let invJ ← getField fields.toList "invocation"
      let inv ← decodeInvocation invJ
      .ok (.invoke inv)
    | "issue" =>
      checkObjectKeys fields.toList ["tag", "grant"]
      let gJ ← getField fields.toList "grant"
      let grant ← decodeGrant gJ
      .ok (.issue grant)
    | "revoke" =>
      checkObjectKeys fields.toList ["tag", "id"]
      let idJ ← getField fields.toList "id"
      let id ← match idJ with
        | .num n => .ok n.mantissa.toNat
        | _ => .error (.jsonType "revokeId")
      .ok (.revoke id)
    | s => .error (.unknownIdentifier s)
  | _ => .error (.jsonType "step")

def decodeWorld (j : Json) : Except DecodeFailure WorldEnc := do
  match j with
  | .obj fields =>
    checkObjectKeys fields.toList ["state", "capabilities"]
    let sJ ← getField fields.toList "state"
    let state ← decodeState sJ
    let cJ ← getField fields.toList "capabilities"
    let caps ← decodeStore cJ
    .ok ⟨state, caps⟩
  | _ => .error (.jsonType "world")

def decodeOutputObservation (j : Json) : Except DecodeFailure OutputObservationEnc := do
  match j with
  | .obj fields =>
    checkObjectKeys fields.toList ["step", "port", "value"]
    let sJ ← getField fields.toList "step"
    let step ← match sJ with
      | .num n => .ok n.mantissa.toNat
      | _ => .error (.jsonType "outputObservationStep")
    let pJ ← getField fields.toList "port"
    let port ← decodeQualifiedPort pJ
    let vJ ← getField fields.toList "value"
    let val ← decodePackedValue vJ
    .ok ⟨step, port, val⟩
  | _ => .error (.jsonType "outputObservation")

def decodeSourcePin (j : Json) : Except DecodeFailure SourcePinEnc := do
  match j with
  | .obj fields =>
    checkObjectKeys fields.toList ["git", "lean_toolchain", "mathlib_rev", "checker_candidate", "compiler_record", "audit_record"]
    let gitJ ← getField fields.toList "git"
    let git ← match gitJ with | .str s => .ok s | _ => .error (.jsonType "git")
    let ltJ ← getField fields.toList "lean_toolchain"
    let lt ← match ltJ with | .str s => .ok s | _ => .error (.jsonType "lean_toolchain")
    let mlJ ← getField fields.toList "mathlib_rev"
    let ml ← match mlJ with | .str s => .ok s | _ => .error (.jsonType "mathlib_rev")
    let ccJ ← getField fields.toList "checker_candidate"
    let cc ← match ccJ with | .str s => .ok s | _ => .error (.jsonType "checker_candidate")
    let crJ := getField? fields.toList "compiler_record"
    let cr := match crJ with | some (.str s) => some s | _ => none
    let arJ := getField? fields.toList "audit_record"
    let ar := match arJ with | some (.str s) => some s | _ => none
    .ok ⟨git, lt, ml, cc, cr, ar⟩
  | _ => .error (.jsonType "source_pin")

def decodeTypesEnum (j : Json) : Except DecodeFailure TypesEnumEnc := do
  match j with
  | .obj fields =>
    checkExactObjectKeys fields.toList ["parties", "assets", "domains"]
    let pJ ← getField fields.toList "parties"
    let pArr ← match pJ with | .arr a => .ok a | _ => .error (.jsonType "parties")
    let parties ← pArr.toList.mapM decodeParty
    let aJ ← getField fields.toList "assets"
    let aArr ← match aJ with | .arr a => .ok a | _ => .error (.jsonType "assets")
    let assets ← aArr.toList.mapM decodeAsset
    let dJ ← getField fields.toList "domains"
    let dArr ← match dJ with | .arr a => .ok a | _ => .error (.jsonType "domains")
    let domains ← dArr.toList.mapM decodeDomain
    .ok ⟨parties, assets, domains⟩
  | _ => .error (.jsonType "types")

def decodeLibraryRef (j : Json) : Except DecodeFailure LibraryRefEnc := do
  match j with
  | .str s => .ok ⟨s, none⟩
  | .obj fields =>
    checkObjectKeys fields.toList ["theorem", "module"]
    let tJ ← getField fields.toList "theorem"
    let t ← match tJ with | .str s => .ok s | _ => .error (.jsonType "theorem")
    let mJ := getField? fields.toList "module"
    let m := match mJ with | some (.str s) => some s | _ => none
    .ok ⟨t, m⟩
  | _ => .error (.jsonType "libraryRef")

def decodeSourceMap (smJ : Json) : Except DecodeFailure (List (String × String)) := do
  match smJ with
  | .obj m =>
    let entries := m.toList
    let keys := entries.map Prod.fst
    if !isSortedStrictAscending keys then
      throw .noncanonicalWhitespace
    entries.mapM (fun (k, v) => match v with | .str s => .ok (k, s) | _ => .error (.jsonType "source_map"))
  | _ => .error (.jsonType "source_map")

def decodeClaimedNextState (cnsJ : Json) : Except DecodeFailure (Option WorldEnc) := do
  match cnsJ with
  | .null => .ok none
  | val => (decodeWorld val).map some

def decodeEnvelope (fields : List (String × Json)) : Except DecodeFailure EnvelopeEnc := do
  let verJ ← match getField? fields "schema_version" with
    | some v => .ok v
    | none => .error .schemaVersion
  let schema_version ← match verJ with
    | .num n =>
      if n.mantissa != 1 then .error .schemaVersion
      else .ok 1
    | _ => .error .schemaVersion
  checkExactObjectKeys fields [
    "schema_version", "mode", "source_pin", "audit_roots", "types", "assumptions",
    "invariants", "libraries", "source_map", "payload", "claimed_judgments",
    "claimed_next_state", "require_library_discharge", "require_invariant_discharge"
  ]
  let modeJ ← getField fields "mode"
  let mode ← match modeJ with | .str s => .ok s | _ => .error (.jsonType "mode")
  let pinJ ← getField fields "source_pin"
  let source_pin ← decodeSourcePin pinJ
  let rootsJ ← getField fields "audit_roots"
  let rootsArr ← match rootsJ with | .arr a => .ok a | _ => .error (.jsonType "audit_roots")
  let audit_roots ← rootsArr.toList.mapM fun x => match x with | .str s => .ok s | _ => .error (.jsonType "root")
  let typesJ ← getField fields "types"
  let types ← decodeTypesEnum typesJ
  let asmJ ← getField fields "assumptions"
  let asmArr ← match asmJ with | .arr a => .ok a | _ => .error (.jsonType "assumptions")
  let assumptions ← asmArr.toList.mapM fun x => match x with | .str s => .ok s | _ => .error (.jsonType "assumption")
  let invJ ← getField fields "invariants"
  let invariants ← match invJ with
    | .arr a => a.toList.mapM fun x => match x with | .str s => .ok s | _ => .error (.jsonType "invariant")
    | _ => .error (.jsonType "invariants")
  let libJ ← getField fields "libraries"
  let libraries ← match libJ with
    | .arr a => a.toList.mapM decodeLibraryRef
    | _ => .error (.jsonType "libraries")
  let smJ ← getField fields "source_map"
  let source_map ← decodeSourceMap smJ
  let cjJ ← getField fields "claimed_judgments"
  let claimed_judgments ← match cjJ with
    | .arr a => a.toList.mapM fun x => match x with | .str s => .ok s | _ => .error (.jsonType "claimedJudgment")
    | _ => .error (.jsonType "claimed_judgments")
  let cnsJ ← getField fields "claimed_next_state"
  let claimed_next_state ← decodeClaimedNextState cnsJ
  let reqLibJ ← getField fields "require_library_discharge"
  let require_library_discharge ← match reqLibJ with
    | .bool b => .ok b
    | _ => .error (.jsonType "require_library_discharge")
  let reqInvJ ← getField fields "require_invariant_discharge"
  let require_invariant_discharge ← match reqInvJ with
    | .bool b => .ok b
    | _ => .error (.jsonType "require_invariant_discharge")
  .ok ⟨schema_version, mode, source_pin, audit_roots, types, assumptions, invariants,
       libraries, source_map, claimed_judgments, claimed_next_state,
       require_library_discharge, require_invariant_discharge⟩

def decodeTypedExecutePayload (j : Json) : Except DecodeFailure TypedExecutePayloadEnc := do
  match j with
  | .obj fields =>
    checkExactObjectKeys fields.toList ["registry", "store", "ctx", "env", "now", "request", "state"]
    let rJ ← getField fields.toList "registry"
    let registry ← decodeRegistry rJ
    let sJ ← getField fields.toList "store"
    let store ← decodeStore sJ
    let cJ ← getField fields.toList "ctx"
    let ctx ← decodeContext cJ
    let eJ ← getField fields.toList "env"
    let env ← decodeEnvironment eJ
    let nJ ← getField fields.toList "now"
    let now ← match nJ with
      | .num n => .ok n.mantissa.toNat
      | _ => .error (.jsonType "now")
    let reqJ ← getField fields.toList "request"
    let request ← decodeRequest reqJ
    let stJ ← getField fields.toList "state"
    let state ← decodeState stJ
    .ok ⟨registry, store, ctx, env, now, request, state⟩
  | _ => .error (.jsonType "typedPayload")

def decodeCompositionStepPayload (j : Json) : Except DecodeFailure CompositionStepPayloadEnc := do
  match j with
  | .obj fields =>
    checkObjectKeys fields.toList ["config", "boundary", "index", "history", "step", "pre"]
    let cJ ← getField fields.toList "config"
    let config ← decodeConfig cJ
    let bJ ← getField fields.toList "boundary"
    let boundary ← decodeBoundary bJ
    let iJ ← getField fields.toList "index"
    let index ← match iJ with
      | .num n => .ok n.mantissa.toNat
      | _ => .error (.jsonType "index")
    let hJ ← getField fields.toList "history"
    let hArr ← match hJ with
      | .arr a => .ok a
      | _ => .error (.jsonType "history")
    let history ← hArr.toList.mapM decodeOutputObservation
    let stepJ ← getField fields.toList "step"
    let step ← decodeStep stepJ
    let preJ ← getField fields.toList "pre"
    let pre ← decodeWorld preJ
    .ok ⟨config, boundary, index, history, step, pre⟩
  | _ => .error (.jsonType "compositionStepPayload")

def decodeCompositionRunPayload (j : Json) : Except DecodeFailure CompositionRunPayloadEnc := do
  match j with
  | .obj fields =>
    checkObjectKeys fields.toList ["config", "boundaries", "world", "steps"]
    let cJ ← getField fields.toList "config"
    let config ← decodeConfig cJ
    let bJ ← getField fields.toList "boundaries"
    let bArr ← match bJ with
      | .arr a => .ok a
      | _ => .error (.jsonType "boundaries")
    let boundaries ← bArr.toList.mapM decodeBoundary
    let wJ ← getField fields.toList "world"
    let world ← decodeWorld wJ
    let sJ ← getField fields.toList "steps"
    let sArr ← match sJ with
      | .arr a => .ok a
      | _ => .error (.jsonType "steps")
    let steps ← sArr.toList.mapM decodeStep
    .ok ⟨config, boundaries, world, steps⟩
  | _ => .error (.jsonType "compositionRunPayload")

def decodeAuditPayload (env : EnvelopeEnc) (j : Json) (hasEnv : Bool := true) : Except DecodeFailure DecodedAudit := do
  match j with
  | .obj fields =>
    checkObjectKeys fields.toList ["commands", "imported_theorems_min", "forbidden_claimed_roots", "imported_theorems", "prefix"]
    let cmds ← match fields.toList.find? (fun (k, _) => k == "commands") with
      | some (_, .arr a) =>
        a.toList.mapM (fun x => match x with | .str s => .ok s | _ => .error (.jsonType "commandString"))
      | some _ => .error (.jsonType "commandsArray")
      | none => .ok []
    let minThm ← match fields.toList.find? (fun (k, _) => k == "imported_theorems_min") with
      | some (_, .num n) => .ok (some n.mantissa.toNat)
      | some _ => .error (.jsonType "imported_theorems_min")
      | none => .ok none
    let forbRoots ← match fields.toList.find? (fun (k, _) => k == "forbidden_claimed_roots") with
      | some (_, .arr a) =>
        (a.toList.mapM (fun (x : Lean.Json) => match x with | .str s => Except.ok s | _ => Except.error (DecodeFailure.jsonType "forbiddenRootString"))).map some
      | some _ => .error (.jsonType "forbiddenRootsArray")
      | none => .ok none
    let impThm ← match fields.toList.find? (fun (k, _) => k == "imported_theorems") with
      | some (_, .num n) => .ok (some n.mantissa.toNat)
      | some _ => .error (.jsonType "imported_theorems")
      | none => .ok none
    let pfx ← match fields.toList.find? (fun (k, _) => k == "prefix") with
      | some (_, .str s) => .ok (some s)
      | some _ => .error (.jsonType "prefix")
      | none => .ok none
    .ok ⟨env, hasEnv, cmds, minThm, forbRoots, impThm, pfx⟩
  | _ => .error .notJsonObject

def decodeEvaluatedDelta (j : Json) : Except DecodeFailure (CellEnc × RatEnc) := do
  match j with
  | .obj fields =>
    checkObjectKeys fields.toList ["cell", "amount"]
    let cJ ← getField fields.toList "cell"
    let c ← decodeCell cJ
    let aJ ← getField fields.toList "amount"
    let a ← decodeRat aJ
    .ok (c, a)
  | _ => .error (.jsonType "evaluatedDelta")

def decodeEvaluatedSupply (j : Json) : Except DecodeFailure ((Domain × Asset) × RatEnc) := do
  match j with
  | .obj fields =>
    checkObjectKeys fields.toList ["domain", "asset", "amount"]
    let dJ ← getField fields.toList "domain"
    let d ← decodeDomain dJ
    let asJ ← getField fields.toList "asset"
    let a ← decodeAsset asJ
    let amJ ← getField fields.toList "amount"
    let am ← decodeRat amJ
    .ok ((d, a), am)
  | _ => .error (.jsonType "evaluatedSupply")

def decodeEvaluated (j : Json) : Except DecodeFailure EvaluatedEnc := do
  match j with
  | .obj fields =>
    checkObjectKeys fields.toList ["guard", "deltas", "supplies", "requiredStateReads", "requiredEnvReads", "declaredStateReads", "declaredEnvReads", "writes"]
    let gJ ← getField fields.toList "guard"
    let guard ← match gJ with | .bool b => .ok b | _ => .error (.jsonType "evaluatedGuard")
    let dJ ← getField fields.toList "deltas"
    let deltas ← match dJ with | .arr a => a.toList.mapM decodeEvaluatedDelta | _ => .error (.jsonType "evaluatedDeltas")
    let sJ ← getField fields.toList "supplies"
    let supplies ← match sJ with | .arr a => a.toList.mapM decodeEvaluatedSupply | _ => .error (.jsonType "evaluatedSupplies")
    let rsrJ ← getField fields.toList "requiredStateReads"
    let rsr ← match rsrJ with | .arr a => a.toList.mapM decodeCell | _ => .error (.jsonType "evaluatedRequiredStateReads")
    let rerJ ← getField fields.toList "requiredEnvReads"
    let rer ← match rerJ with | .arr a => a.toList.mapM decodeObservationKey | _ => .error (.jsonType "evaluatedRequiredEnvReads")
    let dsrJ ← getField fields.toList "declaredStateReads"
    let dsr ← match dsrJ with | .arr a => a.toList.mapM decodeCell | _ => .error (.jsonType "evaluatedDeclaredStateReads")
    let derJ ← getField fields.toList "declaredEnvReads"
    let der ← match derJ with | .arr a => a.toList.mapM decodeObservationKey | _ => .error (.jsonType "evaluatedDeclaredEnvReads")
    let wJ ← getField fields.toList "writes"
    let writes ← match wJ with | .arr a => a.toList.mapM decodeCell | _ => .error (.jsonType "evaluatedWrites")
    .ok ⟨guard, deltas, supplies, rsr, rer, dsr, der, writes⟩
  | _ => .error (.jsonType "evaluated")

def decodeReceipt (j : Json) : Except DecodeFailure ReceiptEnc := do
  match j with
  | .obj fields =>
    let tagJ ← getField fields.toList "tag"
    match tagJ with
    | .str "invoked" =>
      checkObjectKeys fields.toList ["tag", "request", "evaluated"]
      let reqJ ← getField fields.toList "request"
      let req ← decodeRequest reqJ
      let evalJ ← getField fields.toList "evaluated"
      let eval ← decodeEvaluated evalJ
      .ok (.invoked req eval)
    | .str "issued" =>
      checkObjectKeys fields.toList ["tag", "id"]
      let idJ ← getField fields.toList "id"
      let id ← match idJ with | .num n => .ok n.mantissa.toNat | _ => .error (.jsonType "receiptId")
      .ok (.issued id)
    | .str "revoked" =>
      checkObjectKeys fields.toList ["tag", "id"]
      let idJ ← getField fields.toList "id"
      let id ← match idJ with | .num n => .ok n.mantissa.toNat | _ => .error (.jsonType "receiptId")
      .ok (.revoked id)
    | _ => .error (.jsonType "receiptTag")
  | _ => .error (.jsonType "receipt")

def decodeFailurePath (j : Json) : Except DecodeFailure FailurePath := do
  match j with
  | .obj fields =>
    let cJ ← getField fields.toList "class"
    let ctorJ ← getField fields.toList "ctor"
    let cls ← match cJ with
      | .str "kernel" => .ok FailureClass.kernel
      | .str "configuration" => .ok FailureClass.configuration
      | .str "internalReceipt" => .ok FailureClass.internalReceipt
      | .str "staleSource" => .ok FailureClass.staleSource
      | .str "observationMismatch" => .ok FailureClass.observationMismatch
      | .str "incompleteObligation" => .ok FailureClass.incompleteObligation
      | _ => .error (.jsonType "failureClass")
    let ctor ← match ctorJ with
      | .str s => .ok s
      | _ => .error (.jsonType "failureCtor")
    let pld ← match fields.toList.find? (fun (k, _) => k == "payload") with
      | some (_, .str s) => .ok (some s)
      | _ => .ok none
    .ok ⟨cls, ctor, pld⟩
  | _ => .error (.jsonType "failurePath")

def decodeJudgmentResult (j : Json) : Except DecodeFailure JudgmentResult := do
  match j with
  | .obj fields =>
    let famJ ← getField fields.toList "family"
    let outJ ← getField fields.toList "outcome"
    let clmJ ← getField fields.toList "claimed"
    let mchJ ← getField fields.toList "match"
    let fam ← match famJ with | .str s => .ok s | _ => .error (.jsonType "judgmentFamily")
    let out ← match outJ with
      | .str "true" => .ok JudgmentOutcome.«true»
      | .str "false" => .ok JudgmentOutcome.«false»
      | .str "not_reached" => .ok JudgmentOutcome.notReached
      | .str "not_applicable" => .ok JudgmentOutcome.notApplicable
      | _ => .error (.jsonType "judgmentOutcome")
    let clm ← match clmJ with | .bool b => .ok b | _ => .error (.jsonType "judgmentClaimed")
    let mch ← match mchJ with | .bool b => .ok b | _ => .error (.jsonType "judgmentMatch")
    .ok ⟨fam, out, clm, mch⟩
  | _ => .error (.jsonType "judgmentResult")

def decodeReport (j : Json) : Except DecodeFailure Report := do
  match j with
  | .obj fields =>
    let stJ ← getField fields.toList "status"
    let st ← match stJ with
      | .str "accepted" => .ok ReportStatus.accepted
      | .str "refused" => .ok ReportStatus.refused
      | .str "incomplete" => .ok ReportStatus.incomplete
      | _ => .error (.jsonType "reportStatus")
    let fail ← match fields.toList.find? (fun (k, _) => k == "failure") with
      | some (_, .null) => .ok none
      | some (_, obj@(.obj _)) => decodeFailurePath obj >>= (fun fp => .ok (some fp))
      | some _ => .error (.jsonType "reportFailure")
      | none => .ok none
    let jgArr ← match fields.toList.find? (fun (k, _) => k == "judgments") with
      | some (_, .arr a) => a.toList.mapM decodeJudgmentResult
      | _ => .ok []
    let wJ ← getField fields.toList "world"
    let w ← decodeWorld wJ
    let rc ← match fields.toList.find? (fun (k, _) => k == "receipt") with
      | some (_, .null) => .ok none
      | some (_, obj@(.obj _)) => decodeReceipt obj >>= (fun r => .ok (some r))
      | some _ => .error (.jsonType "reportReceipt")
      | none => .ok none
    let outs ← match fields.toList.find? (fun (k, _) => k == "outputs") with
      | some (_, .arr a) => a.toList.mapM decodeOutputObservation
      | _ => .ok []
    let nextIdx ← match fields.toList.find? (fun (k, _) => k == "nextIndex") with
      | some (_, .num n) => .ok n.mantissa.toNat
      | _ => .ok 0
    let asms ← match fields.toList.find? (fun (k, _) => k == "assumptions") with
      | some (_, .obj fs) => .ok (fs.toList.map (fun (k, v) => (k, match v with | .str s => s | _ => "")))
      | _ => .ok []
    let ost ← match fields.toList.find? (fun (k, _) => k == "outstanding") with
      | some (_, .arr a) => a.toList.mapM (fun x => match x with | .str s => .ok s | _ => .error (.jsonType "outstandingString"))
      | _ => .ok []
    let spJ ← getField fields.toList "source_pin"
    let sp ← decodeSourcePin spJ
    let ar ← match fields.toList.find? (fun (k, _) => k == "audit_roots") with
      | some (_, .arr a) => a.toList.mapM (fun x => match x with | .str s => .ok s | _ => .error (.jsonType "auditRootsString"))
      | _ => .ok []
    let unsupp ← match fields.toList.find? (fun (k, _) => k == "unsupported") with
      | some (_, .str s) => .ok (some s)
      | _ => .ok none
    .ok ⟨st, fail, jgArr, w, rc, outs, [], nextIdx, none, asms, ost, sp, ar, unsupp⟩
  | _ => .error .notJsonObject

def decodeDecodedIR (j : Json) (raw : String) : Except DecodeFailure DecodedIR := do
  match j with
  | .obj fields =>
    if !fields.toList.any (fun (k, _) => k == "schema_version") &&
       fields.toList.any (fun (k, _) => k == "commands" || k == "forbidden_claimed_roots" || k == "imported_theorems" || k == "prefix") then
      let defaultEnv : EnvelopeEnc := {
        schema_version := 1,
        mode := "audit",
        source_pin := {
          git := "a12b7cac05a818cc8d35c2ca440b7170a2807e92",
          lean_toolchain := "leanprover/lean4:v4.33.0-rc2",
          mathlib_rev := "51e6992efd06126df61a496bebf8f49482a4e129",
          checker_candidate := "unimplemented",
          compiler_record := none,
          audit_record := none
        },
        audit_roots := ["DefiKernel.Certificates", "DefiKernel.Typed", "DefiKernel.Composition"],
        types := { parties := [], assets := [], domains := [] },
        assumptions := [],
        invariants := [],
        libraries := [],
        source_map := [],
        claimed_judgments := [],
        claimed_next_state := none,
        require_library_discharge := false,
        require_invariant_discharge := false
      }
      let payload ← decodeAuditPayload defaultEnv j false
      .ok (.audit payload)
    else
      let env ← decodeEnvelope fields.toList
      let payloadJ ← getField fields.toList "payload"
      match env.mode with
      | "typed-execute" =>
        let payload ← decodeTypedExecutePayload payloadJ
        .ok (.execution (.typed env payload))
      | "composition-step" =>
        let payload ← decodeCompositionStepPayload payloadJ
        .ok (.execution (.step env payload))
      | "composition-run" =>
        let payload ← decodeCompositionRunPayload payloadJ
        .ok (.execution (.run env payload))
      | "codec" =>
        .ok (.codec ⟨some env, raw⟩)
      | "audit" =>
        let payload ← decodeAuditPayload env payloadJ true
        .ok (.audit payload)
      | s => .error (.unknownIdentifier s)
  | _ => .error .notJsonObject

def encodeModule (ir : DecodedIR) : ByteArray :=
  encodeModuleCanonical ir

/-- Primary byte-level decode entrypoint with lexical security and canonical admission checks. -/
def decodeBytes (bytes : ByteArray) : Except DecodeFailure DecodedIR := do
  scanLexical bytes
  let some str := String.fromUTF8? bytes
    | throw (.jsonType "utf8")
  let j ← match parseCanonicalJson str with
    | .error (.resourceLimit r) => throw (.resourceLimit r)
    | .error _ => throw .notJsonObject
    | .ok j => pure j
  let ir ← decodeDecodedIR j str
  if _h : encodeModule ir = bytes then
    return ir
  else
    throw .noncanonicalWhitespace

end DefiKernel.Certificates



/-!
Trusted dependency records for certificate source identity.

Envelope `source_pin` / `audit_roots` strings are untrusted caller data.
These records are compiled into the checker from delivered path+sha256
bindings and MUST NOT be read back from the envelope.
-/
namespace DefiKernel.Certificates.TrustedHost

/-- Delivered source D. Distinct from any envelope string until compared. -/
def gitSha : String := "a12b7cac05a818cc8d35c2ca440b7170a2807e92"

def leanToolchain : String := "leanprover/lean4:v4.33.0-rc2"

def mathlibRev : String := "51e6992efd06126df61a496bebf8f49482a4e129"

/-- grammar.json SHA-256. Schema identity is this hash, not envelope schema_version alone. -/
def grammarSha256 : String :=
  "908ff747b2f3c3fba50dd4ae7a02486cea8204a4f471457c51ddea30802edfff"

def schemaSha256 : String :=
  "99c58c21022006faad3475bc01db3394d98c9f6237c1df3693594c77802e7000"

structure DependencyRecord where
  path : String
  sha256 : String
  deriving DecidableEq, Repr

/-- Path+sha256 identity of delivered Typed/Composition/pin files. -/
def deliveredDependencies : List DependencyRecord :=
  [ ⟨"lean/DefiKernel/Typed/Types.lean",
      "5f2b7d30028c7445f5523b9a06cb1fb21f36fc28e38d50844d4270177f601f82"⟩
  , ⟨"lean/DefiKernel/Typed/Expr.lean",
      "1c4e0c2e38dd6beaed332bfccbda6d256b3f57d27cb7a0db370fb1a9019fbfed"⟩
  , ⟨"lean/DefiKernel/Typed/Authority.lean",
      "dfd2c140f511144e9928ed4f5ed1db9ee2b56cada1342500d2e60c33ef9a0cdb"⟩
  , ⟨"lean/DefiKernel/Typed/Transition.lean",
      "73f264636236219e45720a531209f8c7ed8f5ee3f615fa34d58bc5596c4499d2"⟩
  , ⟨"lean/DefiKernel/Composition/Interfaces.lean",
      "4f2a32854b298ca5399eb0aa38bb16e892312517ae4f3a0e49e4bfead369f5fe"⟩
  , ⟨"lean/DefiKernel/Composition/Execution.lean",
      "34ac2f2185434d2fc8931b10f3688d909cc984e4e24e16e26c2d115b6fe13602"⟩
  , ⟨"lean/DefiKernel/Composition/Contracts.lean",
      "d23885a9bc2ed695ef8569b97c47c9f07449a5a6aa98bc86c8797dce648fc46c"⟩
  , ⟨"lean/DefiKernel/Composition/Sequence.lean",
      "32bcdbbce182bf9d494dab76a8a114f9e238f92564ef86e7cab2cd123bc0b729"⟩
  , ⟨"lean/lean-toolchain",
      "0d3c76ccd8772d8bcbe207241421a760312b71a6aa82f84194391fdf5cb026d6"⟩
  , ⟨"lean/lakefile.toml",
      "cd72f6c9a5deb6f3724608b2ee074dfcc92e21b4956088b8596abbd6a6ddfaa8"⟩
  , ⟨"lean/lake-manifest.json",
      "8a6ceb0b073bcb3e437c3258aedf250b38da4dec0f696db6b2717bd987c43002"⟩
  ]

/-- Encode a trusted record as `path:sha256`. This form is not an envelope git string. -/
def recordToken (r : DependencyRecord) : String := r.path ++ ":" ++ r.sha256

def compilerRecords : List String := deliveredDependencies.map recordToken

def auditRecords : List String :=
  [ "DefiKernel.Certificates:" ++ grammarSha256
  , "DefiKernel.Typed:" ++ "5f2b7d30028c7445f5523b9a06cb1fb21f36fc28e38d50844d4270177f601f82"
  , "DefiKernel.Composition:" ++ "4f2a32854b298ca5399eb0aa38bb16e892312517ae4f3a0e49e4bfead369f5fe"
  ]

/-- Envelope compiler/audit strings must match a path+sha256 record, never git D. -/
def recordStringAdmissible (s : String) (allowed : List String) : Bool :=
  allowed.contains s && s ≠ gitSha

def recordsMatch (pin : SourcePinEnc) : Bool :=
  pin.lean_toolchain == leanToolchain &&
  pin.mathlib_rev == mathlibRev &&
  (match pin.compiler_record with
    | none => true
    | some s => recordStringAdmissible s compilerRecords) &&
  (match pin.audit_record with
    | none => true
    | some s => recordStringAdmissible s auditRecords)

/-- Git inequality is sufficient for staleSource.git; other pin fields are separate. -/
def gitMatches (pin : SourcePinEnc) : Bool :=
  pin.git == gitSha

end DefiKernel.Certificates.TrustedHost


/-! Checked unsigned values. Width zero contains only zero. -/
namespace DefiKernel.Arithmetic

structure Word (w : Nat) where
  value : Nat
  bound : value < 2^w
  deriving DecidableEq, Repr

inductive Failure
  | inputOverflow | addOverflow | subUnderflow | mulOverflow
  | divisionByZero | quotientOverflow | invalidRate
  | nonPositiveScale | negativeQuantity | nonIntegralQuantity
  deriving DecidableEq, Repr

inductive Rounding | down | up
  deriving DecidableEq, Repr

variable {w : Nat}

def Word.checked (error : Failure) (n : Nat) : Except Failure (Word w) :=
  if h : n < 2^w then .ok ⟨n, h⟩ else .error error

def ofNat (w n : Nat) : Except Failure (Word w) :=
  Word.checked .inputOverflow n

-- BEGIN PROOFS

@[ext] theorem Word.ext {a b : Word w} (h : a.value = b.value) : a = b := by
  cases a; cases b; cases h; rfl

@[simp] theorem Word.checked_ok_iff (error : Failure) (n : Nat) (q : Word w) :
    Word.checked error n = .ok q ↔ n = q.value := by
  unfold Word.checked
  split
  · simp only [Except.ok.injEq]
    exact ⟨fun h ↦ congrArg Word.value h, fun h ↦ Word.ext h⟩
  · rename_i h
    constructor
    · intro eq; cases eq
    · intro eq
      exact False.elim (h (eq ▸ q.bound))

@[simp] theorem Word.checked_error_iff (error failure : Failure) (n : Nat) :
    Word.checked (w := w) error n = .error failure ↔ 2^w ≤ n ∧ error = failure := by
  unfold Word.checked
  split
  · rename_i h
    simp [Nat.not_le_of_lt h]
  · rename_i h
    simp [Nat.le_of_not_gt h]

theorem Word.checked_exists_iff (error : Failure) (n : Nat) :
    (∃ q : Word w, Word.checked error n = .ok q) ↔ n < 2^w := by
  simp only [Word.checked_ok_iff]
  exact ⟨fun ⟨q, h⟩ ↦ h ▸ q.bound, fun h ↦ ⟨⟨n, h⟩, rfl⟩⟩

@[simp] theorem ofNat_ok_iff (n : Nat) (q : Word w) :
    ofNat w n = .ok q ↔ n = q.value := Word.checked_ok_iff _ _ _

@[simp] theorem ofNat_error_iff (n : Nat) (failure : Failure) :
    ofNat w n = .error failure ↔ 2^w ≤ n ∧ failure = .inputOverflow := by
  rw [ofNat, Word.checked_error_iff]
  exact and_congr_right fun _ ↦ eq_comm

theorem ofNat_value (q : Word w) : ofNat w q.value = .ok q := by simp

theorem Word.width_zero (q : Word 0) : q.value = 0 := by
  have := q.bound
  change q.value < 1 at this
  omega

end DefiKernel.Arithmetic


/-! Checked addition, subtraction and multiplication without modular wraparound. -/
namespace DefiKernel.Arithmetic.Operations

variable {w : Nat}

def add (a b : Word w) : Except Failure (Word w) :=
  Word.checked .addOverflow (a.value + b.value)

def sub (a b : Word w) : Except Failure (Word w) :=
  if b.value ≤ a.value then Word.checked .subUnderflow (a.value - b.value)
  else .error .subUnderflow

def mul (a b : Word w) : Except Failure (Word w) :=
  Word.checked .mulOverflow (a.value * b.value)

-- BEGIN PROOFS

@[simp] theorem add_ok_iff (a b q : Word w) :
    add a b = .ok q ↔ a.value + b.value = q.value := Word.checked_ok_iff _ _ _

@[simp] theorem add_error_iff (a b : Word w) (failure : Failure) :
    add a b = .error failure ↔ 2^w ≤ a.value + b.value ∧ failure = .addOverflow := by
  rw [add, Word.checked_error_iff]
  exact and_congr_right fun _ ↦ eq_comm

@[simp] theorem mul_ok_iff (a b q : Word w) :
    mul a b = .ok q ↔ a.value * b.value = q.value := Word.checked_ok_iff _ _ _

@[simp] theorem mul_error_iff (a b : Word w) (failure : Failure) :
    mul a b = .error failure ↔ 2^w ≤ a.value * b.value ∧ failure = .mulOverflow := by
  rw [mul, Word.checked_error_iff]
  exact and_congr_right fun _ ↦ eq_comm

theorem sub_difference_bound (a b : Word w) : a.value - b.value < 2^w :=
  lt_of_le_of_lt (Nat.sub_le _ _) a.bound

theorem sub_checked_ne_error (a b : Word w) (failure : Failure) :
    Word.checked (w := w) .subUnderflow (a.value - b.value) ≠ .error failure := by
  intro h
  exact Nat.not_le_of_lt (sub_difference_bound a b)
    ((Word.checked_error_iff _ _ _).mp h).1

@[simp] theorem sub_ok_iff (a b q : Word w) :
    sub a b = .ok q ↔ b.value ≤ a.value ∧ a.value - b.value = q.value := by
  unfold sub
  by_cases h : b.value ≤ a.value <;> simp [h]

@[simp] theorem sub_error_iff (a b : Word w) (failure : Failure) :
    sub a b = .error failure ↔ a.value < b.value ∧ failure = .subUnderflow := by
  unfold sub
  split
  · simp_all only [sub_checked_ne_error, false_iff, not_and]
    omega
  · simp_all [eq_comm]

theorem add_mono (a a' b q q' : Word w) (h : a.value ≤ a'.value)
    (hq : add a b = .ok q) (hq' : add a' b = .ok q') : q.value ≤ q'.value := by
  have := (add_ok_iff _ _ _).mp hq
  have := (add_ok_iff _ _ _).mp hq'
  omega

theorem mul_mono (a a' b q q' : Word w) (h : a.value ≤ a'.value)
    (hq : mul a b = .ok q) (hq' : mul a' b = .ok q') : q.value ≤ q'.value := by
  rw [← (mul_ok_iff _ _ _).mp hq, ← (mul_ok_iff _ _ _).mp hq']
  exact Nat.mul_le_mul_right _ h

theorem sub_mono (a a' b q q' : Word w) (h : a.value ≤ a'.value)
    (hq : sub a b = .ok q) (hq' : sub a' b = .ok q') : q.value ≤ q'.value := by
  have := (sub_ok_iff _ _ _).mp hq
  have := (sub_ok_iff _ _ _).mp hq'
  omega

theorem sub_antitone (a b b' q q' : Word w) (h : b.value ≤ b'.value)
    (hq : sub a b = .ok q) (hq' : sub a b' = .ok q') : q'.value ≤ q.value := by
  have := (sub_ok_iff _ _ _).mp hq
  have := (sub_ok_iff _ _ _).mp hq'
  omega

theorem add_comm (a b : Word w) : add a b = add b a := by
  simp only [add, Nat.add_comm]

theorem mul_comm (a b : Word w) : mul a b = mul b a := by
  simp only [mul, Nat.mul_comm]

theorem add_zero (a z : Word w) (hz : z.value = 0) : add a z = .ok a := by
  simp [hz]

theorem sub_zero (a z : Word w) (hz : z.value = 0) : sub a z = .ok a := by
  simp [hz]

theorem sub_self (a z : Word w) (hz : z.value = 0) : sub a a = .ok z := by
  simp [hz]

theorem mul_zero (a z : Word w) (hz : z.value = 0) : mul a z = .ok z := by
  simp [hz]

theorem mul_one (a one : Word w) (h : one.value = 1) : mul a one = .ok a := by
  simp [h]

theorem add_mono_right (a b b' q q' : Word w) (h : b.value ≤ b'.value)
    (hq : add a b = .ok q) (hq' : add a b' = .ok q') : q.value ≤ q'.value := by
  exact add_mono b b' a q q' h ((add_comm _ _).trans hq) ((add_comm _ _).trans hq')

theorem mul_mono_right (a b b' q q' : Word w) (h : b.value ≤ b'.value)
    (hq : mul a b = .ok q) (hq' : mul a b' = .ok q') : q.value ≤ q'.value := by
  exact mul_mono b b' a q q' h ((mul_comm _ _).trans hq) ((mul_comm _ _).trans hq')

end DefiKernel.Arithmetic.Operations


/-!
Actual Lean-checked library instantiation for P20 task 21.3.

Envelope `libraries` theorem-name tags never discharge LibraryTheoremsInstantiated.
Only a compiled identity with a recorded theorem from accepted Arithmetic counts.
-/
namespace DefiKernel.Certificates.LibraryInstantiation

open DefiKernel.Arithmetic

/-- Compiled instantiation of accepted Arithmetic checked-addition. -/
theorem instantiated_add_ok_iff {w : Nat} (a b q : Word w) :
    Operations.add a b = .ok q ↔ a.value + b.value = q.value :=
  Operations.add_ok_iff a b q

/-- Fully qualified names of theorems this certificate increment actually instantiated. -/
def instantiatedTheoremNames : List String :=
  ["DefiKernel.Arithmetic.Operations.add_ok_iff"]

/-- Theorem-name tags discharge nothing unless they name a compiled instantiation. -/
def namesDischarged (libs : List LibraryRefEnc) : Bool :=
  !libs.isEmpty && libs.all (fun l => instantiatedTheoremNames.contains l.theoremName)

end DefiKernel.Certificates.LibraryInstantiation


/-! Conservative admission for invocation-only branches. Lists preserve deterministic witnesses. -/
namespace DefiKernel.Parallel
open Typed Composition

inductive BranchId where
  | left
  | right
  deriving DecidableEq, Repr
abbrev Branch (P A D : Type) := List (Invocation P A D)
abbrev ParallelBoundary (P A D : Type) := BranchId → Nat → Boundary P A D
structure Footprint (P A D : Type) where
  reads : List (Cell P A D)
  writes : List (Cell P A D)
  deriving DecidableEq, Repr
structure LocalFailure where
  index : Nat
  reason : Composition.Failure
  deriving DecidableEq, Repr
inductive ConflictKind where
  | writeWrite
  | leftWriteRightRead
  | rightWriteLeftRead
  deriving DecidableEq, Repr
inductive AdmissionFailure (P A D : Type) where
  | configuration
  | structural (branch : BranchId) (failure : LocalFailure)
  | conflict (kind : ConflictKind) (cell : Cell P A D)
  deriving DecidableEq, Repr
variable {P A D : Type} [DecidableEq P] [DecidableEq A] [DecidableEq D]
def Footprint.empty : Footprint P A D := ⟨[], []⟩
def Footprint.append (a b : Footprint P A D) : Footprint P A D :=
  ⟨a.reads ++ b.reads, a.writes ++ b.writes⟩
/-- Lookup, read resolution, write/target resolution, then access checks.
No financial values are evaluated. -/
def analyzeInvocation (cfg : Config P A D) (boundary : Boundary P A D)
    (inv : Invocation P A D) : Except Composition.Failure (Footprint P A D) := do
  let (component, iface) ← match lookupOperation cfg.catalog inv.component inv.operation with
    | none => .error (.interface .unknownOperation)
    | some pair => .ok pair
  let template ← match cfg.registry inv.operation with
    | none => .error (.kernel .unknownOperation)
    | some template => .ok template
  let reads ← (resolveRefs boundary.ctx.principal inv.parties
    (template.requiredStateReads ++ template.stateReads)).mapError
      (fun e ↦ .interface (.resolution e))
  let writes ← (resolveRefs boundary.ctx.principal inv.parties
    (template.writes ++ template.deltas.map (fun d ↦ ⟨d.asset, d.target⟩))).mapError
      (fun e ↦ .interface (.resolution e))
  let _ ← (checkAccess component template boundary.ctx inv.parties).mapError .interface
  return ⟨reads ++ writes ++ iface.outputs.map OutputPort.cell, writes⟩
/-- Structural analysis covers the entire suffix even when a financial prefix would refuse. -/
def analyzeBranchFrom (cfg : Config P A D) (boundary : Nat → Boundary P A D)
    (index : Nat) : Branch P A D → Except LocalFailure (Footprint P A D)
  | [] => .ok .empty
  | inv :: tail => do
    let head ← (analyzeInvocation cfg (boundary index) inv).mapError (⟨index, ·⟩)
    let rest ← analyzeBranchFrom cfg boundary (index + 1) tail
    return head.append rest
def analyzeBranch (cfg : Config P A D) (boundary : Nat → Boundary P A D)
    (branch : Branch P A D) : Except LocalFailure (Footprint P A D) :=
  analyzeBranchFrom cfg boundary 0 branch
def firstOverlap (xs ys : List (Cell P A D)) : Option (Cell P A D) :=
  xs.find? (fun c ↦ decide (c ∈ ys))
def checkCompatibility (left right : Footprint P A D) :
    Except (AdmissionFailure P A D) PUnit :=
  match firstOverlap left.writes right.writes with
  | some c => .error (.conflict .writeWrite c)
  | none => match firstOverlap left.writes right.reads with
    | some c => .error (.conflict .leftWriteRightRead c)
    | none => match firstOverlap right.writes left.reads with
      | some c => .error (.conflict .rightWriteLeftRead c)
      | none => .ok ⟨⟩
def admit (cfg : Config P A D) (boundaries : ParallelBoundary P A D)
    (left right : Branch P A D) : Except (AdmissionFailure P A D)
      (Footprint P A D × Footprint P A D) := do
  if !validateCatalog cfg.registry cfg.catalog then throw .configuration
  let lf ← (analyzeBranch cfg (boundaries .left) left).mapError (.structural .left)
  let rf ← (analyzeBranch cfg (boundaries .right) right).mapError (.structural .right)
  let _ ← checkCompatibility lf rf
  return (lf, rf)

-- BEGIN PROOFS

def Compatible (left right : Footprint P A D) : Prop :=
  (∀ c ∈ left.writes, c ∉ right.writes) ∧
  (∀ c ∈ left.writes, c ∉ right.reads) ∧
  (∀ c ∈ right.writes, c ∉ left.reads)
theorem firstOverlap_none_iff (xs ys : List (Cell P A D)) :
    firstOverlap xs ys = none ↔ ∀ c ∈ xs, c ∉ ys := by
  simp [firstOverlap, List.find?_eq_none]
theorem checkCompatibility_ok_iff (left right : Footprint P A D) :
    checkCompatibility left right = .ok PUnit.unit ↔ Compatible left right := by
  unfold Compatible
  simp only [← firstOverlap_none_iff]
  unfold checkCompatibility
  cases hww : firstOverlap left.writes right.writes <;>
    cases hlr : firstOverlap left.writes right.reads <;>
    cases hrl : firstOverlap right.writes left.reads <;>
    simp_all
omit [DecidableEq P] [DecidableEq A] [DecidableEq D] in
theorem compatible_symm {left right : Footprint P A D} (h : Compatible left right) :
    Compatible right left := by
  exact ⟨fun c hr hl ↦ h.1 c hl hr, h.2.2, h.2.1⟩
theorem analyzeInvocation_ok (cfg : Config P A D) (boundary : Boundary P A D)
    (inv : Invocation P A D) (fp : Footprint P A D)
    (h : analyzeInvocation cfg boundary inv = .ok fp) :
    ∃ component iface template reads writes,
      lookupOperation cfg.catalog inv.component inv.operation = some (component, iface) ∧
      cfg.registry inv.operation = some template ∧
      resolveRefs boundary.ctx.principal inv.parties
        (template.requiredStateReads ++ template.stateReads) = .ok reads ∧
      resolveRefs boundary.ctx.principal inv.parties
        (template.writes ++ template.deltas.map (fun d ↦ ⟨d.asset, d.target⟩)) = .ok writes ∧
      checkAccess component template boundary.ctx inv.parties = .ok PUnit.unit ∧
      fp = ⟨reads ++ writes ++ iface.outputs.map OutputPort.cell, writes⟩ := by
  unfold analyzeInvocation at h
  simp only [bind, Except.bind, Except.mapError, pure, Except.pure] at h
  split at h
  · contradiction
  rename_i pair hl
  rcases pair with ⟨component, iface⟩
  split at h
  · contradiction
  rename_i template ht
  split at h
  · contradiction
  rename_i reads hr
  split at h
  · contradiction
  rename_i writes hw
  split at h
  · contradiction
  rename_i token hc
  cases token
  have unmap {E F X : Type} (f : E → F) (x : Except E X) (v : X)
      (hx : x.mapError f = .ok v) : x = .ok v := by
    cases x <;> simp_all [Except.mapError]
  exact ⟨component, iface, template, reads, writes, hl, ht,
    unmap _ _ _ hr, unmap _ _ _ hw, unmap _ _ _ hc, (Except.ok.inj h).symm⟩
omit [DecidableEq P] [DecidableEq A] [DecidableEq D] in
theorem resolveRefs_member (caller : P) (parties : List P)
    (refs : List (PackedCellRef P A D)) (cells : List (Cell P A D))
    (h : resolveRefs caller parties refs = .ok cells)
    (ref : PackedCellRef P A D) (hr : ref ∈ refs) :
    ∃ cell ∈ cells, ref.2.resolve caller parties = .ok cell := by
  induction refs generalizing cells with
  | nil => simp at hr
  | cons head tail ih =>
    simp only [resolveRefs, List.mapM_cons, bind, Except.bind] at h
    cases hh : head.2.resolve caller parties with
    | error e => simp [hh] at h
    | ok cell =>
      cases ht : resolveRefs caller parties tail with
      | error e =>
        simp only [resolveRefs] at ht
        simp [hh, ht] at h
      | ok rest =>
        have htt := ht
        simp only [resolveRefs] at ht
        simp only [hh, ht, pure, Except.pure,
          Except.ok.injEq] at h
        subst cells
        rcases List.mem_cons.mp hr with he | hm
        · subst ref; exact ⟨cell, by simp, hh⟩
        · obtain ⟨c, hc, resolved⟩ := ih rest htt hm
          exact ⟨c, List.mem_cons_of_mem _ hc, resolved⟩
theorem analyzeBranchFrom_cons (cfg : Config P A D) (boundary : Nat → Boundary P A D)
    (index : Nat) (inv : Invocation P A D) (tail : Branch P A D) (fp : Footprint P A D)
    (h : analyzeBranchFrom cfg boundary index (inv :: tail) = .ok fp) :
    ∃ head rest, analyzeInvocation cfg (boundary index) inv = .ok head ∧
      analyzeBranchFrom cfg boundary (index + 1) tail = .ok rest ∧ fp = head.append rest := by
  unfold analyzeBranchFrom at h
  cases hh : analyzeInvocation cfg (boundary index) inv with
  | error e => simp [hh, Except.mapError, bind, Except.bind] at h
  | ok head =>
    cases ht : analyzeBranchFrom cfg boundary (index + 1) tail with
    | error e => simp [hh, ht, Except.mapError, bind, Except.bind] at h
    | ok rest =>
      simp only [hh, ht, Except.mapError, bind, Except.bind, pure, Except.pure,
        Except.ok.injEq] at h
      exact ⟨head, rest, rfl, rfl, h.symm⟩
theorem admit_ok (cfg : Config P A D) (boundaries : ParallelBoundary P A D)
    (left right : Branch P A D) (lf rf : Footprint P A D)
    (h : admit cfg boundaries left right = .ok (lf, rf)) :
    validateCatalog cfg.registry cfg.catalog = true ∧
    analyzeBranch cfg (boundaries .left) left = .ok lf ∧
    analyzeBranch cfg (boundaries .right) right = .ok rf ∧ Compatible lf rf := by
  unfold admit at h
  simp only [bind, Except.bind, pure, Except.pure] at h
  split at h
  · simp [throw, throwThe] at h
  rename_i hv
  split at h
  · contradiction
  rename_i l hl
  split at h
  · contradiction
  rename_i r hr
  split at h
  · contradiction
  rename_i token hc
  cases token
  obtain ⟨rfl, rfl⟩ := Prod.mk.inj (Except.ok.inj h)
  have unmap {E F X : Type} (f : E → F) (x : Except E X) (v : X)
      (hx : x.mapError f = .ok v) : x = .ok v := by
    cases x <;> simp_all [Except.mapError]
  exact ⟨by simpa using hv, unmap _ _ _ hl, unmap _ _ _ hr,
    (checkCompatibility_ok_iff _ _).mp hc⟩

theorem admit_compatible (cfg : Config P A D) (boundaries : ParallelBoundary P A D)
    (left right : Branch P A D) (lf rf : Footprint P A D)
    (h : admit cfg boundaries left right = .ok (lf, rf)) : Compatible lf rf :=
  (admit_ok cfg boundaries left right lf rf h).2.2.2

omit [DecidableEq P] [DecidableEq A] [DecidableEq D] in
theorem resolveRefs_mem_of_resolve (caller : P) (parties : List P)
    (refs : List (PackedCellRef P A D)) (cells : List (Cell P A D))
    (h : resolveRefs caller parties refs = .ok cells)
    (ref : PackedCellRef P A D) (hr : ref ∈ refs) (cell : Cell P A D)
    (resolved : ref.2.resolve caller parties = .ok cell) : cell ∈ cells := by
  obtain ⟨c, hc, he⟩ := resolveRefs_member caller parties refs cells h ref hr
  rw [resolved] at he
  cases he
  exact hc

omit [DecidableEq P] [DecidableEq A] [DecidableEq D] in
theorem resolveRefs_append_ok (caller : P) (parties : List P)
    (xs ys : List (PackedCellRef P A D)) (cells : List (Cell P A D))
    (h : resolveRefs caller parties (xs ++ ys) = .ok cells) :
    ∃ left right, resolveRefs caller parties xs = .ok left ∧
      resolveRefs caller parties ys = .ok right ∧ cells = left ++ right := by
  simp only [resolveRefs, List.mapM_append] at h
  change ((resolveRefs caller parties xs).bind fun left ↦
    (resolveRefs caller parties ys).bind fun right ↦ .ok (left ++ right)) = .ok cells at h
  cases hx : resolveRefs caller parties xs with
  | error e => simp [hx, Except.bind] at h
  | ok left =>
    cases hy : resolveRefs caller parties ys with
    | error e => simp [hx, hy, Except.bind] at h
    | ok right =>
      simp only [hx, hy, Except.bind, Except.ok.injEq] at h
      exact ⟨left, right, rfl, rfl, h.symm⟩

/-- Accepted analysis covers every syntactic/declared read, every potential write and target,
and every output, regardless of whether the invocation would execute successfully. -/
theorem analyzeInvocation_coverage (cfg : Config P A D) (boundary : Boundary P A D)
    (inv : Invocation P A D) (fp : Footprint P A D)
    (h : analyzeInvocation cfg boundary inv = .ok fp) :
    ∃ component iface template,
      lookupOperation cfg.catalog inv.component inv.operation = some (component, iface) ∧
      cfg.registry inv.operation = some template ∧
      (∀ ref ∈ template.requiredStateReads ++ template.stateReads,
        ∃ c ∈ fp.reads, ref.2.resolve boundary.ctx.principal inv.parties = .ok c) ∧
      (∀ ref ∈ template.writes ++ template.deltas.map (fun d ↦ ⟨d.asset, d.target⟩),
        ∃ c ∈ fp.writes, ref.2.resolve boundary.ctx.principal inv.parties = .ok c) ∧
      (∀ output ∈ iface.outputs, output.cell ∈ fp.reads) ∧
      (∀ c ∈ fp.writes, c ∈ fp.reads) := by
  obtain ⟨component, iface, template, reads, writes, hl, ht, hr, hw, _, rfl⟩ :=
    analyzeInvocation_ok cfg boundary inv fp h
  refine ⟨component, iface, template, hl, ht, ?_, ?_, ?_, ?_⟩
  · intro ref hm
    obtain ⟨c, hc, he⟩ := resolveRefs_member _ _ _ _ hr ref hm
    exact ⟨c, by simp [hc], he⟩
  · intro ref hm
    exact resolveRefs_member _ _ _ _ hw ref hm
  · intro output hm
    simp only [List.mem_append, List.mem_map]
    exact Or.inr ⟨output, hm, rfl⟩
  · intro c hc
    simp [hc]

theorem analyzeInvocation_writes_read (cfg : Config P A D) (boundary : Boundary P A D)
    (inv : Invocation P A D) (fp : Footprint P A D)
    (h : analyzeInvocation cfg boundary inv = .ok fp) :
    ∀ c ∈ fp.writes, c ∈ fp.reads := by
  obtain ⟨_, _, _, _, _, _, _, _, hw⟩ := analyzeInvocation_coverage cfg boundary inv fp h
  exact hw

/-- Every local invocation has its own analyzed footprint contained in the whole branch. -/
theorem analyzeBranchFrom_member (cfg : Config P A D) (boundary : Nat → Boundary P A D)
    (index : Nat) (branch : Branch P A D) (fp : Footprint P A D)
    (h : analyzeBranchFrom cfg boundary index branch = .ok fp)
    (n : Nat) (inv : Invocation P A D) (atIndex : branch[n]? = some inv) :
    ∃ part, analyzeInvocation cfg (boundary (index + n)) inv = .ok part ∧
      (∀ c ∈ part.reads, c ∈ fp.reads) ∧ (∀ c ∈ part.writes, c ∈ fp.writes) := by
  induction branch generalizing index fp n with
  | nil => simp at atIndex
  | cons head tail ih =>
    obtain ⟨hf, tf, hh, ht, rfl⟩ := analyzeBranchFrom_cons _ _ _ _ _ _ h
    cases n with
    | zero =>
      simp only [List.getElem?_cons_zero, Option.some.injEq] at atIndex
      subst inv
      exact ⟨hf, by simpa using hh,
        fun c hc ↦ List.mem_append_left _ hc, fun c hc ↦ List.mem_append_left _ hc⟩
    | succ n =>
      simp only [List.getElem?_cons_succ] at atIndex
      obtain ⟨part, hl, hr, hw⟩ := ih (index + 1) tf ht n atIndex
      refine ⟨part, ?_, fun c hc ↦ List.mem_append_right _ (hr c hc),
        fun c hc ↦ List.mem_append_right _ (hw c hc)⟩
      simpa [Nat.add_assoc, Nat.add_comm, Nat.add_left_comm] using hl

end DefiKernel.Parallel


namespace DefiKernel.Certificates

open DefiKernel.Typed
open DefiKernel.Composition

/-- Conversion helper: map an index and expected unit to a typed variable. -/
def indexToVar : (sig : List (Typed.Unit Asset)) → (idx : Nat) → (u : Typed.Unit Asset) → Option (Typed.Var sig u)
  | [], _, _ => none
  | v :: _, 0, u =>
    if h : v = u then some (h ▸ .here) else none
  | _ :: vs, n + 1, u =>
    (indexToVar vs n u).map (fun var => .there var)

/-- Extract a typed Value from a PackedValueEnc given expected Unit. -/
def packedValueToVal (u : Typed.Unit Asset) (val : PackedValueEnc) : Option (Typed.Value u) :=
  match u, val.unit with
  | .bool, .bool => some val.valBool
  | .amount a, .numeric (.amount a') =>
    if h : a = a' then some (h ▸ val.valRat) else none
  | .price b q, .numeric (.price b' q') =>
    if h : b = b' ∧ q = q' then some (h.1 ▸ h.2 ▸ val.valRat) else none
  | .scalar, .numeric .scalar => some val.valRat
  | _, _ => none

/-- Convert an AST expression to a typed kernel expression. -/
def exprToTyped (sig : List (Typed.Unit Asset)) (u : Typed.Unit Asset) (e : ExprEnc) (fuel : Nat := 100) :
    Option (Typed.Expr Party Asset Domain sig u) :=
  match fuel with
  | 0 => none
  | fuel + 1 =>
    match e with
    | .lit val => do
      let v ← packedValueToVal u val
      some (.lit v)
    | .arg idx uEnc =>
      if h : uEnc.toUnit = u then
        (indexToVar sig idx uEnc.toUnit).map (fun var => h ▸ .arg var)
      else none
    | .balance c =>
      if h : u = .amount c.asset then
        some (h ▸ .balance ⟨c.cell.domain, c.cell.owner.toPartyRef⟩)
      else none
    | .observe r =>
      if h : r.unit.toUnit = u then
        some (h ▸ .observe ⟨⟨r.key.domain, ⟨r.key.id⟩⟩⟩)
      else none
    | .timestamp k =>
      if h : u = .scalar then
        some (h ▸ .timestamp ⟨k.domain, ⟨k.id⟩⟩)
      else none
    | .now =>
      if h : u = .scalar then some (h ▸ .now) else none
    | .unary op x =>
      match op with
      | .neg n =>
        if h : u = n.toNumericUnit.toUnit then do
          let x' ← exprToTyped sig n.toNumericUnit.toUnit x fuel
          some (h ▸ .unary (.neg n.toNumericUnit) x')
        else none
      | .not =>
        if h : u = .bool then do
          let x' ← exprToTyped sig .bool x fuel
          some (h ▸ .unary .not x')
        else none
    | .binary op x y =>
      match op with
      | .add n =>
        if h : u = n.toNumericUnit.toUnit then do
          let x' ← exprToTyped sig n.toNumericUnit.toUnit x fuel
          let y' ← exprToTyped sig n.toNumericUnit.toUnit y fuel
          some (h ▸ .binary (.add n.toNumericUnit) x' y')
        else none
      | .sub n =>
        if h : u = n.toNumericUnit.toUnit then do
          let x' ← exprToTyped sig n.toNumericUnit.toUnit x fuel
          let y' ← exprToTyped sig n.toNumericUnit.toUnit y fuel
          some (h ▸ .binary (.sub n.toNumericUnit) x' y')
        else none
      | .scale n =>
        if h : u = n.toNumericUnit.toUnit then do
          let x' ← exprToTyped sig .scalar x fuel
          let y' ← exprToTyped sig n.toNumericUnit.toUnit y fuel
          some (h ▸ .binary (.scale n.toNumericUnit) x' y')
        else none
      | .divide n =>
        if h : u = n.toNumericUnit.toUnit then do
          let x' ← exprToTyped sig n.toNumericUnit.toUnit x fuel
          let y' ← exprToTyped sig .scalar y fuel
          some (h ▸ .binary (.divide n.toNumericUnit) x' y')
        else none
      | .ratio n =>
        if h : u = .scalar then do
          let x' ← exprToTyped sig n.toNumericUnit.toUnit x fuel
          let y' ← exprToTyped sig n.toNumericUnit.toUnit y fuel
          some (h ▸ .binary (.ratio n.toNumericUnit) x' y')
        else none
      | .convert b q =>
        if h : u = .amount q then do
          let x' ← exprToTyped sig (.amount b) x fuel
          let y' ← exprToTyped sig (.price b q) y fuel
          some (h ▸ .binary (.convert b q) x' y')
        else none
      | .unconvert b q =>
        if h : u = .amount b then do
          let x' ← exprToTyped sig (.amount q) x fuel
          let y' ← exprToTyped sig (.price b q) y fuel
          some (h ▸ .binary (.unconvert b q) x' y')
        else none
      | .le n =>
        if h : u = .bool then do
          let x' ← exprToTyped sig n.toNumericUnit.toUnit x fuel
          let y' ← exprToTyped sig n.toNumericUnit.toUnit y fuel
          some (h ▸ .binary (.le n.toNumericUnit) x' y')
        else none
      | .lt n =>
        if h : u = .bool then do
          let x' ← exprToTyped sig n.toNumericUnit.toUnit x fuel
          let y' ← exprToTyped sig n.toNumericUnit.toUnit y fuel
          some (h ▸ .binary (.lt n.toNumericUnit) x' y')
        else none
      | .eq eqU =>
        if h : u = .bool then do
          let x' ← exprToTyped sig eqU.toUnit x fuel
          let y' ← exprToTyped sig eqU.toUnit y fuel
          some (h ▸ .binary (.eq eqU.toUnit) x' y')
        else none
      | .and =>
        if h : u = .bool then do
          let x' ← exprToTyped sig .bool x fuel
          let y' ← exprToTyped sig .bool y fuel
          some (h ▸ .binary .and x' y')
        else none
      | .or =>
        if h : u = .bool then do
          let x' ← exprToTyped sig .bool x fuel
          let y' ← exprToTyped sig .bool y fuel
          some (h ▸ .binary .or x' y')
        else none
    | .ite c y n => do
      let c' ← exprToTyped sig .bool c fuel
      let y' ← exprToTyped sig u y fuel
      let n' ← exprToTyped sig u n fuel
      some (.ite c' y' n')

def cellDeltaToTyped (sig : List (Typed.Unit Asset)) (d : CellDeltaEnc) :
    Option (Typed.CellDelta Party Asset Domain sig) := do
  let amt ← exprToTyped sig (.amount d.asset) d.amount
  some ⟨d.asset, ⟨d.target.domain, d.target.owner.toPartyRef⟩, amt⟩

def supplyDeltaToTyped (sig : List (Typed.Unit Asset)) (d : SupplyDeltaEnc) :
    Option (Typed.SupplyDelta Party Asset Domain sig) := do
  let amt ← exprToTyped sig (.amount d.asset) d.amount
  some ⟨d.domain, d.asset, amt⟩

def templateToTyped (t : TemplateEnc) : Option (Typed.Template Party Asset Domain) := do
  let sig := t.signature.map UnitEnc.toUnit
  let guard ← exprToTyped sig .bool t.guard
  let deltas ← t.deltas.mapM (cellDeltaToTyped sig)
  let supplyDeltas ← t.supplyDeltas.mapM (supplyDeltaToTyped sig)
  let stateReads := t.stateReads.map PackedCellRefEnc.toPackedCellRef
  let envReads := t.envReads.map EnvReadEnc.toEnvRead
  let writes := t.writes.map PackedCellRefEnc.toPackedCellRef
  some ⟨sig, t.domain, t.partyArity, guard, deltas, supplyDeltas, stateReads, envReads, writes⟩

def registryToTyped (r : RegistryEnc) : Typed.Registry Party Asset Domain :=
  fun op ↦
    match r.entries.find? (fun e ↦ e.id == op.value) with
    | some e => templateToTyped e.template
    | none => none

def storeToTyped (s : StoreEnc) : Typed.CapabilityStore Party Asset Domain :=
  s.toCapabilityStore

def storeToEnc (s : Typed.CapabilityStore Party Asset Domain) : StoreEnc :=
  ⟨s.entries.map fun cap ↦ ⟨cap.1.holder, cap.1.domain, cap.1.operation.value,
    match cap.1.right with
    | .invoke => .invoke
    | .debit c => .debit ⟨c.1, c.2.1, c.2.2⟩
    | .changeSupply d a => .changeSupply d a,
    cap.2⟩⟩

def envToTyped (e : EnvironmentEnc) : Typed.Environment Asset Domain :=
  e.toEnvironment

def stateToTyped? (s : StateEnc) : Option (Typed.State Party Asset Domain) :=
  s.toState?

def configToTyped? (c : ConfigEnc) : Option (Composition.Config Party Asset Domain) := do
  let reg := registryToTyped c.registry
  let admin : Domain → Party := fun d ↦
    match c.domainAdmin.find? (fun a ↦ a.domain == d) with
    | some a => a.party
    | none => .vault
  let cat := c.catalog.map ComponentEnc.toComponent
  some ⟨reg, admin, cat⟩

def boundaryToTyped (b : BoundaryEnc) : Composition.Boundary Party Asset Domain :=
  ⟨b.ctx.toContext, envToTyped b.env, b.now⟩

structure ClaimedJudgments where
  typeCorrect : Bool := false
  footprintCorrect : Bool := false
  authorityCorrect : Bool := false
  accountingCorrect : Bool := false
  compositionCompatible : Bool := false
  assumptionsDeclared : Bool := false
  libraryTheoremsInstantiated : Bool := false
  sourceRefinement : Bool := false
  deriving DecidableEq, Repr, Inhabited

def parseClaimedJudgments (claims : List String) : ClaimedJudgments :=
  claims.foldl (fun acc s ↦
    if s == "typeCorrect" then { acc with typeCorrect := true }
    else if s == "footprintCorrect" then { acc with footprintCorrect := true }
    else if s == "authorityCorrect" then { acc with authorityCorrect := true }
    else if s == "accountingCorrect" then { acc with accountingCorrect := true }
    else if s == "compositionCompatible" then { acc with compositionCompatible := true }
    else if s == "assumptionsDeclared" then { acc with assumptionsDeclared := true }
    else if s == "libraryTheoremsInstantiated" then { acc with libraryTheoremsInstantiated := true }
    else if s == "sourceRefinement" then { acc with sourceRefinement := true }
    else acc) {}

def evalFailureToString : EvalFailure → String
  | .argumentCount => "argumentCount"
  | .argumentUnit => "argumentUnit"
  | .partyArgument => "partyArgument"
  | .missingObservation => "missingObservation"
  | .observationUnit => "observationUnit"
  | .divisionByZero => "divisionByZero"

def refusalToLocatedFailure (r : Refusal) : LocatedFailureEnc :=
  match r with
  | .unknownOperation => ⟨0, none, ⟨.kernel, "unknownOperation", none⟩⟩
  | .actorMismatch => ⟨0, none, ⟨.kernel, "actorMismatch", none⟩⟩
  | .domainMismatch => ⟨0, none, ⟨.kernel, "domainMismatch", none⟩⟩
  | .partyArity => ⟨0, none, ⟨.kernel, "partyArity", none⟩⟩
  | .evaluation ef => ⟨0, none, ⟨.kernel, "evaluation", some (evalFailureToString ef)⟩⟩
  | .unauthorizedInvoke => ⟨0, none, ⟨.kernel, "unauthorizedInvoke", none⟩⟩
  | .guard => ⟨0, none, ⟨.kernel, "guard", none⟩⟩
  | .stateReadFootprint => ⟨0, none, ⟨.kernel, "stateReadFootprint", none⟩⟩
  | .envReadFootprint => ⟨0, none, ⟨.kernel, "envReadFootprint", none⟩⟩
  | .crossDomain => ⟨0, none, ⟨.kernel, "crossDomain", none⟩⟩
  | .unauthorizedDebit => ⟨0, none, ⟨.kernel, "unauthorizedDebit", none⟩⟩
  | .unauthorizedSupply => ⟨0, none, ⟨.kernel, "unauthorizedSupply", none⟩⟩
  | .insufficientFunds => ⟨0, none, ⟨.kernel, "insufficientFunds", none⟩⟩
  | .accounting => ⟨0, none, ⟨.kernel, "accounting", none⟩⟩
  | .writeFootprint => ⟨0, none, ⟨.kernel, "writeFootprint", none⟩⟩

def failureToPath (f : Composition.Failure) : FailurePath :=
  match f with
  | .configuration => ⟨.configuration, "configuration", none⟩
  | .interface .unknownOperation => ⟨.interface, "unknownOperation", none⟩
  | .interface (.resolution ef) => ⟨.interface, "resolution", some (evalFailureToString ef)⟩
  | .interface .readAccess => ⟨.interface, "readAccess", none⟩
  | .interface .writeAccess => ⟨.interface, "writeAccess", none⟩
  | .interface .inputCount => ⟨.interface, "inputCount", none⟩
  | .interface .inputUnit => ⟨.interface, "inputUnit", none⟩
  | .interface .unavailableOutput => ⟨.interface, "unavailableOutput", none⟩
  | .kernel r => (refusalToLocatedFailure r).reason
  | .authority .unauthorizedAdmin => ⟨.authority, "unauthorizedAdmin", none⟩
  | .authority .operationDomain => ⟨.authority, "operationDomain", none⟩
  | .authority .resourceDomain => ⟨.authority, "resourceDomain", none⟩
  | .authority .unknownCapability => ⟨.authority, "unknownCapability", none⟩
  | .internalReceipt => ⟨.internalReceipt, "internalReceipt", none⟩

def evaluatedToEnc (e : Typed.Evaluated Party Asset Domain) (req : Typed.Request Party Asset Domain) : ReceiptEnc :=
  .invoked ⟨req.operation.value, req.parties, req.arguments.map PackedValueEnc.fromPackedValue, req.capabilityIds.map (·.value), req.claimedActor⟩
    ⟨e.guard,
     e.deltas.map (fun (c, amt) ↦ (⟨c.1, c.2.1, c.2.2⟩, ⟨amt.num, amt.den⟩)),
     e.supplies.map (fun ((d, a), amt) ↦ ((d, a), ⟨amt.num, amt.den⟩)),
     e.requiredStateReads.map (fun c ↦ ⟨c.1, c.2.1, c.2.2⟩),
     e.requiredEnvReads.filterMap (fun r ↦ match r with | .observation k => some ⟨k.domain, k.id.value⟩ | .currentTime => none),
     e.declaredStateReads.map (fun c ↦ ⟨c.1, c.2.1, c.2.2⟩),
     e.declaredEnvReads.filterMap (fun r ↦ match r with | .observation k => some ⟨k.domain, k.id.value⟩ | .currentTime => none),
     e.writes.map (fun c ↦ ⟨c.1, c.2.1, c.2.2⟩)⟩

def executionResultToWorld (res : Typed.ExecutionResult Party Asset Domain) (oldState : StateEnc) : WorldEnc :=
  let cells := oldState.cells.map (fun row ↦
    let newBal := res.state.balance (row.domain, row.party, row.asset)
    ⟨row.domain, row.party, row.asset, ⟨newBal.num, newBal.den⟩⟩)
  ⟨⟨cells⟩, storeToEnc res.capabilities⟩

def FAMILIES : List String := [
  "typeCorrect",
  "footprintCorrect",
  "authorityCorrect",
  "accountingCorrect",
  "compositionCompatible",
  "assumptionsDeclared",
  "libraryTheoremsInstantiated",
  "sourceRefinement"
]

def makeJudgments (mapping : List (String × JudgmentOutcome)) (claimed : ClaimedJudgments) : List JudgmentResult :=
  FAMILIES.map fun fam ↦
    let outcome := match mapping.find? (fun (k, _) ↦ k == fam) with
      | some (_, o) => o
      | none => .notApplicable
    let cl := match fam with
      | "typeCorrect" => claimed.typeCorrect
      | "footprintCorrect" => claimed.footprintCorrect
      | "authorityCorrect" => claimed.authorityCorrect
      | "accountingCorrect" => claimed.accountingCorrect
      | "compositionCompatible" => claimed.compositionCompatible
      | "assumptionsDeclared" => claimed.assumptionsDeclared
      | "libraryTheoremsInstantiated" => claimed.libraryTheoremsInstantiated
      | "sourceRefinement" => claimed.sourceRefinement
      | _ => false
    let matchFlag := match outcome with
      | .«true» => cl == true
      | .«false» => cl == false
      | .notReached => !cl
      | .notApplicable => !cl
    ⟨fam, outcome, cl, matchFlag⟩

def SIX_ASSUMPTIONS : List String := [
  "registry-trust",
  "administrator-trust",
  "context-authenticity",
  "observation-truth",
  "environment-authenticity",
  "replay-prevention-outside-model"
]

def computeAssumptions (cert : EnvelopeEnc) : List (String × String) × Option String :=
  let missingEnv := !cert.assumptions.contains "environment-authenticity"
  let missingReplay := !cert.assumptions.contains "replay-prevention-outside-model"
  if missingEnv || missingReplay then
    let pairs := SIX_ASSUMPTIONS.map fun name ↦
      if name == "environment-authenticity" then (name, "missing")
      else (name, "present")
    (pairs, some "environment-authenticity")
  else
    let pairs := SIX_ASSUMPTIONS.map fun name ↦
      if cert.assumptions.contains name then (name, "present")
      else (name, "missing")
    let firstMissing := SIX_ASSUMPTIONS.find? (!cert.assumptions.contains ·)
    (pairs, firstMissing)

structure CertContext where
  claimed_next_state : Option (Typed.ExecutionResult Party Asset Domain) := none
  libraries : List LibraryRefEnc := []
  invariants : List String := []
  source_pin : SourcePinEnc
  audit_roots : List String

/-- Informational outstanding families. Theorem-name tags never become executable pass. -/
def outstandingFamilies (cert : EnvelopeEnc) : List String :=
  (if !cert.libraries.isEmpty then ["libraryTheoremsInstantiated"] else []) ++
  (if !cert.invariants.isEmpty then ["proof.ComponentContract.invariant"] else []) ++
  (if !cert.source_map.isEmpty then ["sourceRefinement"] else [])

/-- Library family is never true from envelope tags. Compiled instantiation is required. -/
def libraryJudgment (cert : EnvelopeEnc) : JudgmentOutcome :=
  if cert.libraries.isEmpty then
    JudgmentOutcome.notApplicable
  else if cert.require_library_discharge &&
      LibraryInstantiation.namesDischarged cert.libraries &&
      TrustedHost.recordsMatch cert.source_pin &&
      cert.source_pin.compiler_record.isSome then
    JudgmentOutcome.«true»
  else
    JudgmentOutcome.notApplicable

def sourceRefinementJudgment (_cert : EnvelopeEnc) : JudgmentOutcome :=
  JudgmentOutcome.notApplicable

def invokeSteps (steps : List StepEnc) : List (Invocation Party Asset Domain) :=
  steps.filterMap fun s =>
    match s with
    | .invoke inv => some inv.toInvocation
    | _ => none

/-- Split decoded invocations into catalog component 0 versus the remainder. -/
def splitInvokeBranches (invs : List (Invocation Party Asset Domain)) :
    List (Invocation Party Asset Domain) × List (Invocation Party Asset Domain) :=
  (invs.filter (fun i => i.component.value = 0),
   invs.filter (fun i => i.component.value ≠ 0))

/-- Recompute footprints via Parallel.admit on decoded catalog and branches.
Caller-supplied footprint labels are not an input. -/
def recomputeAdmit (cfg : Config Party Asset Domain)
    (boundary : Boundary Party Asset Domain)
    (invs : List (Invocation Party Asset Domain)) :
    Except (Parallel.AdmissionFailure Party Asset Domain)
      (Parallel.Footprint Party Asset Domain × Parallel.Footprint Party Asset Domain) :=
  let lr := splitInvokeBranches invs
  let boundaries : Parallel.ParallelBoundary Party Asset Domain := fun _ _ => boundary
  Parallel.admit cfg boundaries lr.1 lr.2

def compositionCompatibleOutcome
    (cfg : Config Party Asset Domain)
    (boundary : Boundary Party Asset Domain)
    (invs : List (Invocation Party Asset Domain)) : JudgmentOutcome :=
  match recomputeAdmit cfg boundary invs with
  | .ok _ => JudgmentOutcome.«true»
  | .error _ => JudgmentOutcome.«false»

/-- Primary Typed execution checker with needles M01, M02, M09, M10. -/
def checkTyped (rawCert : EnvelopeEnc) (payload : TypedExecutePayloadEnc) : Report :=
  let preWorld : WorldEnc := ⟨payload.state, payload.store⟩
  let (assumptionsList, missingAssump) := computeAssumptions rawCert
  let claimed := parseClaimedJudgments rawCert.claimed_judgments
  let outstanding := outstandingFamilies rawCert

  -- Untrusted envelope git compared against compiled TrustedHost.gitSha (definitionally this literal).
  if rawCert.source_pin.git ≠ TrustedHost.gitSha then
    let jmap : List (String × JudgmentOutcome) := [
      ("typeCorrect", .notReached),
      ("footprintCorrect", .notReached),
      ("authorityCorrect", .notReached),
      ("accountingCorrect", .notReached),
      ("compositionCompatible", .notApplicable),
      ("assumptionsDeclared", .«true»),
      ("libraryTheoremsInstantiated", .notApplicable),
      ("sourceRefinement", .notApplicable)
    ]
    ⟨.refused, some ⟨.staleSource, "git", some rawCert.source_pin.git⟩, makeJudgments jmap claimed,
     preWorld, none, [], [], 0, none, assumptionsList, outstanding, rawCert.source_pin, rawCert.audit_roots, none⟩
  else
    let registry := registryToTyped payload.registry
    let store := storeToTyped payload.store
    let ctx := payload.ctx.toContext
    let env := envToTyped payload.env
    let now := payload.now
    let request := payload.request.toRequest
    match stateToTyped? payload.state with
    | none =>
      ⟨.refused, some ⟨.kernel, "stateNonneg", none⟩, [], preWorld, none, [], [], 0, none, assumptionsList, outstanding, rawCert.source_pin, rawCert.audit_roots, none⟩
    | some state =>
      -- M02 context setup
      let cert : CertContext := ⟨
        rawCert.claimed_next_state.bind (fun w ↦ w.toWorld?.map (fun cw ↦ ⟨cw.state, cw.capabilities⟩)),
        rawCert.libraries,
        rawCert.invariants,
        rawCert.source_pin,
        rawCert.audit_roots
      ⟩

      -- Execute transition (M02 needle)
      let execResult : Except Refusal (Typed.ExecutionResult Party Asset Domain) := do
        let post ← Typed.execute registry store ctx env now request state
        return post

      -- Judgment recomputations
      let optTemplate := registry request.operation
      let (tc, fc, ac, acc) : JudgmentOutcome × JudgmentOutcome × JudgmentOutcome × JudgmentOutcome :=
        match optTemplate with
        | none => (.notReached, .notReached, .notReached, .notReached)
        | some template =>
          if request.claimedActor.isSome && request.claimedActor != some ctx.principal then
            (.notReached, .notReached, .notReached, .notReached)
          else if ctx.domain != template.domain || request.parties.length != template.partyArity then
            (.notReached, .notReached, .notReached, .notReached)
          else
            let typeCorrect := match Args.check template.signature request.arguments with | .ok _ => true | .error _ => false
            if !typeCorrect then
              (.«false», .notReached, .notReached, .notReached)
            else
              let hasInv := hasAuthority store request.capabilityIds ctx request.operation .invoke
              if !hasInv then
                (.«true», .notReached, .«false», .notReached)
              else
                match Args.check template.signature request.arguments with
                | .error _ => (.«true», .notReached, .notReached, .notReached)
                | .ok checkedArgs =>
                  match template.evaluate ⟨state, env, ctx.principal, request.parties, checkedArgs, now⟩ with
                  | .error _ => (.«true», .notReached, .«true», .notReached)
                  | .ok eval =>
                    let fp := eval.stateReadsOK && eval.envReadsOK && eval.domainOK ctx.domain
                    let deb := eval.debitsOK store request ctx && eval.suppliesOK store request ctx
                    if !fp then
                      (.«true», .«false», .«true», .notReached)
                    else if !deb then
                      (.«true», .«true», .«false», .notReached)
                    else
                      let balNonneg := decide (∀ c, 0 ≤ state.balance c + eval.effect c)
                      let wr := eval.writesOK
                      let accOK := eval.accountingOK && balNonneg
                      if !accOK then
                        (.«true», .«true», .«true», .«false»)
                      else if !wr then
                        (.«true», .«false», .«true», .«true»)
                      else
                        (.«true», .«true», .«true», .«true»)

      -- M09 and M10 needles
      let libraryTheoremsInstantiated := if cert.libraries.isEmpty then JudgmentOutcome.notApplicable else JudgmentOutcome.true
      let sourceRefinement := if cert.invariants.isEmpty then JudgmentOutcome.notApplicable else JudgmentOutcome.notApplicable

      let jmap : List (String × JudgmentOutcome) := [
        ("typeCorrect", tc),
        ("footprintCorrect", fc),
        ("authorityCorrect", ac),
        ("accountingCorrect", acc),
        ("compositionCompatible", .notApplicable),
        ("assumptionsDeclared", .«true»),
        ("libraryTheoremsInstantiated", libraryTheoremsInstantiated),
        ("sourceRefinement", sourceRefinement)
      ]
      let judgments := makeJudgments jmap claimed

      match execResult with
      | .error r =>
        let failPath := (refusalToLocatedFailure r).reason
        ⟨.refused, some failPath, judgments, preWorld, none, [], [], 0, none, assumptionsList, outstanding, cert.source_pin, cert.audit_roots, none⟩
      | .ok post =>
        let postWorld := executionResultToWorld post payload.state
        let postReceipt : Option ReceiptEnc :=
          match optTemplate with
          | some tmpl =>
            match Args.check tmpl.signature request.arguments with
            | .ok checkedArgs =>
              match tmpl.evaluate ⟨state, env, ctx.principal, request.parties, checkedArgs, now⟩ with
              | .ok e => some (evaluatedToEnc e request)
              | .error _ => none
            | .error _ => none
          | none => none
        match missingAssump with
        | some missingClass =>
          ⟨.incomplete, some ⟨.incompleteObligation, missingClass, none⟩, judgments,
           postWorld, postReceipt, [], [], 0, none, assumptionsList, outstanding, cert.source_pin, cert.audit_roots, none⟩
        | none =>
          -- Claimed next state observation mismatch check (F36)
          match rawCert.claimed_next_state with
          | some claimedWorld =>
            if claimedWorld != postWorld then
              ⟨.refused, some ⟨.observationMismatch, "claimedNextState", none⟩, judgments,
               postWorld, postReceipt, [], [], 0, none, assumptionsList, outstanding, cert.source_pin, cert.audit_roots, none⟩
            else
              ⟨.accepted, none, judgments, postWorld, postReceipt, [], [], 0, none, assumptionsList, outstanding, cert.source_pin, cert.audit_roots, none⟩
          | none =>
            ⟨.accepted, none, judgments, postWorld, postReceipt, [], [], 0, none, assumptionsList, outstanding, cert.source_pin, cert.audit_roots, none⟩

/-- Composition single-step checker. -/
def checkStep (cert : EnvelopeEnc) (payload : CompositionStepPayloadEnc) : Report :=
  let preWorld := payload.pre
  let (assumptionsList, _) := computeAssumptions cert
  let claimed := parseClaimedJudgments cert.claimed_judgments
  let outstanding := outstandingFamilies cert
  match configToTyped? payload.config with
  | none =>
    ⟨.refused, some ⟨.configuration, "configuration", none⟩, [], preWorld, none, [], [], payload.index, none, assumptionsList, outstanding, cert.source_pin, cert.audit_roots, none⟩
  | some cfg =>
    match payload.pre.toWorld? with
    | none =>
      ⟨.refused, some ⟨.kernel, "stateNonneg", none⟩, [], preWorld, none, [], [], payload.index, none, assumptionsList, outstanding, cert.source_pin, cert.audit_roots, none⟩
    | some preW =>
      let boundary := boundaryToTyped payload.boundary
      let history := payload.history.map OutputObservationEnc.toOutputObservation
      let stepInvs := invokeSteps [payload.step]
      let compatOut := compositionCompatibleOutcome cfg boundary stepInvs
      match payload.step.toStep? with
      | none =>
        ⟨.refused, some ⟨.interface, "unknownStep", none⟩, [], preWorld, none, [], [], payload.index, none, assumptionsList, outstanding, cert.source_pin, cert.audit_roots, none⟩
      | some step =>
        match Composition.executeStep cfg boundary payload.index history step preW with
        | .error fail =>
          let failPath := failureToPath fail
          let cursorFail : Option LocatedFailureEnc := match fail with
            | .configuration => some ⟨payload.index, none, ⟨.configuration, "configuration", none⟩⟩
            | _ => none
          let jmap : List (String × JudgmentOutcome) := [
            ("typeCorrect", .notReached),
            ("footprintCorrect", .notReached),
            ("authorityCorrect", .notReached),
            ("accountingCorrect", .notReached),
            ("compositionCompatible", .«false»),
            ("assumptionsDeclared", .«true»),
            ("libraryTheoremsInstantiated", .notApplicable),
            ("sourceRefinement", .notApplicable)
          ]
          ⟨.refused, some failPath, makeJudgments jmap claimed, preWorld, none, [], [], payload.index, cursorFail, assumptionsList, outstanding, cert.source_pin, cert.audit_roots, none⟩
        | .ok res =>
          let postWorld : WorldEnc := ⟨⟨payload.pre.state.cells.map (fun row ↦
            let b := res.world.state.balance (row.domain, row.party, row.asset)
            ⟨row.domain, row.party, row.asset, ⟨b.num, b.den⟩⟩)⟩, storeToEnc res.world.capabilities⟩
          let receiptEnc : ReceiptEnc :=
            match res.receipt with
            | .invoked req e => evaluatedToEnc e req
            | .issued id => .issued id.value
            | .revoked id => .revoked id.value
          let outputsEnc := res.outputs.map OutputObservationEnc.fromOutputObservation
          let isIssueRevoke := match step with | .issue _ | .revoke _ => true | _ => false
          let jmap : List (String × JudgmentOutcome) := [
            ("typeCorrect", if isIssueRevoke then .notApplicable else .«true»),
            ("footprintCorrect", if isIssueRevoke then .notApplicable else .«true»),
            ("authorityCorrect", .«true»),
            ("accountingCorrect", if isIssueRevoke then .notApplicable else .«true»),
            ("compositionCompatible", compatOut),
            ("assumptionsDeclared", .«true»),
            ("libraryTheoremsInstantiated", .notApplicable),
            ("sourceRefinement", .notApplicable)
          ]
          ⟨.accepted, none, makeJudgments jmap claimed, postWorld, some receiptEnc, outputsEnc, [], payload.index, none, assumptionsList, outstanding, cert.source_pin, cert.audit_roots, none⟩

/-- Composition run checker. -/
def checkRun (cert : EnvelopeEnc) (payload : CompositionRunPayloadEnc) : Report :=
  let preWorld := payload.world
  let (assumptionsList, _) := computeAssumptions cert
  let claimed := parseClaimedJudgments cert.claimed_judgments
  let outstanding := outstandingFamilies cert
  match configToTyped? payload.config with
  | none =>
    ⟨.refused, some ⟨.configuration, "configuration", none⟩, [], preWorld, none, [], [], 0, none, assumptionsList, outstanding, cert.source_pin, cert.audit_roots, none⟩
  | some cfg =>
    match payload.world.toWorld? with
    | none =>
      ⟨.refused, some ⟨.kernel, "stateNonneg", none⟩, [], preWorld, none, [], [], 0, none, assumptionsList, outstanding, cert.source_pin, cert.audit_roots, none⟩
    | some initialWorld =>
      let bList := payload.boundaries.map boundaryToTyped
      let defaultBoundary : Composition.Boundary Party Asset Domain :=
        ⟨⟨.alice, .main⟩, fun _ ↦ none, 100⟩
      let boundaries : Nat → Composition.Boundary Party Asset Domain :=
        fun idx ↦ match bList[idx]? with
        | some b => b
        | none => bList.head?.getD defaultBoundary
      let steps : List (Composition.Step Party Asset Domain) :=
        payload.steps.filterMap StepEnc.toStep?
      let runInvs := invokeSteps payload.steps
      let compatOut := compositionCompatibleOutcome cfg (boundaries 0) runInvs

        let cursor := Composition.run cfg boundaries initialWorld steps
        let postWorld : WorldEnc := ⟨⟨payload.world.state.cells.map (fun row ↦
          let b := cursor.world.state.balance (row.domain, row.party, row.asset)
          ⟨row.domain, row.party, row.asset, ⟨b.num, b.den⟩⟩)⟩, storeToEnc cursor.world.capabilities⟩
        let outputsEnc := cursor.outputs.map OutputObservationEnc.fromOutputObservation
        let eventsEnc : List SequentialEventEnc := cursor.events.map (fun ev ↦
          let stepEnc := StepEnc.fromStep ev.step
          let bWorld : WorldEnc := ⟨⟨payload.world.state.cells.map (fun row ↦
            let b := ev.before.state.balance (row.domain, row.party, row.asset)
            ⟨row.domain, row.party, row.asset, ⟨b.num, b.den⟩⟩)⟩, storeToEnc ev.before.capabilities⟩
          let aWorld : WorldEnc := ⟨⟨payload.world.state.cells.map (fun row ↦
            let b := ev.result.world.state.balance (row.domain, row.party, row.asset)
            ⟨row.domain, row.party, row.asset, ⟨b.num, b.den⟩⟩)⟩, storeToEnc ev.result.world.capabilities⟩
          let receiptEnc : ReceiptEnc :=
            match ev.result.receipt with
            | .invoked req e => evaluatedToEnc e req
            | .issued id => .issued id.value
            | .revoked id => .revoked id.value
          let stepOutputs := ev.result.outputs.map OutputObservationEnc.fromOutputObservation
          ⟨ev.index, stepEnc, bWorld, ⟨aWorld, receiptEnc, stepOutputs⟩⟩)

        let lastReceipt : Option ReceiptEnc :=
          cursor.events.getLast?.bind (fun ev ↦
            match ev.result.receipt with
            | .invoked req e => some (evaluatedToEnc e req)
            | .issued id => some (.issued id.value)
            | .revoked id => some (.revoked id.value))

        match cursor.failure with
        | some lf =>
          let failPath := failureToPath lf.reason
          let stepEnc : Option StepEnc := lf.step.map StepEnc.fromStep
          let cursorFail : LocatedFailureEnc := ⟨lf.index, stepEnc, failPath⟩
          let jmap : List (String × JudgmentOutcome) := [
            ("typeCorrect", .«true»),
            ("footprintCorrect", .«true»),
            ("authorityCorrect", .«true»),
            ("accountingCorrect", .«false»),
            ("compositionCompatible", compatOut),
            ("assumptionsDeclared", .«true»),
            ("libraryTheoremsInstantiated", .notApplicable),
            ("sourceRefinement", .notApplicable)
          ]
          ⟨.refused, some failPath, makeJudgments jmap claimed, postWorld, lastReceipt, outputsEnc, eventsEnc, cursor.nextIndex, some cursorFail, assumptionsList, outstanding, cert.source_pin, cert.audit_roots, none⟩
        | none =>
          let jmap : List (String × JudgmentOutcome) := [
            ("typeCorrect", .«true»),
            ("footprintCorrect", .«true»),
            ("authorityCorrect", .«true»),
            ("accountingCorrect", .«true»),
            ("compositionCompatible", compatOut),
            ("assumptionsDeclared", .«true»),
            ("libraryTheoremsInstantiated", .notApplicable),
            ("sourceRefinement", .notApplicable)
          ]
          ⟨.accepted, none, makeJudgments jmap claimed, postWorld, lastReceipt, outputsEnc, eventsEnc, cursor.nextIndex, none, assumptionsList, outstanding, cert.source_pin, cert.audit_roots, none⟩

/-- Raw execution observation without policy or source-pin guards. -/
def rawExecute (exec : DecodedExecution) : RawObservation :=
  match exec with
  | .typed _ payload =>
    let preWorld : WorldEnc := ⟨payload.state, payload.store⟩
    let registry := registryToTyped payload.registry
    let store := storeToTyped payload.store
    let ctx := payload.ctx.toContext
    let env := envToTyped payload.env
    let now := payload.now
    let request := payload.request.toRequest
    match stateToTyped? payload.state with
    | none =>
      ⟨preWorld, none, [], [], 0, none, some ⟨.kernel, "stateNonneg", none⟩⟩
    | some state =>
      let optTemplate := registry request.operation
      match Typed.execute registry store ctx env now request state with
      | .ok post =>
        let postWorld := executionResultToWorld post payload.state
        let postReceipt : Option ReceiptEnc :=
          match optTemplate with
          | some tmpl =>
            match Args.check tmpl.signature request.arguments with
            | .ok checkedArgs =>
              match tmpl.evaluate ⟨state, env, ctx.principal, request.parties, checkedArgs, now⟩ with
              | .ok e => some (evaluatedToEnc e request)
              | .error _ => none
            | .error _ => none
          | none => none
        ⟨postWorld, postReceipt, [], [], 0, none, none⟩
      | .error r =>
        ⟨preWorld, none, [], [], 0, none, some (refusalToLocatedFailure r).reason⟩

  | .step _ payload =>
    let preWorld := payload.pre
    match configToTyped? payload.config with
    | none =>
      ⟨preWorld, none, [], [], payload.index, none, some ⟨.configuration, "configuration", none⟩⟩
    | some cfg =>
      match payload.pre.toWorld? with
      | none =>
        ⟨preWorld, none, [], [], payload.index, none, some ⟨.kernel, "stateNonneg", none⟩⟩
      | some pre =>
        let boundary := boundaryToTyped payload.boundary
        match payload.step.toStep? with
        | none =>
          ⟨preWorld, none, [], [], payload.index, none, some ⟨.interface, "unknownStep", none⟩⟩
        | some step =>
          let hist := payload.history.map OutputObservationEnc.toOutputObservation
          match Composition.executeStep cfg boundary payload.index hist step pre with
          | .ok res =>
            let postWorld : WorldEnc := ⟨⟨payload.pre.state.cells.map (fun row ↦
              let b := res.world.state.balance (row.domain, row.party, row.asset)
              ⟨row.domain, row.party, row.asset, ⟨b.num, b.den⟩⟩)⟩, storeToEnc res.world.capabilities⟩
            let receiptEnc : ReceiptEnc :=
              match res.receipt with
              | .invoked req e => evaluatedToEnc e req
              | .issued id => .issued id.value
              | .revoked id => .revoked id.value
            let outputsEnc := res.outputs.map OutputObservationEnc.fromOutputObservation
            ⟨postWorld, some receiptEnc, outputsEnc, [], 0, none, none⟩
          | .error f =>
            ⟨preWorld, none, [], [], payload.index, none, some (failureToPath f)⟩

  | .run _ payload =>
    let preWorld := payload.world
    match configToTyped? payload.config with
    | none =>
      ⟨preWorld, none, [], [], 0, none, some ⟨.configuration, "configuration", none⟩⟩
    | some cfg =>
      match payload.world.toWorld? with
      | none =>
        ⟨preWorld, none, [], [], 0, none, some ⟨.kernel, "stateNonneg", none⟩⟩
      | some initialWorld =>
        let bList := payload.boundaries.map boundaryToTyped
        let defaultBoundary : Composition.Boundary Party Asset Domain :=
          ⟨⟨.alice, .main⟩, fun _ ↦ none, 100⟩
        let boundaries : Nat → Composition.Boundary Party Asset Domain :=
          fun idx ↦ match bList[idx]? with
          | some b => b
          | none => bList.head?.getD defaultBoundary
        let steps : List (Composition.Step Party Asset Domain) :=
          payload.steps.filterMap StepEnc.toStep?
          let cursor := Composition.run cfg boundaries initialWorld steps
          let postWorld : WorldEnc := ⟨⟨payload.world.state.cells.map (fun row ↦
            let b := cursor.world.state.balance (row.domain, row.party, row.asset)
            ⟨row.domain, row.party, row.asset, ⟨b.num, b.den⟩⟩)⟩, storeToEnc cursor.world.capabilities⟩
          let outputsEnc := cursor.outputs.map OutputObservationEnc.fromOutputObservation
          let eventsEnc : List SequentialEventEnc := cursor.events.map (fun ev ↦
            let stepEnc := StepEnc.fromStep ev.step
            let bWorld : WorldEnc := ⟨⟨payload.world.state.cells.map (fun row ↦
              let b := ev.before.state.balance (row.domain, row.party, row.asset)
              ⟨row.domain, row.party, row.asset, ⟨b.num, b.den⟩⟩)⟩, storeToEnc ev.before.capabilities⟩
            let aWorld : WorldEnc := ⟨⟨payload.world.state.cells.map (fun row ↦
              let b := ev.result.world.state.balance (row.domain, row.party, row.asset)
              ⟨row.domain, row.party, row.asset, ⟨b.num, b.den⟩⟩)⟩, storeToEnc ev.result.world.capabilities⟩
            let receiptEnc : ReceiptEnc :=
              match ev.result.receipt with
              | .invoked req e => evaluatedToEnc e req
              | .issued id => .issued id.value
              | .revoked id => .revoked id.value
            let stepOutputs := ev.result.outputs.map OutputObservationEnc.fromOutputObservation
            ⟨ev.index, stepEnc, bWorld, ⟨aWorld, receiptEnc, stepOutputs⟩⟩)
          let lastReceipt : Option ReceiptEnc :=
            cursor.events.getLast?.map fun ev ↦
              match ev.result.receipt with
              | .invoked req e => evaluatedToEnc e req
              | .issued id => .issued id.value
              | .revoked id => .revoked id.value
          let cursorFail : Option LocatedFailureEnc :=
            cursor.failure.map fun cf ↦
              let stepEnc := cf.step.map StepEnc.fromStep
              ⟨cf.index, stepEnc, failureToPath cf.reason⟩
          let kernFail := cursor.failure.map (fun cf ↦ failureToPath cf.reason)
          ⟨postWorld, lastReceipt, outputsEnc, eventsEnc, cursor.nextIndex, cursorFail, kernFail⟩

def checkAudit (a : DecodedAudit) : AuditResult :=
  if a.imported_theorems == some 0 then
    ⟨.blocked, some "emptyScope", [], none⟩
  else if a.forbidden_claimed_roots.isSome then
    ⟨.passed, none, [], some false⟩
  else
    let pfxs := if !a.commands.isEmpty then
      a.commands.filterMap fun cmd =>
        if cmd.startsWith "#audit_axioms " then
          some (cmd.drop "#audit_axioms ".length |>.toString)
        else none
    else
      match a.auditPrefix with
      | some p => [p]
      | none => ["DefiKernel"]
    ⟨.passed, none, pfxs, none⟩

def checkIR (ir : DecodedIR) : Outcome :=
  match ir with
  | .execution (.typed env payload) => .execution (checkTyped env payload)
  | .execution (.step env payload) => .execution (checkStep env payload)
  | .execution (.run env payload) => .execution (checkRun env payload)
  | .audit a => .audit (checkAudit a)
  | .codec doc => .codec (.ok (.codec doc))

def checkBytes (bytes : ByteArray) : Outcome :=
  match decodeBytes bytes with
  | .error (.resourceLimit limit) => .codec (.blocked limit)
  | .error e => .codec (.malformed e)
  | .ok ir => checkIR ir

def checkCertificate (exec : DecodedExecution) : Outcome :=
  checkIR (.execution exec)

def checkCertificateBytes (bytes : ByteArray) : Outcome :=
  checkBytes bytes

end DefiKernel.Certificates



/-! Observation and equality functions for certificates, reports, and execution outcomes.
Includes needle M11 comparing failure constructor identity. -/
namespace DefiKernel.Certificates

/-- Execution report equality comparison with needle M11. -/
def reportEq (r other : Report) : Bool :=
  let failure := r.failure
  decide (
    r.status = other.status ∧
    failure = other.failure ∧
    r.judgments = other.judgments ∧
    r.world = other.world ∧
    r.receipt = other.receipt ∧
    r.outputs = other.outputs ∧
    r.events = other.events ∧
    r.nextIndex = other.nextIndex ∧
    r.cursorFailure = other.cursorFailure ∧
    r.assumptions = other.assumptions ∧
    r.outstanding = other.outstanding ∧
    r.source_pin = other.source_pin ∧
    r.audit_roots = other.audit_roots ∧
    r.unsupported = other.unsupported
  )

def codecEq (c other : CodecResult) : Bool :=
  decide (c = other)

def auditEq (a other : AuditResult) : Bool :=
  decide (a = other)

def worldEq (w other : WorldEnc) : Bool :=
  decide (w = other)

def outcomeEq (o other : Outcome) : Bool :=
  decide (o = other)


end DefiKernel.Certificates


namespace DefiKernel.Certificates.Tests

open DefiKernel.Certificates

def defaultSourcePin : SourcePinEnc := {
  git := "a12b7cac05a818cc8d35c2ca440b7170a2807e92"
  lean_toolchain := "leanprover/lean4:v4.33.0-rc2"
  mathlib_rev := "51e6992efd06126df61a496bebf8f49482a4e129"
  checker_candidate := "unimplemented"
  compiler_record := none
  audit_record := none
}

def defaultAuditRoots : List String := [
  "DefiKernel.Certificates",
  "DefiKernel.Typed",
  "DefiKernel.Composition"
]

def defaultEnvelope : EnvelopeEnc := {
  schema_version := 1
  mode := "typed-execute"
  source_pin := defaultSourcePin
  audit_roots := defaultAuditRoots
  types := {
    parties := [.alice, .bob, .vault, .pool]
    assets := [.usd, .share, .collateral, .debt]
    domains := [.main, .other]
  }
  assumptions := [
    "registry-trust",
    "administrator-trust",
    "context-authenticity",
    "observation-truth",
    "environment-authenticity",
    "replay-prevention-outside-model"
  ]
  invariants := []
  libraries := []
  source_map := [("transfer", "lean/DefiKernel/Typed/Examples.lean:transfer")]
  claimed_judgments := []
  claimed_next_state := none
  require_library_discharge := false
  require_invariant_discharge := false
}

def initialCells : List StateCellEnc :=
  let spec : List ((Domain × Party × Asset) × RatEnc) := [
    ((.main, .alice, .usd), ⟨10, 1⟩),
    ((.main, .alice, .share), ⟨4, 1⟩),
    ((.main, .alice, .collateral), ⟨10, 1⟩),
    ((.main, .alice, .debt), ⟨2, 1⟩),
    ((.main, .vault, .usd), ⟨20, 1⟩),
    ((.main, .pool, .usd), ⟨100, 1⟩)
  ]
  let domains : List Domain := [.main, .other]
  let parties : List Party := [.alice, .bob, .vault, .pool]
  let assets : List Asset := [.usd, .share, .collateral, .debt]
  domains.flatMap fun d ↦
    parties.flatMap fun p ↦
      assets.map fun a ↦
        let amt := match spec.find? (·.1 == (d, p, a)) with
          | some (_, r) => r
          | none => ⟨0, 1⟩
        ⟨d, p, a, amt⟩

def initialStateEnc : StateEnc := ⟨initialCells⟩

def defaultStore12 : StoreEnc := ⟨[
  ⟨.alice, .main, 0, .invoke, true⟩,
  ⟨.alice, .main, 0, .debit ⟨.main, .alice, .usd⟩, true⟩,
  ⟨.alice, .main, 1, .invoke, true⟩,
  ⟨.alice, .main, 1, .debit ⟨.main, .alice, .usd⟩, true⟩,
  ⟨.alice, .main, 1, .changeSupply .main .share, true⟩,
  ⟨.alice, .main, 2, .invoke, true⟩,
  ⟨.alice, .main, 2, .debit ⟨.main, .vault, .usd⟩, true⟩,
  ⟨.alice, .main, 2, .debit ⟨.main, .alice, .share⟩, true⟩,
  ⟨.alice, .main, 2, .changeSupply .main .share, true⟩,
  ⟨.alice, .main, 3, .invoke, true⟩,
  ⟨.alice, .main, 3, .debit ⟨.main, .pool, .usd⟩, true⟩,
  ⟨.alice, .main, 3, .changeSupply .main .debt, true⟩
]⟩

def transferTemplate : TemplateEnc := {
  signature := [.numeric (.amount .usd)]
  domain := .main
  partyArity := 1
  guard := .binary (.le (.amount .usd)) (.lit ⟨.numeric (.amount .usd), 0, false⟩) (.arg 0 (.numeric (.amount .usd)))
  deltas := [
    ⟨.usd, ⟨.main, .caller⟩, .unary (.neg (.amount .usd)) (.arg 0 (.numeric (.amount .usd)))⟩,
    ⟨.usd, ⟨.main, .argument 0⟩, .arg 0 (.numeric (.amount .usd))⟩
  ]
  supplyDeltas := []
  stateReads := []
  envReads := []
  writes := [
    ⟨.usd, ⟨.main, .caller⟩⟩,
    ⟨.usd, ⟨.main, .argument 0⟩⟩
  ]
}

def vaultGuardedTransfer : TemplateEnc :=
  let t := transferTemplate
  let vaultBal : ExprEnc := .balance ⟨.usd, ⟨.main, .literal .vault⟩⟩
  let ge0 : ExprEnc := .binary (.le (.amount .usd)) (.lit ⟨.numeric (.amount .usd), 0, false⟩) vaultBal
  { t with
    guard := .binary .and t.guard ge0,
    stateReads := [⟨.usd, ⟨.main, .literal .vault⟩⟩]
  }

def observeTransfer : TemplateEnc :=
  let t := transferTemplate
  let key : ObservationKeyEnc := ⟨.main, 7⟩
  let obs : ExprEnc := .observe ⟨key, .numeric (.amount .usd)⟩
  { t with
    deltas := [
      ⟨.usd, ⟨.main, .caller⟩, .unary (.neg (.amount .usd)) obs⟩,
      ⟨.usd, ⟨.main, .argument 0⟩, obs⟩
    ],
    envReads := [.observation key]
  }

def unbalancedTemplate : TemplateEnc := {
  signature := []
  domain := .main
  partyArity := 0
  guard := .lit ⟨.bool, 0, true⟩
  deltas := [
    ⟨.usd, ⟨.main, .caller⟩, .unary (.neg (.amount .usd)) (.lit ⟨.numeric (.amount .usd), 3, false⟩)⟩,
    ⟨.usd, ⟨.main, .literal .bob⟩, .lit ⟨.numeric (.amount .usd), 4, false⟩⟩
  ]
  supplyDeltas := []
  stateReads := []
  envReads := []
  writes := [
    ⟨.usd, ⟨.main, .caller⟩⟩,
    ⟨.usd, ⟨.main, .literal .bob⟩⟩
  ]
}

def defaultRegistry : RegistryEnc := ⟨[
  ⟨0, transferTemplate⟩,
  ⟨4, vaultGuardedTransfer⟩,
  ⟨6, observeTransfer⟩
]⟩

def defaultContext : ContextEnc := ⟨.alice, .main⟩

def defaultRequest : RequestEnc := {
  operation := 0
  parties := [.bob]
  arguments := [⟨.numeric (.amount .usd), 3, false⟩]
  capabilityIds := [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11]
  claimedActor := none
}

def defaultPayload : TypedExecutePayloadEnc := {
  registry := defaultRegistry
  store := defaultStore12
  ctx := defaultContext
  env := ⟨[]⟩
  now := 100
  request := defaultRequest
  state := initialStateEnc
}

def catalogOk : List ComponentEnc := [
  {
    id := 0
    privateCells := [⟨.main, .bob, .usd⟩]
    exports := [⟨10, ⟨.main, .alice, .usd⟩, true⟩]
    imports := []
    operations := [{
      operation := 0
      inputs := [⟨0, .numeric (.amount .usd)⟩]
      outputs := [⟨1, ⟨.main, .alice, .usd⟩⟩]
    }]
  },
  {
    id := 1
    privateCells := [⟨.main, .vault, .usd⟩, ⟨.main, .alice, .share⟩]
    exports := []
    imports := [⟨⟨0, 10⟩, ⟨.main, .alice, .usd⟩, true⟩]
    operations := []
  },
  {
    id := 2
    privateCells := [⟨.main, .alice, .collateral⟩]
    exports := []
    imports := []
    operations := []
  }
]

def catalogDupIds : List ComponentEnc :=
  let other : ComponentEnc := {
    id := 0
    privateCells := [⟨.other, .pool, .debt⟩]
    exports := []
    imports := []
    operations := []
  }
  [catalogOk[0]!, other, catalogOk[1]!, catalogOk[2]!]

def catalogExportPrivate : List ComponentEnc :=
  let c0 := catalogOk[0]!
  let bad0 : ComponentEnc := { c0 with
    exports := [⟨10, ⟨.main, .alice, .usd⟩, true⟩, ⟨11, ⟨.main, .bob, .usd⟩, true⟩],
    operations := [{
      operation := 0,
      inputs := [⟨0, .numeric (.amount .usd)⟩],
      outputs := [⟨1, ⟨.main, .alice, .usd⟩⟩]
    }]
  }
  [bad0, catalogOk[1]!, catalogOk[2]!]

def catalogNoVaultRead : List ComponentEnc :=
  let c0 := catalogOk[0]!
  let c0' : ComponentEnc := { c0 with
    operations := c0.operations ++ [{
      operation := 4,
      inputs := [⟨2, .numeric (.amount .usd)⟩],
      outputs := [⟨3, ⟨.main, .alice, .usd⟩⟩]
    }]
  }
  [c0', catalogOk[1]!, catalogOk[2]!]

def defaultConfig : ConfigEnc := {
  registry := defaultRegistry
  domainAdmin := [⟨.main, .vault⟩, ⟨.other, .vault⟩]
  catalog := catalogOk
}

def defaultStep : StepEnc := .invoke {
  component := 0
  operation := 0
  parties := [.bob]
  inputs := [.literal ⟨.numeric (.amount .usd), 3, false⟩]
  capabilityIds := [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11]
  claimedActor := none
}

def defaultStepPayload : CompositionStepPayloadEnc := {
  config := defaultConfig
  boundary := ⟨defaultContext, ⟨[]⟩, 100⟩
  index := 0
  history := []
  step := defaultStep
  pre := ⟨initialStateEnc, defaultStore12⟩
}

-- 19 runtime comparison checks

def checkTypingRecomputed : Bool :=
  let rep := checkTyped { defaultEnvelope with claimed_judgments := ["typeCorrect"] }
    { defaultPayload with request := { defaultRequest with arguments := [⟨.numeric (.amount .share), 3, false⟩] } }
  rep.judgments.any (fun j => j.family == "typeCorrect" ∧ j.outcome == .«false»)

def checkTransferAlice7 : Bool :=
  let rep := checkTyped defaultEnvelope defaultPayload
  rep.status == .accepted ∧
  rep.world.state.cells.any (fun c => c.domain == .main ∧ c.party == .alice ∧ c.asset == .usd ∧ c.amount == ⟨7, 1⟩)

def checkExecuteRecomputed : Bool :=
  let rep := checkTyped { defaultEnvelope with claimed_next_state := some ⟨initialStateEnc, defaultStore12⟩ } defaultPayload
  rep.status == .refused ∧ rep.failure == some ⟨.observationMismatch, "claimedNextState", none⟩

def checkAccountingRecomputed : Bool :=
  let reg23 : RegistryEnc := ⟨defaultRegistry.entries ++ [⟨11, unbalancedTemplate⟩]⟩
  let st23 : StoreEnc := ⟨defaultStore12.entries ++ [
    ⟨.alice, .main, 11, .invoke, true⟩,
    ⟨.alice, .main, 11, .debit ⟨.main, .alice, .usd⟩, true⟩
  ]⟩
  let req23 : RequestEnc := {
    operation := 11
    parties := []
    arguments := []
    capabilityIds := [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13]
    claimedActor := none
  }
  let rep := checkTyped defaultEnvelope { defaultPayload with registry := reg23, store := st23, request := req23 }
  rep.failure == some ⟨.kernel, "accounting", none⟩

def checkAuthorityDebit : Bool :=
  let rep := checkTyped defaultEnvelope { defaultPayload with request := { defaultRequest with capabilityIds := [0] } }
  rep.failure == some ⟨.kernel, "unauthorizedDebit", none⟩

def checkCatalogNodup : Bool :=
  let rep := checkStep defaultEnvelope { defaultStepPayload with config := { defaultConfig with catalog := catalogDupIds } }
  rep.failure == some ⟨.configuration, "configuration", none⟩

def checkCatalogExportNotPrivate : Bool :=
  let rep := checkStep defaultEnvelope { defaultStepPayload with config := { defaultConfig with catalog := catalogExportPrivate } }
  rep.failure == some ⟨.configuration, "configuration", none⟩

def checkAccessReads : Bool :=
  let st47 : StoreEnc := ⟨defaultStore12.entries ++ [
    ⟨.alice, .main, 4, .invoke, true⟩,
    ⟨.alice, .main, 4, .debit ⟨.main, .alice, .usd⟩, true⟩
  ]⟩
  let step47 : StepEnc := .invoke {
    component := 0
    operation := 4
    parties := [.bob]
    inputs := [.literal ⟨.numeric (.amount .usd), 3, false⟩]
    capabilityIds := [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13]
    claimedActor := none
  }
  let rep := checkStep defaultEnvelope { defaultStepPayload with
    config := { defaultConfig with catalog := catalogNoVaultRead },
    step := step47,
    pre := ⟨initialStateEnc, st47⟩
  }
  rep.failure == some ⟨.interface, "readAccess", none⟩

def checkStepAlice7 : Bool :=
  let rep := checkStep defaultEnvelope defaultStepPayload
  rep.status == .accepted ∧
  rep.world.state.cells.any (fun c => c.domain == .main ∧ c.party == .alice ∧ c.asset == .usd ∧ c.amount == ⟨7, 1⟩)

def checkRationalCanonical : Bool :=
  match decodeRational 2 4 with
  | Except.error (DecodeFailure.illegalRational IllegalRationalReason.noncanonical) => true
  | _ => false

def checkRationalZeroDen : Bool :=
  match decodeRational 1 0 with
  | Except.error (DecodeFailure.illegalRational IllegalRationalReason.zeroDenominator) => true
  | _ => false

def checkPrecedenceActorMismatch : Bool :=
  let rep := checkTyped defaultEnvelope { defaultPayload with request := { defaultRequest with claimedActor := some .bob, capabilityIds := [] } }
  rep.failure == some ⟨.kernel, "actorMismatch", none⟩

def checkLibraryOutstanding : Bool :=
  let rep := checkTyped { defaultEnvelope with libraries := [⟨"asset_delta_balance", none⟩] } defaultPayload
  rep.judgments.any (fun j => j.family == "libraryTheoremsInstantiated" ∧ j.outcome == .notApplicable) ∧
  rep.outstanding.contains "libraryTheoremsInstantiated"

def checkPropNotExecutable : Bool :=
  let rep := checkTyped { defaultEnvelope with invariants := ["10 ≤ collateral"] } defaultPayload
  rep.judgments.any (fun j => j.family == "sourceRefinement" ∧ j.outcome == .notApplicable) ∧
  rep.outstanding.contains "proof.ComponentContract.invariant"

def checkRefusalConstructor : Bool :=
  let r1 : Report := {
    status := .refused
    failure := some ⟨.kernel, "insufficientFunds", none⟩
    judgments := []
    world := ⟨initialStateEnc, defaultStore12⟩
    receipt := none
    outputs := []
    events := []
    nextIndex := 0
    cursorFailure := none
    assumptions := []
    outstanding := []
    source_pin := defaultSourcePin
    audit_roots := defaultAuditRoots
  }
  let r2 : Report := { r1 with failure := some ⟨.kernel, "unauthorizedDebit", none⟩ }
  !reportEq r1 r2

def checkFundsInsufficient : Bool :=
  let rep := checkTyped defaultEnvelope { defaultPayload with request := { defaultRequest with arguments := [⟨.numeric (.amount .usd), 11, false⟩] } }
  rep.failure == some ⟨.kernel, "insufficientFunds", none⟩

def checkCapabilityFreshId : Bool :=
  let adminBoundary : BoundaryEnc := { ctx := ⟨.vault, .main⟩, env := ⟨[]⟩, now := 100 }
  let issueStep : StepEnc := .issue ⟨.bob, .main, 0, .invoke⟩
  let rep := checkStep defaultEnvelope { defaultStepPayload with boundary := adminBoundary, step := issueStep }
  rep.status == .accepted ∧ rep.receipt == some (.issued 12)

def checkEnvMissingObservation : Bool :=
  let st40 : StoreEnc := ⟨defaultStore12.entries ++ [
    ⟨.alice, .main, 6, .invoke, true⟩
  ]⟩
  let req40 : RequestEnc := { defaultRequest with
    operation := 6
    capabilityIds := [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12]
  }
  let rep := checkTyped defaultEnvelope { defaultPayload with
    store := st40,
    env := ⟨[]⟩,
    request := req40
  }
  rep.failure == some ⟨.kernel, "evaluation", some "missingObservation"⟩

def checkUnsupportedRejected : Bool :=
  let f53Step : Lean.Json := Lean.Json.mkObj [
    ("tag", Lean.Json.str "treeJoin"),
    ("invocation", Lean.Json.mkObj [
      ("component", Lean.Json.num 0),
      ("operation", Lean.Json.num 0),
      ("parties", Lean.Json.arr #[Lean.Json.str "bob"]),
      ("inputs", Lean.Json.arr #[Lean.Json.mkObj [
        ("tag", Lean.Json.str "literal"),
        ("value", Lean.Json.mkObj [
          ("unit", Lean.Json.mkObj [("tag", Lean.Json.str "amount"), ("asset", Lean.Json.str "usd")]),
          ("value", Lean.Json.mkObj [("num", Lean.Json.num 3), ("den", Lean.Json.num 1)])
        ])
      ]]),
      ("capabilityIds", Lean.Json.arr (#[0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11].map Lean.Json.num)),
      ("claimedActor", Lean.Json.null)
    ])
  ]
  match decodeStep f53Step with
  | Except.error (DecodeFailure.unsupportedForm _) => true
  | _ => false

def makeArrDoc (n : Nat) : String :=
  let zeros := String.intercalate "," (List.replicate n "0")
  "{\"arr\":[" ++ zeros ++ "]}"

def checkArrayLengthBoundaryRegression : Bool :=
  let test4095 := checkBytes (makeArrDoc 4095).toUTF8
  let test4096 := checkBytes (makeArrDoc 4096).toUTF8
  let test4097 := checkBytes (makeArrDoc 4097).toUTF8
  let ok4095 := match test4095 with | .codec (.malformed _) => true | _ => false
  let ok4096 := match test4096 with | .codec (.malformed _) => true | _ => false
  let ok4097 := match test4097 with | .codec (.blocked "max_array_length") => true | _ => false
  ok4095 && ok4096 && ok4097

def makeNestedDoc (depth : Nat) : String :=
  let openBraces := String.intercalate "" (List.replicate depth "{\"a\":")
  let closeBraces := String.intercalate "" (List.replicate depth "}")
  openBraces ++ "1" ++ closeBraces

def checkDepthBoundaryRegression : Bool :=
  let test63 := checkBytes (makeNestedDoc 63).toUTF8
  let test64 := checkBytes (makeNestedDoc 64).toUTF8
  let test65 := checkBytes (makeNestedDoc 65).toUTF8
  let ok63 := match test63 with | .codec (.malformed _) => true | _ => false
  let ok64 := match test64 with | .codec (.malformed _) => true | _ => false
  let ok65 := match test65 with | .codec (.blocked "maxDepth") => true | _ => false
  ok63 && ok64 && ok65

def checkTrustedGitDistinct : Bool :=
  TrustedHost.gitSha == "a12b7cac05a818cc8d35c2ca440b7170a2807e92" &&
  !(TrustedHost.compilerRecords.contains TrustedHost.gitSha) &&
  TrustedHost.recordStringAdmissible TrustedHost.gitSha TrustedHost.compilerRecords = false

def checkLibraryInstantiation : Bool :=
  LibraryInstantiation.instantiatedTheoremNames.contains
    "DefiKernel.Arithmetic.Operations.add_ok_iff" &&
  !LibraryInstantiation.namesDischarged [⟨"asset_delta_balance", none⟩] &&
  LibraryInstantiation.namesDischarged [⟨"DefiKernel.Arithmetic.Operations.add_ok_iff", none⟩]

def runtimeChecks : List (String × Bool) := [
  ("cert.typing.recomputed", checkTypingRecomputed),
  ("cert.transfer.alice7", checkTransferAlice7),
  ("cert.execute.recomputed", checkExecuteRecomputed),
  ("cert.accounting.recomputed", checkAccountingRecomputed),
  ("cert.authority.debit", checkAuthorityDebit),
  ("cert.catalog.nodup", checkCatalogNodup),
  ("cert.catalog.export-not-private", checkCatalogExportNotPrivate),
  ("cert.access.reads", checkAccessReads),
  ("cert.step.alice7", checkStepAlice7),
  ("cert.rational.canonical", checkRationalCanonical),
  ("cert.rational.zero-den", checkRationalZeroDen),
  ("cert.precedence.actor-mismatch", checkPrecedenceActorMismatch),
  ("cert.library.outstanding", checkLibraryOutstanding),
  ("cert.prop.not-executable", checkPropNotExecutable),
  ("cert.refusal.constructor", checkRefusalConstructor),
  ("cert.funds.insufficient", checkFundsInsufficient),
  ("cert.capability.fresh-id", checkCapabilityFreshId),
  ("cert.env.missing-observation", checkEnvMissingObservation),
  ("cert.unsupported.rejected", checkUnsupportedRejected),
  ("cert.boundary.array-length", checkArrayLengthBoundaryRegression),
  ("cert.boundary.nesting-depth", checkDepthBoundaryRegression),
  ("cert.host.git-distinct", checkTrustedGitDistinct),
  ("cert.library.instantiated", checkLibraryInstantiation)
]

end DefiKernel.Certificates.Tests


namespace DefiKernel.Certificates.Audit

def runtimeChecks : List (String × Bool) := Tests.runtimeChecks

def main : IO Unit := do
  let checks := runtimeChecks
  if checks.isEmpty then throw (IO.userError "Certificate runtime comparisons empty")
  if !(checks.map Prod.fst).Nodup then
    throw (IO.userError "Certificate runtime comparison names are duplicated")
  for (name, passed) in checks do IO.println s!"{name}: {passed}"
  let failures := checks.filter (!·.2) |>.map Prod.fst
  if !failures.isEmpty then
    throw (IO.userError s!"Certificate runtime comparisons failed: {failures.length}")

#eval main


end DefiKernel.Certificates.Audit
