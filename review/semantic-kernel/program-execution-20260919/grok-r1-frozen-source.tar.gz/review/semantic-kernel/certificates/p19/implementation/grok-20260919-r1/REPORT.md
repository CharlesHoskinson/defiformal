# P19 grok-20260919-r1: Valid TreeJson depth identity and typed-execute universal depth

- **Attempt**: `grok-20260919-r1`
- **Author**: Grok 4.6 (native implementation)
- **Checker**: pending independent GPT-6 Astra medium
- **Disposition**: `PARTIAL`
- **Build**: `DefiKernel.Certificates.IRDepth` and `DefiKernel.Certificates.Verify` compiled; Verify 940 jobs, forbidden axioms 0

## What this round proved

R28 left `h_depth` and `h_lex` open on
`decodeBytes_encodeModule_of_depth_and_lex`. Empty-registry lemmas and witness
depth do not close generic depth. This round proves the missing **representation
metric** between `TreeJson.depth` and `jsonDepth` for Valid trees, then uses
unchanged `WholeDocumentDepthBounded` to discharge `h_depth` for **every**
structurally admissible **typed-execute** module, including nonempty
registries and templates.

Core identity (any Valid tree, distinct keys required):

```lean
theorem jsonDepthFuel_toJson_eq_min (t : TreeJson) (fuel : Nat) (h : TreeJson.Valid t) :
    jsonDepthFuel fuel t.toJson = min fuel (TreeJson.depth t)
```

`Json.mkObj` stores `Std.TreeMap.Raw.ofList`. Duplicate keys drop earlier
values, so the object identity uses `Nodup` keys from `TreeJson.Valid`. Boolean
`Json` equality via private `beq'` is not used. Array fold uses
`Array.foldl_toList`. Object fold uses `TreeMap.Raw.foldl_eq_foldl_toList` and
`toList` permutation of `ofList` under distinct keys.

IR metric lemmas then equate `jsonDepthFuel` of `*ToJson` with
`(*ToTreeJson).toJson` when `mkObj` field order differs (world, request,
operation interface, component, config, typed payload, envelope). Child
`jsonDepthFuel` equality is enough; raw map shapes need not be equal.

## Strongest new theorem

```lean
theorem decodeBytes_encodeModule_typed_of_lex
    (env : EnvelopeEnc) (p : TypedExecutePayloadEnc)
    (h_adm : StructurallyAdmissibleIR (.execution (.typed env p)))
    (h_lex : scanLexical (encodeModule (.execution (.typed env p))) = .ok ()) :
    decodeBytes (encodeModule (.execution (.typed env p))) = .ok (.execution (.typed env p))
```

`h_depth` is gone for this family. `moduleToTreeJson_typed_depth_le_64` derives
`TreeJson.depth (moduleToTreeJson (.execution (.typed env p))) ≤ 64` from
`StructurallyAdmissibleIR` alone (hence from `WholeDocumentDepthBounded`).
Axioms: `propext`, `Classical.choice`, `Quot.sound` only.

This is strictly stronger than R28 `decodeBytes_encodeModule_typed_empty_registry`,
which still required `p.registry.entries = []`.

## Still open

1. **`h_lex`**: `scanLexical (encodeModule ir) = .ok ()` remains open for the
   full grammar (1 MiB, depth 64, collection 4096, arbitrary supported Unicode
   strings and rationals). R28 scalar step equations are unchanged. This round
   did not add structural `scanLexicalFuel` induction on encoded TreeJson
   (string/number buffers, key uniqueness, scope/array/depth, sufficient fuel).
2. **Composition-step and composition-run general depth**: envelope, world,
   boundary, config, and component metrics exist. Step/run payloads still need
   `stepToTreeJson` / history / invocation metric lemmas before
   `moduleToTreeJson_*_depth_le_64` can be stated for those modes. Empty-registry
   step/run lemmas from R28 remain the strongest for those modes.
3. **`EncodeDecodeRoundtripStatement`**: still the explicit `def Prop`
   `∀ ir, StructurallyAdmissibleIR ir → decodeBytes (encodeModule ir) = .ok ir`.
   Not proved. General strongest theorem is still
   `decodeBytes_encodeModule_of_depth_and_lex` with both `h_depth` and `h_lex`
   for mixed modes; typed-execute now drops `h_depth` only.
4. **P19/P20 acceptance**: not claimed. Unchanged 54/21/7 campaigns were not
   rerun.

## Source contract

- R28 Roundtrip 246 declarations preserved. One import of `DepthBridge` added
  at the top of `Roundtrip.lean`. No existing theorem statements, signatures,
  or docstrings changed.
- New modules: `lean/DefiKernel/Certificates/DepthBridge.lean`,
  `lean/DefiKernel/Certificates/IRDepth.lean`.
- `Verify.lean` imports `IRDepth`.
- No `sorry`, `native_decide`, custom axioms, `h_depth`/`h_lex` added to
  admission, or alternate codec.

## New compiled declarations

DepthBridge: 25 theorems plus one `RightCommutative` instance (26 declarations
in the inline axiom scan). IRDepth: 12 theorems. Combined 38 declarations, all
standard axioms only (plugin `check-axioms-inline --report-only`).

## Verification recorded this round

| Check | Result |
|---|---|
| Baseline `lake build DefiKernel.Certificates.Roundtrip` before edits | exit 0 |
| `lake build DefiKernel.Certificates.IRDepth` | exit 0, 935 jobs |
| `lake build DefiKernel.Certificates.Verify` | exit 0, 940 jobs, forbidden=0 |
| Axiom scan of new modules | 38/38 standard axioms only |
| LSP `lean_verify` of `jsonDepthFuel_toJson_eq_min`, `moduleToTreeJson_typed_depth_le_64`, `decodeBytes_encodeModule_typed_of_lex` | `propext`, `Classical.choice`, `Quot.sound` |

Toolchain remains Lean/mathlib `v4.33.0-rc2`. No `lake update`.
