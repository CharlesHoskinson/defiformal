#!/usr/bin/env python3
"""Unrecorded final seal for grok-20260919-r5. Writes REPORT/verdict/source-manifest/MANIFEST.
Self-excludes MANIFEST. Do not record this script or hash active streams."""
from pathlib import Path
import datetime
import hashlib
import json
import os
import subprocess

WORK = Path('/home/charl/defiformal-wt-p19-certificates-grok-opus-20260909')
EV = WORK / 'review/semantic-kernel/certificates/p19/implementation/grok-20260919-r5'


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def now() -> str:
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def write(path: Path, value) -> None:
    path.write_text(json.dumps(value, indent=2) + '\n')


def main() -> None:
    commands = json.loads((EV / 'commands.json').read_text())
    unfinished = [c['id'] for c in commands if 'finished_utc' not in c]
    if unfinished:
        raise SystemExit(f'refusing to seal with unfinished commands: {unfinished}')

    sources = {}
    for p in sorted((WORK / 'lean/DefiKernel/Certificates').rglob('*')):
        if p.is_file():
            rel = str(p.relative_to(WORK))
            sources[rel] = {'sha256': sha(p), 'bytes': p.stat().st_size}
    extra = [
        'lean/DefiKernel.lean',
        'lean/DefiKernel/Arithmetic/Operations.lean',
        'lean/DefiKernel/Arithmetic/Word.lean',
        'lean/DefiKernel/Parallel/Compatibility.lean',
        'lean/DefiKernel/Parallel/Examples.lean',
        'scripts/run_certificate_fixtures.py',
        'scripts/run_certificate_mutations.py',
        'scripts/run_all_p19_mutations.py',
        'scripts/test_certificate_fixture_runner.py',
        'scripts/test_certificate_mutation_runner.py',
        'openspec/changes/serialized-kernel-certificates/fixtures.json',
        'openspec/changes/serialized-kernel-certificates/grammar.json',
        'openspec/changes/serialized-kernel-certificates/schema.json',
        'openspec/changes/serialized-kernel-certificates/scenario-map.json',
        'openspec/changes/serialized-kernel-certificates/planned-mutations.json',
        'openspec/changes/serialized-kernel-certificates/correspondence-theorems.json',
        'openspec/changes/serialized-kernel-certificates/judgment-contract.json',
        'lean/DefiKernel/Certificates/trusted-host-records.json',
        str((EV / 'correspondence-inventory.json').relative_to(WORK)),
        str((EV / 'new-changed-inventory.json').relative_to(WORK)),
    ]
    for rel in extra:
        p = WORK / rel
        if p.is_file():
            sources[rel] = {'sha256': sha(p), 'bytes': p.stat().st_size}

    source_manifest = {
        'schema': 'defiformal-p19-source-manifest/v2',
        'time_utc': now(),
        'attempt': 'grok-20260919-r5',
        'files': sources,
        'planning_identity': {
            'task_accepted': '20.1',
            'archive_sha256': 'e73a61d9c98256270696ead1c3c554b070f100075b76d594d4ec251636ee5e5a',
            'review_sha256': '5fab03cdac0d6e396b3e28fbde94d4f631c5c29d73d77ce1233c01c6dc24dddb',
            'accepted_inputs_sha256': '8c76c3d2ed88d16824d1beac6eaa044e58b1a00344421f26e3c70a9b666dea39',
            'STATUS_gate_accepted': False
        }
    }
    write(EV / 'source-manifest.json', source_manifest)

    git_head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=str(WORK), text=True).strip()
    lean_ver = subprocess.check_output(
        ['/home/charl/.elan/toolchains/leanprover--lean4---v4.33.0-rc2/bin/lean', '--version'],
        text=True).strip()

    report = (EV / 'REPORT.md').read_text()
    verdict = {
        'schema': 'defiformal-p19-verdict/v1',
        'attempt': 'grok-20260919-r5',
        'author': 'grok-4.6',
        'auditor': 'pending gpt-6-astra medium',
        'disposition': 'PARTIAL',
        'self_accepted': False,
        'P19_accepted': False,
        'P20_accepted': False,
        'P37_accepted': False,
        'git_head': git_head,
        'lean_version': lean_ver,
        'commands': len(commands),
        'source_manifest_sha256': sha(EV / 'source-manifest.json'),
        'report_sha256': hashlib.sha256(report.encode()).hexdigest(),
        'sealed_utc': now()
    }
    write(EV / 'verdict.json', verdict)

    manifest = {}
    for p in sorted(EV.rglob('*')):
        if not p.is_file():
            continue
        if p.name == 'MANIFEST.json':
            continue
        rel = str(p.relative_to(EV))
        manifest[rel] = {'sha256': sha(p), 'bytes': p.stat().st_size}
    write(EV / 'MANIFEST.json', {
        'schema': 'defiformal-p19-r5-manifest/v1',
        'time_utc': now(),
        'self_excluded': 'MANIFEST.json',
        'files': manifest
    })
    print('sealed', EV)


if __name__ == '__main__':
    main()
