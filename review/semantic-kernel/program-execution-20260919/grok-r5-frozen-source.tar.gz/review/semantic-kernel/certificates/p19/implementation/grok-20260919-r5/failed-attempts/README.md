# R5 failed recorded commands (preserved)

Compiler retries with nonzero exit are retained under `logs/`:

- `compile-library-instantiation` — addHolds_iff extra constructor; namesDischarged_ignores_module type
- `compile-kernel-correspondence` r1–r3 — dsimp/let-binding proofs; remaining typed sequential fields
- `compile-compat-examples` r1–r3 — Schema.Party versus Typed.Examples.Party; PUnit universe; admit unfold
- `compile-tests` — PUnit universe in checkAdmitDisjointSuccess
- `compile-verify` r1–r3 — CompatibilityExamples then Audit `cert.admit.examples-conflict` (peerUSD cells were disjoint)
- `axioms-new-r5` — printed new axioms (standard only) then unknown `encode_decode_roundtrip` without Correspondence import

Do not treat these exits as semantic detections.
