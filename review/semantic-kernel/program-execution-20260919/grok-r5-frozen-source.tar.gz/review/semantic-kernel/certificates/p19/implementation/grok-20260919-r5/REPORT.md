# P19 grok-20260919-r5: library instantiation and delivered correspondence

- **Attempt**: `grok-20260919-r5`
- **Author**: Grok 4.6 (native implementation)
- **Checker**: pending independent GPT-6 Astra medium
- **Disposition**: `PARTIAL`
- **Build**: `DefiKernel.Certificates.Verify` 955 jobs, forbidden axioms 0
- **Self-accepted**: no

## Scope of this round

R4 remains independently rejected. This round repairs R4 findings that root confirmed, without rewriting frozen original specs and without changing historical theorem statements.

Production CLI (`RunFixtures` `check` / `observation-pair`) now calls `DefiKernel.Certificates.Delivered.checkBytes`. Legacy `checkTyped` / `checkIR` / `checkBytes` remain for preserved Soundness statements.

## Library instantiation (task 21.3)

`LibraryInstantiation.instantiated_add_ok_iff` and `namesDischarged` are unchanged.

New binding:

- Operands are extracted from the typed payload (recipient pre-cell + request amount) and the claimed or recomputed post-cell.
- `Operations.add` is executed on those `Word 64` values.
- Discharge requires theorem name `DefiKernel.Arithmetic.Operations.add_ok_iff`, optional module `DefiKernel.Arithmetic.Operations`, and compiler record `TrustedHost.arithmeticAddCompilerRecord`.
- Name-only, operand substitution (amount 4), claim substitution (bob 4), wrong module, absent/null record, mismatched record, and git-string record all fail.
- Transfer-three credit `0+3=3` and debit conservation `7+3=10` are Lean theorems instantiating `add_ok_iff`.

`libraryJudgment` (legacy helper) is fail-closed: nonempty libraries stay `notApplicable`. M09 needle in `checkTyped` is preserved. Delivered reports use `familyBound`.

Runtime Audit `#eval`: 38 named checks true, including the new library and delivered checks.

## Quantified correspondence (task 21.1)

Historical `checkIR_execute_ok` / `_error` / step / run names remain definitional dispatch.

New `Delivered` theorems (see `correspondence-inventory.json`):

- `rawExecute_typed_ok_complete` / `_error_complete` versus `Typed.execute`
- `checkTyped_source_identity_git_guard` (stale git: refused, pre-world, null receipt, no kernel fields)
- `checkTyped_from_raw_typed_ok` / `_error`: after `sourceIdentity`, kernel fields equal `rawExecute`; does not imply `accepted`
- `checkTyped_claimed_next_state_mismatch`
- `checkTyped_report_accepted_from_raw_and_policy` with explicit source identity, six-class, claimed-world, and discharge premises
- `checkStep_from_raw_ok`, `checkRun_from_raw_cursor`
- `decode_error_no_execute` on the delivered entry

Delivered `sourceIdentity` requires git, lean_toolchain, mathlib_rev, and `TrustedHost.recordsMatch` (wrong compiler_record fails). Legacy `checkTyped` still guards git only so `checkTyped_execute_ok` stays true.

`#print axioms` on new theorems: `propext` / `Classical.choice` / `Quot.sound` only.

## Compatibility (task 21.2)

Declared branches: catalog component 0 versus remaining components, each invoke analyzed at its original step index and boundary. Issue/revoke are not Parallel branches.

`checkRun` no longer uses `boundaries 0` for every invoke. `admitIndexed` recomputes footprints via `analyzeInvocation` then `checkCompatibility`.

Witnesses in `CompatibilityExamples`: disjoint usd/share `admit` success; overlapping usd-template write-write refusal. Caller footprint labels are not inputs.

## Host records and scenarios

`verify_trusted_host` now fails closed on missing file, malformed/empty JSON, empty dependencies, omitted required paths, and substituted hashes. Intact inventory count is 11. Recorded probe `host-records-controls` exit 0.

Scenario mapper no longer marks S13/S14/S80 verified from fixture pass flags. S78 is labelled as the R3 proved codec roundtrip, not a finite-fixture discharge of P20 execute correspondence.

Mutation `--bind-working-tree` `matches_git_head` is actual `cat-file` blob equality.

Canonical positive companion is Lean `checkCanonicalPositiveRoundtrip` (encode of a sorted-source_map IR). Original F13/F28 bytes are not rewritten.

## Recorded commands

21 recorded commands under `logs/`. Failures retained. Final Verify `compile-verify-r4` exit 0. No command after seal.

## Remaining gates (honest)

- Independent Astra review of this candidate
- Full 54-fixture and 16-mutant campaigns not rerun this round; production CLI routing may change issue/revoke `compositionCompatible` to `notApplicable`
- Receipt field of typed `rawExecute` is computed at runtime; the complete receipt equation is not in `rawExecute_typed_ok_complete`
- Component-0 versus remainder remains the declared Parallel split; intra-component sequential writes are not Parallel conflicts
- S13/S14/S80 remain open
- Claims/Tree/Nary/atomic/Quint stay `unsupportedForm`
- Qualified certificate delivery, parent publish, P19/P20/P37 acceptance remain open
- Roadmap through P37 stays open

This report does not accept the candidate.
