#!/usr/bin/env python3
"""Fail-closed trusted-host controls. Does not run the 54-fixture campaign."""
import json
import sys
import tempfile
from pathlib import Path

REPO = Path("/home/charl/defiformal-wt-p19-certificates-grok-opus-20260909")
sys.path.insert(0, str(REPO / "scripts"))
import run_certificate_fixtures as runner


def expect_fail(label, fn):
    try:
        fn()
    except SystemExit as e:
        print(f"PASS {label}: {e}")
        return True
    print(f"FAIL {label}: did not fail closed")
    return False


results = []
results.append(expect_fail("missing-file", lambda: runner.verify_trusted_host(REPO, "does-not-exist.json")))
with tempfile.TemporaryDirectory() as tmp:
    empty = Path(tmp) / "empty.json"
    empty.write_text("{}\n")
    rel = str(empty)  # absolute, not relative to repo
    results.append(expect_fail("empty-object-abs", lambda: runner.verify_trusted_host(REPO, rel)))

# omitted dependencies
with tempfile.TemporaryDirectory() as tmp:
    host = Path(tmp) / "partial.json"
    host.write_text(json.dumps({
        "kind": "certificates-trusted-host-records/v1",
        "git": runner.TRUSTED_GIT,
        "lean_toolchain": runner.TRUSTED_TOOLCHAIN,
        "mathlib_rev": runner.TRUSTED_MATHLIB,
        "grammar_sha256": runner.GRAMMAR_SHA256,
        "schema_sha256": runner.SCHEMA_SHA256,
        "dependencies": {}
    }))
    results.append(expect_fail("empty-dependencies", lambda: runner.verify_trusted_host(REPO, str(host))))

# intact required inventory
ok = runner.verify_trusted_host(REPO, "lean/DefiKernel/Certificates/trusted-host-records.json")
print("PASS intact:", json.dumps({k: ok[k] for k in ("dependency_count", "trusted_git", "grammar_sha256")}))
results.append(ok["dependency_count"] == 11)

# substituted hash
with tempfile.TemporaryDirectory() as tmp:
    host = Path(tmp) / "badhash.json"
    data = json.loads((REPO / "lean/DefiKernel/Certificates/trusted-host-records.json").read_text())
    first = next(iter(data["dependencies"]))
    data["dependencies"][first] = "0" * 64
    host.write_text(json.dumps(data))
    results.append(expect_fail("substituted-hash", lambda: runner.verify_trusted_host(REPO, str(host))))

sys.exit(0 if all(results) else 1)
