import DefiKernel.Certificates.Check
import DefiKernel.Certificates.Delivered
import DefiKernel.Certificates.Soundness
import DefiKernel.Certificates.LibraryInstantiation
import DefiKernel.Parallel.Compatibility

/-!
Quantified checker-to-Lean correspondence for the delivered production entry.

Historical `checkIR_execute_ok` / `_error` remain definitional dispatch on the
legacy checker and are preserved in `Soundness`. This module maps
`correspondence-theorems.json` names onto statements about `rawExecute` and
`Delivered.checkTyped` / `checkStep` / `checkRun`. Finite F25/F27/F28 tests
do not discharge these.
-/
namespace DefiKernel.Certificates.Delivered

set_option linter.style.longLine false

open DefiKernel.Certificates
open DefiKernel.Typed
open DefiKernel.Composition
open DefiKernel.Parallel

/-- Inventory map: T-raw-typed-ok. Kernel observation, not a Report. -/
theorem rawExecute_typed_ok_complete (env : EnvelopeEnc) (payload : TypedExecutePayloadEnc)
    (state : Typed.State Party Asset Domain)
    (h_state : stateToTyped? payload.state = some state)
    (post : Typed.ExecutionResult Party Asset Domain)
    (h_exec : Typed.execute (registryToTyped payload.registry) (storeToTyped payload.store)
        payload.ctx.toContext (envToTyped payload.env) payload.now payload.request.toRequest state = .ok post) :
    (rawExecute (.typed env payload)).world = executionResultToWorld post payload.state ∧
    (rawExecute (.typed env payload)).kernelFailure = none ∧
    (rawExecute (.typed env payload)).outputs = [] ∧
    (rawExecute (.typed env payload)).events = [] ∧
    (rawExecute (.typed env payload)).nextIndex = 0 ∧
    (rawExecute (.typed env payload)).cursorFailure = none :=
  rawExecute_typed_ok env payload state h_state post h_exec

/-- Inventory map: T-raw-typed-error. -/
theorem rawExecute_typed_error_complete (env : EnvelopeEnc) (payload : TypedExecutePayloadEnc)
    (state : Typed.State Party Asset Domain)
    (h_state : stateToTyped? payload.state = some state)
    (r : Typed.Refusal)
    (h_exec : Typed.execute (registryToTyped payload.registry) (storeToTyped payload.store)
        payload.ctx.toContext (envToTyped payload.env) payload.now payload.request.toRequest state = .error r) :
    rawExecute (.typed env payload) =
      ⟨⟨payload.state, payload.store⟩, none, [], [], 0, none, some (refusalToLocatedFailure r).reason⟩ :=
  rawExecute_typed_error env payload state h_state r h_exec

/-- Typed rawExecute always uses empty sequential fields. -/
theorem rawExecute_typed_sequential_fields (env : EnvelopeEnc) (payload : TypedExecutePayloadEnc) :
    (rawExecute (.typed env payload)).outputs = [] ∧
    (rawExecute (.typed env payload)).events = [] ∧
    (rawExecute (.typed env payload)).nextIndex = 0 ∧
    (rawExecute (.typed env payload)).cursorFailure = none := by
  dsimp [rawExecute]
  split
  · exact ⟨rfl, rfl, rfl, rfl⟩
  · split <;> exact ⟨rfl, rfl, rfl, rfl⟩

/-- Inventory map: T-checkIR-stale. Git mismatch refuses without using rawExecute fields. -/
theorem checkTyped_source_identity_git_guard (env : EnvelopeEnc) (payload : TypedExecutePayloadEnc)
    (h : env.source_pin.git ≠ TrustedHost.gitSha) :
    (checkTyped env payload).status = .refused ∧
    (checkTyped env payload).failure = some ⟨.staleSource, "git", some env.source_pin.git⟩ ∧
    (checkTyped env payload).world = ⟨payload.state, payload.store⟩ ∧
    (checkTyped env payload).receipt = none ∧
    (checkTyped env payload).outputs = [] ∧
    (checkTyped env payload).events = [] ∧
    (checkTyped env payload).nextIndex = 0 ∧
    (checkTyped env payload).cursorFailure = none := by
  have h_id : sourceIdentity env.source_pin = false := by
    simp [sourceIdentity, h]
  dsimp only [checkTyped]
  rcases computeAssumptions env with ⟨assList, missAss⟩
  dsimp only
  simp [h_id, sourceIdentityFailure, h]

/-- Inventory map: T-checkIR-typed-ok. Source identity then kernel fields equal rawExecute.
Does not imply Report.accepted. -/
theorem checkTyped_from_raw_typed_ok (env : EnvelopeEnc) (payload : TypedExecutePayloadEnc)
    (h_id : sourceIdentity env.source_pin = true)
    (h_ok : (rawExecute (.typed env payload)).kernelFailure = none) :
    (checkTyped env payload).world = (rawExecute (.typed env payload)).world ∧
    (checkTyped env payload).receipt = (rawExecute (.typed env payload)).receipt ∧
    (checkTyped env payload).outputs = (rawExecute (.typed env payload)).outputs ∧
    (checkTyped env payload).events = (rawExecute (.typed env payload)).events ∧
    (checkTyped env payload).nextIndex = (rawExecute (.typed env payload)).nextIndex ∧
    (checkTyped env payload).cursorFailure = (rawExecute (.typed env payload)).cursorFailure := by
  have hseq := rawExecute_typed_sequential_fields env payload
  dsimp only [checkTyped]
  rcases computeAssumptions env with ⟨assList, missAss⟩
  dsimp only
  simp [h_id]
  cases hkf : (rawExecute (.typed env payload)).kernelFailure with
  | some _ =>
    rw [hkf] at h_ok
    cases h_ok
  | none =>
    dsimp only
    split <;> try (split <;> try split)
    · simp [hseq]
    · simp [hseq]
    · simp [hseq]
    · simp [hseq]

/-- Inventory map: T-checkIR-typed-error. -/
theorem checkTyped_from_raw_typed_error (env : EnvelopeEnc) (payload : TypedExecutePayloadEnc)
    (h_id : sourceIdentity env.source_pin = true)
    (kf : FailurePath)
    (h_err : (rawExecute (.typed env payload)).kernelFailure = some kf) :
    (checkTyped env payload).status = .refused ∧
    (checkTyped env payload).failure = some kf ∧
    (checkTyped env payload).world = ⟨payload.state, payload.store⟩ ∧
    (checkTyped env payload).receipt = none := by
  unfold checkTyped
  simp [h_id]
  cases hkf : (rawExecute (.typed env payload)).kernelFailure with
  | none =>
    rw [hkf] at h_err
    cases h_err
  | some kf' =>
    rw [hkf] at h_err
    injection h_err with heq
    subst heq
    simp

/-- Inventory map: T-observation-mismatch. -/
theorem checkTyped_claimed_next_state_mismatch (env : EnvelopeEnc) (payload : TypedExecutePayloadEnc)
    (h_id : sourceIdentity env.source_pin = true)
    (h_ok : (rawExecute (.typed env payload)).kernelFailure = none)
    (claimed : WorldEnc)
    (h_cl : env.claimed_next_state = some claimed)
    (h_ne : claimed ≠ (rawExecute (.typed env payload)).world) :
    (checkTyped env payload).status = .refused ∧
    (checkTyped env payload).failure = some ⟨.observationMismatch, "claimedNextState", none⟩ ∧
    (checkTyped env payload).world = (rawExecute (.typed env payload)).world ∧
    (checkTyped env payload).receipt = (rawExecute (.typed env payload)).receipt := by
  unfold checkTyped
  simp [h_id]
  cases hkf : (rawExecute (.typed env payload)).kernelFailure with
  | some _ =>
    rw [hkf] at h_ok
    cases h_ok
  | none =>
    have h_ag : claimedWorldAgreement env (rawExecute (.typed env payload)).world = false := by
      simp [claimedWorldAgreement, h_cl, h_ne]
    simp [hkf, h_ag]

/-- Inventory map: T-report-policy-accepted. Each conjunct is an explicit premise. -/
theorem checkTyped_report_accepted_from_raw_and_policy
    (env : EnvelopeEnc) (payload : TypedExecutePayloadEnc)
    (h_id : sourceIdentity env.source_pin = true)
    (h_ok : (rawExecute (.typed env payload)).kernelFailure = none)
    (h_six : (computeAssumptions env).2 = none)
    (h_claim : claimedWorldAgreement env (rawExecute (.typed env payload)).world = true)
    (h_disc : requestedDischargeOk env payload
      (env.claimed_next_state.getD (rawExecute (.typed env payload)).world) = true) :
    (checkTyped env payload).status = .accepted ∧
    (checkTyped env payload).failure = none ∧
    (checkTyped env payload).world = (rawExecute (.typed env payload)).world := by
  unfold checkTyped
  simp [h_id]
  cases hkf : (rawExecute (.typed env payload)).kernelFailure with
  | some _ =>
    rw [hkf] at h_ok
    cases h_ok
  | none =>
    cases hca : computeAssumptions env with
    | mk _ miss =>
      have : miss = none := by
        simpa [hca] using h_six
      subst this
      simp [hkf, h_claim, h_disc, hca]

/-- Inventory map: T-checkIR-step-ok (delivered). -/
theorem checkStep_from_raw_ok (env : EnvelopeEnc) (payload : CompositionStepPayloadEnc)
    (h_id : sourceIdentity env.source_pin = true)
    (h_ok : (rawExecute (.step env payload)).kernelFailure = none) :
    (checkStep env payload).world = (rawExecute (.step env payload)).world ∧
    (checkStep env payload).receipt = (rawExecute (.step env payload)).receipt ∧
    (checkStep env payload).outputs = (rawExecute (.step env payload)).outputs := by
  unfold checkStep
  simp [h_id]
  cases hkf : (rawExecute (.step env payload)).kernelFailure with
  | some _ =>
    rw [hkf] at h_ok
    cases h_ok
  | none =>
    simp [hkf]
    split <;> try (split <;> try split) <;> simp

/-- Inventory map: T-checkIR-run-cursor (delivered kernel fields). -/
theorem checkRun_from_raw_cursor (env : EnvelopeEnc) (payload : CompositionRunPayloadEnc)
    (h_id : sourceIdentity env.source_pin = true)
    (h_ok : (rawExecute (.run env payload)).kernelFailure = none) :
    (checkRun env payload).world = (rawExecute (.run env payload)).world ∧
    (checkRun env payload).outputs = (rawExecute (.run env payload)).outputs ∧
    (checkRun env payload).events = (rawExecute (.run env payload)).events ∧
    (checkRun env payload).nextIndex = (rawExecute (.run env payload)).nextIndex := by
  unfold checkRun
  simp [h_id]
  cases hkf : (rawExecute (.run env payload)).kernelFailure with
  | some _ =>
    rw [hkf] at h_ok
    cases h_ok
  | none =>
    simp [hkf]
    split <;> try (split <;> try split) <;> simp

/-- Delivered checkIR routes to delivered checkers, not the legacy ones. -/
theorem checkIR_typed (env : EnvelopeEnc) (payload : TypedExecutePayloadEnc) :
    checkIR (.execution (.typed env payload)) = .execution (checkTyped env payload) := rfl

theorem checkIR_step (env : EnvelopeEnc) (payload : CompositionStepPayloadEnc) :
    checkIR (.execution (.step env payload)) = .execution (checkStep env payload) := rfl

theorem checkIR_run (env : EnvelopeEnc) (payload : CompositionRunPayloadEnc) :
    checkIR (.execution (.run env payload)) = .execution (checkRun env payload) := rfl

theorem checkBytes_of_decode_typed (raw : ByteArray) (env : EnvelopeEnc)
    (payload : TypedExecutePayloadEnc)
    (h : decodeBytes raw = .ok (.execution (.typed env payload))) :
    checkBytes raw = .execution (checkTyped env payload) := by
  unfold checkBytes
  rw [h]
  rfl

/-- Inventory map: T-malformed-no-kernel for the delivered entry. -/
theorem decode_error_no_execute (raw : ByteArray) (e : DecodeFailure)
    (h : decodeBytes raw = .error e) (h_not : ∀ lim, e ≠ .resourceLimit lim) :
    checkBytes raw = .codec (.malformed e) := by
  unfold checkBytes
  rw [h]
  cases e with
  | resourceLimit lim =>
    exfalso
    exact h_not lim rfl
  | emptyDocument => rfl
  | lexicalScientificOrFloat => rfl
  | notJsonObject => rfl
  | duplicateKey _ => rfl
  | noncanonicalWhitespace => rfl
  | schemaVersion => rfl
  | missingField _ => rfl
  | jsonType _ => rfl
  | unknownIdentifier _ => rfl
  | uniqueness _ => rfl
  | illegalRational _ => rfl
  | stateNonneg => rfl
  | unknownExecutableField _ => rfl
  | unsupportedForm _ => rfl

end DefiKernel.Certificates.Delivered
