import datetime
import hashlib
import json
import os
import re
import subprocess
import sys

REPO_ROOT = "/home/charl/defiformal-wt-p19-certificates-grok-opus-20260909"
LEAN_DIR = os.path.join(REPO_ROOT, "lean")
EVIDENCE_DIR = os.path.join(REPO_ROOT, "review/semantic-kernel/certificates/p19/implementation/agy-r19-proof")
LOGS_DIR = os.path.join(EVIDENCE_DIR, "logs")
PROBES_DIR = os.path.join(EVIDENCE_DIR, "probes")

os.makedirs(LOGS_DIR, exist_ok=True)
os.makedirs(PROBES_DIR, exist_ok=True)

COMPILER_INFO = {
    "version": "Lean (version 4.33.0-rc2, x86_64-unknown-linux-gnu, commit d8b18978322de05a8f3dba51ef03cf5461676c17, Release)",
    "lean_path": "/home/charl/.elan/toolchains/leanprover--lean4---v4.33.0-rc2/bin/lean",
    "lean_sha256": "e8baaa71855a616dc351028f3ad2200051b0671f423a1696a100e809302d5550",
    "lake_path": "/home/charl/.elan/toolchains/leanprover--lean4---v4.33.0-rc2/bin/lake",
    "lake_sha256": "60330ab6f07dce20f3fa9ebb08e8b984ea9549eac172afeb15d9d2227060e2b3"
}

COMMAND_SPECS = [
    {
        "id": "CMD-01",
        "name": "lean4-skills-preflight",
        "argv": [
            "/home/charl/.codex/plugins/cache/lean4-skills/lean4/4.8.7/bin/lean4-skills-preflight",
            "--codex"
        ],
        "cwd": REPO_ROOT,
        "purpose": "Verify Lean4 skills preflight environment and plugin integrity with --codex"
    },
    {
        "id": "CMD-02",
        "name": "lake-build-defikernel",
        "argv": [
            "/home/charl/.elan/toolchains/leanprover--lean4---v4.33.0-rc2/bin/lake",
            "build",
            "DefiKernel"
        ],
        "cwd": LEAN_DIR,
        "purpose": "Full build of DefiKernel modules (Schema, Encode, Decode, CanonicalJson, Correspondence, etc.)"
    },
    {
        "id": "CMD-03",
        "name": "lake-build-tests",
        "argv": [
            "/home/charl/.elan/toolchains/leanprover--lean4---v4.33.0-rc2/bin/lake",
            "build",
            "DefiKernel.Certificates.Tests"
        ],
        "cwd": LEAN_DIR,
        "purpose": "Build and replay all 21 certificate unit tests and sanity checks"
    },
    {
        "id": "CMD-04",
        "name": "transitive-verify",
        "argv": [
            "/home/charl/.elan/toolchains/leanprover--lean4---v4.33.0-rc2/bin/lake",
            "env",
            "/home/charl/.elan/toolchains/leanprover--lean4---v4.33.0-rc2/bin/lean",
            "DefiKernel/Certificates/Verify.lean"
        ],
        "cwd": LEAN_DIR,
        "purpose": "Execute transitive compiler axiom audit across Certificates, Typed, and Composition scopes"
    },
    {
        "id": "CMD-05",
        "name": "probe-mixed-error-precedence",
        "argv": [
            "/home/charl/.elan/toolchains/leanprover--lean4---v4.33.0-rc2/bin/lake",
            "env",
            "/home/charl/.elan/toolchains/leanprover--lean4---v4.33.0-rc2/bin/lean",
            os.path.join(PROBES_DIR, "mixed_error_precedence.lean")
        ],
        "cwd": LEAN_DIR,
        "purpose": "Execute 6-case root diagnostic probe verifying exact mixed-error failure precedence restoration matching R15",
        "probe": "probes/mixed_error_precedence.lean"
    },
    {
        "id": "CMD-06",
        "name": "probe-unterminated-precedence",
        "argv": [
            "/home/charl/.elan/toolchains/leanprover--lean4---v4.33.0-rc2/bin/lake",
            "env",
            "/home/charl/.elan/toolchains/leanprover--lean4---v4.33.0-rc2/bin/lean",
            os.path.join(PROBES_DIR, "unterminated_precedence.lean")
        ],
        "cwd": LEAN_DIR,
        "purpose": "Execute 4-case root unterminated probe verifying end-of-input whitespace failure precedence restoration matching R15",
        "probe": "probes/unterminated_precedence.lean"
    },
    {
        "id": "CMD-07",
        "name": "probe-c0-controls",
        "argv": [
            "/home/charl/.elan/toolchains/leanprover--lean4---v4.33.0-rc2/bin/lake",
            "env",
            "/home/charl/.elan/toolchains/leanprover--lean4---v4.33.0-rc2/bin/lean",
            os.path.join(PROBES_DIR, "c0_controls.lean")
        ],
        "cwd": LEAN_DIR,
        "purpose": "Execute 32 C0 collision roundtrips, escaped key duplicate detection, and quote/backslash controls",
        "probe": "probes/c0_controls.lean"
    },
    {
        "id": "CMD-08",
        "name": "probe-named-axioms-343",
        "argv": [
            "/home/charl/.elan/toolchains/leanprover--lean4---v4.33.0-rc2/bin/lake",
            "env",
            "/home/charl/.elan/toolchains/leanprover--lean4---v4.33.0-rc2/bin/lean",
            os.path.join(PROBES_DIR, "named_axioms_343.lean")
        ],
        "cwd": LEAN_DIR,
        "purpose": "Direct compiler #print axioms query for all 343 named declarations in CanonicalJson and Correspondence",
        "probe": "probes/named_axioms_343.lean"
    },
    {
        "id": "CMD-09",
        "name": "test-fixture-runner",
        "argv": [
            "/usr/bin/python3",
            "scripts/test_certificate_fixture_runner.py"
        ],
        "cwd": REPO_ROOT,
        "purpose": "Execute certificate fixture runner safety regressions (7/7 pass)"
    }
]

def sha256_file(path):
    with open(path, "rb") as f:
        return hashlib.sha256(f.read()).hexdigest()

def sha256_bytes(b):
    return hashlib.sha256(b).hexdigest()

def run_all_commands():
    commands_records = []
    for spec in COMMAND_SPECS:
        cmd_id = spec["id"].lower()
        cmd_dir = os.path.join(LOGS_DIR, cmd_id)
        os.makedirs(cmd_dir, exist_ok=True)
        
        start_dt = datetime.datetime.now(datetime.timezone.utc)
        print(f"[{start_dt.isoformat()}] Starting {spec['id']}: {spec['name']}...")
        
        proc = subprocess.run(
            spec["argv"],
            cwd=spec["cwd"],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE
        )
        
        end_dt = datetime.datetime.now(datetime.timezone.utc)
        print(f"[{end_dt.isoformat()}] Finished {spec['id']}: exit={proc.returncode}")
        
        stdout_path = os.path.join(cmd_dir, "stdout.log")
        stderr_path = os.path.join(cmd_dir, "stderr.log")
        with open(stdout_path, "wb") as f:
            f.write(proc.stdout)
        with open(stderr_path, "wb") as f:
            f.write(proc.stderr)
            
        rec = {
            "id": spec["id"],
            "name": spec["name"],
            "argv": spec["argv"],
            "cwd": spec["cwd"],
            "start": start_dt.isoformat(),
            "end": end_dt.isoformat(),
            "exit": proc.returncode,
            "compiler": COMPILER_INFO,
            "rawstdout": f"logs/{cmd_id}/stdout.log",
            "rawstderr": f"logs/{cmd_id}/stderr.log",
            "stdout_sha256": sha256_bytes(proc.stdout),
            "stderr_sha256": sha256_bytes(proc.stderr),
            "purpose": spec["purpose"]
        }
        if "probe" in spec:
            probe_rel = spec["probe"]
            probe_abs = os.path.join(EVIDENCE_DIR, probe_rel)
            rec["probe"] = probe_rel
            rec["probe_sha256"] = sha256_file(probe_abs)
            
        meta_path = os.path.join(cmd_dir, "meta.json")
        with open(meta_path, "w") as f:
            json.dump(rec, f, indent=2)
            
        commands_records.append(rec)
        
    with open(os.path.join(EVIDENCE_DIR, "commands.json"), "w") as f:
        json.dump(commands_records, f, indent=2)
    print(f"Recorded {len(commands_records)} command records in commands.json")
    return commands_records

if __name__ == "__main__":
    run_all_commands()
