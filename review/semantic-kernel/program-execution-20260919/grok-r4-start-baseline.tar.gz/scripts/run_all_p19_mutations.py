#!/usr/bin/env python3
"""Run all 16 certificate mutations M01-M16 and produce mutants-summary.json."""
import json
from pathlib import Path
import subprocess
import sys
import time


def main():
    repo_root = Path(__file__).resolve().parent.parent
    mirror_repo = Path("/tmp/p19-mirror-r5")
    specs_dir = repo_root / "review/semantic-kernel/certificates/p19/implementation/agy-r5/mutant-specs"
    out_base = repo_root / "review/semantic-kernel/certificates/p19/implementation/agy-r5/mutants"
    out_base.mkdir(parents=True, exist_ok=True)

    summary_file = repo_root / "review/semantic-kernel/certificates/p19/implementation/agy-r5/mutants-summary.json"

    mutant_ids = [f"M{i:02d}" for i in range(1, 17)]
    results = []

    for mid in mutant_ids:
        spec_path = specs_dir / f"{mid}.json"
        mutant_out = out_base / mid
        print(f"\n==========================================")
        print(f"Running mutant {mid} from {spec_path}...")
        print(f"==========================================")

        with open(spec_path, "r", encoding="utf-8") as f:
            spec_data = json.load(f)

        mut_info = spec_data["mutations"][0]
        mut_name = mut_info["name"]
        mut_mod = mut_info["module"]
        req_false = mut_info.get("required_false", [])
        pos_checks = spec_data.get("positive_checks", [])

        # If already run and complete, check if we can reuse or need to rerun
        res_json_path = mutant_out / "results.json"
        if res_json_path.exists() and (mutant_out / f"{mut_name}.log").exists():
            try:
                res_data = json.loads(res_json_path.read_text(encoding="utf-8"))
                runs = res_data.get("runs", [])
                variant_run = next((r for r in runs if r.get("label") == mut_name), None)
                control_run = next((r for r in runs if r.get("label") == "control"), None)
                if variant_run and control_run and control_run.get("exit") == 0 and variant_run.get("exit") == 1:
                    print(f"Mutant {mid} already completed successfully with discrimination. Reusing result.")
                    results.append({
                        "id": mid,
                        "name": mut_name,
                        "module": mut_mod,
                        "required_false": req_false,
                        "positive_checks": pos_checks,
                        "control_exit": 0,
                        "mutant_exit": 1,
                        "discriminated": True,
                        "status": "passed"
                    })
                    continue
            except Exception as e:
                print(f"Existing results unreadable ({e}), re-running...")

        # If directory exists, remove to avoid run_certificate_mutations.py exist_ok=False error
        if mutant_out.exists():
            import shutil
            shutil.rmtree(mutant_out)

        cmd = [
            sys.executable,
            str(repo_root / "scripts/run_certificate_mutations.py"),
            "--repo", str(mirror_repo),
            "--spec", str(spec_path),
            "--out", str(mutant_out),
            "--timeout-seconds", "600"
        ]

        tick = time.monotonic()
        proc = subprocess.run(cmd, capture_output=True, text=True)
        elapsed = round(time.monotonic() - tick, 4)
        stdout = proc.stdout.strip()
        stderr = proc.stderr.strip()

        print(f"Exit code: {proc.returncode} ({elapsed}s)")
        if stdout:
            print(stdout)
        if stderr:
            print("STDERR:", stderr)

        discriminated = (proc.returncode == 0 and "DISCRIMINATES: 1 mutants" in stdout)
        if not discriminated:
            print(f"ERROR: Mutant {mid} failed to discriminate!")
            sys.exit(1)

        results.append({
            "id": mid,
            "name": mut_name,
            "module": mut_mod,
            "required_false": req_false,
            "positive_checks": pos_checks,
            "control_exit": 0,
            "mutant_exit": 1,
            "elapsed_seconds": elapsed,
            "discriminated": True,
            "status": "passed"
        })

    summary = {
        "schema": "defiformal-certificate-mutants/v1",
        "timestamp_utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        "total": len(mutant_ids),
        "discriminated": sum(1 for r in results if r["discriminated"]),
        "failed": sum(1 for r in results if not r["discriminated"]),
        "mutants": results
    }

    summary_file.write_text(json.dumps(summary, indent=2) + "\n", encoding="utf-8")
    print(f"\nAll {len(mutant_ids)} mutants passed and discriminated non-vacuously!")
    print(f"Wrote summary to {summary_file}")


if __name__ == "__main__":
    main()
