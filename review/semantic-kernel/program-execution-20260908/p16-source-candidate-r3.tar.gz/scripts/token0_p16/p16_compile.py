#!/usr/bin/env python3
"""Compile Token0Probe with pinned solc 0.7.6 standard-JSON.

Copies frozen probe + captured six-library closure into an overlay. Does not
edit captured library bytes. Empty/malformed compile is blocked 3.
"""
from __future__ import annotations

import argparse
import json
import shutil
import subprocess
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from p16_common import (
    CAPTURE_ROOT,
    EXPECTED_SOLC_SHA256,
    FROZEN_PROBE,
    FROZEN_PROBE_SHA256,
    LIB_NAMES,
    SOLC,
    encode_probe_calldata,
    python_env,
    sha256_bytes,
    sha256_file,
    sha256_text,
    utc_now,
    write_json,
)

COMPILER_SETTINGS = {
    "optimizer": {"enabled": True, "runs": 800},
    "metadata": {"bytecodeHash": "none"},
    "evmVersion": "istanbul",
}


def copy_overlay(dest: Path) -> dict:
    dest.mkdir(parents=True, exist_ok=True)
    copied = []
    probe_dest = dest / "Token0Probe.sol"
    shutil.copy2(FROZEN_PROBE, probe_dest)
    probe_sha = sha256_file(probe_dest)
    if probe_sha != FROZEN_PROBE_SHA256:
        raise SystemExit("blocked: Token0Probe.sol overlay hash drifted")
    copied.append({"name": "Token0Probe.sol", "sha256": probe_sha, "bytes": probe_dest.stat().st_size})
    for name in LIB_NAMES:
        src = CAPTURE_ROOT / "contracts/libraries" / name
        dst = dest / name
        shutil.copy2(src, dst)
        copied.append({"name": name, "sha256": sha256_file(dst), "bytes": dst.stat().st_size, "src": str(src)})
    return {"overlay": str(dest), "files": copied}


def standard_json_input(overlay: Path) -> dict:
    sources = {}
    for name in ["Token0Probe.sol", *LIB_NAMES]:
        path = overlay / name
        sources[name] = {"content": path.read_text()}
    return {
        "language": "Solidity",
        "sources": sources,
        "settings": {
            **COMPILER_SETTINGS,
            "outputSelection": {
                "*": {
                    "*": [
                        "abi",
                        "evm.bytecode.object",
                        "evm.deployedBytecode.object",
                        "evm.methodIdentifiers",
                        "metadata",
                    ]
                }
            },
        },
    }


def compile_overlay(overlay: Path, out_dir: Path, solc: Path = SOLC) -> dict:
    out_dir.mkdir(parents=True, exist_ok=True)
    if not solc.is_file():
        report = {
            "status": "blocked_missing_compiler",
            "solc": str(solc),
            "exists": False,
        }
        write_json(out_dir / "compile.json", report)
        return report
    solc_sha = sha256_file(solc)
    if solc_sha != EXPECTED_SOLC_SHA256:
        report = {
            "status": "blocked_compiler_hash_mismatch",
            "solc": str(solc),
            "sha256": solc_sha,
            "expected": EXPECTED_SOLC_SHA256,
        }
        write_json(out_dir / "compile.json", report)
        return report
    inp = standard_json_input(overlay)
    input_bytes = (json.dumps(inp, indent=2) + "\n").encode("utf-8")
    (out_dir / "standard-json-input.json").write_bytes(input_bytes)
    source_hashes = {
        name: sha256_text(body["content"]) for name, body in inp["sources"].items()
    }
    write_json(out_dir / "source-hashes.json", source_hashes)
    argv = [str(solc), "--standard-json"]
    start = utc_now()
    proc = subprocess.run(
        argv,
        input=input_bytes,
        cwd=str(overlay),
        env=python_env(),
        capture_output=True,
        check=False,
    )
    end = utc_now()
    (out_dir / "solc.stdout.bin").write_bytes(proc.stdout)
    (out_dir / "solc.stderr.bin").write_bytes(proc.stderr)
    if proc.returncode != 0 or not proc.stdout.strip():
        report = {
            "status": "blocked_compile_empty_or_nonzero",
            "exit": proc.returncode,
            "stdout_bytes": len(proc.stdout),
            "stderr_bytes": len(proc.stderr),
            "stdout_sha256": sha256_bytes(proc.stdout),
            "stderr_sha256": sha256_bytes(proc.stderr),
            "solc_sha256": solc_sha,
            "argv": argv,
            "start_utc": start,
            "end_utc": end,
        }
        write_json(out_dir / "compile.json", report)
        return report
    try:
        output = json.loads(proc.stdout.decode("utf-8"))
    except json.JSONDecodeError as exc:
        report = {
            "status": "blocked_compile_malformed_json",
            "error": str(exc),
            "stdout_sha256": sha256_bytes(proc.stdout),
            "solc_sha256": solc_sha,
        }
        write_json(out_dir / "compile.json", report)
        return report
    (out_dir / "standard-json-output.json").write_bytes(proc.stdout)
    errors = output.get("errors") or []
    severe = [e for e in errors if e.get("severity") in ("error", "Error")]
    contracts = (output.get("contracts") or {}).get("Token0Probe.sol") or {}
    probe = contracts.get("Token0Probe") or {}
    evm = probe.get("evm") or {}
    creation = ((evm.get("bytecode") or {}).get("object")) or ""
    runtime = ((evm.get("deployedBytecode") or {}).get("object")) or ""
    methods = evm.get("methodIdentifiers") or {}
    abi = probe.get("abi") or []
    if severe or not runtime:
        report = {
            "status": "blocked_compile_error_or_empty_bytecode",
            "errors": severe,
            "all_errors": errors,
            "runtime_empty": not bool(runtime),
            "creation_empty": not bool(creation),
            "solc_sha256": solc_sha,
            "argv": argv,
            "start_utc": start,
            "end_utc": end,
        }
        write_json(out_dir / "compile.json", report)
        return report
    creation_hex = creation.lower().removeprefix("0x")
    runtime_hex = runtime.lower().removeprefix("0x")
    (out_dir / "creation.hex").write_text(creation_hex + "\n")
    (out_dir / "runtime.hex").write_text(runtime_hex + "\n")
    selector = methods.get("probe(uint160,uint128,uint256,bool)")
    write_json(out_dir / "abi.json", abi)
    write_json(out_dir / "methodIdentifiers.json", methods)
    report = {
        "status": "compiled",
        "argv": argv,
        "cwd": str(overlay),
        "start_utc": start,
        "end_utc": end,
        "exit": proc.returncode,
        "solc": str(solc),
        "solc_sha256": solc_sha,
        "settings": COMPILER_SETTINGS,
        "source_hashes": source_hashes,
        "creation_bytecode_sha256": sha256_bytes(bytes.fromhex(creation_hex)),
        "runtime_bytecode_sha256": sha256_bytes(bytes.fromhex(runtime_hex)),
        "creation_hex_sha256": sha256_text(creation_hex + "\n"),
        "runtime_hex_sha256": sha256_text(runtime_hex + "\n"),
        "creation_bytes": len(creation_hex) // 2,
        "runtime_bytes": len(runtime_hex) // 2,
        "methodIdentifiers": methods,
        "probe_selector": selector,
        "selector_source": "compiler_methodIdentifiers",
        "abi": abi,
        "errors_nonfatal": [e for e in errors if e not in severe],
        "standard_json_input_sha256": sha256_bytes(input_bytes),
        "standard_json_output_sha256": sha256_bytes(proc.stdout),
        "stderr_sha256": sha256_bytes(proc.stderr),
        "note": "creation bytecode and deployed runtime bytecode are distinct hashes",
    }
    write_json(out_dir / "compile.json", report)
    write_json(
        out_dir / "bytecode-hashes.json",
        {
            "creation_bytecode_sha256": report["creation_bytecode_sha256"],
            "runtime_bytecode_sha256": report["runtime_bytecode_sha256"],
            "creation_bytes": report["creation_bytes"],
            "runtime_bytes": report["runtime_bytes"],
        },
    )
    if selector:
        sample = encode_probe_calldata(selector, 1, 1, 1, True)
        write_json(
            out_dir / "calldata-encoding.json",
            {
                "signature": "probe(uint160,uint128,uint256,bool)",
                "selector": selector,
                "selector_source": "compiler_methodIdentifiers_not_sha3",
                "encoding": "ABI 4-byte selector plus four 32-byte words",
                "sample_add_1_1_1_true_hex": sample.hex(),
            },
        )
    return report


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--overlay", required=True)
    parser.add_argument("--out", required=True)
    parser.add_argument("--solc", default=str(SOLC))
    parser.add_argument("--prepare-overlay", action="store_true")
    args = parser.parse_args()
    overlay = Path(args.overlay)
    out = Path(args.out)
    if args.prepare_overlay:
        copy_overlay(overlay)
    report = compile_overlay(overlay, out, Path(args.solc))
    print(json.dumps({"status": report.get("status"), "runtime": report.get("runtime_bytecode_sha256")}))
    if report.get("status") != "compiled":
        return 3
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
