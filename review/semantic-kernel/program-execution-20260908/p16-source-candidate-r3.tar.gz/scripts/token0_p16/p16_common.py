#!/usr/bin/env python3
"""Shared P16 source-campaign paths, hashes, fixtures, and recorder invocation.

Does not edit frozen Token0Probe.sol / record_cmd.py / Lean sources.
"""
from __future__ import annotations

import hashlib
import json
import os
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

ROOT = Path("/home/charl/defiformal-wt-p16-token0-grok-gpt6-20260908")
PRIMARY = Path("/home/charl/defiformal/review/semantic-kernel/program-execution-20260908")
TOOLS = Path("/home/charl/.cache/defiformal-program/program-execution-20260908/p16-tools")
SOLC = TOOLS / "solc-linux-amd64-v0.7.6+commit.7338295f"
EVM = TOOLS / "evm"
EXPECTED_SOLC_SHA256 = "bd69ea85427bf2f4da74cb426ad951dd78db9dfdd01d791208eccc2d4958a6bb"
EXPECTED_EVM_SHA256 = "d298ce2c811de089d650ed4f9535c0c58efc72e7adee9b61a40b6c10cc26fb5c"
EXPECTED_RUNNER_SHA256 = "f50fda86bd030cdd4f49f8521d3f7f8e56619123f2a61d9f3cc94d47480fadac"
FROZEN_ARCHIVE = PRIMARY / "p16-proof-recorder-candidate-r2.tar.gz"
FROZEN_ARCHIVE_SHA256 = "62a2b86a3148a38cc9db59658a6843723a81454d8732eae8b23344f2309a1ec8"
FROZEN_PROBE = ROOT / "scripts/token0_p16/Token0Probe.sol"
FROZEN_PROBE_SHA256 = "cc12001912e34069e54042ed62be5ecd0c1e57bca7e1c3685fce404e21cb069c"
RECORDER = ROOT / "scripts/token0_p16/record_cmd.py"
CAPTURE_ROOT = (
    ROOT
    / "review/semantic-kernel/program-loop-20260908"
    / "concentrated-liquidity-source-readiness-gpt6-evidence/upstream"
)
LIB_NAMES = [
    "FullMath.sol",
    "UnsafeMath.sol",
    "LowGasSafeMath.sol",
    "SafeCast.sol",
    "FixedPoint96.sol",
    "SqrtPriceMath.sol",
]
EVIDENCE = ROOT / "review/semantic-kernel/uniswap-token0/p16/implementation/grok-r3"
PLAN_DIR = ROOT / "openspec/changes/uniswap-token0-p16"
PYTHON = sys.executable
PROBE_SIGNATURE = "probe(uint160,uint128,uint256,bool)"
SENDER = "0x1000000000000000000000000000000000000001"
RECEIVER = "0x2000000000000000000000000000000000000002"
GAS_LIMIT = 10_000_000_000
SELECTED_FORK = "istanbul"

MUTANT_IDS = [
    "T0-ID-SKIP",
    "T0-WRAP-SKIP",
    "T0-PROD-SKIP",
    "T0-REQ-SKIP",
    "T0-FLOOR",
    "T0-CHECKED-ADD",
]


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def sha256_text(text: str) -> str:
    return sha256_bytes(text.encode("utf-8"))


def write_json(path: Path, obj: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(obj, indent=2) + "\n")


def load_json(path: Path) -> Any:
    return json.loads(path.read_text())


def load_fixtures() -> list[dict]:
    data = load_json(PLAN_DIR / "fixtures.json")
    fixtures = data["fixtures"]
    if not fixtures:
        raise SystemExit("blocked: empty fixtures.json")
    ids = [row["id"] for row in fixtures]
    if len(ids) != len(set(ids)):
        raise SystemExit("blocked: duplicated fixture ids")
    return fixtures


def load_mutations() -> list[dict]:
    data = load_json(PLAN_DIR / "planned-mutations.json")
    rows = data["token0_production_mutants"]
    got = [row["id"] for row in rows]
    if got != MUTANT_IDS:
        raise SystemExit(f"blocked: mutant id mismatch {got}")
    return rows


def python_env(extra: dict[str, str] | None = None) -> dict[str, str]:
    env = os.environ.copy()
    env["PYTHONDONTWRITEBYTECODE"] = "1"
    env["PYTHONHASHSEED"] = "0"
    if extra:
        env.update(extra)
    return env


def record_cmd(
    name: str,
    cmd: list[str],
    cwd: Path,
    out_dir: Path,
    timeout: float | None = None,
    env_pairs: list[str] | None = None,
) -> dict:
    """Invoke frozen record_cmd.py. Returns receipt plus wrapper_exit."""
    out_dir.mkdir(parents=True, exist_ok=True)
    receipt_path = out_dir / "receipt.json"
    stdout_path = out_dir / "stdout.bin"
    stderr_path = out_dir / "stderr.bin"
    argv = [
        PYTHON,
        "-B",
        str(RECORDER),
        "--name",
        name,
        "--cwd",
        str(cwd),
        "--out",
        str(receipt_path),
        "--stdout-path",
        str(stdout_path),
        "--stderr-path",
        str(stderr_path),
        "--env",
        "PYTHONDONTWRITEBYTECODE=1",
    ]
    if timeout is not None:
        argv.extend(["--timeout", str(timeout)])
    for pair in env_pairs or []:
        argv.extend(["--env", pair])
    argv.append("--")
    argv.extend(cmd)
    proc = subprocess.run(argv, cwd=str(ROOT), env=python_env(), check=False)
    wrapper = {
        "wrapper_exit": proc.returncode,
        "receipt_path": str(receipt_path),
        "stdout_path": str(stdout_path),
        "stderr_path": str(stderr_path),
        "recorder_argv": argv,
        "recorder_sha256": sha256_file(RECORDER),
    }
    write_json(out_dir / "wrapper.json", wrapper)
    receipt: dict[str, Any] = {}
    if receipt_path.is_file():
        receipt = load_json(receipt_path)
    receipt["_wrapper"] = wrapper
    return receipt


def encode_word(value: int) -> bytes:
    if value < 0 or value >= 2**256:
        raise ValueError(f"ABI word not representable: {value}")
    return value.to_bytes(32, "big")


def encode_probe_calldata(selector_hex: str, sqrt_p: int, liquidity: int, amount: int, add: bool) -> bytes:
    sel = selector_hex.lower().removeprefix("0x")
    if len(sel) != 8 or any(c not in "0123456789abcdef" for c in sel):
        raise ValueError(f"selector is not 4 bytes hex: {selector_hex}")
    if sqrt_p < 0 or sqrt_p >= 2**160:
        raise ValueError(f"sqrtPX96 not uint160: {sqrt_p}")
    if liquidity < 0 or liquidity >= 2**128:
        raise ValueError(f"liquidity not uint128: {liquidity}")
    if amount < 0 or amount >= 2**256:
        raise ValueError(f"amount not uint256: {amount}")
    return (
        bytes.fromhex(sel)
        + encode_word(sqrt_p)
        + encode_word(liquidity)
        + encode_word(amount)
        + encode_word(1 if add else 0)
    )


def decode_uint160(returndata_hex: str) -> int | None:
    h = returndata_hex.lower().removeprefix("0x")
    if len(h) != 64:
        return None
    try:
        n = int(h, 16)
    except ValueError:
        return None
    if n >= 2**160:
        return None
    return n


def fixture_inputs(row: dict) -> tuple[int, int, int, bool]:
    inp = row["inputs"]
    return (
        int(inp["sqrtPX96"]),
        int(inp["liquidity"]),
        int(inp["amount"]),
        bool(inp["add"]),
    )


def independent_expected(row: dict) -> dict:
    exp = row["expected"]
    if "ok" in exp:
        return {"kind": "ok", "value": int(exp["ok"]), "reason": row.get("independent", "literal ok")}
    return {
        "kind": "error",
        "source_note": exp.get("source"),
        "model_label_not_payload": exp.get("model_label"),
        "reason": exp.get("source") or row.get("independent") or "literal refusal",
    }
