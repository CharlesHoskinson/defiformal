#!/usr/bin/env python3
"""P16 pinned Solidity/EVM source campaign and six compiled production mutants.

New tooling only. Frozen Token0Probe.sol, record_cmd.py, and Lean libraries are
read, not edited. Python diagnostics are never scored as source execution.
"""
from __future__ import annotations

import argparse
import json
import shutil
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from p16_common import (
    EVM,
    EVIDENCE,
    EXPECTED_EVM_SHA256,
    EXPECTED_RUNNER_SHA256,
    EXPECTED_SOLC_SHA256,
    FROZEN_ARCHIVE,
    FROZEN_ARCHIVE_SHA256,
    FROZEN_PROBE,
    FROZEN_PROBE_SHA256,
    MUTANT_IDS,
    PLAN_DIR,
    PRIMARY,
    RECORDER,
    ROOT,
    SOLC,
    TOOLS,
    encode_probe_calldata,
    fixture_inputs,
    independent_expected,
    load_fixtures,
    load_json,
    load_mutations,
    record_cmd,
    sha256_file,
    sha256_text,
    utc_now,
    write_json,
)
from p16_compile import compile_overlay, copy_overlay
from p16_evm import classify_evm_stdout, run_probe, write_genesis
from p16_mutants import apply_mutant

GO = Path("/usr/local/go/bin/go")
RUNNER_RETAINED = PRIMARY / "p16-evm-readiness/runner.go"


def blocked(reason: str, extra: dict | None = None, exit_code: int = 3) -> int:
    payload = {"status": "blocked", "reason": reason, **(extra or {})}
    print(json.dumps(payload))
    return exit_code


def fail(reason: str, extra: dict | None = None) -> int:
    payload = {"status": "fail", "reason": reason, **(extra or {})}
    print(json.dumps(payload))
    return 1


def setup(ev: Path) -> dict:
    logs = ev / "logs" / "setup"
    logs.mkdir(parents=True, exist_ok=True)
    solc_ok = SOLC.is_file() and sha256_file(SOLC) == EXPECTED_SOLC_SHA256
    evm_ok = EVM.is_file() and sha256_file(EVM) == EXPECTED_EVM_SHA256
    runner_ok = RUNNER_RETAINED.is_file() and sha256_file(RUNNER_RETAINED) == EXPECTED_RUNNER_SHA256
    archive_ok = FROZEN_ARCHIVE.is_file() and sha256_file(FROZEN_ARCHIVE) == FROZEN_ARCHIVE_SHA256
    probe_ok = FROZEN_PROBE.is_file() and sha256_file(FROZEN_PROBE) == FROZEN_PROBE_SHA256
    recorder_ok = RECORDER.is_file()
    version = record_cmd(
        "solc-version",
        [str(SOLC), "--version"],
        ROOT,
        logs / "solc-version",
        timeout=10,
    ) if solc_ok else {}
    evm_version = record_cmd(
        "evm-version",
        [str(EVM), "--version"],
        ROOT,
        logs / "evm-version",
        timeout=10,
    ) if evm_ok else {}
    go_m = {}
    if GO.is_file() and evm_ok:
        go_m = record_cmd(
            "go-version-m",
            [str(GO), "version", "-m", str(EVM)],
            ROOT,
            logs / "go-version-m",
            timeout=20,
        )
    genesis_path = ev / "genesis" / "istanbul-genesis.json"
    genesis_binding = write_genesis(genesis_path)
    stop_path = ev / "genesis" / "stop.hex"
    stop_path.write_text("00\n")
    empty_in = ev / "genesis" / "empty-input.hex"
    empty_in.write_text("\n")
    smoke = record_cmd(
        "genesis-smoke",
        [
            str(EVM),
            "run",
            "--prestate",
            str(genesis_path),
            "--codefile",
            str(stop_path),
            "--inputfile",
            str(empty_in),
            "--gas",
            "1000000",
            "--sender",
            "0x1000000000000000000000000000000000000001",
            "--receiver",
            "0x2000000000000000000000000000000000000002",
        ],
        ROOT,
        logs / "genesis-smoke",
        timeout=15,
    ) if evm_ok else {"exit": 3, "timeout": False}
    smoke_stdout = ""
    smoke_stdout_path = Path((smoke.get("_wrapper") or {}).get("stdout_path") or "")
    if smoke_stdout_path.is_file():
        smoke_stdout = smoke_stdout_path.read_text(errors="replace")
    smoke_class = classify_evm_stdout(smoke_stdout, smoke.get("exit"), bool(smoke.get("timeout")))
    genesis_ok = smoke.get("exit") == 0 and smoke_class.get("class") in ("success", "evm_exception")
    # STOP returns empty returndata without error; treat as genesis accepted.
    if smoke.get("exit") == 0 and smoke_class.get("class") == "success":
        genesis_ok = True
    if smoke.get("exit") not in (0, None) or smoke_class.get("class") == "process_failure":
        genesis_ok = False
    pin = load_json(PLAN_DIR / "source-pin.json")
    capture = ROOT / pin["capture_root"]
    closure = []
    for entry in pin["token0_closure"]:
        path = capture / entry["rel"]
        actual = sha256_file(path) if path.is_file() else None
        closure.append({
            "rel": entry["rel"],
            "expected": entry["sha256"],
            "actual": actual,
            "match": actual == entry["sha256"],
        })
    man = load_json(PRIMARY / "p16-proof-recorder-candidate-r2-manifest.json")
    frozen_mismatch = []
    for rel, exp in man["files"].items():
        path = ROOT / rel
        if not path.is_file():
            frozen_mismatch.append({"rel": rel, "missing": True})
            continue
        actual = sha256_file(path)
        if actual != exp:
            frozen_mismatch.append({"rel": rel, "expected": exp, "actual": actual})
    report = {
        "utc": utc_now(),
        "solc": {
            "path": str(SOLC),
            "exists": SOLC.is_file(),
            "sha256": sha256_file(SOLC) if SOLC.is_file() else None,
            "expected": EXPECTED_SOLC_SHA256,
            "match": solc_ok,
            "version_exit": version.get("exit"),
            "version_stdout_sha256": version.get("stdout_sha256"),
        },
        "evm": {
            "path": str(EVM),
            "exists": EVM.is_file(),
            "sha256": sha256_file(EVM) if EVM.is_file() else None,
            "expected": EXPECTED_EVM_SHA256,
            "match": evm_ok,
            "version_exit": evm_version.get("exit"),
            "version_stdout_sha256": evm_version.get("stdout_sha256"),
        },
        "runner_go": {
            "path": str(RUNNER_RETAINED),
            "sha256": sha256_file(RUNNER_RETAINED) if RUNNER_RETAINED.is_file() else None,
            "expected": EXPECTED_RUNNER_SHA256,
            "match": runner_ok,
        },
        "go_version_m": {
            "exit": go_m.get("exit"),
            "stdout_sha256": go_m.get("stdout_sha256"),
        },
        "frozen_archive": {
            "path": str(FROZEN_ARCHIVE),
            "sha256": sha256_file(FROZEN_ARCHIVE) if FROZEN_ARCHIVE.is_file() else None,
            "expected": FROZEN_ARCHIVE_SHA256,
            "match": archive_ok,
        },
        "frozen_probe": {
            "path": str(FROZEN_PROBE),
            "sha256": sha256_file(FROZEN_PROBE) if FROZEN_PROBE.is_file() else None,
            "expected": FROZEN_PROBE_SHA256,
            "match": probe_ok,
        },
        "frozen_candidate_files": {
            "count": len(man["files"]),
            "mismatches": frozen_mismatch,
            "all_match": not frozen_mismatch,
        },
        "source_closure": closure,
        "closure_all_match": all(row["match"] for row in closure),
        "genesis": genesis_binding,
        "genesis_smoke": {
            "process_exit": smoke.get("exit"),
            "classification": smoke_class,
            "accepted": genesis_ok,
        },
        "recorder": str(RECORDER),
        "tools_dir": str(TOOLS),
        "ready": solc_ok and evm_ok and runner_ok and archive_ok and probe_ok and recorder_ok and genesis_ok and not frozen_mismatch and all(row["match"] for row in closure),
    }
    write_json(ev / "logs" / "tool-rehash.json", report)
    return report


def compare_observation(obs: dict, expected: dict) -> dict:
    o = obs.get("observation") or {}
    klass = o.get("class")
    if klass in ("process_failure", "process_timeout") or obs.get("status", "").startswith("blocked"):
        return {
            "match": False,
            "gate": "blocked",
            "reason": o.get("reason") or obs.get("status") or "blocked observation",
            "observation_class": klass,
        }
    if expected["kind"] == "ok":
        if klass == "success" and o.get("uint160") == expected["value"]:
            return {
                "match": True,
                "gate": "ok",
                "reason": expected.get("reason") or "independent literal ok",
                "source_uint160": o.get("uint160"),
                "expected_uint160": expected["value"],
                "observation_class": klass,
            }
        return {
            "match": False,
            "gate": "fail",
            "reason": f"independent expected ok {expected['value']}; source {klass} uint160={o.get('uint160')} returndata={o.get('returndata')} error={o.get('error')}",
            "observation_class": klass,
        }
    if klass in ("evm_revert", "evm_exception"):
        return {
            "match": True,
            "gate": "ok",
            "reason": expected.get("reason") or "independent literal refusal",
            "source_class": klass,
            "returndata": o.get("returndata"),
            "error": o.get("error"),
            "model_label_not_payload": expected.get("model_label_not_payload"),
            "observation_class": klass,
        }
    return {
        "match": False,
        "gate": "fail",
        "reason": f"independent expected refusal; source {klass} uint160={o.get('uint160')}",
        "observation_class": klass,
    }


def run_fixture_list(
    name_prefix: str,
    fixtures: list[dict],
    compile_report: dict,
    genesis: Path,
    runtime: Path,
    out_dir: Path,
) -> list[dict]:
    selector = compile_report["probe_selector"]
    rows = []
    for row in fixtures:
        fid = row["id"]
        sqrt_p, liq, amount, add = fixture_inputs(row)
        calldata = encode_probe_calldata(selector, sqrt_p, liq, amount, add).hex()
        obs = run_probe(
            f"{name_prefix}-{fid}",
            runtime,
            calldata,
            genesis,
            out_dir / fid,
        )
        expected = independent_expected(row)
        cmp_ = compare_observation(obs, expected)
        rec = {
            "id": fid,
            "partition": row.get("partition"),
            "inputs": {
                "sqrtPX96": str(sqrt_p),
                "liquidity": str(liq),
                "amount": str(amount),
                "add": add,
            },
            "inputs_bound_directly": True,
            "independent_expected": expected,
            "calldata_hex": calldata,
            "selector": selector,
            "selector_source": "compiler_methodIdentifiers",
            "observation": obs.get("observation"),
            "process_exit": obs.get("process_exit"),
            "wrapper_exit": obs.get("wrapper_exit"),
            "comparison": cmp_,
            "model_failure_names_are_not_source_payloads": True,
        }
        write_json(out_dir / fid / "comparison.json", rec)
        rows.append(rec)
    return rows


def planned_mutant_expected(plan: dict, kind: str) -> dict:
    if kind == "designated":
        pub = plan.get("mutant_public") or plan.get("mutant_public_strict") or {}
    else:
        pub = plan.get("ordinary_control") or {}
        if not pub and kind == "control":
            orig = plan.get("original_public") or {}
            pub = orig
    if "ok" in pub:
        return {"kind": "ok", "value": int(pub["ok"]), "reason": f"planned {kind} public ok"}
    if pub.get("status") == "exceptional_failure":
        return {
            "kind": "error",
            "reason": pub.get("mechanism") or "planned exceptional failure",
            "want_class": "evm_exception",
        }
    if pub.get("status") == "source_revert":
        return {
            "kind": "error",
            "reason": pub.get("mechanism") or "planned source revert",
            "want_class": "evm_revert",
        }
    if "error" in pub:
        return {"kind": "error", "reason": "planned refusal"}
    return {"kind": "error", "reason": "planned non-success"}


def compare_mutant_obs(obs: dict, expected: dict) -> dict:
    o = obs.get("observation") or {}
    klass = o.get("class")
    if klass in ("process_failure", "process_timeout"):
        return {"match": False, "gate": "blocked", "reason": o.get("reason"), "observation_class": klass}
    if expected["kind"] == "ok":
        if klass == "success" and o.get("uint160") == expected["value"]:
            return {
                "match": True,
                "gate": "ok",
                "reason": expected["reason"],
                "source_uint160": o.get("uint160"),
                "observation_class": klass,
            }
        return {
            "match": False,
            "gate": "fail",
            "reason": f"{expected['reason']}; got {klass} uint160={o.get('uint160')}",
            "observation_class": klass,
        }
    want = expected.get("want_class")
    if want and klass != want:
        # exceptional vs revert are both semantic refusals; still fail if plan named a class
        if klass in ("evm_revert", "evm_exception"):
            return {
                "match": True,
                "gate": "ok",
                "reason": f"{expected['reason']}; classified {klass} (plan named {want})",
                "observation_class": klass,
                "returndata": o.get("returndata"),
                "error": o.get("error"),
                "class_note": "semantic refusal recorded; exact opcode class kept verbatim",
            }
        return {
            "match": False,
            "gate": "fail",
            "reason": f"{expected['reason']}; got {klass}",
            "observation_class": klass,
        }
    if klass in ("evm_revert", "evm_exception"):
        return {
            "match": True,
            "gate": "ok",
            "reason": expected["reason"],
            "observation_class": klass,
            "returndata": o.get("returndata"),
            "error": o.get("error"),
        }
    return {
        "match": False,
        "gate": "fail",
        "reason": f"{expected['reason']}; got {klass} uint160={o.get('uint160')}",
        "observation_class": klass,
    }


def observations_differ(a: dict, b: dict) -> bool:
    oa = (a.get("observation") or {})
    ob = (b.get("observation") or {})
    return (oa.get("class"), oa.get("uint160"), oa.get("returndata"), oa.get("error")) != (
        ob.get("class"),
        ob.get("uint160"),
        ob.get("returndata"),
        ob.get("error"),
    )


def score_rows(rows: list[dict]) -> dict:
    if not rows:
        return {
            "status": "blocked",
            "exit": 3,
            "denominator": 0,
            "reason": "empty selection; zero source credit",
        }
    ids = [r["id"] for r in rows]
    if len(ids) != len(set(ids)):
        return {"status": "blocked", "exit": 3, "denominator": len(ids), "reason": "duplicated fixture ids"}
    blocked_n = sum(1 for r in rows if r["comparison"]["gate"] == "blocked")
    fail_n = sum(1 for r in rows if r["comparison"]["gate"] == "fail")
    ok_n = sum(1 for r in rows if r["comparison"]["gate"] == "ok")
    if blocked_n:
        return {
            "status": "blocked",
            "exit": 3,
            "denominator": len(rows),
            "ok": ok_n,
            "fail": fail_n,
            "blocked": blocked_n,
            "reason": "one or more observations blocked by tool/setup",
        }
    if fail_n:
        return {
            "status": "fail",
            "exit": 1,
            "denominator": len(rows),
            "ok": ok_n,
            "fail": fail_n,
            "blocked": 0,
            "reason": "bound observation disagrees with independent expected",
        }
    return {
        "status": "ok",
        "exit": 0,
        "denominator": len(rows),
        "ok": ok_n,
        "fail": 0,
        "blocked": 0,
        "reason": "nonempty unique fixtures; all independent comparisons hold",
    }


def mode_empty_selection(ev: Path) -> int:
    out = ev / "controls" / "empty-selection"
    out.mkdir(parents=True, exist_ok=True)
    scored = score_rows([])
    write_json(out / "result.json", scored)
    print(json.dumps(scored))
    return scored["exit"]


def mode_malformed(ev: Path) -> int:
    out = ev / "controls" / "malformed"
    out.mkdir(parents=True, exist_ok=True)
    bad = out / "malformed-fixtures.json"
    bad.write_text("{this is not json\n")
    try:
        json.loads(bad.read_text())
        write_json(out / "result.json", {"status": "fail", "reason": "malformed JSON unexpectedly parsed"})
        return 1
    except json.JSONDecodeError as exc:
        report = {
            "status": "fail",
            "exit": 1,
            "reason": "malformed fixture input rejected",
            "error": str(exc),
            "path": str(bad),
            "sha256": sha256_file(bad),
        }
        write_json(out / "result.json", report)
        print(json.dumps({"status": "fail", "reason": report["reason"]}))
        return 1


def mode_missing_tool(ev: Path) -> int:
    out = ev / "controls" / "missing-tool"
    overlay = out / "overlay"
    copy_overlay(overlay)
    report = compile_overlay(overlay, out / "compile", Path("/nonexistent/p16-missing-solc"))
    write_json(out / "result.json", {"status": "blocked", "exit": 3, "compile": report})
    print(json.dumps({"status": "blocked", "reason": report.get("status")}))
    return 3


def mode_mismatch(ev: Path) -> int:
    out = ev / "controls" / "mismatch"
    src = ev / "evm" / "baseline" / "P16-ADD" / "comparison.json"
    if not src.is_file():
        return blocked("mismatch control requires intact P16-ADD observation", {"path": str(src)})
    rec = load_json(src)
    wrong = {"kind": "ok", "value": 0, "reason": "deliberate bound observation mismatch"}
    cmp_ = compare_observation({"observation": rec["observation"]}, wrong)
    report = {
        "status": "fail" if cmp_["gate"] == "fail" else cmp_["gate"],
        "exit": 1 if cmp_["gate"] == "fail" else (3 if cmp_["gate"] == "blocked" else 0),
        "fixture": "P16-ADD",
        "actual_uint160": (rec.get("observation") or {}).get("uint160"),
        "wrong_expected": 0,
        "comparison": cmp_,
        "reason": "deliberate independent-expected mismatch against a real bound observation",
    }
    write_json(out / "result.json", report)
    print(json.dumps({"status": report["status"], "reason": report["reason"]}))
    return report["exit"]


def run_lean_runtime(ev: Path) -> dict:
    logs = ev / "lean" / "runtime"
    receipt = record_cmd(
        "lake-runtime-r3",
        ["lake", "build", "DefiKernel.ConcentratedLiquidity.RuntimeAudit"],
        ROOT / "lean",
        logs,
        timeout=120,
    )
    stdout_path = Path(receipt["_wrapper"]["stdout_path"])
    text = stdout_path.read_text(errors="replace") if stdout_path.is_file() else ""
    p16_lines = [ln for ln in text.splitlines() if ln.startswith("P16-")]
    report = {
        "exit": receipt.get("exit"),
        "wrapper_exit": receipt["_wrapper"]["wrapper_exit"],
        "timeout": receipt.get("timeout"),
        "classification": receipt.get("classification"),
        "p16_lines": p16_lines,
        "p16_true": sum(1 for ln in p16_lines if ln.endswith(": true")),
        "stdout_sha256": receipt.get("stdout_sha256"),
        "kind": "bounded_lean_execution_not_solidity",
    }
    write_json(ev / "lean" / "runtime-summary.json", report)
    return report


def write_source_bindings_lean(path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(
        """import DefiKernel.ConcentratedLiquidity.SqrtPriceMath

/-!
Ephemeral P16 source-campaign model export. Imports frozen library bytes.
Independent expected values are literals, not helper self-output.
-/
open DefiKernel.ConcentratedLiquidity
open DefiKernel.ConcentratedLiquidity.SqrtPriceMath

def w128 (n : Nat) (h : n < 2 ^ 128 := by decide) : U128 := ⟨n, h⟩
def w160 (n : Nat) (h : n < 2 ^ 160 := by decide) : U160 := ⟨n, h⟩
def w256 (n : Nat) (h : n < 2 ^ 256 := by decide) : U256 := ⟨n, h⟩

structure Row where
  id : String
  sqrtP : U160
  L : U128
  amount : U256
  add : Bool
  expectedOk : Option Nat
  expectedErr : Option Failure

def showF : Failure → String
  | .divisionByZero => "divisionByZero"
  | .quotientOverflow => "quotientOverflow"
  | .subUnderflow => "subUnderflow"
  | .addOverflow => "addOverflow"
  | .uint160Overflow => "uint160Overflow"

def runRow (r : Row) : IO Bool := do
  let got := getNextSqrtPriceFromAmount0RoundingUp r.sqrtP r.L r.amount r.add
  let actual :=
    match got with
    | .ok q => s!"ok:{q.value}"
    | .error e => s!"error:{showF e}"
  let agrees :=
    match got, r.expectedOk, r.expectedErr with
    | .ok q, some n, none => decide (q.value = n)
    | .error e, none, some f => decide (e = f)
    | _, _, _ => false
  IO.println s!"{r.id} sqrtP={r.sqrtP.value} L={r.L.value} amount={r.amount.value} add={r.add} model={actual} match={agrees}"
  pure agrees

def rows : List Row :=
  [ { id := "P16-I-ADD"
      sqrtP := w160 79228162514264337593543950336
      L := w128 1
      amount := w256 0
      add := true
      expectedOk := some 79228162514264337593543950336
      expectedErr := none }
  , { id := "P16-I-REM"
      sqrtP := w160 79228162514264337593543950336
      L := w128 1
      amount := w256 0
      add := false
      expectedOk := some 79228162514264337593543950336
      expectedErr := none }
  , { id := "P16-I-ZERO-LIQ"
      sqrtP := w160 79228162514264337593543950336
      L := w128 0
      amount := w256 0
      add := false
      expectedOk := some 79228162514264337593543950336
      expectedErr := none }
  , { id := "P16-ADD"
      sqrtP := w160 79228162514264337593543950336
      L := w128 1
      amount := w256 1
      add := true
      expectedOk := some 39614081257132168796771975168
      expectedErr := none }
  , { id := "P16-ADD-ROUND"
      sqrtP := w160 79228162514264337593543950336
      L := w128 1
      amount := w256 2
      add := true
      expectedOk := some 26409387504754779197847983446
      expectedErr := none }
  , { id := "P16-REQ"
      sqrtP := w160 79228162514264337593543950336
      L := w128 1
      amount := w256 1
      add := false
      expectedOk := none
      expectedErr := some .subUnderflow }
  , { id := "P16-REQ-STRICT"
      sqrtP := w160 79228162514264337593543950336
      L := w128 1
      amount := w256 2
      add := false
      expectedOk := none
      expectedErr := some .subUnderflow }
  , { id := "P16-REM"
      sqrtP := w160 79228162514264337593543950336
      L := w128 2
      amount := w256 1
      add := false
      expectedOk := some 158456325028528675187087900672
      expectedErr := none }
  , { id := "P16-SAFECAST"
      sqrtP := w160 730750818665451459101842416358141509827966271488
      L := w128 9223372036854775809
      amount := w256 1
      add := false
      expectedOk := none
      expectedErr := some .uint160Overflow }
  , { id := "P16-ADD-DEN0"
      sqrtP := w160 0
      L := w128 0
      amount := w256 1
      add := true
      expectedOk := none
      expectedErr := some .divisionByZero }
  , { id := "P16-PROD"
      sqrtP := w160 79228162514264337593543950336
      L := w128 79228162514264337593543950336
      amount := w256 1461501637330902918203684832716283019655932542976
      add := true
      expectedOk := some 4294967296
      expectedErr := none }
  , { id := "P16-WRAP"
      sqrtP := w160 1461446703485210103287273052203988822378723970341
      L := w128 340282366920938463463374607431768211455
      amount := w256 79231140577496994670249413376
      add := true
      expectedOk := some 340269576638287423012608907232989748562
      expectedErr := none }
  ]

def main : IO UInt32 := do
  if rows.isEmpty then
    IO.eprintln "P16 source-binding rows empty"
    return 3
  let ids := rows.map (·.id)
  if !ids.Nodup then
    IO.eprintln "P16 source-binding ids duplicated"
    return 3
  let mut all := true
  for r in rows do
    let m ← runRow r
    all := all && m
  if all then
    IO.println s!"P16 source-binding comparisons: {rows.length} of {rows.length}"
    return 0
  IO.eprintln "P16 source-binding comparison failed"
  return 1

#eval main
"""
    )


def run_lean_bindings(ev: Path) -> dict:
    lean_path = ev / "lean" / "P16SourceBindings.lean"
    write_source_bindings_lean(lean_path)
    logs = ev / "lean" / "bindings"
    receipt = record_cmd(
        "lean-source-bindings",
        ["lake", "env", "lean", str(lean_path)],
        ROOT / "lean",
        logs,
        timeout=180,
    )
    stdout_path = Path(receipt["_wrapper"]["stdout_path"])
    text = stdout_path.read_text(errors="replace") if stdout_path.is_file() else ""
    lines = [ln for ln in text.splitlines() if ln.startswith("P16-")]
    report = {
        "exit": receipt.get("exit"),
        "wrapper_exit": receipt["_wrapper"]["wrapper_exit"],
        "timeout": receipt.get("timeout"),
        "classification": receipt.get("classification"),
        "lean_path": str(lean_path),
        "lean_sha256": sha256_file(lean_path),
        "p16_lines": lines,
        "stdout_sha256": receipt.get("stdout_sha256"),
        "stderr_sha256": receipt.get("stderr_sha256"),
        "kind": "ephemeral_model_export_importing_frozen_library",
    }
    write_json(ev / "lean" / "bindings-summary.json", report)
    return report


def mode_intact(ev: Path) -> int:
    setup_report = setup(ev)
    if not setup_report.get("ready"):
        write_json(ev / "result-partial.json", {"status": "blocked", "setup": setup_report})
        return blocked("tool/genesis/frozen-byte setup failed", {"ready": False})
    overlay = ev / "compiler" / "baseline" / "overlay"
    if overlay.exists():
        shutil.rmtree(overlay)
    copy_overlay(overlay)
    compile_dir = ev / "compiler" / "baseline"
    compile_report = compile_overlay(overlay, compile_dir)
    write_json(compile_dir / "overlay-copy.json", {"overlay": str(overlay)})
    if compile_report.get("status") != "compiled":
        return blocked("baseline compile empty or failed", compile_report)
    fixtures = load_fixtures()
    genesis = ev / "genesis" / "istanbul-genesis.json"
    runtime = compile_dir / "runtime.hex"
    baseline_rows = run_fixture_list(
        "baseline",
        fixtures,
        compile_report,
        genesis,
        runtime,
        ev / "evm" / "baseline",
    )
    baseline_score = score_rows(baseline_rows)
    write_json(ev / "evm" / "baseline" / "score.json", baseline_score)
    mutations = load_mutations()
    mutant_rows = []
    by_id = {row["id"]: row for row in fixtures}
    for plan in mutations:
        mid = plan["id"]
        mout = ev / "compiler" / "mutants" / mid
        molay = mout / "overlay"
        if molay.exists():
            shutil.rmtree(molay)
        copy_overlay(molay)
        applied = apply_mutant(molay, mid, mout / "edit.json")
        if applied.get("status") != "applied":
            mutant_rows.append({
                "id": mid,
                "status": "blocked",
                "gate": "blocked",
                "reason": "mutant edit did not apply; compiler failure/empty-selection is blocked not detection",
                "edit": applied,
            })
            continue
        crep = compile_overlay(molay, mout / "compile")
        if crep.get("status") != "compiled":
            mutant_rows.append({
                "id": mid,
                "status": "blocked",
                "gate": "blocked",
                "reason": "mutant compile failed or empty bytecode; blocked not detection",
                "compile": crep.get("status"),
            })
            continue
        designated_id = plan["designated_false"]
        control_id = plan["unaffected_positive"]
        runtime_m = mout / "compile" / "runtime.hex"
        des_fix = by_id[designated_id]
        ctrl_fix = by_id[control_id]
        des_rows = run_fixture_list(
            f"{mid}-designated",
            [des_fix],
            crep,
            genesis,
            runtime_m,
            ev / "evm" / "mutants" / mid / "designated",
        )
        ctrl_rows = run_fixture_list(
            f"{mid}-control",
            [ctrl_fix],
            crep,
            genesis,
            runtime_m,
            ev / "evm" / "mutants" / mid / "control",
        )
        extra = None
        extra_rows = []
        if plan.get("equality_baseline_control"):
            eq_id = plan["equality_baseline_control"]
            extra = eq_id
            extra_rows = run_fixture_list(
                f"{mid}-equality",
                [by_id[eq_id]],
                crep,
                genesis,
                runtime_m,
                ev / "evm" / "mutants" / mid / "equality",
            )
        base_des = next(r for r in baseline_rows if r["id"] == designated_id)
        base_ctrl = next(r for r in baseline_rows if r["id"] == control_id)
        des_obs = des_rows[0]
        ctrl_obs = ctrl_rows[0]
        plan_des = planned_mutant_expected(plan, "designated")
        # For designated, compare against planned mutant public, not original fixture expected.
        des_plan_cmp = compare_mutant_obs({"observation": des_obs["observation"]}, plan_des)
        ctrl_plan = {
            "kind": "ok",
            "value": int(plan.get("ordinary_control", {}).get("ok") or by_id[control_id]["expected"]["ok"]),
            "reason": "planned unaffected ordinary ADD",
        }
        ctrl_cmp = compare_mutant_obs({"observation": ctrl_obs["observation"]}, ctrl_plan)
        changed = observations_differ(des_obs, base_des)
        ctrl_same = not observations_differ(ctrl_obs, base_ctrl)
        runtime_changed = crep["runtime_bytecode_sha256"] != compile_report["runtime_bytecode_sha256"]
        eq_report = None
        if extra_rows:
            eq_obs = extra_rows[0]
            eq_expected = independent_expected(by_id[extra])
            eq_cmp = compare_observation({"observation": eq_obs["observation"]}, eq_expected)
            eq_report = {
                "id": extra,
                "comparison": eq_cmp,
                "observation": eq_obs["observation"],
                "note": "equality baseline remains a refusing FullMath control after T0-REQ-SKIP",
            }
        ok = (
            des_plan_cmp["match"]
            and ctrl_cmp["match"]
            and changed
            and ctrl_same
            and runtime_changed
            and (eq_report is None or eq_report["comparison"]["match"])
        )
        row = {
            "id": mid,
            "status": "ok" if ok else "fail",
            "gate": "ok" if ok else "fail",
            "edit": {
                "find_sha256": applied.get("find_sha256"),
                "replace_sha256": applied.get("replace_sha256"),
                "before_sha256": applied.get("before_sha256"),
                "after_sha256": applied.get("after_sha256"),
            },
            "compile_status": crep.get("status"),
            "runtime_bytecode_sha256": crep.get("runtime_bytecode_sha256"),
            "baseline_runtime_bytecode_sha256": compile_report["runtime_bytecode_sha256"],
            "runtime_changed": runtime_changed,
            "designated": {
                "id": designated_id,
                "baseline": base_des["observation"],
                "mutant": des_obs["observation"],
                "changed": changed,
                "planned": plan_des,
                "comparison": des_plan_cmp,
            },
            "unaffected_control": {
                "id": control_id,
                "baseline": base_ctrl["observation"],
                "mutant": ctrl_obs["observation"],
                "unchanged": ctrl_same,
                "planned": ctrl_plan,
                "comparison": ctrl_cmp,
            },
            "equality_control": eq_report,
            "reason": (
                "designated observation changed and matches planned public value; "
                "independent ordinary ADD control unchanged"
            )
            if ok
            else "mutant designated/control comparison failed",
        }
        write_json(ev / "evm" / "mutants" / mid / "summary.json", row)
        mutant_rows.append(row)
    mutant_blocked = [r for r in mutant_rows if r.get("gate") == "blocked"]
    mutant_fail = [r for r in mutant_rows if r.get("gate") == "fail"]
    mutant_ok = [r for r in mutant_rows if r.get("gate") == "ok"]
    if len(mutant_rows) != 6:
        mutant_score = {
            "status": "blocked",
            "exit": 3,
            "denominator": len(mutant_rows),
            "reason": "mutant inventory not exactly 6",
        }
    elif mutant_blocked:
        mutant_score = {
            "status": "blocked",
            "exit": 3,
            "denominator": 6,
            "ok": len(mutant_ok),
            "fail": len(mutant_fail),
            "blocked": len(mutant_blocked),
            "reason": "mutant compile/edit blocked; not scored as detection",
        }
    elif mutant_fail:
        mutant_score = {
            "status": "fail",
            "exit": 1,
            "denominator": 6,
            "ok": len(mutant_ok),
            "fail": len(mutant_fail),
            "blocked": 0,
            "reason": "one or more mutants missed designated change or control",
        }
    else:
        mutant_score = {
            "status": "ok",
            "exit": 0,
            "denominator": 6,
            "ok": 6,
            "fail": 0,
            "blocked": 0,
            "reason": "six compiled mutants each have designated change and unaffected ADD control",
        }
    write_json(ev / "evm" / "mutants" / "score.json", mutant_score)
    lean_runtime = run_lean_runtime(ev)
    lean_bind = run_lean_bindings(ev)
    exits = [baseline_score["exit"], mutant_score["exit"]]
    if lean_runtime.get("exit") not in (0, None):
        # RuntimeAudit #eval may still compile with warnings; require exit 0.
        if lean_runtime.get("exit") != 0:
            exits.append(1 if lean_runtime.get("exit") == 1 else 3)
    if lean_bind.get("wrapper_exit") not in (0, None):
        # lake env lean -- #eval main returns UInt32 printed; compile exit is wrapper.
        if lean_bind.get("exit") not in (0, None) and lean_bind.get("exit") != 0:
            exits.append(1 if lean_bind.get("exit") == 1 else 3)
    overall_exit = 3 if 3 in exits else (1 if 1 in exits else 0)
    overall = {
        "status": {0: "ok", 1: "fail", 3: "blocked"}[overall_exit],
        "exit": overall_exit,
        "baseline": baseline_score,
        "mutants": mutant_score,
        "lean_runtime": {
            "exit": lean_runtime.get("exit"),
            "p16_true": lean_runtime.get("p16_true"),
            "p16_lines": lean_runtime.get("p16_lines"),
        },
        "lean_bindings": {
            "exit": lean_bind.get("exit"),
            "wrapper_exit": lean_bind.get("wrapper_exit"),
            "p16_lines": lean_bind.get("p16_lines"),
        },
        "compile": {
            "status": compile_report.get("status"),
            "runtime_bytecode_sha256": compile_report.get("runtime_bytecode_sha256"),
            "creation_bytecode_sha256": compile_report.get("creation_bytecode_sha256"),
            "selector": compile_report.get("probe_selector"),
        },
        "python_diagnostic_credit": False,
        "self_accepted": False,
        "operation_credit": False,
        "source_refinement": False,
        "finite_comparison_is_not_universal_refinement": True,
    }
    write_json(ev / "campaign-score.json", overall)
    write_json(ev / "evm" / "baseline" / "rows.json", baseline_rows)
    write_json(ev / "evm" / "mutants" / "rows.json", mutant_rows)
    print(json.dumps({"status": overall["status"], "exit": overall_exit, "baseline": baseline_score, "mutants": mutant_score}))
    return overall_exit


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--mode",
        required=True,
        choices=["setup", "intact", "empty-selection", "malformed", "missing-tool", "mismatch"],
    )
    parser.add_argument("--evidence", default=str(EVIDENCE))
    args = parser.parse_args()
    ev = Path(args.evidence)
    ev.mkdir(parents=True, exist_ok=True)
    if args.mode == "setup":
        report = setup(ev)
        print(json.dumps({"ready": report.get("ready")}))
        return 0 if report.get("ready") else 3
    if args.mode == "intact":
        return mode_intact(ev)
    if args.mode == "empty-selection":
        return mode_empty_selection(ev)
    if args.mode == "malformed":
        return mode_malformed(ev)
    if args.mode == "missing-tool":
        return mode_missing_tool(ev)
    if args.mode == "mismatch":
        return mode_mismatch(ev)
    return 3


if __name__ == "__main__":
    raise SystemExit(main())
