# Capability provenance foundation r1

Native Grok 4.6 author. Independent GPT-6 checker is not this turn. No Foreman. No commit, push, or self-acceptance. Root owns freeze/review/delivery.

Official r2 planning is ACCEPT WITH LIMITATIONS with no required fixes (`capability-official-planning-acceptance-r2.json`). Implementation authorization was already supplied. Sealed r1/r2 STATUS, original r1/r2 bytes, tasks.md, and accepted Composition/Typed/Atomic/Nary/root `DefiKernel.lean` were not rewritten.

## Bound

Assigned foundation only: tasks 1.3, 2.1–2.6, 3.1–3.2, 4.1–4.2. New files:

| Module | Path | SHA-256 | Bytes |
| --- | --- | --- | --- |
| Origins | `lean/DefiKernel/CapabilityProvenance/Origins.lean` | `2ff9ba9d09a698335c8051e3bb7a7fc0239d8a1120ef622f979d3bc1c84ccf89` | 11343 |
| Observation | `lean/DefiKernel/CapabilityProvenance/Observation.lean` | `79110900be9d394dfe0ff8ae58c48047f958e9142c83401e15242da4dcd5e667` | 11244 |
| Trace | `lean/DefiKernel/CapabilityProvenance/Trace.lean` | `8957285fd8241bbafe6019c3ee3b5306871da3b21ff5c145d1d5fb75560d5381` | 31793 |
| FoundationChecks | `lean/DefiKernel/CapabilityProvenance/FoundationChecks.lean` | `defab8de0839861ffb29b4c92b4aabc34617233f9ea81dc7fcf161f4ccfb344f` | 7218 |

Isolation, Examples, Tests, Audit, Verify, F01–F20, harness adaptation, mutations, and root import remain later phases. Runtime declarations sit before `-- BEGIN PROOFS`. FoundationChecks does not import old Tests/Acceptance.

Head: `a12b7cac05a818cc8d35c2ca440b7170a2807e92`. M3 source candidate `94f70e502c75132656bd0902a17be60ca45ab1c2` is distinct and was not treated as this worktree identity. Pins unchanged: `lean-toolchain` `0d3c76ccd8772d8bcbe207241421a760312b71a6aa82f84194391fdf5cb026d6`, `lake-manifest.json` `8a6ceb0b073bcb3e437c3258aedf250b38da4dec0f696db6b2717bd987c43002`. Private `.lake` is a real directory, not a shared symlink.

## Task 1.3 baseline

Focused accepted modules were rebuilt with pinned lake/lean (not a full-repo rebuild). Ten targets including Typed/Composition Audit and Verify exited 0. 23-file import closure hashes were nonempty and unique. CapabilityProvenance was absent at baseline; its absence was not used as negative credit.

Historical runner: first command omitted required `--repo`/`--out` (exit 2, preserved under `failed-attempts/historical-runner-missing-args`). Corrected command:

```
python3 scripts/test_metatheory_mutation_runner.py --repo <worktree> --out /home/charl/.cache/defiformal-capability-foundation-r1-runner
```

cwd worktree root, PATH prefix pinned v4.33.0-rc2, start `2026-09-08T09:16:06Z`, end `2026-09-08T09:17:23Z`, exit 0, 65/65 controls. Runner/driver/spec hashes match the frozen adaptation record.

## What is proved

OriginAt is a predicate over actual `TraceSound` event lists. Issued cases require the existing `issueCapability` equation at the event’s before-store, not a second executor and not final-store legitimacy.

Generic (not fixture-only) theorems include:

- `rootsAccepted_empty`; nonempty dead+live instance in FoundationChecks
- `originAt_complete` / `originAt_unique` on arbitrary initialized traces
- `trace_allocation_count`, `trace_persistent_grant`, `trace_dead_stays_dead`
- `accepted_invoke_current_authority`: current pre-store invoke / negative aggregate debit / nonzero supply, each with a requested-ID origin witness from the actual prefix
- `advance_rejected_prefix`, `executeStep_issue_error` / `revoke_error`, `revoke_unknown_before_admin`, `issue_unauthorized_before_domains`
- `issuedOrigin` / `originOf` / `currentAuthorityOrigin` runtime plus `originOf_sound` under initialized traces
- `auditRun_delegates`: cursor equals `Composition.run`
- `observeWorld_eq_iff`, `viewEq_iff`, `capEq_eq`, value-valued `SupportsObservation` for `observeWorld`

`#print axioms` on the named theorems reports only `propext`, `Classical.choice`, and `Quot.sound`. Owned source has no `sorry`, `native_decide`, or custom `axiom`.

## Foundation checks

22 named comparisons, all true (compile-time `#eval main`, nonempty unique names). They cover empty and nonempty dead/live initials, actual issue/revoke/current-authority, forged-event query without a certificate, auditRun delegation, rejected-admin prefix, capEq one-field negatives, viewEq live/nextId siblings, and selected-support vs full-store. They are not F01–F20 or the 14 production mutants.

## Failed attempts kept

Origins `List.mem_cons_self`; Observation injection/`capEq`/`and` association; Trace `prefix` reserved token, `execute_preserves_capabilities` arity, projection names, uniqueness induction; FoundationChecks DecidableEq on receipts and an unselected live-ID viewEq that correctly agreed. Each log is under `failed-attempts/`.

## Remaining obligations (honest partial)

Not claimed complete as a single packaged theorem:

- issued `originOf` completeness iff (pieces: `originOf_sound`, `originOf_complete_initial`, `issuedOrigin_of_unique`, `originAt_unique`)
- `currentAuthorityOrigin` completeness iff on initialized cursors (cons lemmas exist)
- a separately named “this prefix revoke stays dead at final” lemma (`trace_dead_stays_dead` plus step preservation cover the content)

Later phases by assignment: Isolation, Examples/Tests/Audit/Verify, F01–F20, mutations, root import.

This is a reviewable foundation candidate for independent GPT-6, not implementation acceptance.
