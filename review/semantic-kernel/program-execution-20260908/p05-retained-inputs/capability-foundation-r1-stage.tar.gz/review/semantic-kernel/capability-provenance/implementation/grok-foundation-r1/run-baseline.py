#!/usr/bin/env python3
"""Task 1.3: preserve accepted source/pins/normative hashes and run fresh
relevant accepted Lean/Verify/Audit plus historical runner baseline.

Does not compile CapabilityProvenance (it does not exist yet) and does not
treat absence of that namespace as negative credit. Does not mutate source.
"""
from __future__ import annotations

import hashlib
import json
import os
import subprocess
import sys
import time
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parents[5]
OUT = Path(__file__).resolve().parent
BASE = OUT / "baseline"
LOGS = OUT / "logs"
HASHES = OUT / "hashes"
PINNED_BIN = Path("/home/charl/.elan/toolchains/leanprover--lean4---v4.33.0-rc2/bin")
LAKE = PINNED_BIN / "lake"
LEAN = PINNED_BIN / "lean"

CLOSURE = [
    "lean/DefiKernel/Typed/Types.lean",
    "lean/DefiKernel/Typed/Authority.lean",
    "lean/DefiKernel/Typed/Expr.lean",
    "lean/DefiKernel/Typed/Transition.lean",
    "lean/DefiKernel/Composition/Interfaces.lean",
    "lean/DefiKernel/Composition/Contracts.lean",
    "lean/DefiKernel/Composition/Execution.lean",
    "lean/DefiKernel/Composition/Sequence.lean",
    "lean/DefiKernel/Parallel/Compatibility.lean",
    "lean/DefiKernel/Parallel/Observation.lean",
    "lean/DefiKernel/Parallel/Execution.lean",
    "lean/DefiKernel/Parallel/Dependency.lean",
    "lean/DefiKernel/Parallel/Dependency/Adapter.lean",
    "lean/DefiKernel/Parallel/Commutation.lean",
    "lean/DefiKernel/Composition/Preservation.lean",
    "lean/DefiKernel/Parallel/Preservation.lean",
    "lean/DefiKernel/Interleaving/Schedule.lean",
    "lean/DefiKernel/Interleaving/Execution.lean",
    "lean/DefiKernel/Interleaving/Soundness.lean",
    "lean/DefiKernel/Interleaving/LocalOrder.lean",
    "lean/DefiKernel/Interleaving/Preservation.lean",
    "lean/DefiKernel/Metatheory/SequentialGroups.lean",
    "lean/DefiKernel/Metatheory/Observation.lean",
]

PINS = [
    "lean/lean-toolchain",
    "lean/lakefile.toml",
    "lean/lake-manifest.json",
]

NORMATIVE = [
    "openspec/changes/capability-provenance-isolation/proposal.md",
    "openspec/changes/capability-provenance-isolation/design.md",
    "openspec/changes/capability-provenance-isolation/tasks.md",
    "openspec/changes/capability-provenance-isolation/specs/initialized-capability-provenance/spec.md",
    "openspec/changes/capability-provenance-isolation/specs/supported-component-isolation/spec.md",
    "openspec/changes/capability-provenance-isolation/specs/capability-provenance-evidence/spec.md",
    "openspec/changes/capability-provenance-isolation/accepted-api.json",
    "openspec/changes/capability-provenance-isolation/proposed-api.json",
    "openspec/changes/capability-provenance-isolation/dependency-baseline.json",
    "openspec/changes/capability-provenance-isolation/planned-mutations.json",
    "openspec/changes/capability-provenance-isolation/fixtures.json",
    "openspec/changes/capability-provenance-isolation/scenario-map.json",
    "openspec/changes/capability-provenance-isolation/runner-adaptation.json",
    "review/semantic-kernel/capability-provenance/planning/grok-gpt6-official-r2/appendices/E-module-plan.json",
    "review/semantic-kernel/program-loop-20260908/capability-official-r2-gpt6-review.md",
    "review/semantic-kernel/program-loop-20260908/capability-official-r2-gpt6-inputs.json",
    "review/semantic-kernel/program-loop-20260908/capability-official-planning-acceptance-r2.json",
    "review/semantic-kernel/program-loop-20260908/private-cache-assignment-r1.json",
]

PROTECTED = [
    "lean/DefiKernel.lean",
    "scripts/check_metatheory_mutations.py",
    "scripts/test_metatheory_mutation_runner.py",
    "mutations/metatheory.json",
    "review/semantic-kernel/capability-provenance/planning/pre-official-r1/original-draft.tar.gz",
    "review/semantic-kernel/capability-provenance/planning/grok-gpt6-official-r1/STATUS.json",
    "review/semantic-kernel/capability-provenance/planning/grok-gpt6-official-r2/STATUS.json",
]

FOCUS_BUILDS = [
    "DefiKernel.Typed.Authority",
    "DefiKernel.Composition.Execution",
    "DefiKernel.Composition.Sequence",
    "DefiKernel.Composition.Contracts",
    "DefiKernel.Composition.Preservation",
    "DefiKernel.Metatheory.Observation",
    "DefiKernel.Typed.Audit",
    "DefiKernel.Composition.Audit",
    "DefiKernel.Typed.Verify",
    "DefiKernel.Composition.Verify",
]


def sha256_file(path: Path) -> dict:
    raw = path.read_bytes()
    return {
        "path": str(path.relative_to(ROOT)) if path.is_relative_to(ROOT) else str(path),
        "bytes": len(raw),
        "sha256": hashlib.sha256(raw).hexdigest(),
        "mtime_ns": path.stat().st_mtime_ns,
        "exists": True,
    }


def sha256_bytes(raw: bytes) -> str:
    return hashlib.sha256(raw).hexdigest()


def run_cmd(argv: list[str], cwd: Path, log_stem: str, env: dict | None = None,
            timeout: int | None = None) -> dict:
    start = datetime.now(timezone.utc)
    t0 = time.perf_counter()
    merged_env = os.environ.copy()
    if env:
        merged_env.update(env)
    proc = subprocess.run(
        argv,
        cwd=str(cwd),
        env=merged_env,
        capture_output=True,
        timeout=timeout,
    )
    elapsed = time.perf_counter() - t0
    end = datetime.now(timezone.utc)
    stdout = proc.stdout
    stderr = proc.stderr
    (LOGS / f"{log_stem}.stdout.log").write_bytes(stdout)
    (LOGS / f"{log_stem}.stderr.log").write_bytes(stderr)
    record = {
        "argv": argv,
        "cwd": str(cwd),
        "start_utc": start.isoformat(),
        "end_utc": end.isoformat(),
        "elapsed_seconds": elapsed,
        "exit_code": proc.returncode,
        "stdout_bytes": len(stdout),
        "stderr_bytes": len(stderr),
        "stdout_sha256": sha256_bytes(stdout),
        "stderr_sha256": sha256_bytes(stderr),
        "stdout_log": str((LOGS / f"{log_stem}.stdout.log").relative_to(ROOT)),
        "stderr_log": str((LOGS / f"{log_stem}.stderr.log").relative_to(ROOT)),
        "timeout_seconds": timeout,
    }
    return record


def git(argv: list[str]) -> str:
    return subprocess.check_output(["git", *argv], cwd=ROOT, text=True).strip()


def hash_list(paths: list[str], label: str) -> list[dict]:
    rows = []
    for rel in paths:
        path = ROOT / rel
        if not path.exists():
            rows.append({"path": rel, "exists": False})
            continue
        rows.append(sha256_file(path))
    (HASHES / f"{label}.json").write_text(json.dumps(rows, indent=2) + "\n")
    return rows


def tool_hashes() -> dict:
    tools = {
        "lean": LEAN,
        "lake": LAKE,
        "python3": Path(sys.executable),
    }
    out = {}
    for name, path in tools.items():
        info = sha256_file(path)
        version = subprocess.check_output([str(path), "--version"], text=True).strip()
        info["version"] = version.splitlines()[0]
        out[name] = info
    (HASHES / "tools.json").write_text(json.dumps(out, indent=2) + "\n")
    return out


def lake_env() -> dict:
    path = f"{PINNED_BIN}:{os.environ.get('PATH', '')}"
    return {
        "PATH": path,
        "ELAN_TOOLCHAIN": "leanprover/lean4:v4.33.0-rc2",
    }


def main() -> int:
    BASE.mkdir(parents=True, exist_ok=True)
    LOGS.mkdir(parents=True, exist_ok=True)
    HASHES.mkdir(parents=True, exist_ok=True)
    porcelain_before = git(["status", "--porcelain", "-uall"])
    (BASE / "git-status-before.txt").write_text(porcelain_before + "\n")
    head = git(["rev-parse", "HEAD"])
    snapshot = {
        "purpose": "task-1.3-accepted-baseline-before-capability-provenance-foundation",
        "head": head,
        "expected_head": "a12b7cac05a818cc8d35c2ca440b7170a2807e92",
        "m3_source_candidate": "94f70e502c75132656bd0902a17be60ca45ab1c2",
        "source_and_administrative_differ": head != "94f70e502c75132656bd0902a17be60ca45ab1c2",
        "utc": datetime.now(timezone.utc).isoformat(),
        "capability_provenance_dir_exists": (ROOT / "lean/DefiKernel/CapabilityProvenance").exists(),
        "root_defikernel_import": (ROOT / "lean/DefiKernel.lean").read_text(),
        "private_cache": {
            "path": str(ROOT / "lean/.lake"),
            "is_symlink": (ROOT / "lean/.lake").is_symlink(),
            "resolved": str((ROOT / "lean/.lake").resolve()),
        },
        "closure": hash_list(CLOSURE, "closure-before"),
        "pins": hash_list(PINS, "pins-before"),
        "normative": hash_list(NORMATIVE, "normative-before"),
        "protected": hash_list(PROTECTED, "protected-before"),
        "tools": tool_hashes(),
    }
    missing = [row["path"] for row in snapshot["closure"] + snapshot["pins"] if not row.get("exists", True)]
    if missing:
        snapshot["blocked"] = {"reason": "missing declared baseline files", "paths": missing}
        (BASE / "snapshot-before.json").write_text(json.dumps(snapshot, indent=2) + "\n")
        print("BLOCKED missing files", missing)
        return 3
    if snapshot["capability_provenance_dir_exists"]:
        snapshot["note"] = "CapabilityProvenance already present; baseline still uses declared existing modules only"
    (BASE / "snapshot-before.json").write_text(json.dumps(snapshot, indent=2) + "\n")

    builds = []
    env = lake_env()
    for module in FOCUS_BUILDS:
        stem = "lake-" + module.replace(".", "-")
        rec = run_cmd(
            [str(LAKE), "build", module],
            cwd=ROOT / "lean",
            log_stem=stem,
            env=env,
            timeout=1800,
        )
        rec["module"] = module
        rec["lake_sha256"] = snapshot["tools"]["lake"]["sha256"]
        rec["lean_sha256"] = snapshot["tools"]["lean"]["sha256"]
        builds.append(rec)
        (BASE / f"{stem}.json").write_text(json.dumps(rec, indent=2) + "\n")
        if rec["exit_code"] != 0:
            (BASE / "builds.json").write_text(json.dumps(builds, indent=2) + "\n")
            print("FAIL", module, rec["exit_code"])
            return rec["exit_code"]

    (BASE / "builds.json").write_text(json.dumps(builds, indent=2) + "\n")

    runner = run_cmd(
        [sys.executable, str(ROOT / "scripts/test_metatheory_mutation_runner.py")],
        cwd=ROOT,
        log_stem="historical-runner",
        timeout=3600,
    )
    runner["script_sha256"] = sha256_file(ROOT / "scripts/test_metatheory_mutation_runner.py")["sha256"]
    runner["driver_sha256"] = sha256_file(ROOT / "scripts/check_metatheory_mutations.py")["sha256"]
    runner["spec_sha256"] = sha256_file(ROOT / "mutations/metatheory.json")["sha256"]
    (BASE / "historical-runner.json").write_text(json.dumps(runner, indent=2) + "\n")

    porcelain_after = git(["status", "--porcelain", "-uall"])
    (BASE / "git-status-after.txt").write_text(porcelain_after + "\n")
    after = {
        "head": git(["rev-parse", "HEAD"]),
        "closure": hash_list(CLOSURE, "closure-after"),
        "pins": hash_list(PINS, "pins-after"),
        "normative": hash_list(NORMATIVE, "normative-after"),
        "protected": hash_list(PROTECTED, "protected-after"),
        "porcelain_changed": porcelain_before != porcelain_after,
        "source_changed_by_verification": False,
    }
    before_map = {row["path"]: row.get("sha256") for row in snapshot["closure"] + snapshot["pins"] + snapshot["protected"]}
    after_map = {row["path"]: row.get("sha256") for row in after["closure"] + after["pins"] + after["protected"]}
    drifted = [p for p, h in before_map.items() if after_map.get(p) != h]
    after["drifted_protected_or_closure"] = drifted
    after["source_changed_by_verification"] = bool(drifted)
    (BASE / "snapshot-after.json").write_text(json.dumps(after, indent=2) + "\n")

    nonempty = {
        "closure_rows": len([r for r in snapshot["closure"] if r.get("exists")]),
        "pin_rows": len([r for r in snapshot["pins"] if r.get("exists")]),
        "normative_rows": len([r for r in snapshot["normative"] if r.get("exists")]),
        "builds": len(builds),
        "unique_closure_hashes": len({r["sha256"] for r in snapshot["closure"] if "sha256" in r}),
    }
    summary = {
        "head": head,
        "builds_all_exit_0": all(b["exit_code"] == 0 for b in builds),
        "runner_exit": runner["exit_code"],
        "source_unchanged": not after["source_changed_by_verification"],
        "inventory": nonempty,
        "capability_provenance_absent": not snapshot["capability_provenance_dir_exists"],
        "no_missing_feature_negative_credit": True,
    }
    (BASE / "summary.json").write_text(json.dumps(summary, indent=2) + "\n")
    print(json.dumps(summary, indent=2))
    if not summary["builds_all_exit_0"]:
        return 1
    if runner["exit_code"] not in (0,):
        return runner["exit_code"]
    if after["source_changed_by_verification"]:
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
