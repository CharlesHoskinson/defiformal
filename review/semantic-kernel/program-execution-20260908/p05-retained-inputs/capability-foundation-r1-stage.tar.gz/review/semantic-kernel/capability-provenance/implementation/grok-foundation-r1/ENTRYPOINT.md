# Foundation r1 entrypoint

Read `REPORT.md`, `compile-status.json`, `remaining-obligations.json`, `declaration-inventory.json`, `hashes/owned-source.json`, and `baseline/`.

Independent GPT-6 reviews this candidate. This worker does not self-accept.
