#!/usr/bin/env python3
import os, sys, json, re, subprocess, datetime, hashlib
from pathlib import Path

repo_root = Path("/home/charl/defiformal-wt-p19-certificates-grok-opus-20260909")
lean_dir = repo_root / "lean"
r18_dir = repo_root / "review/semantic-kernel/certificates/p19/implementation/agy-r18-proof"
logs_dir = r18_dir / "logs"
probes_dir = r18_dir / "probes"

os.makedirs(r18_dir, exist_ok=True)
os.makedirs(logs_dir, exist_ok=True)
os.makedirs(probes_dir, exist_ok=True)

def sha256_file(p):
    return hashlib.sha256(Path(p).read_bytes()).hexdigest()

def now_iso():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()

# Compiler info
lean_bin = "/home/charl/.elan/toolchains/leanprover--lean4---v4.33.0-rc2/bin/lean"
lake_bin = "/home/charl/.elan/toolchains/leanprover--lean4---v4.33.0-rc2/bin/lake"
preflight_bin = "/home/charl/.codex/plugins/cache/lean4-skills/lean4/4.8.7/bin/lean4-skills-preflight"

lean_ver_res = subprocess.run([lean_bin, "--version"], capture_output=True, text=True)
lean_version_str = lean_ver_res.stdout.strip()
compiler_info = {
    "version": lean_version_str,
    "lean_path": lean_bin,
    "lean_sha256": sha256_file(lean_bin),
    "lake_path": lake_bin,
    "lake_sha256": sha256_file(lake_bin)
}

# 1. Extract 311 declarations
def get_decls(filepath):
    with open(filepath) as f:
        content = f.read()
    return re.findall(r"^(?:theorem|lemma)\s+([A-Za-z0-9_.?]+)", content, re.MULTILINE)

cj_decls = get_decls(repo_root / "lean/DefiKernel/Certificates/CanonicalJson.lean")
corr_decls = get_decls(repo_root / "lean/DefiKernel/Certificates/Correspondence.lean")
assert len(cj_decls) == 68, f"Expected 68 CJ decls, got {len(cj_decls)}"
assert len(corr_decls) == 243, f"Expected 243 Corr decls, got {len(corr_decls)}"
all_decls = cj_decls + corr_decls
assert len(all_decls) == 311, f"Expected 311 total decls, got {len(all_decls)}"

# 2. Generate probe files
p1_file = probes_dir / "mixed_error_precedence.lean"
with open(p1_file, "w") as f:
    f.write('''import DefiKernel.Certificates.Correspondence
namespace DefiKernel.Certificates
set_option maxRecDepth 500000
set_option maxHeartbeats 4000000
def mixedErrorInputs : List (String × String) := [
  ("bad_escape_then_scientific", "{\\"a\\":\\"\\\\x\\",\\"b\\":1e2}"),
  ("whitespace_then_bad_escape", "{\\"a\\": \\"\\\\x\\"}"),
  ("bad_escape_then_duplicate", "{\\"a\\":\\"\\\\x\\",\\"b\\":1,\\"b\\":2}"),
  ("bad_escape_then_depth", "{\\"a\\":\\"\\\\x\\",\\"b\\":[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[0]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]}"),
  ("scientific_then_bad_escape", "{\\"b\\":1e2,\\"a\\":\\"\\\\x\\"}"),
  ("duplicate_then_bad_escape", "{\\"b\\":1,\\"b\\":2,\\"a\\":\\"\\\\x\\"}")
]
#eval mixedErrorInputs.map fun (name, s) =>
  let scan := match scanLexical s.toUTF8 with | .ok _ => "ok" | .error e => reprStr e
  let dec := match decodeBytes s.toUTF8 with | .ok _ => "ok" | .error e => reprStr e
  s!"{name};scan={scan};decode={dec}"
end DefiKernel.Certificates
''')

p2_file = probes_dir / "c0_controls.lean"
with open(p2_file, "w") as f:
    f.write('''import DefiKernel.Certificates.Correspondence
namespace DefiKernel.Certificates
set_option maxRecDepth 500000
set_option maxHeartbeats 4000000
def controlIR (sm : List (String × String)) : DecodedIR :=
  match canonicalWitnessIR with
  | .execution (.typed env payload) => .execution (.typed { env with source_map := sm } payload)
  | ir => ir
def runControl (n : Nat) : String := Id.run do
  let k := "k" ++ String.singleton (Char.ofNat n)
  let aliasKey := String.ofList ['k', 'u', '0', '0', hexDigit (n / 16), hexDigit (n % 16)]
  let ir := controlIR [(k, "v1"), (aliasKey, "v2")]
  let raw := encodeModule ir
  let str := (String.fromUTF8? raw).getD ""
  let scan := match scanLexical raw with | .ok _ => "ok" | .error e => reprStr e
  let dec := match decodeBytes raw with | .ok _ => "ok" | .error e => reprStr e
  let parser := match parseCanonicalJson str with
    | .ok j => match decodeDecodedIR j str with | .ok _ => "ok" | .error e => reprStr e
    | .error e => reprStr e
  return s!"C0={n};size={raw.size};depth={jsonDepth (decodedIRToJson ir)};maxArray={jsonMaxArrayLength (decodedIRToJson ir)};sorted={isSortedStrictAscending [k,aliasKey]};scan={scan};decode={dec};parserObject={parser}"
#eval List.range 32 |>.map runControl
#eval ["{\\"a\\":\\"1\\",\\"a\\":\\"2\\"}", "{\\"a\\":\\"1\\",\\"\\\\u0061\\":\\"2\\"}", "{\\"q\\\\\\":\\"1\\",\\"q\\":\\"2\\"}", "{\\"b\\\\\\\\\\":\\"1\\",\\"b\\":\\"2\\"}"].map fun s =>
  let scan := match scanLexical s.toUTF8 with | .ok _ => "ok" | .error e => reprStr e
  let parser := match parseCanonicalJson s with | .ok _ => "ok" | .error e => reprStr e
  s!"raw={s};scan={scan};parser={parser}"
end DefiKernel.Certificates
''')

p3_file = probes_dir / "named_axioms_311.lean"
with open(p3_file, "w") as f:
    f.write("import DefiKernel.Certificates.CanonicalJson\n")
    f.write("import DefiKernel.Certificates.Correspondence\n\n")
    for name in all_decls:
        f.write(f"#print axioms DefiKernel.Certificates.{name}\n")

# Commands specification
commands_spec = [
    {
        "id": "CMD-01",
        "name": "lean4-skills-preflight",
        "argv": [preflight_bin, "--codex"],
        "cwd": str(repo_root),
        "purpose": "Verify Lean4 skills preflight environment and plugin integrity with --codex"
    },
    {
        "id": "CMD-02",
        "name": "lake-build-defikernel",
        "argv": [lake_bin, "build", "DefiKernel"],
        "cwd": str(lean_dir),
        "purpose": "Full build of DefiKernel modules (Schema, Encode, Decode, CanonicalJson, Correspondence, etc.)"
    },
    {
        "id": "CMD-03",
        "name": "lake-build-tests",
        "argv": [lake_bin, "build", "DefiKernel.Certificates.Tests"],
        "cwd": str(lean_dir),
        "purpose": "Build and replay all 21 certificate unit tests and sanity checks"
    },
    {
        "id": "CMD-04",
        "name": "transitive-verify",
        "argv": [lake_bin, "env", lean_bin, "DefiKernel/Certificates/Verify.lean"],
        "cwd": str(lean_dir),
        "purpose": "Execute transitive compiler axiom audit across Certificates, Typed, and Composition scopes"
    },
    {
        "id": "CMD-05",
        "name": "probe-mixed-error-precedence",
        "argv": [lake_bin, "env", lean_bin, str(p1_file)],
        "cwd": str(lean_dir),
        "probe": str(p1_file),
        "purpose": "Execute 6-case root diagnostic probe verifying exact mixed-error failure precedence restoration matching R15"
    },
    {
        "id": "CMD-06",
        "name": "probe-c0-controls",
        "argv": [lake_bin, "env", lean_bin, str(p2_file)],
        "cwd": str(lean_dir),
        "probe": str(p2_file),
        "purpose": "Execute 32 C0 collision roundtrips, escaped key duplicate detection, and quote/backslash controls"
    },
    {
        "id": "CMD-07",
        "name": "probe-named-axioms-311",
        "argv": [lake_bin, "env", lean_bin, str(p3_file)],
        "cwd": str(lean_dir),
        "probe": str(p3_file),
        "purpose": "Direct compiler #print axioms query for all 311 named declarations in CanonicalJson and Correspondence"
    },
    {
        "id": "CMD-08",
        "name": "test-fixture-runner",
        "argv": [sys.executable, "scripts/test_certificate_fixture_runner.py"],
        "cwd": str(repo_root),
        "purpose": "Execute certificate fixture runner safety regressions (7/7 pass)"
    }
]

commands_record = []
for spec in commands_spec:
    cid = spec["id"]
    cname = spec["name"]
    cmd_log_dir = logs_dir / cid.lower()
    os.makedirs(cmd_log_dir, exist_ok=True)

    stdout_path = cmd_log_dir / "stdout.log"
    stderr_path = cmd_log_dir / "stderr.log"

    start_t = now_iso()
    print(f"Running {cid}: {' '.join(spec['argv'])} in {spec['cwd']} ...")
    res = subprocess.run(spec["argv"], cwd=spec["cwd"], capture_output=True)
    end_t = now_iso()

    stdout_path.write_bytes(res.stdout)
    stderr_path.write_bytes(res.stderr)

    rec = {
        "id": cid,
        "name": cname,
        "argv": spec["argv"],
        "cwd": spec["cwd"],
        "start": start_t,
        "end": end_t,
        "exit": res.returncode,
        "compiler": compiler_info,
        "rawstdout": str(stdout_path.relative_to(r18_dir)),
        "rawstderr": str(stderr_path.relative_to(r18_dir)),
        "stdout_sha256": hashlib.sha256(res.stdout).hexdigest(),
        "stderr_sha256": hashlib.sha256(res.stderr).hexdigest(),
        "purpose": spec["purpose"]
    }
    if "probe" in spec:
        rec["probe"] = str(Path(spec["probe"]).relative_to(r18_dir))
        rec["probe_sha256"] = sha256_file(spec["probe"])

    # Meta json in logs folder
    with open(cmd_log_dir / "meta.json", "w") as f:
        json.dump(rec, f, indent=2)

    commands_record.append(rec)
    print(f"  {cid} finished with exit code {res.returncode}")
    assert res.returncode == 0, f"{cid} failed with exit code {res.returncode}"

# Write commands.json
with open(r18_dir / "commands.json", "w") as f:
    json.dump(commands_record, f, indent=2)

print("commands.json successfully written.")
