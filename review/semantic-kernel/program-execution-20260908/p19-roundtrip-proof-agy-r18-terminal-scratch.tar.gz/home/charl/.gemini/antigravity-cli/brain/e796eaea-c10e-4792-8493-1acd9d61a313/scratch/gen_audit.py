import json, re, subprocess, datetime, hashlib
from pathlib import Path

repo_root = Path("/home/charl/defiformal-wt-p19-certificates-grok-opus-20260909")
lean_dir = repo_root / "lean"
scratch_dir = Path("/home/charl/.gemini/antigravity-cli/brain/e796eaea-c10e-4792-8493-1acd9d61a313/scratch")

def get_decls(filepath):
    with open(filepath) as f:
        content = f.read()
    # Match theorem or lemma declarations
    matches = re.findall(r"^(?:theorem|lemma)\s+([A-Za-z0-9_.?]+)", content, re.MULTILINE)
    return matches

cj_decls = get_decls(repo_root / "lean/DefiKernel/Certificates/CanonicalJson.lean")
corr_decls = get_decls(repo_root / "lean/DefiKernel/Certificates/Correspondence.lean")

print(f"CanonicalJson decls: {len(cj_decls)}")
print(f"Correspondence decls: {len(corr_decls)}")
all_decls = cj_decls + corr_decls
print(f"Total decls: {len(all_decls)}")

probe_file = scratch_dir / "audit_311.lean"
with open(probe_file, "w") as f:
    f.write("import DefiKernel.Certificates.CanonicalJson\n")
    f.write("import DefiKernel.Certificates.Correspondence\n\n")
    for name in all_decls:
        f.write(f"#print axioms DefiKernel.Certificates.{name}\n")

print(f"Wrote probe to {probe_file}")
