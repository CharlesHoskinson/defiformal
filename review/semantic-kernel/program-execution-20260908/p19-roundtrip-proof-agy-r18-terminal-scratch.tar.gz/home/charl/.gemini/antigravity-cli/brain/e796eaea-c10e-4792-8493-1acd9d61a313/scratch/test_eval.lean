import DefiKernel.Certificates.CanonicalJson

open DefiKernel.Certificates

/-- Pushdown parser transition for first key and colon in empty/initial object frame. -/
theorem parse_obj_first_field_step (k : String) (v_toks : List JsonToken) (v : Lean.Json)
    (acc : List (String × Lean.Json)) (rest : List StackFrame)
    (h_val : v_toks.foldlM parseStep { stack := StackFrame.obj acc (ObjState.expectVal k) :: rest, result := none } =
             .ok { stack := StackFrame.obj ((k, v) :: acc) ObjState.expectCommaOrRbrace :: rest, result := none }) :
    (JsonToken.str k :: JsonToken.colon :: v_toks).foldlM parseStep { stack := StackFrame.obj acc ObjState.emptyOrKey :: rest, result := none } =
    .ok { stack := StackFrame.obj ((k, v) :: acc) ObjState.expectCommaOrRbrace :: rest, result := none } := by
  have h_split : (JsonToken.str k :: JsonToken.colon :: v_toks) = [JsonToken.str k, JsonToken.colon] ++ v_toks := rfl
  rw [h_split, List.foldlM_append]
  dsimp [bind, Except.bind, parseStep]
  exact h_val

/-- Pushdown parser transition for first key, colon, value and trailing comma in empty/initial object frame. -/
theorem parse_obj_first_field_comma (k : String) (v_toks : List JsonToken) (v : Lean.Json)
    (acc : List (String × Lean.Json)) (rest : List StackFrame)
    (h_val : v_toks.foldlM parseStep { stack := StackFrame.obj acc (ObjState.expectVal k) :: rest, result := none } =
             .ok { stack := StackFrame.obj ((k, v) :: acc) ObjState.expectCommaOrRbrace :: rest, result := none }) :
    ((JsonToken.str k :: JsonToken.colon :: v_toks) ++ [JsonToken.comma]).foldlM parseStep { stack := StackFrame.obj acc ObjState.emptyOrKey :: rest, result := none } =
    .ok { stack := StackFrame.obj ((k, v) :: acc) ObjState.expectKey :: rest, result := none } := by
  rw [List.foldlM_append]
  have h_step := parse_obj_first_field_step k v_toks v acc rest h_val
  rw [h_step]
  rfl

/-- Feeding scalar string property into object frame expecting value. -/
theorem parse_field_str_val (acc : List (String × Lean.Json)) (key s : String) (rest : List StackFrame)
    (h_not_dup : acc.any (fun (k, _) => k == key) = false) :
    [JsonToken.str s].foldlM parseStep { stack := StackFrame.obj acc (ObjState.expectVal key) :: rest, result := none } =
    .ok { stack := StackFrame.obj ((key, Lean.Json.str s) :: acc) ObjState.expectCommaOrRbrace :: rest, result := none } := by
  dsimp [List.foldlM, parseStep, bind, Except.bind]
  rw [feedValue_obj_expectVal acc key (.str s) rest h_not_dup]
  rfl

/-- Feeding scalar number property into object frame expecting value. -/
theorem parse_field_num_val (acc : List (String × Lean.Json)) (key : String) (n : Lean.JsonNumber) (rest : List StackFrame)
    (h_not_dup : acc.any (fun (k, _) => k == key) = false) :
    [JsonToken.num n].foldlM parseStep { stack := StackFrame.obj acc (ObjState.expectVal key) :: rest, result := none } =
    .ok { stack := StackFrame.obj ((key, Lean.Json.num n) :: acc) ObjState.expectCommaOrRbrace :: rest, result := none } := by
  dsimp [List.foldlM, parseStep, bind, Except.bind]
  rw [feedValue_obj_expectVal acc key (.num n) rest h_not_dup]
  rfl

/-- Feeding scalar boolean property into object frame expecting value. -/
theorem parse_field_bool_val (acc : List (String × Lean.Json)) (key : String) (b : Bool) (rest : List StackFrame)
    (h_not_dup : acc.any (fun (k, _) => k == key) = false) :
    [JsonToken.bool b].foldlM parseStep { stack := StackFrame.obj acc (ObjState.expectVal key) :: rest, result := none } =
    .ok { stack := StackFrame.obj ((key, Lean.Json.bool b) :: acc) ObjState.expectCommaOrRbrace :: rest, result := none } := by
  dsimp [List.foldlM, parseStep, bind, Except.bind]
  rw [feedValue_obj_expectVal acc key (.bool b) rest h_not_dup]
  rfl

/-- Feeding null property into object frame expecting value. -/
theorem parse_field_null_val (acc : List (String × Lean.Json)) (key : String) (rest : List StackFrame)
    (h_not_dup : acc.any (fun (k, _) => k == key) = false) :
    [JsonToken.null].foldlM parseStep { stack := StackFrame.obj acc (ObjState.expectVal key) :: rest, result := none } =
    .ok { stack := StackFrame.obj ((key, Lean.Json.null) :: acc) ObjState.expectCommaOrRbrace :: rest, result := none } := by
  dsimp [List.foldlM, parseStep, bind, Except.bind]
  rw [feedValue_obj_expectVal acc key .null rest h_not_dup]
  rfl

#print axioms parse_obj_first_field_step
#print axioms parse_obj_first_field_comma
#print axioms parse_field_str_val
#print axioms parse_field_num_val
#print axioms parse_field_bool_val
#print axioms parse_field_null_val
