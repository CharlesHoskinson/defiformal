#!/usr/bin/env python3
"""Q3 probe of the FROZEN vault_exec.run_lean_vault_bindings parser.

DISCLOSURE: this probe substitutes vault_exec.record_cmd with a private stub so
crafted model-output streams and process receipts can be fed to the real parser
without recompiling Lean. The parser body under test is the unmodified frozen
function. No Solidity production-mutant or fresh-model-execution credit is
claimed from this attempt.
"""
from __future__ import annotations

import hashlib
import json
import os
import sys
import time
import traceback
from pathlib import Path

DIAG = Path("/home/charl/defiformal/review/semantic-kernel/program-execution-20260908/p17-agy-r2-opus-consumer-diagnostic")
ENGINE = DIAG / "snapshot/scripts/platform_engine"
sys.path.insert(0, str(ENGINE))

import common  # noqa: E402
import vault_exec  # noqa: E402

IDS = list(common.VAULT_FIXTURE_IDS)
OK_VAL = "1000000000000000000"


def good_line(fid: str) -> str:
    if fid in ("P17-DEP-D0", "P17-MINT-D0", "P17-RED-D0", "P17-WD-D0", "P17-DEP-D1",
               "P17-MINT-D1", "P17-RED-D1", "P17-WD-D1", "P17-DEP-ZERO", "P17-RED-DELEGATED"):
        return f"{fid} status=ok value={OK_VAL}"
    return f"{fid} status=error failure=SUsds/invalid-address"


FULL = [good_line(i) for i in IDS]

PROBES = {
    "P1-intact-control": {
        "stdout": "\n".join(FULL) + "\n",
        "receipt_exit": 0, "classification": "ok", "valid": True, "timeout": False,
        "expect": "17 rows, honest baseline",
    },
    "P2-truncated-partial-stdout": {
        "stdout": "\n".join(FULL[:9]) + "\n",
        "receipt_exit": 0, "classification": "ok", "valid": True, "timeout": False,
        "expect": "9 of 17 rows; does the parser signal the shortfall to its caller?",
    },
    "P3-nonzero-process-receipt": {
        "stdout": "\n".join(FULL) + "\n",
        "receipt_exit": 1, "classification": "nonzero", "valid": True, "timeout": False,
        "expect": "full stdout but the process failed",
    },
    "P4-timeout-blocked-receipt": {
        "stdout": "\n".join(FULL[:5]) + "\n",
        "receipt_exit": 124, "classification": "timeout_blocked", "valid": False,
        "timeout": True, "reason": "timeout is blocked, never success",
        "expect": "recorder marked the run invalid/timed out",
    },
    "P5-duplicate-row-last-wins": {
        "stdout": "\n".join(FULL) + "\nP17-DEP-D0 status=ok value=999\n",
        "receipt_exit": 0, "classification": "ok", "valid": True, "timeout": False,
        "expect": "duplicate id with a conflicting value",
    },
    "P6-malformed-value": {
        "stdout": "\n".join(FULL[:3]) + "\nP17-DEP-MUL-OVF status=ok value=NaN\n",
        "receipt_exit": 0, "classification": "ok", "valid": True, "timeout": False,
        "expect": "non-integer value field",
    },
    "P7-foreign-P17-line": {
        "stdout": "\n".join(FULL[:16]) + "\nP17-RED-DELEGATED status=ok value=1\n",
        "receipt_exit": 0, "classification": "ok", "valid": True, "timeout": False,
        "expect": "a P17- prefixed line that is not a formatRow emission",
    },
    "P8-blocked-receipt-no-wrapper": {
        "stdout": None,  # simulate record_cmd returning blocked(): no _wrapper key
        "receipt_exit": None, "classification": None, "valid": None, "timeout": None,
        "expect": "record_cmd itself returned a blocked report",
    },
}


def main() -> int:
    base = Path(sys.argv[1])
    base.mkdir(parents=True, exist_ok=True)
    results = {}
    real_record_cmd = vault_exec.record_cmd

    for name, cfg in PROBES.items():
        d = base / name
        d.mkdir(parents=True, exist_ok=True)

        def fake_record_cmd(_n, cmd, cwd, out_dir, timeout=None, env_pairs=None, _cfg=cfg, _d=d):
            out_dir = Path(out_dir)
            out_dir.mkdir(parents=True, exist_ok=True)
            (_d / "substituted_cmd.json").write_text(
                json.dumps({"cmd": cmd, "cwd": str(cwd), "timeout": timeout}, indent=2))
            if _cfg["stdout"] is None:
                return common.blocked("frozen record_cmd.py missing",
                                      {"path": str(common.RECORDER)})
            sp = out_dir / "stdout.bin"
            sp.write_text(_cfg["stdout"])
            rec = {
                "name": _n, "exit": _cfg["receipt_exit"],
                "classification": _cfg["classification"],
                "valid": _cfg["valid"], "timeout": _cfg["timeout"],
                "_wrapper": {"stdout_path": str(sp), "wrapper_exit": _cfg["receipt_exit"]},
            }
            if "reason" in _cfg:
                rec["reason"] = _cfg["reason"]
            return rec

        vault_exec.record_cmd = fake_record_cmd
        entry = {"expect": cfg["expect"], "receipt_exit": cfg["receipt_exit"],
                 "receipt_classification": cfg["classification"],
                 "receipt_valid": cfg["valid"],
                 "stdout_lines": 0 if cfg["stdout"] is None else len(cfg["stdout"].strip().splitlines())}
        try:
            parsed = vault_exec.run_lean_vault_bindings(d / "lean")
            entry["parser_raised"] = None
            entry["returned_row_count"] = len(parsed)
            entry["returned_ids"] = sorted(parsed)
            entry["missing_ids"] = [i for i in IDS if i not in parsed]
            entry["dep_d0_value"] = parsed.get("P17-DEP-D0", {}).get("value")
            summ_p = d / "lean" / "bindings-summary.json"
            if summ_p.is_file():
                s = json.loads(summ_p.read_text())
                entry["summary_status_on_disk"] = s.get("status")
                entry["summary_count_on_disk"] = s.get("count")
            entry["caller_sees_only"] = "the returned dict; summary status is not returned"
        except BaseException as exc:  # noqa: BLE001
            entry["parser_raised"] = repr(exc)
            entry["traceback"] = traceback.format_exc().splitlines()[-4:]
        vault_exec.record_cmd = real_record_cmd
        results[name] = entry
        print(name, json.dumps(entry, sort_keys=True))

    prov = {
        "argv": sys.argv, "cwd": os.getcwd(),
        "utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        "recorder_substituted": True,
        "disclosure": ("vault_exec.record_cmd replaced by a private stub for these probes only; "
                       "the parser under test is the unmodified frozen run_lean_vault_bindings"),
        "vault_exec_sha256": hashlib.sha256((ENGINE / "vault_exec.py").read_bytes()).hexdigest(),
        "common_sha256": hashlib.sha256((ENGINE / "common.py").read_bytes()).hexdigest(),
        "parser_file": vault_exec.run_lean_vault_bindings.__code__.co_filename,
        "parser_firstline": vault_exec.run_lean_vault_bindings.__code__.co_firstlineno,
    }
    (base / "provenance.json").write_text(json.dumps(prov, indent=2, sort_keys=True))
    (base / "result.json").write_text(json.dumps(results, indent=2, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
