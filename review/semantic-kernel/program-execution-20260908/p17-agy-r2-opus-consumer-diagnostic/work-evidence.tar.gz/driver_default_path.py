#!/usr/bin/env python3
"""End-to-end probe of the PRODUCTION path: run_fixtures with lean_rows omitted.

DISCLOSURE: vault_exec.record_cmd is replaced by a private stub ONLY for the
Lean-bindings subprocess, so a blocked/failed model run can be simulated without
Lean recompilation. EVM execution is unaffected and uses the real frozen
record_cmd + pinned evm binary. No fresh-model-execution credit is claimed.
"""
from __future__ import annotations
import hashlib, json, os, sys, time, traceback
from pathlib import Path

DIAG = Path("/home/charl/defiformal/review/semantic-kernel/program-execution-20260908/p17-agy-r2-opus-consumer-diagnostic")
ENGINE = DIAG / "snapshot/scripts/platform_engine"
DEPLOY = DIAG / "work/setup/evm/execute/deploy"
sys.path.insert(0, str(ENGINE))
import common, vault_exec  # noqa: E402

attempt = Path(sys.argv[1]); attempt.mkdir(parents=True, exist_ok=True)
mode = sys.argv[2]  # "blocked-recorder" | "nonzero-exit-full-rows"
real = vault_exec.record_cmd
FULL = [(f"{i} status=ok value=1000000000000000000" if i in
         ("P17-DEP-D0","P17-MINT-D0","P17-RED-D0","P17-WD-D0","P17-DEP-D1","P17-MINT-D1",
          "P17-RED-D1","P17-WD-D1","P17-DEP-ZERO","P17-RED-DELEGATED")
         else f"{i} status=error failure=SUsds/invalid-address")
        for i in common.VAULT_FIXTURE_IDS]

def stub(name, cmd, cwd, out_dir, timeout=None, env_pairs=None):
    if name != "lean-vault-bindings":
        return real(name, cmd, cwd, out_dir, timeout=timeout, env_pairs=env_pairs)
    out_dir = Path(out_dir); out_dir.mkdir(parents=True, exist_ok=True)
    if mode == "blocked-recorder":
        # exactly what common.record_cmd returns when the pinned recorder is absent
        return common.blocked("frozen record_cmd.py missing", {"path": str(common.RECORDER)})
    sp = out_dir / "stdout.bin"; sp.write_text("\n".join(FULL) + "\n")
    return {"name": name, "exit": 1, "classification": "nonzero", "valid": True,
            "timeout": False, "_wrapper": {"stdout_path": str(sp), "wrapper_exit": 1}}

vault_exec.record_cmd = stub
addrs = json.loads((DEPLOY / "addresses.json").read_text())
res = {"mode": mode}
try:
    scored = vault_exec.run_fixtures(
        attempt / "fixtures", addrs, DEPLOY / "create-proxy/genesis.json",
        fixture_ids=["P17-DEP-D0", "P17-DEP-BAD-RECV", "P17-RED-BAL"])
    res["scored"] = scored
    rows = json.loads((attempt / "fixtures" / "rows.json").read_text())
    res["row_gates"] = [{"id": r["id"], "gate": r["comparison"]["gate"],
                         "semantic_ok": r["comparison"].get("semantic_ok"),
                         "lean_model": r["comparison"].get("lean_model"),
                         "lean_model_match": r["comparison"].get("lean_model_match"),
                         "refusal_match": r["comparison"].get("refusal_match")} for r in rows]
except BaseException as e:
    res["driver_exception"] = repr(e); res["traceback"] = traceback.format_exc()
vault_exec.record_cmd = real

prov = {"argv": sys.argv, "cwd": os.getcwd(), "mode": mode,
        "utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        "recorder_substituted": True,
        "disclosure": "lean-vault-bindings subprocess stubbed; EVM used the real frozen recorder",
        "lean_rows_argument": "omitted (production default path)",
        "vault_exec_sha256": hashlib.sha256((ENGINE/"vault_exec.py").read_bytes()).hexdigest()}
(attempt/"provenance.json").write_text(json.dumps(prov, indent=2, sort_keys=True))
(attempt/"result.json").write_text(json.dumps(res, indent=2, sort_keys=True))
print(json.dumps({k: v for k, v in res.items() if k != "row_gates"}, sort_keys=True))
for r in res.get("row_gates", []): print("ROW", json.dumps(r, sort_keys=True))
