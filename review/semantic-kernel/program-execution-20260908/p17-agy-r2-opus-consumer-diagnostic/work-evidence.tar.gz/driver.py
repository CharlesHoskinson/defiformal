#!/usr/bin/env python3
"""Opus consumer diagnostic driver.

Imports the FROZEN snapshot engine unmodified and calls the real public
vault_exec.run_fixtures / common.score_rows. Only the output directory and the
public lean_rows argument vary between attempts. No consumer logic is
reimplemented here.
"""
from __future__ import annotations

import hashlib
import json
import os
import sys
import time
import traceback
from pathlib import Path

DIAG = Path("/home/charl/defiformal/review/semantic-kernel/program-execution-20260908/p17-agy-r2-opus-consumer-diagnostic")
SNAP = DIAG / "snapshot"
ENGINE = SNAP / "scripts/platform_engine"
DEPLOY = DIAG / "work/setup/evm/execute/deploy"

sys.path.insert(0, str(ENGINE))


def sha(p: Path) -> str:
    return hashlib.sha256(Path(p).read_bytes()).hexdigest()


def main() -> int:
    scenario = sys.argv[1]
    attempt_dir = Path(sys.argv[2])
    spec = json.loads(Path(sys.argv[3]).read_text())
    attempt_dir.mkdir(parents=True, exist_ok=True)

    import common  # noqa: E402
    import vault_exec  # noqa: E402
    from score import score_rows  # noqa: E402

    prov = {
        "scenario": scenario,
        "argv": sys.argv,
        "cwd": os.getcwd(),
        "started_utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        "engine_root_ROOT": str(common.ROOT),
        "FIXTURES": str(vault_exec.FIXTURES),
        "RECORDER": str(common.RECORDER),
        "recorder_sha256": sha(common.RECORDER),
        "source_hashes": {
            "vault_exec.py": sha(ENGINE / "vault_exec.py"),
            "common.py": sha(ENGINE / "common.py"),
            "score.py": sha(ENGINE / "score.py"),
            "evm.py": sha(ENGINE / "evm.py"),
            "fixtures.json": sha(vault_exec.FIXTURES),
        },
        "run_fixtures_qualname": f"{vault_exec.run_fixtures.__module__}.{vault_exec.run_fixtures.__qualname__}",
        "run_fixtures_file": vault_exec.run_fixtures.__code__.co_filename,
        "score_rows_file": score_rows.__code__.co_filename,
        "spec": spec,
        "recorder_substituted": False,
    }

    addrs = json.loads((DEPLOY / "addresses.json").read_text())
    genesis = DEPLOY / "create-proxy/genesis.json"
    prov["addresses_sha256"] = sha(DEPLOY / "addresses.json")
    prov["genesis_sha256"] = sha(genesis)

    lean_rows = spec.get("lean_rows")
    if lean_rows == "OMIT":
        lean_rows = None

    result = {}
    try:
        scored = vault_exec.run_fixtures(
            attempt_dir / "fixtures",
            addrs,
            genesis,
            fixture_ids=spec.get("fixture_ids"),
            lean_rows=lean_rows,
        )
        result["scored"] = scored
        rows = json.loads((attempt_dir / "fixtures" / "rows.json").read_text())
        result["row_gates"] = [
            {
                "id": r.get("id"),
                "gate": r.get("comparison", {}).get("gate"),
                "reason": r.get("comparison", {}).get("reason"),
                "semantic_ok": r.get("comparison", {}).get("semantic_ok"),
                "lean_model": r.get("comparison", {}).get("lean_model"),
                "lean_model_match": r.get("comparison", {}).get("lean_model_match"),
                "refusal_match": r.get("comparison", {}).get("refusal_match"),
                "decoded_error": r.get("comparison", {}).get("decoded_error"),
                "expected_error": r.get("comparison", {}).get("expected_error"),
                "cells_gate": (r.get("comparison", {}).get("cells") or {}).get("gate"),
                "returndata_gate": (r.get("comparison", {}).get("returndata_cmp") or {}).get("gate"),
                "log_gate": (r.get("comparison", {}).get("log_cmp") or {}).get("gate"),
            }
            for r in rows
        ]
        result["consumer_status"] = scored.get("status")
        result["consumer_exit"] = scored.get("exit")
    except BaseException as exc:  # noqa: BLE001
        result["driver_exception"] = repr(exc)
        result["traceback"] = traceback.format_exc()

    prov["finished_utc"] = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
    (attempt_dir / "provenance.json").write_text(json.dumps(prov, indent=2, sort_keys=True))
    (attempt_dir / "result.json").write_text(json.dumps(result, indent=2, sort_keys=True))
    print(json.dumps({k: result[k] for k in result if k != "row_gates"}, sort_keys=True))
    for rg in result.get("row_gates", []):
        print("ROW", json.dumps(rg, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
