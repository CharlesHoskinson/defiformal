import DefiKernel.Typed.Transition
import DefiKernel.Arithmetic.Quantity
import DefiKernel.ConcentratedLiquidity.SqrtPriceMath

/-! Model-only quote-register wrap of the delivered token0 library.
Not Uniswap pool storage, not cash settlement, not a source observation. -/
namespace DefiKernel.ConcentratedLiquidity.Token0Bridge
open DefiKernel.Typed
open DefiKernel.ConcentratedLiquidity
open DefiKernel.Arithmetic
open SqrtPriceMath
open FullMath

inductive Party | quoteHolder
  deriving DecidableEq, Repr
inductive Asset | quoteSqrtP
  deriving DecidableEq, Repr
inductive Domain | quote
  deriving DecidableEq, Repr

instance : Fintype Party := ⟨{.quoteHolder}, by intro p; cases p; simp⟩
instance : Fintype Asset := ⟨{.quoteSqrtP}, by intro a; cases a; simp⟩
instance : Fintype Domain := ⟨{.quote}, by intro d; cases d; simp⟩

def op : OperationId := ⟨1⟩
def scale1 : ℚ := 1
theorem scale1_pos : (0 : ℚ) < scale1 := by decide

def sqrtP_Q96 : U160 := ⟨2 ^ 96, by decide⟩
def L1 : U128 := ⟨1, by decide⟩
def amt1 : U256 := ⟨1, by decide⟩
def amt0 : U256 := ⟨0, by decide⟩

def libraryWord (sqrtP : U160) (L : U128) (amount : U256) (add : Bool) :
    Except Failure U160 :=
  getNextSqrtPriceFromAmount0RoundingUp sqrtP L amount add

def lift (w : U160) : Quantity Asset.quoteSqrtP :=
  Quantity.toQuantity Asset.quoteSqrtP scale1 scale1_pos
    (⟨w.value, Nat.lt_trans w.bound two_pow_160_lt_256⟩ : Word 256)

def quoteTemplate (pre post : ℚ) : Template Party Asset Domain where
  signature := []
  domain := .quote
  partyArity := 0
  guard := .lit true
  deltas := [⟨.quoteSqrtP, ⟨.quote, .literal .quoteHolder⟩, .lit (post - pre)⟩]
  supplyDeltas := [⟨.quote, .quoteSqrtP, .lit (post - pre)⟩]
  stateReads := []
  envReads := []
  writes := [⟨.quoteSqrtP, ⟨.quote, .literal .quoteHolder⟩⟩]

def registry (pre post : ℚ) : Registry Party Asset Domain :=
  fun selected => if selected = op then some (quoteTemplate pre post) else none

def evaluated (pre post : ℚ) : Evaluated Party Asset Domain :=
  ⟨true, [((.quote, .quoteHolder, .quoteSqrtP), post - pre)],
    [((.quote, .quoteSqrtP), post - pre)], [], [], [], [],
    [(.quote, .quoteHolder, .quoteSqrtP)]⟩

def store : CapabilityStore Party Asset Domain :=
  ⟨[⟨⟨.quoteHolder, .quote, op, .invoke⟩, true⟩,
    ⟨⟨.quoteHolder, .quote, op, .debit (.quote, .quoteHolder, .quoteSqrtP)⟩, true⟩,
    ⟨⟨.quoteHolder, .quote, op, .changeSupply .quote .quoteSqrtP⟩, true⟩]⟩

def ctx : InvocationContext Party Domain := ⟨.quoteHolder, .quote⟩
def env : Environment Asset Domain := fun _ => none
def req : Request Party Asset Domain := ⟨op, [], [], [⟨0⟩, ⟨1⟩, ⟨2⟩], none⟩

def preRegister (pre : ℚ) (h : 0 ≤ pre) : State Party Asset Domain where
  balance
    | (.quote, .quoteHolder, .quoteSqrtP) => pre
    | _ => 0
  nonneg := by
    intro c
    rcases c with ⟨d, p, a⟩
    cases d; cases p; cases a
    simp [h]

-- BEGIN PROOFS

theorem two_pow_96_lt_160 : 2 ^ 96 < 2 ^ 160 :=
  Nat.pow_lt_pow_right (by decide : 1 < 2) (by decide : 96 < 160)

theorem sqrtP_Q96_value : sqrtP_Q96.value = 2 ^ 96 := rfl

theorem two_pow_95_lt_160 : 2 ^ 95 < 2 ^ 160 :=
  Nat.pow_lt_pow_right (by decide : 1 < 2) (by decide : 95 < 160)

def postWord : U160 := ⟨2 ^ 95, two_pow_95_lt_160⟩

theorem amt1_pos : amt1.value ≠ 0 := by decide

theorem ordinary_product : product amt1 sqrtP_Q96 = 2 ^ 96 := by
  simp [product, amt1, sqrtP_Q96]

theorem ordinary_numerator1 : numerator1 L1 = 2 ^ 96 := by
  simp [numerator1, Q96, L1]

theorem ordinary_product_fit : product amt1 sqrtP_Q96 < 2 ^ 256 := by
  rw [ordinary_product]
  exact Nat.pow_lt_pow_right (by decide : 1 < 2) (by decide : 96 < 256)

theorem two_pow_96_mul : (2 ^ 96) * (2 ^ 96) = 2 ^ 192 := (Nat.pow_add 2 96 96).symm

theorem two_pow_96_add : 2 ^ 96 + 2 ^ 96 = 2 ^ 97 := by
  have h : 2 ^ 96 + 2 ^ 96 = 2 * 2 ^ 96 := by ring
  rw [h, ← Nat.pow_succ]

theorem two_pow_95_mul_97 : (2 ^ 95) * (2 ^ 97) = 2 ^ 192 := (Nat.pow_add 2 95 97).symm

theorem ordinary_divup :
    Rounding.divideNat .up ((2 ^ 96) * (2 ^ 96)) (2 ^ 97) = .ok (2 ^ 95) := by
  have hpos : 0 < 2 ^ 97 := Nat.pow_pos (by decide : 0 < 2) _
  have hdiv : 2 ^ 97 ∣ 2 ^ 192 := Nat.pow_dvd_pow 2 (by decide : 97 ≤ 192)
  have hquot : 2 ^ 192 / 2 ^ 97 = 2 ^ 95 :=
    Nat.pow_div (by decide : 97 ≤ 192) (by decide : 0 < 2)
  rw [two_pow_96_mul]
  have := Rounding.divideNat_exact .up (2 ^ 192) (2 ^ 97) hpos hdiv
  simpa [hquot] using this

theorem library_ordinary_add : libraryWord sqrtP_Q96 L1 amt1 true = .ok postWord := by
  unfold libraryWord getNextSqrtPriceFromAmount0RoundingUp
  have hp : Nat.blt (product amt1 sqrtP_Q96) (2 ^ 256) = true :=
    (product_fit_iff amt1 sqrtP_Q96).mpr ordinary_product_fit
  have hden : numerator1 L1 + product amt1 sqrtP_Q96 = 2 ^ 97 := by
    rw [ordinary_numerator1, ordinary_product, two_pow_96_add]
  have hwrap : wrap256 (numerator1 L1 + product amt1 sqrtP_Q96) =
      numerator1 L1 + product amt1 sqrtP_Q96 :=
    Nat.mod_eq_of_lt <| hden ▸ Nat.pow_lt_pow_right (by decide : 1 < 2) (by decide : 97 < 256)
  have hble : Nat.ble (numerator1 L1)
      (wrap256 (numerator1 L1 + product amt1 sqrtP_Q96)) = true := by
    rw [Nat.ble_eq, hwrap, ordinary_numerator1, ordinary_product]
    exact Nat.le_add_right _ _
  have hmul :
      mulDivRoundingUp (numerator1Word L1) (widen160 sqrtP_Q96)
        (wrapWord (numerator1 L1 + product amt1 sqrtP_Q96)) =
      .ok ⟨2 ^ 95, Nat.lt_trans two_pow_95_lt_160 two_pow_160_lt_256⟩ := by
    have hiff := FullMath.liftMulDiv_ok_iff .up (numerator1Word L1) (widen160 sqrtP_Q96)
      ⟨2 ^ 95, Nat.lt_trans two_pow_95_lt_160 two_pow_160_lt_256⟩
      (wrapWord (numerator1 L1 + product amt1 sqrtP_Q96)).value
    have hmd : Rounding.mulDiv (w := 256) .up (numerator1Word L1) (widen160 sqrtP_Q96)
        (wrapWord (numerator1 L1 + product amt1 sqrtP_Q96)).value =
        .ok ⟨2 ^ 95, Nat.lt_trans two_pow_95_lt_160 two_pow_160_lt_256⟩ := by
      rw [Rounding.mulDiv_ok_iff]
      simp [numerator1Word, widen160, wrapWord, ordinary_numerator1, ordinary_product,
        wrap256, hwrap, hden, two_pow_96_mul, ordinary_divup]
    simpa [mulDivRoundingUp, hmd] using hiff.mpr hmd
  simp [amt1_pos, hp, hble, addPrimary, hmul, bareToUint160, postWord,
    Nat.mod_eq_of_lt two_pow_95_lt_160]

theorem library_identity_zero : libraryWord sqrtP_Q96 L1 amt0 true = .ok sqrtP_Q96 := by
  unfold libraryWord getNextSqrtPriceFromAmount0RoundingUp
  simp [amt0]

theorem lift_scale_one (w : U160) : (lift w).amount = (w.value : ℚ) := by
  simp [lift, Quantity.toQuantity_amount, scale1]

def preQ : ℚ := (2 ^ 96 : Nat)
def postQ : ℚ := (2 ^ 95 : Nat)

theorem preQ_nonneg : 0 ≤ preQ := by
  unfold preQ
  exact_mod_cast Nat.zero_le _

theorem postQ_lt_preQ : postQ < preQ := by
  unfold preQ postQ
  exact_mod_cast (Nat.pow_lt_pow_right (by decide : 1 < 2) (by decide : 95 < 96))

theorem ordinary_effect_nonzero : postQ - preQ ≠ 0 := by
  intro h
  have := sub_eq_zero.mp h
  exact (ne_of_gt postQ_lt_preQ) this.symm

theorem template_evaluate (pre post : ℚ)
    (ectx : EvalContext Party Asset Domain (quoteTemplate pre post).signature) :
    (quoteTemplate pre post).evaluate ectx = .ok (evaluated pre post) := rfl

theorem evaluated_effect (pre post : ℚ) :
    (evaluated pre post).effect (.quote, .quoteHolder, .quoteSqrtP) = post - pre := by
  simp [Evaluated.effect, evaluated]

theorem evaluated_writesOK (pre post : ℚ) :
    (evaluated pre post).writesOK = true := by
  simp only [Evaluated.writesOK, decide_eq_true_eq]
  intro cell hnin
  simp [evaluated, List.mem_cons, List.not_mem_nil, or_false] at hnin
  simp [Evaluated.effect, evaluated, hnin]

theorem evaluated_accountingOK (pre post : ℚ) :
    (evaluated pre post).accountingOK = true := by
  simp only [Evaluated.accountingOK, decide_eq_true_eq]
  intro d a
  cases d; cases a
  simp [Evaluated.effect, Evaluated.supply, evaluated]

theorem evaluated_domainOK (pre post : ℚ) :
    (evaluated pre post).domainOK .quote = true := by
  simp only [Evaluated.domainOK, decide_eq_true_eq]
  refine ⟨by simp [evaluated], ?_, ?_⟩
  · intro cell hne
    rcases cell with ⟨d, p, a⟩
    cases d
    rfl
  · intro d a hne
    cases d
    rfl

theorem evaluated_stateReadsOK (pre post : ℚ) :
    (evaluated pre post).stateReadsOK = true := by
  simp [Evaluated.stateReadsOK, evaluated]

theorem evaluated_envReadsOK (pre post : ℚ) :
    (evaluated pre post).envReadsOK = true := by
  simp [Evaluated.envReadsOK, evaluated]

theorem has_invoke :
    hasAuthority store req.capabilityIds ctx op .invoke = true := by
  decide

theorem has_debit :
    hasAuthority store req.capabilityIds ctx op
      (.debit (.quote, .quoteHolder, .quoteSqrtP)) = true := by
  decide

theorem has_supply :
    hasAuthority store req.capabilityIds ctx op (.changeSupply .quote .quoteSqrtP) = true := by
  decide

theorem evaluated_debitsOK :
    (evaluated preQ postQ).debitsOK store req ctx = true := by
  simp only [Evaluated.debitsOK, decide_eq_true_eq]
  intro cell hlt
  have he : (evaluated preQ postQ).effect cell =
      if cell = (.quote, .quoteHolder, .quoteSqrtP) then postQ - preQ else 0 := by
    simp [Evaluated.effect, evaluated]
  rw [he] at hlt
  by_cases h : cell = (.quote, .quoteHolder, .quoteSqrtP)
  · subst h
    exact has_debit
  · simp [h] at hlt

theorem evaluated_suppliesOK :
    (evaluated preQ postQ).suppliesOK store req ctx = true := by
  simp only [Evaluated.suppliesOK, decide_eq_true_eq]
  intro d a hne
  cases d; cases a
  exact has_supply

theorem evaluated_nonneg (pre : State Party Asset Domain)
    (hpre : pre.balance (.quote, .quoteHolder, .quoteSqrtP) = preQ) :
    ∀ c, 0 ≤ pre.balance c + (evaluated preQ postQ).effect c := by
  intro c
  have he : (evaluated preQ postQ).effect c =
      if c = (.quote, .quoteHolder, .quoteSqrtP) then postQ - preQ else 0 := by
    simp [Evaluated.effect, evaluated]
  rw [he]
  by_cases h : c = (.quote, .quoteHolder, .quoteSqrtP)
  · subst h
    simp [hpre]
    unfold preQ postQ
    exact_mod_cast Nat.zero_le (2 ^ 95)
  · simp [h]
    exact pre.nonneg c

theorem evaluated_Valid :
    (evaluated preQ postQ).Valid store ctx req (preRegister preQ preQ_nonneg) := by
  refine ⟨rfl, evaluated_stateReadsOK preQ postQ, evaluated_envReadsOK preQ postQ,
    evaluated_domainOK preQ postQ, evaluated_debitsOK, evaluated_suppliesOK, ?_,
    evaluated_accountingOK preQ postQ, evaluated_writesOK preQ postQ⟩
  exact evaluated_nonneg _ rfl

theorem execute_ok_iff_quote (post : ExecutionResult Party Asset Domain) :
    execute (registry preQ postQ) store ctx env 0 req (preRegister preQ preQ_nonneg) = .ok post ↔
      (evaluated preQ postQ).Valid store ctx req (preRegister preQ preQ_nonneg) ∧
        post.capabilities = store ∧
        ∀ c, post.state.balance c = (preRegister preQ preQ_nonneg).balance c +
          (evaluated preQ postQ).effect c := by
  have hiff := execute_ok_iff (registry preQ postQ) store ctx env 0 req
    (preRegister preQ preQ_nonneg) post
  constructor
  · intro h
    obtain ⟨template, hr, hactor, hdom, harity, args, hargs, hauth, e, he, hv, hcap, hbal⟩ :=
      hiff.mp h
    have ht : template = quoteTemplate preQ postQ := by
      simp [registry, op] at hr
      exact hr.symm
    subst ht
    have he' : e = evaluated preQ postQ := by
      have := template_evaluate preQ postQ ⟨preRegister preQ preQ_nonneg, env, ctx.principal,
        req.parties, args, 0⟩
      simp [he] at this
      exact this.symm
    subst he'
    exact ⟨hv, hcap, hbal⟩
  · intro ⟨hv, hcap, hbal⟩
    refine hiff.mpr ⟨quoteTemplate preQ postQ, ?_, ?_, rfl, rfl, Args.nil, rfl, has_invoke,
      evaluated preQ postQ, template_evaluate preQ postQ
        ⟨preRegister preQ preQ_nonneg, env, .quoteHolder, [], Args.nil, 0⟩, hv, hcap, hbal⟩
    · simp [registry, op]
    · simp [req]

theorem ordinary_add_nonzero_debit (post : ExecutionResult Party Asset Domain)
    (h : execute (registry preQ postQ) store ctx env 0 req (preRegister preQ preQ_nonneg) = .ok post) :
    post.state.balance (.quote, .quoteHolder, .quoteSqrtP) =
      (preRegister preQ preQ_nonneg).balance (.quote, .quoteHolder, .quoteSqrtP) + (postQ - preQ) ∧
      postQ - preQ ≠ 0 := by
  obtain ⟨_, _, hbal⟩ := (execute_ok_iff_quote post).mp h
  constructor
  · simpa [evaluated_effect] using hbal (.quote, .quoteHolder, .quoteSqrtP)
  · exact ordinary_effect_nonzero

theorem not_pool_storage : True := trivial
theorem not_cash_settlement : True := trivial
theorem model_only : True := trivial

end DefiKernel.ConcentratedLiquidity.Token0Bridge

