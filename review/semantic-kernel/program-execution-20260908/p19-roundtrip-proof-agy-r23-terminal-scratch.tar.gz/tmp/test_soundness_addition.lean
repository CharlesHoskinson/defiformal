import DefiKernel.Certificates.Schema
import DefiKernel.Certificates.Decode
import DefiKernel.Certificates.Check
import DefiKernel.Certificates.Observation
import DefiKernel.Certificates.Correspondence
import DefiKernel.Certificates.Soundness

namespace DefiKernel.Certificates

open DefiKernel.Composition

theorem checkIR_execute_error (rawCert : EnvelopeEnc) (payload : TypedExecutePayloadEnc) :
    checkIR (.execution (.typed rawCert payload)) = .execution (checkTyped rawCert payload) := by
  dsimp [checkIR]

theorem checkIR_execute_ok (rawCert : EnvelopeEnc) (payload : TypedExecutePayloadEnc) :
    checkIR (.execution (.typed rawCert payload)) = .execution (checkTyped rawCert payload) := by
  dsimp [checkIR]

theorem checkIR_executeStep_error (rawCert : EnvelopeEnc) (payload : CompositionStepPayloadEnc) :
    checkIR (.execution (.step rawCert payload)) = .execution (checkStep rawCert payload) := by
  dsimp [checkIR]

theorem checkIR_executeStep_ok (rawCert : EnvelopeEnc) (payload : CompositionStepPayloadEnc) :
    checkIR (.execution (.step rawCert payload)) = .execution (checkStep rawCert payload) := by
  dsimp [checkIR]

theorem checkIR_run (rawCert : EnvelopeEnc) (payload : CompositionRunPayloadEnc) :
    checkIR (.execution (.run rawCert payload)) = .execution (checkRun rawCert payload) := by
  dsimp [checkIR]

theorem checkRun_cursor_fail (cert : EnvelopeEnc) (payload : CompositionRunPayloadEnc)
    (cfg : Config Party Asset Domain)
    (h_cfg : configToTyped? payload.config = some cfg)
    (initialWorld : World Party Asset Domain)
    (h_world : payload.world.toWorld? = some initialWorld) :
    let bList := payload.boundaries.map boundaryToTyped
    let defaultBoundary : Composition.Boundary Party Asset Domain :=
      ⟨⟨.alice, .main⟩, fun _ ↦ none, 100⟩
    let boundaries : Nat → Composition.Boundary Party Asset Domain :=
      fun idx ↦ match bList[idx]? with
      | some b => b
      | none => bList.head?.getD defaultBoundary
    let steps : List (Composition.Step Party Asset Domain) :=
      payload.steps.filterMap StepEnc.toStep?
    let cursor := Composition.run cfg boundaries initialWorld steps
    ∀ (lf : LocatedFailure Party Asset Domain),
    cursor.failure = some lf →
    (checkRun cert payload).status = ReportStatus.refused ∧
    (checkRun cert payload).failure = some (failureToPath lf.reason) := by
  intro bList defaultBoundary boundaries steps cursor lf h_fail
  dsimp [checkRun]
  rw [h_cfg]
  dsimp
  rw [h_world]
  dsimp
  have h_cf : (Composition.run cfg (fun idx => match (List.map boundaryToTyped payload.boundaries)[idx]? with | some b => b | none => (List.map boundaryToTyped payload.boundaries).head?.getD { ctx := { principal := Party.alice, domain := Domain.main }, env := fun x => none, now := 100 }) initialWorld (List.filterMap StepEnc.toStep? payload.steps)).failure = some lf := h_fail
  generalize h_fail_expr : (Composition.run cfg (fun idx => match (List.map boundaryToTyped payload.boundaries)[idx]? with | some b => b | none => (List.map boundaryToTyped payload.boundaries).head?.getD { ctx := { principal := Party.alice, domain := Domain.main }, env := fun x => none, now := 100 }) initialWorld (List.filterMap StepEnc.toStep? payload.steps)).failure = f_opt
  rw [h_fail_expr] at h_cf
  cases f_opt with
  | none => contradiction
  | some lf2 =>
    injection h_cf with h_eq
    subst h_eq
    refine ⟨rfl, rfl⟩

theorem checkRun_cursor_ok (cert : EnvelopeEnc) (payload : CompositionRunPayloadEnc)
    (cfg : Config Party Asset Domain)
    (h_cfg : configToTyped? payload.config = some cfg)
    (initialWorld : World Party Asset Domain)
    (h_world : payload.world.toWorld? = some initialWorld) :
    let bList := payload.boundaries.map boundaryToTyped
    let defaultBoundary : Composition.Boundary Party Asset Domain :=
      ⟨⟨.alice, .main⟩, fun _ ↦ none, 100⟩
    let boundaries : Nat → Composition.Boundary Party Asset Domain :=
      fun idx ↦ match bList[idx]? with
      | some b => b
      | none => bList.head?.getD defaultBoundary
    let steps : List (Composition.Step Party Asset Domain) :=
      payload.steps.filterMap StepEnc.toStep?
    let cursor := Composition.run cfg boundaries initialWorld steps
    cursor.failure = none →
    (checkRun cert payload).status = ReportStatus.accepted ∧
    (checkRun cert payload).failure = none ∧
    (checkRun cert payload).outputs = cursor.outputs.map OutputObservationEnc.fromOutputObservation ∧
    (checkRun cert payload).nextIndex = cursor.nextIndex := by
  intro bList defaultBoundary boundaries steps cursor h_succ
  dsimp [checkRun]
  rw [h_cfg]
  dsimp
  rw [h_world]
  dsimp
  have h_cf : (Composition.run cfg (fun idx => match (List.map boundaryToTyped payload.boundaries)[idx]? with | some b => b | none => (List.map boundaryToTyped payload.boundaries).head?.getD { ctx := { principal := Party.alice, domain := Domain.main }, env := fun x => none, now := 100 }) initialWorld (List.filterMap StepEnc.toStep? payload.steps)).failure = none := h_succ
  generalize h_fail_expr : (Composition.run cfg (fun idx => match (List.map boundaryToTyped payload.boundaries)[idx]? with | some b => b | none => (List.map boundaryToTyped payload.boundaries).head?.getD { ctx := { principal := Party.alice, domain := Domain.main }, env := fun x => none, now := 100 }) initialWorld (List.filterMap StepEnc.toStep? payload.steps)).failure = f_opt
  rw [h_fail_expr] at h_cf
  cases f_opt with
  | some lf => contradiction
  | none =>
    dsimp
    refine ⟨rfl, rfl, rfl, ?_⟩
    dsimp [bList, defaultBoundary, boundaries, steps, cursor]
    rfl

end DefiKernel.Certificates
