import DefiKernel.Arithmetic.Operations
import DefiKernel.Arithmetic.Rounding
import DefiKernel.Vault.Types

/-! Directed share/asset conversion under overflow premises. chi>0 excludes `_divup(0,0)`. -/
namespace DefiKernel.Vault
open DefiKernel.Arithmetic

def divUp (x y : Nat) : Except Failure Nat :=
  (Rounding.divideNat .up x y).mapError ofArith

def convertToShares (assets : Word 256) (chi : Word 192) : Except Failure (Word 256) := do
  let prod ← (Operations.mul assets rayWord).mapError ofArith
  let q ← (Rounding.divideNat .down prod.value chi.value).mapError ofArith
  (Word.checked (w := 256) .quotientOverflow q).mapError ofArith

def convertToAssets (shares : Word 256) (chi : Word 192) : Except Failure (Word 256) := do
  let chi256 : Word 256 := ⟨chi.value, Nat.lt_trans chi.bound two_pow_192_lt_256⟩
  let prod ← (Operations.mul shares chi256).mapError ofArith
  let q ← (Rounding.divideNat .down prod.value RAY).mapError ofArith
  (Word.checked (w := 256) .quotientOverflow q).mapError ofArith

def previewMint (shares : Word 256) (chi : Word 192) : Except Failure (Word 256) := do
  let chi256 : Word 256 := ⟨chi.value, Nat.lt_trans chi.bound two_pow_192_lt_256⟩
  let prod ← (Operations.mul shares chi256).mapError ofArith
  let q ← divUp prod.value RAY
  (Word.checked (w := 256) .quotientOverflow q).mapError ofArith

def previewWithdraw (assets : Word 256) (chi : Word 192) : Except Failure (Word 256) := do
  let prod ← (Operations.mul assets rayWord).mapError ofArith
  let q ← divUp prod.value chi.value
  (Word.checked (w := 256) .quotientOverflow q).mapError ofArith

-- BEGIN PROOFS

theorem divUp_eq_divideNat_up (x y q : Nat) :
    divUp x y = .ok q ↔ Rounding.divideNat .up x y = .ok q := by
  unfold divUp
  cases h : Rounding.divideNat .up x y <;> simp [Except.mapError]

theorem divUp_zero (y : Nat) (hy : 0 < y) : divUp 0 y = .ok 0 := by
  exact (divUp_eq_divideNat_up 0 y 0).mpr (Rounding.divideNat_zero .up y hy)

theorem mul_ray_ok (assets : Word 256)
    (hprod : assets.value * rayWord.value < 2 ^ 256) :
    Operations.mul assets rayWord = .ok ⟨assets.value * rayWord.value, hprod⟩ :=
  (Operations.mul_ok_iff assets rayWord ⟨assets.value * rayWord.value, hprod⟩).mpr rfl

theorem convertToShares_ok (assets : Word 256) (chi : Word 192) (q : Word 256)
    (_hchi : 0 < chi.value) (hprod : assets.value * rayWord.value < 2 ^ 256) :
    convertToShares assets chi = .ok q ↔
      Rounding.divideNat .down (assets.value * rayWord.value) chi.value = .ok q.value := by
  unfold convertToShares
  rw [mul_ray_ok assets hprod]
  cases hd : Rounding.divideNat .down (assets.value * rayWord.value) chi.value with
  | error e =>
    simp only [Except.mapError, Except.bind, reduceCtorEq]
  | ok n =>
    simp only [Except.mapError, Except.bind]
    constructor
    · intro h
      have := (Word.checked_ok_iff (w := 256) .quotientOverflow n q).mp ?_
      · exact this ▸ hd
      · simpa [Except.mapError] using h
    · intro hq
      have hn : n = q.value := (Except.ok.injEq _ _).mp (hd.symm.trans hq)
      subst hn
      simp [Word.checked_ok_iff, Except.mapError]

theorem convertToShares_floor (assets : Word 256) (chi : Word 192) (q : Word 256)
    (hchi : 0 < chi.value) (hprod : assets.value * rayWord.value < 2 ^ 256) :
    convertToShares assets chi = .ok q ↔
      q.value * chi.value ≤ assets.value * rayWord.value ∧
        assets.value * rayWord.value < (q.value + 1) * chi.value := by
  rw [convertToShares_ok assets chi q hchi hprod, Rounding.divideNat_down_ok_iff]
  exact ⟨fun h => And.intro h.2.1 h.2.2, fun h => ⟨hchi, h.1, h.2⟩⟩

theorem mul_chi_ok (shares : Word 256) (chi : Word 192)
    (hprod : shares.value * chi.value < 2 ^ 256) :
    Operations.mul shares ⟨chi.value, Nat.lt_trans chi.bound two_pow_192_lt_256⟩ =
      .ok ⟨shares.value * chi.value, hprod⟩ :=
  (Operations.mul_ok_iff shares ⟨chi.value, Nat.lt_trans chi.bound two_pow_192_lt_256⟩
    ⟨shares.value * chi.value, hprod⟩).mpr rfl

theorem previewMint_up (shares : Word 256) (chi : Word 192) (q : Word 256)
    (hprod : shares.value * chi.value < 2 ^ 256) :
    previewMint shares chi = .ok q →
      Rounding.divideNat .up (shares.value * chi.value) RAY = .ok q.value := by
  unfold previewMint
  rw [mul_chi_ok shares chi hprod]
  intro h
  cases hd : Rounding.divideNat .up (shares.value * chi.value) RAY with
  | error e =>
    simp [divUp, hd, Except.mapError, Except.bind] at h
  | ok n =>
    have : divUp (shares.value * chi.value) RAY = .ok n :=
      (divUp_eq_divideNat_up _ _ _).mpr hd
    simp [this, Except.mapError, Except.bind, Word.checked_ok_iff] at h
    exact h ▸ hd

theorem mulRay_error_iff (assets : Word 256) :
    Operations.mul assets rayWord = .error .mulOverflow ↔
      2 ^ 256 ≤ assets.value * rayWord.value := by
  rw [Operations.mul_error_iff]
  constructor
  · exact And.left
  · intro h
    exact ⟨h, rfl⟩

theorem convertToShares_mulOverflow (assets : Word 256) (chi : Word 192)
    (hov : 2 ^ 256 ≤ assets.value * rayWord.value) :
    convertToShares assets chi = .error .mulOverflow := by
  unfold convertToShares
  have hm : Operations.mul assets rayWord = .error .mulOverflow :=
    (mulRay_error_iff assets).mpr hov
  simp only [hm, Except.mapError, ofArith, Except.bind]

end DefiKernel.Vault
