import DefiKernel.Certificates.Schema
import DefiKernel.Certificates.Decode
import DefiKernel.Certificates.CanonicalJson
import DefiKernel.Certificates.Correspondence

open DefiKernel.Certificates

-- [Previous proven theorems omitted, testing new additions]

def registryEntryToJson (e : RegistryEntryEnc) : Lean.Json :=
  Lean.Json.mkObj [("id", Lean.Json.num e.id), ("template", templateToJson' e.template)]
where
  templateToJson' (t : TemplateEnc) : Lean.Json :=
    Lean.Json.mkObj [
      ("signature", Lean.Json.arr (t.signature.map unitToJson).toArray),
      ("domain", domainToJson t.domain),
      ("partyArity", Lean.Json.num t.partyArity),
      ("guard", exprToJson t.guard),
      ("deltas", Lean.Json.arr (t.deltas.map (fun d => Lean.Json.mkObj [("asset", assetToJson d.asset), ("target", cellRefToJson d.target), ("amount", exprToJson d.amount)])).toArray),
      ("supplyDeltas", Lean.Json.arr (t.supplyDeltas.map (fun s => Lean.Json.mkObj [("domain", domainToJson s.domain), ("asset", assetToJson s.asset), ("amount", exprToJson s.amount)])).toArray),
      ("stateReads", Lean.Json.arr (t.stateReads.map packedCellRefToJson).toArray),
      ("envReads", Lean.Json.arr (t.envReads.map (fun er => match er with | .observation k => Lean.Json.mkObj [("tag", Lean.Json.str "observation"), ("key", observationKeyToJson k)] | .currentTime => Lean.Json.mkObj [("tag", Lean.Json.str "currentTime")])).toArray),
      ("writes", Lean.Json.arr (t.writes.map packedCellRefToJson).toArray)
    ]

def capabilityToJson (c : CapabilityEnc) : Lean.Json :=
  Lean.Json.mkObj [
    ("holder", partyToJson c.holder),
    ("domain", domainToJson c.domain),
    ("operation", Lean.Json.num c.operation),
    ("right", rightToJson c.right),
    ("live", Lean.Json.bool c.live)
  ]

theorem decodeCapability_capabilityToJson (c : CapabilityEnc) :
    decodeCapability (capabilityToJson c) = .ok c := by
  cases c with | mk holder domain op right live =>
  have h_h := decodeParty_partyToJson holder
  have h_d := decodeDomain_domainToJson domain
  have h_r := decodeRight_rightToJson right
  have h_def : decodeCapability (capabilityToJson ⟨holder, domain, op, right, live⟩) = (do
      let h ← decodeParty (partyToJson holder)
      let d ← decodeDomain (domainToJson domain)
      let r ← decodeRight (rightToJson right)
      .ok ⟨h, d, op, r, live⟩) := rfl
  rw [h_def, h_h, h_d, h_r]
  cases live <;> rfl

def storeToJson (s : StoreEnc) : Lean.Json :=
  Lean.Json.mkObj [("entries", Lean.Json.arr (s.entries.map capabilityToJson).toArray)]

theorem list_mapM_decode_ok {α : Type} (xs : List α) (f : α → Lean.Json) (dec : Lean.Json → Except DecodeFailure α)
    (h : ∀ x ∈ xs, dec (f x) = .ok x) :
    (xs.map f).mapM dec = .ok xs := by
  induction xs with
  | nil => rfl
  | cons x xs ih =>
    simp only [List.map_cons, List.mapM_cons]
    have h_x := h x (List.Mem.head xs)
    have h_xs : ∀ y ∈ xs, dec (f y) = .ok y := fun y hy => h y (List.Mem.tail x hy)
    have ih_app := ih h_xs
    rw [h_x]
    dsimp [bind, Except.bind]
    rw [ih_app]
    rfl

theorem decodeStore_storeToJson (s : StoreEnc) :
    decodeStore (storeToJson s) = .ok s := by
  have h_map : (s.entries.map capabilityToJson).mapM decodeCapability = .ok s.entries := by
    apply list_mapM_decode_ok
    intro c _
    exact decodeCapability_capabilityToJson c
  have h_def : decodeStore (storeToJson s) = (do
      let entries ← (s.entries.map capabilityToJson).mapM decodeCapability
      .ok ⟨entries⟩) := rfl
  rw [h_def, h_map]
  rfl

def contextToJson (c : ContextEnc) : Lean.Json :=
  Lean.Json.mkObj [("principal", partyToJson c.principal), ("domain", domainToJson c.domain)]

theorem decodeContext_contextToJson (c : ContextEnc) :
    decodeContext (contextToJson c) = .ok c := by
  cases c with | mk p d =>
  have h_p := decodeParty_partyToJson p
  have h_d := decodeDomain_domainToJson d
  have h_def : decodeContext (contextToJson ⟨p, d⟩) = (do
      let p_dec ← decodeParty (partyToJson p)
      let d_dec ← decodeDomain (domainToJson d)
      .ok ⟨p_dec, d_dec⟩) := rfl
  rw [h_def, h_p, h_d]
  rfl

def observationToJson (o : ObservationEnc) : Lean.Json :=
  Lean.Json.mkObj [("value", packedValueToJson o.value), ("timestamp", Lean.Json.num o.timestamp)]

def environmentEntryToJson (e : EnvironmentEntryEnc) : Lean.Json :=
  Lean.Json.mkObj [("key", observationKeyToJson e.key), ("observation", observationToJson e.observation)]

def environmentToJson (env : EnvironmentEnc) : Lean.Json :=
  Lean.Json.mkObj [("entries", Lean.Json.arr (env.entries.map environmentEntryToJson).toArray)]

def domainAdminToJson (d : DomainAdminEnc) : Lean.Json :=
  Lean.Json.mkObj [("domain", domainToJson d.domain), ("party", partyToJson d.party)]

theorem decodeDomainAdmin_domainAdminToJson (d : DomainAdminEnc) :
    decodeDomainAdmin (domainAdminToJson d) = .ok d := by
  cases d with | mk dom p =>
  have h_dom := decodeDomain_domainToJson dom
  have h_p := decodeParty_partyToJson p
  have h_def : decodeDomainAdmin (domainAdminToJson ⟨dom, p⟩) = (do
      let d_dec ← decodeDomain (domainToJson dom)
      let p_dec ← decodeParty (partyToJson p)
      .ok ⟨d_dec, p_dec⟩) := rfl
  rw [h_def, h_dom, h_p]
  rfl

def inputPortToJson (p : InputPortEnc) : Lean.Json :=
  Lean.Json.mkObj [("id", Lean.Json.num p.id), ("unit", unitToJson p.unit)]

theorem decodeInputPort_inputPortToJson (p : InputPortEnc) :
    decodeInputPort (inputPortToJson p) = .ok p := by
  cases p with | mk id u =>
  have h_u := decodeUnit_unitToJson u
  have h_def : decodeInputPort (inputPortToJson ⟨id, u⟩) = (do
      let u_dec ← decodeUnit (unitToJson u)
      .ok ⟨id, u_dec⟩) := rfl
  rw [h_def, h_u]
  rfl

def outputPortToJson (p : OutputPortEnc) : Lean.Json :=
  Lean.Json.mkObj [("id", Lean.Json.num p.id), ("cell", cellToJson p.cell)]

theorem decodeOutputPort_outputPortToJson (p : OutputPortEnc) :
    decodeOutputPort (outputPortToJson p) = .ok p := by
  cases p with | mk id c =>
  have h_c := decodeCell_cellToJson c
  have h_def : decodeOutputPort (outputPortToJson ⟨id, c⟩) = (do
      let c_dec ← decodeCell (cellToJson c)
      .ok ⟨id, c_dec⟩) := rfl
  rw [h_def, h_c]
  rfl

def resourcePortToJson (rp : ResourcePortEnc) : Lean.Json :=
  Lean.Json.mkObj [("id", Lean.Json.num rp.id), ("cell", cellToJson rp.cell), ("writable", Lean.Json.bool rp.writable)]

theorem decodeResourcePort_resourcePortToJson (rp : ResourcePortEnc) :
    decodeResourcePort (resourcePortToJson rp) = .ok rp := by
  cases rp with | mk id c w =>
  have h_c := decodeCell_cellToJson c
  have h_def : decodeResourcePort (resourcePortToJson ⟨id, c, w⟩) = (do
      let c_dec ← decodeCell (cellToJson c)
      .ok ⟨id, c_dec, w⟩) := rfl
  rw [h_def, h_c]
  cases w <;> rfl

def qualifiedPortToJson (qp : QualifiedPortEnc) : Lean.Json :=
  Lean.Json.mkObj [("component", Lean.Json.num qp.component), ("port", Lean.Json.num qp.port)]

theorem decodeQualifiedPort_qualifiedPortToJson (qp : QualifiedPortEnc) :
    decodeQualifiedPort (qualifiedPortToJson qp) = .ok qp := by
  cases qp with | mk c p => rfl

def resourceImportToJson (ri : ResourceImportEnc) : Lean.Json :=
  Lean.Json.mkObj [("source", qualifiedPortToJson ri.source), ("cell", cellToJson ri.cell), ("writable", Lean.Json.bool ri.writable)]

theorem decodeResourceImport_resourceImportToJson (ri : ResourceImportEnc) :
    decodeResourceImport (resourceImportToJson ri) = .ok ri := by
  cases ri with | mk s c w =>
  have h_c := decodeCell_cellToJson c
  have h_def : decodeResourceImport (resourceImportToJson ⟨s, c, w⟩) = (do
      let c_dec ← decodeCell (cellToJson c)
      .ok ⟨s, c_dec, w⟩) := rfl
  rw [h_def, h_c]
  cases w <;> rfl

def sourcePinToJson (sp : SourcePinEnc) : Lean.Json :=
  Lean.Json.mkObj [
    ("git", Lean.Json.str sp.git),
    ("lean_toolchain", Lean.Json.str sp.lean_toolchain),
    ("mathlib_rev", Lean.Json.str sp.mathlib_rev),
    ("checker_candidate", Lean.Json.str sp.checker_candidate)
  ]

theorem decodeSourcePin_sourcePinToJson (sp : SourcePinEnc) (h_cr : sp.compiler_record = none) (h_ar : sp.audit_record = none) :
    decodeSourcePin (sourcePinToJson sp) = .ok sp := by
  cases sp with | mk git lt ml cc cr ar =>
  dsimp at h_cr h_ar
  subst h_cr h_ar
  rfl

def typesEnumToJson (te : TypesEnumEnc) : Lean.Json :=
  Lean.Json.mkObj [
    ("parties", Lean.Json.arr (te.parties.map partyToJson).toArray),
    ("assets", Lean.Json.arr (te.assets.map assetToJson).toArray),
    ("domains", Lean.Json.arr (te.domains.map domainToJson).toArray)
  ]

theorem decodeTypesEnum_typesEnumToJson (te : TypesEnumEnc) :
    decodeTypesEnum (typesEnumToJson te) = .ok te := by
  have h_p : (te.parties.map partyToJson).mapM decodeParty = .ok te.parties := by
    apply list_mapM_decode_ok; intro p _; exact decodeParty_partyToJson p
  have h_a : (te.assets.map assetToJson).mapM decodeAsset = .ok te.assets := by
    apply list_mapM_decode_ok; intro a _; exact decodeAsset_assetToJson a
  have h_d : (te.domains.map domainToJson).mapM decodeDomain = .ok te.domains := by
    apply list_mapM_decode_ok; intro d _; exact decodeDomain_domainToJson d
  have h_def : decodeTypesEnum (typesEnumToJson te) = (do
      let parties ← (te.parties.map partyToJson).mapM decodeParty
      let assets ← (te.assets.map assetToJson).mapM decodeAsset
      let domains ← (te.domains.map domainToJson).mapM decodeDomain
      .ok ⟨parties, assets, domains⟩) := rfl
  rw [h_def, h_p, h_a, h_d]
  rfl
