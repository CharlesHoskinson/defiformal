import DefiKernel.Certificates.Schema
import DefiKernel.Certificates.Decode
import DefiKernel.Certificates.CanonicalJson
import DefiKernel.Certificates.Correspondence

open DefiKernel.Certificates

theorem rat_toRat_fromRat (q : ℚ) : (RatEnc.mk q.num q.den).toRat = q := by
  dsimp [RatEnc.toRat]
  exact Rat.num_divInt_den q

/-- Canonical rational decoder inversion: any reduced non-zero denominator rational roundtrips. -/
theorem decodeRat_ratToJson (r : RatEnc) (h_den : r.den ≠ 0) (h_gcd : Int.gcd r.num.natAbs r.den = 1) :
    decodeRat (ratToJson r) = .ok r :=
  decodeRat_mkObj r.num r.den h_den h_gcd

/-- Canonical rational decoder inversion from Mathlib ℚ: any ℚ roundtrips canonically. -/
theorem decodeRat_fromRat (q : ℚ) :
    decodeRat (ratToJson (RatEnc.fromRat q)) = .ok (RatEnc.fromRat q) := by
  have h_den : q.den ≠ 0 := q.den_nz
  have h_gcd : Int.gcd q.num.natAbs q.den = 1 := q.reduced
  exact decodeRat_mkObj q.num q.den h_den h_gcd

/-- Canonical packed value inversion for literal expression decoding. -/
theorem decodeExprFuel_lit_canonical (fuel : Nat) (v : PackedValueEnc) (h_can : PackedValueCanonical v) :
    decodeExprFuel (fuel + 1) (exprToJson (.lit v)) = .ok (.lit v) := by
  cases v with | mk u valRat valBool =>
  dsimp [PackedValueCanonical] at h_can
  cases u with
  | bool =>
    have h_rat := h_can.1 rfl
    have h_def : decodeExprFuel (fuel + 1) (exprToJson (.lit ⟨.bool, valRat, valBool⟩)) =
        .ok (.lit ⟨.bool, 0, valBool⟩) := by
      cases valBool <;> rfl
    rw [h_def, h_rat]
  | numeric nu =>
    have h_bool := h_can.2 nu rfl
    have h_den : valRat.den ≠ 0 := valRat.den_nz
    have h_gcd : Int.gcd valRat.num.natAbs valRat.den = 1 := valRat.reduced
    have h_rat : decodeRat (ratToJson ⟨valRat.num, valRat.den⟩) = .ok ⟨valRat.num, valRat.den⟩ :=
      decodeRat_mkObj valRat.num valRat.den h_den h_gcd
    have h_toRat : (RatEnc.mk valRat.num valRat.den).toRat = valRat := rat_toRat_fromRat valRat
    have h_u := decodeUnit_unitToJson (.numeric nu)
    have h_def : decodeExprFuel (fuel + 1) (exprToJson (.lit ⟨.numeric nu, valRat, valBool⟩)) = (do
        let u_dec ← decodeUnit (unitToJson (.numeric nu))
        match u_dec with
        | .bool => .error (.jsonType "boolValue")
        | .numeric nu' =>
          let r ← decodeRat (ratToJson ⟨valRat.num, valRat.den⟩)
          .ok (.lit ⟨.numeric nu', r.toRat, false⟩)) := rfl
    rw [h_def, h_u]
    dsimp [bind, Except.bind]
    rw [h_rat]
    dsimp [bind, Except.bind]
    rw [h_toRat, h_bool]

lemma exprDepth_pos (e : ExprEnc) : ExprEnc.depth e ≥ 1 := by
  cases e <;> simp [ExprEnc.depth]

/-- Expression inductive inversion theorem: any canonical expression roundtrips when given sufficient fuel. -/
theorem decodeExprFuel_exprToJson (e : ExprEnc) (fuel : Nat) (h_fuel : ExprEnc.depth e ≤ fuel) (h_can : ExprCanonical e) :
    decodeExprFuel fuel (exprToJson e) = .ok e := by
  induction fuel generalizing e with
  | zero =>
    have h_pos := exprDepth_pos e
    omega
  | succ f ih =>
    cases e with
    | lit v =>
      dsimp [ExprCanonical] at h_can
      exact decodeExprFuel_lit_canonical f v h_can.2
    | arg idx u =>
      exact exprToJson_decode_arg f idx u
    | balance c =>
      exact exprToJson_decode_balance f c
    | observe r =>
      exact exprToJson_decode_observe f r
    | timestamp k =>
      exact exprToJson_decode_timestamp f k
    | now =>
      exact exprToJson_decode_now f
    | unary op x =>
      simp only [ExprEnc.depth] at h_fuel
      have h_xfuel : ExprEnc.depth x ≤ f := by omega
      have h_x := ih x h_xfuel h_can.2
      exact exprToJson_decode_unary_step f op x h_x
    | binary op x y =>
      simp only [ExprEnc.depth] at h_fuel
      have h_xfuel : ExprEnc.depth x ≤ f := by omega
      have h_yfuel : ExprEnc.depth y ≤ f := by omega
      have h_x := ih x h_xfuel h_can.2.1
      have h_y := ih y h_yfuel h_can.2.2
      exact exprToJson_decode_binary_step f op x y h_x h_y
    | ite c y n =>
      simp only [ExprEnc.depth] at h_fuel
      have h_cfuel : ExprEnc.depth c ≤ f := by omega
      have h_yfuel : ExprEnc.depth y ≤ f := by omega
      have h_nfuel : ExprEnc.depth n ≤ f := by omega
      have h_c := ih c h_cfuel h_can.2.1
      have h_y := ih y h_yfuel h_can.2.2.1
      have h_n := ih n h_nfuel h_can.2.2.2
      exact exprToJson_decode_ite_step f c y n h_c h_y h_n

/-- Production expression decoder inversion theorem: decodeExpr inverts exprToJson for any bounded canonical expression. -/
theorem decodeExpr_exprToJson (e : ExprEnc) (h_depth : ExprEnc.depth e ≤ 64) (h_can : ExprCanonical e) :
    decodeExpr (exprToJson e) = .ok e := by
  dsimp [decodeExpr]
  exact decodeExprFuel_exprToJson e 64 h_depth h_can

def envReadToJson (er : EnvReadEnc) : Lean.Json :=
  match er with
  | .observation k => Lean.Json.mkObj [("tag", Lean.Json.str "observation"), ("key", observationKeyToJson k)]
  | .currentTime => Lean.Json.mkObj [("tag", Lean.Json.str "currentTime")]

theorem decodeEnvRead_envReadToJson (er : EnvReadEnc) :
    decodeEnvRead (envReadToJson er) = .ok er := by
  cases er with
  | observation k =>
    have h_k := decodeObservationKey_observationKeyToJson k
    have h_def : decodeEnvRead (envReadToJson (.observation k)) = (do
        let k_dec ← decodeObservationKey (observationKeyToJson k)
        .ok (.observation k_dec)) := rfl
    rw [h_def, h_k]
    rfl
  | currentTime => rfl

def cellDeltaToJson (d : CellDeltaEnc) : Lean.Json :=
  Lean.Json.mkObj [("asset", assetToJson d.asset), ("target", cellRefToJson d.target), ("amount", exprToJson d.amount)]

theorem decodeCellDelta_cellDeltaToJson (d : CellDeltaEnc)
    (h_depth : ExprEnc.depth d.amount ≤ 64) (h_can : ExprCanonical d.amount) :
    decodeCellDelta (cellDeltaToJson d) = .ok d := by
  cases d with | mk a t amt =>
  have h_a := decodeAsset_assetToJson a
  have h_t := decodeCellRef_cellRefToJson t
  have h_amt := decodeExpr_exprToJson amt h_depth h_can
  have h_def : decodeCellDelta (cellDeltaToJson ⟨a, t, amt⟩) = (do
      let a_dec ← decodeAsset (assetToJson a)
      let t_dec ← decodeCellRef (cellRefToJson t)
      let amt_dec ← decodeExpr (exprToJson amt)
      .ok ⟨a_dec, t_dec, amt_dec⟩) := rfl
  rw [h_def, h_a, h_t, h_amt]
  rfl

def supplyDeltaToJson (s : SupplyDeltaEnc) : Lean.Json :=
  Lean.Json.mkObj [("domain", domainToJson s.domain), ("asset", assetToJson s.asset), ("amount", exprToJson s.amount)]

theorem decodeSupplyDelta_supplyDeltaToJson (s : SupplyDeltaEnc)
    (h_depth : ExprEnc.depth s.amount ≤ 64) (h_can : ExprCanonical s.amount) :
    decodeSupplyDelta (supplyDeltaToJson s) = .ok s := by
  cases s with | mk d a amt =>
  have h_d := decodeDomain_domainToJson d
  have h_a := decodeAsset_assetToJson a
  have h_amt := decodeExpr_exprToJson amt h_depth h_can
  have h_def : decodeSupplyDelta (supplyDeltaToJson ⟨d, a, amt⟩) = (do
      let d_dec ← decodeDomain (domainToJson d)
      let a_dec ← decodeAsset (assetToJson a)
      let amt_dec ← decodeExpr (exprToJson amt)
      .ok ⟨d_dec, a_dec, amt_dec⟩) := rfl
  rw [h_def, h_d, h_a, h_amt]
  rfl

theorem list_mapM_decode_ok {α : Type} (xs : List α) (f : α → Lean.Json) (dec : Lean.Json → Except DecodeFailure α)
    (h : ∀ x ∈ xs, dec (f x) = .ok x) :
    (xs.map f).mapM dec = .ok xs := by
  induction xs with
  | nil => rfl
  | cons x xs ih =>
    simp only [List.map_cons, List.mapM_cons]
    have h_x := h x (List.Mem.head xs)
    have h_xs : ∀ y ∈ xs, dec (f y) = .ok y := fun y hy => h y (List.Mem.tail x hy)
    have ih_app := ih h_xs
    rw [h_x]
    dsimp [bind, Except.bind]
    rw [ih_app]
    rfl

def templateToJson (t : TemplateEnc) : Lean.Json :=
  Lean.Json.mkObj [
    ("signature", Lean.Json.arr (t.signature.map unitToJson).toArray),
    ("domain", domainToJson t.domain),
    ("partyArity", Lean.Json.num t.partyArity),
    ("guard", exprToJson t.guard),
    ("deltas", Lean.Json.arr (t.deltas.map cellDeltaToJson).toArray),
    ("supplyDeltas", Lean.Json.arr (t.supplyDeltas.map supplyDeltaToJson).toArray),
    ("stateReads", Lean.Json.arr (t.stateReads.map packedCellRefToJson).toArray),
    ("envReads", Lean.Json.arr (t.envReads.map envReadToJson).toArray),
    ("writes", Lean.Json.arr (t.writes.map packedCellRefToJson).toArray)
  ]

set_option maxHeartbeats 1000000 in
theorem decodeTemplate_templateToJson (t : TemplateEnc) (h_can : TemplateCanonical t) :
    decodeTemplate (templateToJson t) = .ok t := by
  cases t with | mk sig dom arity guard deltas supplyDeltas stateReads envReads writes =>
  dsimp [TemplateCanonical] at h_can
  have h_sig : (sig.map unitToJson).mapM decodeUnit = .ok sig := by
    apply list_mapM_decode_ok
    intro u _
    exact decodeUnit_unitToJson u
  have h_dom := decodeDomain_domainToJson dom
  have h_guard_can : ExprCanonical guard := h_can.1
  have h_guard_depth : ExprEnc.depth guard ≤ 64 := by
    unfold ExprCanonical at h_guard_can
    exact h_guard_can.1
  have h_guard := decodeExpr_exprToJson guard h_guard_depth h_guard_can
  have h_deltas : (deltas.map cellDeltaToJson).mapM decodeCellDelta = .ok deltas := by
    apply list_mapM_decode_ok
    intro d hd
    have hd_can : ExprCanonical d.amount := h_can.2.1 d hd
    have hd_depth : ExprEnc.depth d.amount ≤ 64 := by
      unfold ExprCanonical at hd_can
      exact hd_can.1
    exact decodeCellDelta_cellDeltaToJson d hd_depth hd_can
  have h_supply : (supplyDeltas.map supplyDeltaToJson).mapM decodeSupplyDelta = .ok supplyDeltas := by
    apply list_mapM_decode_ok
    intro s hs
    have hs_can : ExprCanonical s.amount := h_can.2.2 s hs
    have hs_depth : ExprEnc.depth s.amount ≤ 64 := by
      unfold ExprCanonical at hs_can
      exact hs_can.1
    exact decodeSupplyDelta_supplyDeltaToJson s hs_depth hs_can
  have h_sr : (stateReads.map packedCellRefToJson).mapM decodePackedCellRef = .ok stateReads := by
    apply list_mapM_decode_ok
    intro r _
    exact decodePackedCellRef_packedCellRefToJson r
  have h_er : (envReads.map envReadToJson).mapM decodeEnvRead = .ok envReads := by
    apply list_mapM_decode_ok
    intro r _
    exact decodeEnvRead_envReadToJson r
  have h_wr : (writes.map packedCellRefToJson).mapM decodePackedCellRef = .ok writes := by
    apply list_mapM_decode_ok
    intro w _
    exact decodePackedCellRef_packedCellRefToJson w
  have h_def : decodeTemplate (templateToJson ⟨sig, dom, arity, guard, deltas, supplyDeltas, stateReads, envReads, writes⟩) = (do
      let sigArr ← Except.ok (sig.map unitToJson).toArray
      let signature ← sigArr.toList.mapM decodeUnit
      let domain ← decodeDomain (domainToJson dom)
      let guard_dec ← decodeExpr (exprToJson guard)
      let deltasArr ← Except.ok (deltas.map cellDeltaToJson).toArray
      let deltas_dec ← deltasArr.toList.mapM decodeCellDelta
      let supArr ← Except.ok (supplyDeltas.map supplyDeltaToJson).toArray
      let supplyDeltas_dec ← supArr.toList.mapM decodeSupplyDelta
      let srArr ← Except.ok (stateReads.map packedCellRefToJson).toArray
      let stateReads_dec ← srArr.toList.mapM decodePackedCellRef
      let erArr ← Except.ok (envReads.map envReadToJson).toArray
      let envReads_dec ← erArr.toList.mapM decodeEnvRead
      let wArr ← Except.ok (writes.map packedCellRefToJson).toArray
      let writes_dec ← wArr.toList.mapM decodePackedCellRef
      .ok ⟨signature, domain, arity, guard_dec, deltas_dec, supplyDeltas_dec, stateReads_dec, envReads_dec, writes_dec⟩) := rfl
  rw [h_def]
  change (do
      let signature ← (sig.map unitToJson).mapM decodeUnit
      let domain ← decodeDomain (domainToJson dom)
      let guard_dec ← decodeExpr (exprToJson guard)
      let deltas_dec ← (deltas.map cellDeltaToJson).mapM decodeCellDelta
      let supplyDeltas_dec ← (supplyDeltas.map supplyDeltaToJson).mapM decodeSupplyDelta
      let stateReads_dec ← (stateReads.map packedCellRefToJson).mapM decodePackedCellRef
      let envReads_dec ← (envReads.map envReadToJson).mapM decodeEnvRead
      let writes_dec ← (writes.map packedCellRefToJson).mapM decodePackedCellRef
      Except.ok (TemplateEnc.mk signature domain arity guard_dec deltas_dec supplyDeltas_dec stateReads_dec envReads_dec writes_dec)) =
    (Except.ok (TemplateEnc.mk sig dom arity guard deltas supplyDeltas stateReads envReads writes) : Except DecodeFailure TemplateEnc)
  rw [h_sig, h_dom, h_guard, h_deltas, h_supply, h_sr, h_er, h_wr]
  rfl

theorem filter_not_beq_of_not_mem [BEq α] [LawfulBEq α] {a : α} {as : List α} (h : ∀ x ∈ as, a ≠ x) :
    List.filter (fun b => !(b == a)) as = as := by
  induction as with
  | nil => rfl
  | cons x xs ih =>
    have h_not_head : a ≠ x := h x (List.Mem.head xs)
    have h_not_tail : ∀ y ∈ xs, a ≠ y := fun y hy => h y (List.Mem.tail x hy)
    simp only [List.filter_cons]
    have h_ne : (x == a) = false := by
      cases h_eq : (x == a)
      · rfl
      · have h_true := eq_of_beq h_eq
        exact False.elim (h_not_head h_true.symm)
    rw [h_ne]
    dsimp
    rw [ih h_not_tail]

theorem eraseDups_eq_of_nodup [BEq α] [LawfulBEq α] {as : List α} (h : as.Nodup) :
    as.eraseDups = as := by
  induction as with
  | nil => exact List.eraseDups_nil
  | cons x xs ih =>
    cases h with
    | cons h_not_mem h_nodup =>
      rw [List.eraseDups_cons]
      have h_not_mem' : ∀ y ∈ xs, x ≠ y := fun y hy => (h_not_mem y hy)
      have h_filt := filter_not_beq_of_not_mem h_not_mem'
      rw [h_filt, ih h_nodup]

theorem nodup_eraseDups_length (ids : List Nat) (h_nodup : ids.Nodup) :
    (ids.length != ids.eraseDups.length) = false := by
  have h_eq : ids.eraseDups = ids := eraseDups_eq_of_nodup h_nodup
  rw [h_eq]
  exact bne_self_eq_false ids.length

def registryEntryToJson (e : RegistryEntryEnc) : Lean.Json :=
  Lean.Json.mkObj [("id", Lean.Json.num e.id), ("template", templateToJson e.template)]

set_option maxHeartbeats 1000000 in
theorem decodeRegistryEntry_registryEntryToJson (e : RegistryEntryEnc) (h_can : TemplateCanonical e.template) :
    decodeRegistryEntry (registryEntryToJson e) = .ok e := by
  cases e with | mk id t =>
  have h_t := decodeTemplate_templateToJson t h_can
  have h_def : decodeRegistryEntry (registryEntryToJson ⟨id, t⟩) = (do
      let t_dec ← decodeTemplate (templateToJson t)
      .ok ⟨id, t_dec⟩) := rfl
  rw [h_def, h_t]
  rfl

def registryToJson (r : RegistryEnc) : Lean.Json :=
  Lean.Json.mkObj [("entries", Lean.Json.arr (r.entries.map registryEntryToJson).toArray)]

set_option maxHeartbeats 1000000 in
theorem decodeRegistry_registryToJson (r : RegistryEnc) (h_can : RegistryCanonical r) :
    decodeRegistry (registryToJson r) = .ok r := by
  cases r with | mk entries =>
  dsimp [RegistryCanonical] at h_can
  have h_entries : (entries.map registryEntryToJson).mapM decodeRegistryEntry = .ok entries := by
    apply list_mapM_decode_ok
    intro e he
    have he_can := h_can.2 e he
    exact decodeRegistryEntry_registryEntryToJson e he_can
  have h_def : decodeRegistry (registryToJson ⟨entries⟩) = (do
      let entArr ← Except.ok (entries.map registryEntryToJson).toArray
      let ents ← entArr.toList.mapM decodeRegistryEntry
      let ids := ents.map (·.id)
      if ids.length != ids.eraseDups.length then
        throw (.uniqueness "registry")
      .ok ⟨ents⟩) := rfl
  rw [h_def]
  change (do
      let ents ← (entries.map registryEntryToJson).mapM decodeRegistryEntry
      let ids := ents.map (·.id)
      if ids.length != ids.eraseDups.length then
        throw (.uniqueness "registry")
      Except.ok (RegistryEnc.mk ents)) =
    (Except.ok (RegistryEnc.mk entries) : Except DecodeFailure RegistryEnc)
  rw [h_entries]
  dsimp [bind, Except.bind]
  have h_uniq := nodup_eraseDups_length (entries.map (·.id)) h_can.1
  rw [h_uniq]
  rfl

def capabilityToJson (c : CapabilityEnc) : Lean.Json :=
  Lean.Json.mkObj [
    ("holder", partyToJson c.holder),
    ("domain", domainToJson c.domain),
    ("operation", Lean.Json.num c.operation),
    ("right", rightToJson c.right),
    ("live", Lean.Json.bool c.live)
  ]

theorem decodeCapability_capabilityToJson (c : CapabilityEnc) :
    decodeCapability (capabilityToJson c) = .ok c := by
  cases c with | mk holder domain op right live =>
  have h_h := decodeParty_partyToJson holder
  have h_d := decodeDomain_domainToJson domain
  have h_r := decodeRight_rightToJson right
  have h_def : decodeCapability (capabilityToJson ⟨holder, domain, op, right, live⟩) = (do
      let h ← decodeParty (partyToJson holder)
      let d ← decodeDomain (domainToJson domain)
      let r ← decodeRight (rightToJson right)
      .ok ⟨h, d, op, r, live⟩) := rfl
  rw [h_def, h_h, h_d, h_r]
  cases live <;> rfl

def storeToJson (s : StoreEnc) : Lean.Json :=
  Lean.Json.mkObj [("entries", Lean.Json.arr (s.entries.map capabilityToJson).toArray)]

theorem decodeStore_storeToJson (s : StoreEnc) :
    decodeStore (storeToJson s) = .ok s := by
  have h_map : (s.entries.map capabilityToJson).mapM decodeCapability = .ok s.entries := by
    apply list_mapM_decode_ok
    intro c _
    exact decodeCapability_capabilityToJson c
  have h_def : decodeStore (storeToJson s) = (do
      let entArr ← Except.ok (s.entries.map capabilityToJson).toArray
      let entries ← entArr.toList.mapM decodeCapability
      .ok ⟨entries⟩) := rfl
  rw [h_def]
  change (do
      let entries ← (s.entries.map capabilityToJson).mapM decodeCapability
      Except.ok (StoreEnc.mk entries)) =
    (Except.ok (StoreEnc.mk s.entries) : Except DecodeFailure StoreEnc)
  rw [h_map]
  rfl

def contextToJson (c : ContextEnc) : Lean.Json :=
  Lean.Json.mkObj [("principal", partyToJson c.principal), ("domain", domainToJson c.domain)]

theorem decodeContext_contextToJson (c : ContextEnc) :
    decodeContext (contextToJson c) = .ok c := by
  cases c with | mk p d =>
  have h_p := decodeParty_partyToJson p
  have h_d := decodeDomain_domainToJson d
  have h_def : decodeContext (contextToJson ⟨p, d⟩) = (do
      let p_dec ← decodeParty (partyToJson p)
      let d_dec ← decodeDomain (domainToJson d)
      .ok ⟨p_dec, d_dec⟩) := rfl
  rw [h_def, h_p, h_d]
  rfl

def packedValueFullToJson (v : PackedValueEnc) : Lean.Json :=
  Lean.Json.mkObj [("unit", unitToJson v.unit), ("value", packedValueToJson v)]

theorem decodePackedValue_canonical (v : PackedValueEnc) (h_can : PackedValueCanonical v) :
    decodePackedValue (packedValueFullToJson v) = .ok v := by
  cases v with | mk u valRat valBool =>
  dsimp [PackedValueCanonical] at h_can
  cases u with
  | bool =>
    have h_rat := h_can.1 rfl
    have h_def : decodePackedValue (packedValueFullToJson ⟨.bool, valRat, valBool⟩) =
        .ok ⟨.bool, 0, valBool⟩ := by
      cases valBool <;> rfl
    rw [h_def, h_rat]
  | numeric nu =>
    have h_bool := h_can.2 nu rfl
    have h_den : valRat.den ≠ 0 := valRat.den_nz
    have h_gcd : Int.gcd valRat.num.natAbs valRat.den = 1 := valRat.reduced
    have h_rat : decodeRat (ratToJson ⟨valRat.num, valRat.den⟩) = .ok ⟨valRat.num, valRat.den⟩ :=
      decodeRat_mkObj valRat.num valRat.den h_den h_gcd
    have h_toRat : (RatEnc.mk valRat.num valRat.den).toRat = valRat := rat_toRat_fromRat valRat
    have h_u := decodeUnit_unitToJson (.numeric nu)
    have h_def : decodePackedValue (packedValueFullToJson ⟨.numeric nu, valRat, valBool⟩) = (do
        let u_dec ← decodeUnit (unitToJson (.numeric nu))
        match u_dec with
        | .bool => .error (.jsonType "boolValue")
        | .numeric nu' =>
          let r ← decodeRat (ratToJson ⟨valRat.num, valRat.den⟩)
          .ok ⟨.numeric nu', r.toRat, false⟩) := rfl
    rw [h_def, h_u]
    dsimp [bind, Except.bind]
    rw [h_rat]
    dsimp [bind, Except.bind]
    rw [h_toRat, h_bool]

def observationToJson (o : ObservationEnc) : Lean.Json :=
  Lean.Json.mkObj [("value", packedValueFullToJson o.value), ("timestamp", Lean.Json.num o.timestamp)]

theorem decodeObservation_observationToJson (o : ObservationEnc) (h_can : PackedValueCanonical o.value) :
    decodeObservation (observationToJson o) = .ok o := by
  cases o with | mk val ts =>
  have h_val := decodePackedValue_canonical val h_can
  have h_def : decodeObservation (observationToJson ⟨val, ts⟩) = (do
      let v_dec ← decodePackedValue (packedValueFullToJson val)
      .ok ⟨v_dec, ts⟩) := rfl
  rw [h_def, h_val]
  rfl

def environmentEntryToJson (e : EnvironmentEntryEnc) : Lean.Json :=
  Lean.Json.mkObj [("key", observationKeyToJson e.key), ("observation", observationToJson e.observation)]

theorem decodeEnvironmentEntry_environmentEntryToJson (e : EnvironmentEntryEnc) (h_can : PackedValueCanonical e.observation.value) :
    decodeEnvironmentEntry (environmentEntryToJson e) = .ok e := by
  cases e with | mk k o =>
  have h_k := decodeObservationKey_observationKeyToJson k
  have h_o := decodeObservation_observationToJson o h_can
  have h_def : decodeEnvironmentEntry (environmentEntryToJson ⟨k, o⟩) = (do
      let k_dec ← decodeObservationKey (observationKeyToJson k)
      let o_dec ← decodeObservation (observationToJson o)
      .ok ⟨k_dec, o_dec⟩) := rfl
  rw [h_def, h_k, h_o]
  rfl

def environmentToJson (env : EnvironmentEnc) : Lean.Json :=
  Lean.Json.mkObj [("entries", Lean.Json.arr (env.entries.map environmentEntryToJson).toArray)]

theorem decodeEnvironment_environmentToJson (env : EnvironmentEnc) (h_can : EnvironmentCanonical env) :
    decodeEnvironment (environmentToJson env) = .ok env := by
  cases env with | mk entries =>
  dsimp [EnvironmentCanonical] at h_can
  have h_entries : (entries.map environmentEntryToJson).mapM decodeEnvironmentEntry = .ok entries := by
    apply list_mapM_decode_ok
    intro e he
    have he_can := h_can e he
    exact decodeEnvironmentEntry_environmentEntryToJson e he_can
  have h_def : decodeEnvironment (environmentToJson ⟨entries⟩) = (do
      let entArr ← Except.ok (entries.map environmentEntryToJson).toArray
      let ents ← entArr.toList.mapM decodeEnvironmentEntry
      .ok ⟨ents⟩) := rfl
  rw [h_def]
  change (do
      let ents ← (entries.map environmentEntryToJson).mapM decodeEnvironmentEntry
      Except.ok (EnvironmentEnc.mk ents)) =
    (Except.ok (EnvironmentEnc.mk entries) : Except DecodeFailure EnvironmentEnc)
  rw [h_entries]
  rfl

def domainAdminToJson (d : DomainAdminEnc) : Lean.Json :=
  Lean.Json.mkObj [("domain", domainToJson d.domain), ("party", partyToJson d.party)]

theorem decodeDomainAdmin_domainAdminToJson (d : DomainAdminEnc) :
    decodeDomainAdmin (domainAdminToJson d) = .ok d := by
  cases d with | mk dom p =>
  have h_dom := decodeDomain_domainToJson dom
  have h_p := decodeParty_partyToJson p
  have h_def : decodeDomainAdmin (domainAdminToJson ⟨dom, p⟩) = (do
      let d_dec ← decodeDomain (domainToJson dom)
      let p_dec ← decodeParty (partyToJson p)
      .ok ⟨d_dec, p_dec⟩) := rfl
  rw [h_def, h_dom, h_p]
  rfl

def inputPortToJson (p : InputPortEnc) : Lean.Json :=
  Lean.Json.mkObj [("id", Lean.Json.num p.id), ("unit", unitToJson p.unit)]

theorem decodeInputPort_inputPortToJson (p : InputPortEnc) :
    decodeInputPort (inputPortToJson p) = .ok p := by
  cases p with | mk id u =>
  have h_u := decodeUnit_unitToJson u
  have h_def : decodeInputPort (inputPortToJson ⟨id, u⟩) = (do
      let u_dec ← decodeUnit (unitToJson u)
      .ok ⟨id, u_dec⟩) := rfl
  rw [h_def, h_u]
  rfl

def outputPortToJson (p : OutputPortEnc) : Lean.Json :=
  Lean.Json.mkObj [("id", Lean.Json.num p.id), ("cell", cellToJson p.cell)]

theorem decodeOutputPort_outputPortToJson (p : OutputPortEnc) :
    decodeOutputPort (outputPortToJson p) = .ok p := by
  cases p with | mk id c =>
  have h_c := decodeCell_cellToJson c
  have h_def : decodeOutputPort (outputPortToJson ⟨id, c⟩) = (do
      let c_dec ← decodeCell (cellToJson c)
      .ok ⟨id, c_dec⟩) := rfl
  rw [h_def, h_c]
  rfl

def resourcePortToJson (rp : ResourcePortEnc) : Lean.Json :=
  Lean.Json.mkObj [("id", Lean.Json.num rp.id), ("cell", cellToJson rp.cell), ("writable", Lean.Json.bool rp.writable)]

theorem decodeResourcePort_resourcePortToJson (rp : ResourcePortEnc) :
    decodeResourcePort (resourcePortToJson rp) = .ok rp := by
  cases rp with | mk id c w =>
  have h_c := decodeCell_cellToJson c
  have h_def : decodeResourcePort (resourcePortToJson ⟨id, c, w⟩) = (do
      let c_dec ← decodeCell (cellToJson c)
      .ok ⟨id, c_dec, w⟩) := rfl
  rw [h_def, h_c]
  cases w <;> rfl

def qualifiedPortToJson (qp : QualifiedPortEnc) : Lean.Json :=
  Lean.Json.mkObj [("component", Lean.Json.num qp.component), ("port", Lean.Json.num qp.port)]

theorem decodeQualifiedPort_qualifiedPortToJson (qp : QualifiedPortEnc) :
    decodeQualifiedPort (qualifiedPortToJson qp) = .ok qp := by
  cases qp with | mk c p => rfl

def resourceImportToJson (ri : ResourceImportEnc) : Lean.Json :=
  Lean.Json.mkObj [("source", qualifiedPortToJson ri.source), ("cell", cellToJson ri.cell), ("writable", Lean.Json.bool ri.writable)]

theorem decodeResourceImport_resourceImportToJson (ri : ResourceImportEnc) :
    decodeResourceImport (resourceImportToJson ri) = .ok ri := by
  cases ri with | mk s c w =>
  have h_c := decodeCell_cellToJson c
  have h_def : decodeResourceImport (resourceImportToJson ⟨s, c, w⟩) = (do
      let c_dec ← decodeCell (cellToJson c)
      .ok ⟨s, c_dec, w⟩) := rfl
  rw [h_def, h_c]
  cases w <;> rfl

def sourcePinToJson (sp : SourcePinEnc) : Lean.Json :=
  Lean.Json.mkObj [
    ("git", Lean.Json.str sp.git),
    ("lean_toolchain", Lean.Json.str sp.lean_toolchain),
    ("mathlib_rev", Lean.Json.str sp.mathlib_rev),
    ("checker_candidate", Lean.Json.str sp.checker_candidate)
  ]

theorem decodeSourcePin_sourcePinToJson (sp : SourcePinEnc) (h_cr : sp.compiler_record = none) (h_ar : sp.audit_record = none) :
    decodeSourcePin (sourcePinToJson sp) = .ok sp := by
  cases sp with | mk git lt ml cc cr ar =>
  dsimp at h_cr h_ar
  subst h_cr h_ar
  rfl

def typesEnumToJson (te : TypesEnumEnc) : Lean.Json :=
  Lean.Json.mkObj [
    ("parties", Lean.Json.arr (te.parties.map partyToJson).toArray),
    ("assets", Lean.Json.arr (te.assets.map assetToJson).toArray),
    ("domains", Lean.Json.arr (te.domains.map domainToJson).toArray)
  ]

theorem decodeTypesEnum_typesEnumToJson (te : TypesEnumEnc) :
    decodeTypesEnum (typesEnumToJson te) = .ok te := by
  have h_p : (te.parties.map partyToJson).mapM decodeParty = .ok te.parties := by
    apply list_mapM_decode_ok; intro p _; exact decodeParty_partyToJson p
  have h_a : (te.assets.map assetToJson).mapM decodeAsset = .ok te.assets := by
    apply list_mapM_decode_ok; intro a _; exact decodeAsset_assetToJson a
  have h_d : (te.domains.map domainToJson).mapM decodeDomain = .ok te.domains := by
    apply list_mapM_decode_ok; intro d _; exact decodeDomain_domainToJson d
  have h_def : decodeTypesEnum (typesEnumToJson te) = (do
      let parties ← (te.parties.map partyToJson).mapM decodeParty
      let assets ← (te.assets.map assetToJson).mapM decodeAsset
      let domains ← (te.domains.map domainToJson).mapM decodeDomain
      .ok ⟨parties, assets, domains⟩) := rfl
  rw [h_def, h_p, h_a, h_d]
  rfl

theorem decodeStateCell_stateCellToJson (c : StateCellEnc)
    (h_den : c.amount.den ≠ 0) (h_gcd : Int.gcd c.amount.num.natAbs c.amount.den = 1) (h_nonneg : c.amount.num ≥ 0) :
    decodeStateCell (stateCellToJson c) = .ok c := by
  cases c with | mk d p a amt =>
  dsimp at h_nonneg
  have h_d := decodeDomain_domainToJson d
  have h_p := decodeParty_partyToJson p
  have h_a := decodeAsset_assetToJson a
  have h_amt : decodeRat (ratToJson amt) = .ok amt := decodeRat_ratToJson amt h_den h_gcd
  have h_def : decodeStateCell (stateCellToJson ⟨d, p, a, amt⟩) = (do
      let d_dec ← decodeDomain (domainToJson d)
      let p_dec ← decodeParty (partyToJson p)
      let a_dec ← decodeAsset (assetToJson a)
      let amt_dec ← decodeRat (ratToJson amt)
      if amt_dec.num < 0 then throw .stateNonneg
      .ok ⟨d_dec, p_dec, a_dec, amt_dec⟩) := rfl
  rw [h_def, h_d, h_p, h_a, h_amt]
  dsimp [bind, Except.bind]
  have h_neg : ¬ (amt.num < 0) := by omega
  rw [if_neg h_neg]


