import DefiKernel.Interleaving.RunnerDependency
namespace DefiKernel.Certificates
def splitLimit : Nat := 4
-- BEGIN PROOFS
theorem splitLimit_value : splitLimit = 4 := rfl
end DefiKernel.Certificates
