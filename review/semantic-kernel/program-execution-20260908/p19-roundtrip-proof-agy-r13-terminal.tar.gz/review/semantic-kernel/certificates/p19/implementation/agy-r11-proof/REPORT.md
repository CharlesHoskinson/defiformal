# P19 Universal IR Encode/Decode Proof Report (agy-r11-proof)

- **Candidate**: P19 Typed/Sequential Certificates (Resource Classification, Depth Fidelity & Container Inversions)
- **Attempt**: `agy-r11-proof`
- **Timestamp**: 2026-09-10T10:42:00Z
- **Author**: Native AGY Gemini 3.8 Flash High (`gemini-3.8-flash-high`, `--effort high`)
- **Auditor**: Pending Independent Audit by Fresh Native Grok 4.6 (`grok-4.6-high`)
- **Disposition**: `PARTIAL_PROOF_WORK`
- **Worktree**: `/home/charl/defiformal-wt-p19-certificates-grok-opus-20260909` (0 commits, 0 pushes)
- **Base Git Revision**: `38de83c58e3f9315bf400807591d538d7565152e`
- **Resolved Toolchain**: `leanprover/lean4:v4.33.0-rc2`, commit `d8b18978322de05a8f3dba51ef03cf5461676c17`
- **Working Directory**: `/home/charl/defiformal-wt-p19-certificates-grok-opus-20260909/lean`
- **Resolved Lean Binary**: `/home/charl/.elan/toolchains/leanprover--lean4---v4.33.0-rc2/bin/lean`
- **Axiom Audit Compliance**: Strictly ZERO `sorry`, ZERO custom axioms, ZERO `native_decide` in accepted kernel proofs. Standard axioms only: `[propext, Classical.choice, Quot.sound]`.

---

## Executive Summary

Attempt `agy-r11-proof` continues the authorized core roadmap for P19 canonical certificate verification. It directly resolves the root-identified gaps from previous attempts, establishes exact resource limit classification and whole-document structural metrics, and scales the inductive inversion theorem hierarchy to cover all remaining container and payload structures across the certificate grammar:

1. **Public Resource Classification (`RESOURCE-LIMIT-PROPAGATION` - RESOLVED)**:
   - In `Decode.lean`, `decodeBytes` previously mapped all `parseCanonicalJson` errors to `.notJsonObject`. This caused documents exceeding parser resource limits (e.g. array length > 4096 or depth > 64) to be misclassified as `.codec (.malformed .notJsonObject)`.
   - Patched `decodeBytes` to preserve `Except.error (.resourceLimit r)`. Through `Check.lean`, these errors are now faithfully mapped to `.codec (.blocked r)`.
   - Added two exact boundary regressions in `Tests.lean` (`checkArrayLengthBoundaryRegression` and `checkDepthBoundaryRegression`), verifying that limit-minus-one (4095/63) and limit (4096/64) are admitted by the parser (proceeding to schema validation), while limit-plus-one (4097/65) is blocked with `.codec (.blocked "max_array_length")` and `.codec (.blocked "maxDepth")` respectively.

2. **Depth and Grammar Fidelity (`DEPTH-FIDELITY-REPAIR` - RESOLVED)**:
   - Eliminated artificial guessed depth margins (`exprMaxStackDepth <= 52 ∧ exprDepth <= 55`) from `SupportedIR`.
   - Replaced both with faithful whole-document structural metrics:
     ```lean
     def WholeDocumentDepthBounded (ir : DecodedIR) : Prop :=
       jsonDepth (decodedIRToJson ir) <= 64

     def WholeDocumentArrayBounded (ir : DecodedIR) : Prop :=
       jsonMaxArrayLength (decodedIRToJson ir) <= 4096
     ```
     alongside exact `SerializedByteBound ir : (encodeModule ir).size <= 1048576`.
   - Retained necessary collection size bounds (`TypedPayloadLengthBounds`, `StepPayloadLengthBounds`, `RunPayloadLengthBounds`) while eliminating speculative expression depth offsets.
   - Proved non-emptiness of the repaired domain in `structurallyAdmissible_nonempty` on `canonicalWitnessIR` with standard axioms only (`by decide`).

3. **Universal Codec Inversion Hierarchy (`AST-CONTAINER-INVERSIONS` - ADVANCED)**:
   - Proved 17 new container and payload inversion theorems in `Correspondence.lean`, completing the structural inductive basis across all remaining AST types:
     - `decodeLibraryRef_libraryRefToJson`
     - `decodeNat_natToJson`
     - `decodeNatList_map_num`
     - `decodeState_stateToJson` (with deduplication uniqueness proof)
     - `decodeRequest_requestToJson`
     - `decodeOperationInterface_operationInterfaceToJson`
     - `decodeComponent_componentToJson`
     - `decodeConfig_configToJson`
     - `decodeWorld_worldToJson`
     - `decodeBoundary_boundaryToJson`
     - `decodeInputSource_inputSourceToJson`
     - `decodeInvocation_invocationToJson`
     - `decodeStep_stepToJson`
     - `decodeOutputObservation_outputObservationToJson`
     - `decodeTypedExecutePayload_typedExecutePayloadToJson`
     - `decodeCompositionStepPayload_compositionStepPayloadToJson`
     - `decodeCompositionRunPayload_compositionRunPayloadToJson`
   - Total verified cataloged theorems increased from 148 in R10 to **165 verified theorems** in `theorems.json`, all depending strictly on standard Lean 4 axioms (`[propext, Classical.choice, Quot.sound]`), with 0 sorry and 0 custom axioms.
   - Total theorems passing the transitive compiler axiom audit across Certificates, Typed, and Composition increased from 1973 in R10 to **1992 theorems** (Certificates: 1285, Typed: 420, Composition: 287).

4. **Status Truthfulness Mandate (`UNIVERSAL-ROUNDTRIP-STATUS` - PARTIAL_PROOF_WORK)**:
   - `EncodeDecodeRoundtripStatement` remains defined as `def Prop`:
     ```lean
     def EncodeDecodeRoundtripStatement : Prop :=
       ∀ (ir : DecodedIR), StructurallyAdmissibleIR ir → decodeBytes (encodeModule ir) = .ok ir
     ```
   - Partial proof work is clearly and truthfully reported as `PARTIAL_PROOF_WORK`. Full universal roundtrip equivalence across byte-level serialization and parser inversion remains open pending universal tokenization-to-bytes synthesis.

---

## Detailed Technical Resolutions

### 1. Resource Limit Error Propagation (`RESOURCE-LIMIT-PROPAGATION`)
- **Finding**: In R10, `decodeBytes` contained:
  ```lean
  let j ← match parseCanonicalJson str with
    | .error _ => throw .notJsonObject
    | .ok j => pure j
  ```
  This swallowed the specific `.resourceLimit r` error returned by the canonical JSON parser when array lengths exceed 4096 or object nesting depths exceed 64, turning them into generic `.notJsonObject` errors. In `Check.lean`, `.notJsonObject` becomes `.codec (.malformed .notJsonObject)`, violating the public resource classification requirement.
- **Repair**:
  In `lean/DefiKernel/Certificates/Decode.lean`:
  ```lean
  let j ← match parseCanonicalJson str with
    | .error (.resourceLimit r) => throw (.resourceLimit r)
    | .error _ => throw .notJsonObject
    | .ok j => pure j
  ```
- **Fidelity & Regression Testing**:
  Added regression functions `checkArrayLengthBoundaryRegression` and `checkDepthBoundaryRegression` to `Tests.lean`:
  - `checkArrayLengthBoundaryRegression`:
    - Array of length 4095: admitted by parser, fails schema as `.codec (.malformed ...)` (expected, not blocked).
    - Array of length 4096: admitted by parser, fails schema as `.codec (.malformed ...)` (admitted at exact limit).
    - Array of length 4097: blocked by parser, classified as `.codec (.blocked "max_array_length")`.
  - `checkDepthBoundaryRegression`:
    - Nesting depth 63: admitted by parser, fails schema as `.codec (.malformed ...)`.
    - Nesting depth 64: admitted by parser, fails schema as `.codec (.malformed ...)`.
    - Nesting depth 65: blocked by parser, classified as `.codec (.blocked "maxDepth")`.
  Both boundary regressions are integrated into `Tests.runtimeChecks` and evaluate to `true`.

### 2. Whole-Document Structural Metrics (`DEPTH-FIDELITY-REPAIR`)
- **Finding**: The earlier restriction `exprMaxStackDepth <= 52 ∧ exprDepth <= 55` was an artificial guess applied to individual expressions to prevent nesting overflow. It was not a whole-document metric and did not accurately reflect document-level grammar limits.
- **Repair**:
  In `lean/DefiKernel/Certificates/Correspondence.lean`:
  - Defined whole-document depth and array length metrics over JSON:
    ```lean
    def jsonDepthFuel (fuel : Nat) (j : Lean.Json) : Nat
    def jsonDepth (j : Lean.Json) : Nat := jsonDepthFuel 256 j

    def jsonMaxArrayLengthFuel (fuel : Nat) (j : Lean.Json) : Nat
    def jsonMaxArrayLength (j : Lean.Json) : Nat := jsonMaxArrayLengthFuel 65536 j

    def WholeDocumentDepthBounded (ir : DecodedIR) : Prop :=
      jsonDepth (decodedIRToJson ir) <= 64

    def WholeDocumentArrayBounded (ir : DecodedIR) : Prop :=
      jsonMaxArrayLength (decodedIRToJson ir) <= 4096
    ```
  - Replaced the guessed expression depth margins in `SupportedIR` with the whole-document metrics:
    ```lean
    def SupportedIR (ir : DecodedIR) : Prop :=
      TypedPayloadLengthBounds ir ∧
      StepPayloadLengthBounds ir ∧
      RunPayloadLengthBounds ir ∧
      WholeDocumentDepthBounded ir ∧
      WholeDocumentArrayBounded ir ∧
      SerializedByteBound ir
    ```
  - Updated `structurallyAdmissible_nonempty` to prove both bounds on `canonicalWitnessIR`:
    ```lean
    have h_doc_depth : WholeDocumentDepthBounded canonicalWitnessIR := by decide
    have h_doc_arr : WholeDocumentArrayBounded canonicalWitnessIR := by decide
    ```
    verifying non-emptiness with standard Lean 4 axioms only.

### 3. Container & Payload Codec Inversions (`AST-CONTAINER-INVERSIONS`)
- **Implementation**:
  In `lean/DefiKernel/Certificates/Correspondence.lean`, reordered component JSON serializers before `SupportedIR` and proved 17 new container and payload inversion theorems:
  1. `decodeLibraryRef_libraryRefToJson`: Proves roundtrip of `LibraryRefEnc` records.
  2. `decodeNat_natToJson`: Proves decoding of numeric capability IDs.
  3. `decodeNatList_map_num`: Proves roundtrip of capability ID lists under monadic map.
  4. `decodeState_stateToJson`: Proves state decoding roundtrip, discharging the key-uniqueness check via `(s.cells.map ...).eraseDups.length = s.cells.length`.
  5. `decodeRequest_requestToJson`: Proves request decoding roundtrip, handling both `actor = none` and `actor = some p`.
  6. `decodeOperationInterface_operationInterfaceToJson`: Proves operation interface decoding roundtrip across inputs and outputs.
  7. `decodeComponent_componentToJson`: Proves component decoding roundtrip across private cells, exports, imports, and operations.
  8. `decodeConfig_configToJson`: Proves config decoding roundtrip across registry, domain admin, and catalog.
  9. `decodeWorld_worldToJson`: Proves world decoding roundtrip across state and capability store.
  10. `decodeBoundary_boundaryToJson`: Proves boundary decoding roundtrip across context, environment, and block time.
  11. `decodeInputSource_inputSourceToJson`: Proves input source decoding roundtrip across literal and priorOutput variants.
  12. `decodeInvocation_invocationToJson`: Proves invocation decoding roundtrip across components, operations, parties, inputs, capabilities, and actor.
  13. `decodeStep_stepToJson`: Proves step decoding roundtrip across invoke, issue, and revoke variants.
  14. `decodeOutputObservation_outputObservationToJson`: Proves output observation decoding roundtrip across step indices, qualified ports, and packed values.
  15. `decodeTypedExecutePayload_typedExecutePayloadToJson`: Proves complete typed execution payload decoding roundtrip across registry, store, context, environment, timestamp, request, and state.
  16. `decodeCompositionStepPayload_compositionStepPayloadToJson`: Proves composition step payload decoding roundtrip across config, boundary, index, history, step, and pre-state.
  17. `decodeCompositionRunPayload_compositionRunPayloadToJson`: Proves composition run payload decoding roundtrip across config, boundaries, world, and execution steps.

---

## Verification Results

### 1. Compiler Axiom Audit
- **Command**: `lake env lean DefiKernel/Certificates/Verify.lean`
- **Exit Code**: 0
- **Log SHA-256**: `27d4b2a0f1860ea37005e10536af01db7ec9bc2f8b6c0a0c50697fcab1f6fe27`
- **Scope Summary**:
  - `DefiKernel.Certificates`: 1285/1285 theorems passed, 2502/2502 supplemental passed, forbidden = 0
  - `DefiKernel.Typed`: 420/420 theorems passed, 677/677 supplemental passed, forbidden = 0
  - `DefiKernel.Composition`: 287/287 theorems passed, 408/408 supplemental passed, forbidden = 0
- **Axioms Present**: `[propext, Classical.choice, Quot.sound]`. Strictly ZERO `sorry`, ZERO custom axioms, ZERO `native_decide`.

### 2. Certificate Fixtures and Negative Controls
- **Command**: `python3 scripts/run_certificate_fixtures.py --out review/semantic-kernel/certificates/p19/implementation/agy-r11-proof`
- **Exit Code**: 0
- **Fixtures Total**: 54/54 passed deep structural comparison.
- **Negative Controls**: 54/54 discriminated non-vacuously.
- **Regression Controls**: 2/2 passed (F13 non-canonical source_map order rejection, F28 non-canonical source_map order rejection).

### 3. Tests.lean Runtime Checks
- **Command**: `lake env lean --stdin <<< 'import DefiKernel.Certificates.Tests; #eval DefiKernel.Certificates.Tests.runtimeChecks'`
- **Exit Code**: 0
- **Results**: 21/21 checks evaluated to `true`, including:
  - `("cert.boundary.array-length", true)`
  - `("cert.boundary.nesting-depth", true)`

---

## Status and Next Steps

- **Current Status**: `PARTIAL_PROOF_WORK`.
- **Delivered Capabilities**:
  - Exact public resource classification (`.codec (.blocked limit)`) on parser limits.
  - Faithful whole-document structural metrics (`WholeDocumentDepthBounded`, `WholeDocumentArrayBounded`, `SerializedByteBound`).
  - Inductive AST codec inversion basis completed across all 17 component and payload structures.
- **Open Obligation**:
  - `EncodeDecodeRoundtripStatement` remains `def Prop`. The bridge connecting tokenization inversion to whole-document byte-level decoding remains open for subsequent sprints.
