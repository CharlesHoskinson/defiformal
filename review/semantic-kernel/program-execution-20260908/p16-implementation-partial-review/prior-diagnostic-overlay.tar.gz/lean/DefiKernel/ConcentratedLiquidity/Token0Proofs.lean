import DefiKernel.ConcentratedLiquidity.SqrtPriceMath

namespace DefiKernel.ConcentratedLiquidity.SqrtPriceMath
open ConcentratedLiquidity

theorem add_mod_eq_sub {W a : Nat} (hle : W ≤ a) (hlt : a < W + W) :
    a % W = a - W := by
  have ha : a = W + (a - W) := (Nat.add_sub_of_le hle).symm
  have hsmall : a - W < W := Nat.sub_lt_left_of_lt_add hle hlt
  rw [ha, Nat.add_mod, Nat.mod_self, Nat.zero_add, Nat.mod_eq_of_lt hsmall]

theorem wrap_ge_iff_width (W n1 prod : Nat) (hn1 : n1 < W) (hprod : prod < W) :
    (n1 + prod) % W ≥ n1 ↔ n1 + prod < W := by
  constructor
  · intro hge
    by_contra hnot
    have hle : W ≤ n1 + prod := Nat.le_of_not_gt hnot
    have hlt : n1 + prod < W + W := Nat.add_lt_add hn1 hprod
    have hmod : (n1 + prod) % W = n1 + prod - W := add_mod_eq_sub hle hlt
    have hge' : n1 + prod - W ≥ n1 := by
      simpa [hmod] using hge
    have hadd : n1 + prod - W + W ≥ n1 + W := Nat.add_le_add_right hge' _
    have hsum : n1 + prod ≥ n1 + W := by
      rwa [Nat.sub_add_cancel hle] at hadd
    have hprodle : W ≤ prod := Nat.le_of_add_le_add_left hsum
    exact (Nat.not_le.mpr hprod) hprodle
  · intro hfit
    have : (n1 + prod) % W = n1 + prod := Nat.mod_eq_of_lt hfit
    rw [this]
    exact Nat.le_add_right _ _

theorem wrap_ge_iff_sum_fit (n1 prod : Nat) (hn1 : n1 < 2 ^ 256)
    (hprod : prod < 2 ^ 256) :
    wrap256 (n1 + prod) ≥ n1 ↔ n1 + prod < 2 ^ 256 :=
  wrap_ge_iff_width (2 ^ 256) n1 prod hn1 hprod

end DefiKernel.ConcentratedLiquidity.SqrtPriceMath
