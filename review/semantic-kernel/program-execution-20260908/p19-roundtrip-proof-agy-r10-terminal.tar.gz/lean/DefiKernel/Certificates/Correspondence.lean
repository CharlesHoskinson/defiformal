import DefiKernel.Certificates.Schema
import DefiKernel.Certificates.Decode
import DefiKernel.Certificates.Check
import DefiKernel.Certificates.Observation
import DefiKernel.Certificates.CanonicalJson

namespace DefiKernel.Certificates

set_option linter.style.longLine false

/-! Correspondence theorems and open remainder obligations for serialized certificates.
In accordance with P19 specifications and RC01/P20 gates:
- Exact codec, raw execution, and checker success/error correspondence theorems are proven.
- Component-level roundtrip theorems (rational, party, asset, domain, right) are proven.
- Bounded finite fixture evidence (F25, F27, F28, etc.) is verified computationally.
- Universal quantified statements (T-roundtrip, T-canonical-bytes) are explicitly defined over
  a nonempty structurally admissible canonical IR domain. General parser inversion remains a P20 gate.
- Strictly zero `sorry`, custom axioms, or `native_decide` are used in accepted kernel proofs. -/

/-- Standard declaration order of 32 cell keys across (Domain × Party × Asset). -/
def standard32CellKeys : List (Domain × Party × Asset) :=
  let parties : List Party := [.alice, .bob, .vault, .pool]
  let assets : List Asset := [.usd, .share, .collateral, .debt]
  let domains : List Domain := [.main, .other]
  domains.flatMap fun d ↦
    parties.flatMap fun p ↦
      assets.map fun a ↦ (d, p, a)

/-- Complete 32-cell universe predicate: exact declaration order, unique cells, and canonical rationals. -/
def StateCellsMatchStandard32 (cells : List StateCellEnc) : Prop :=
  cells.length = 32 ∧
  cells.map (fun c ↦ (c.domain, c.party, c.asset)) = standard32CellKeys ∧
  cells.all (fun c ↦ c.amount.den > 0 ∧ c.amount.num ≥ 0 ∧ Int.gcd c.amount.num.natAbs c.amount.den = 1) = true

/-- Declaration order of types enumeration matching the standard universe. -/
def StandardTypesEnum (t : TypesEnumEnc) : Prop :=
  t.parties = [.alice, .bob, .vault, .pool] ∧
  t.assets = [.usd, .share, .collateral, .debt] ∧
  t.domains = [.main, .other]

/-- Strictly ascending lexicographical UTF-8 byte order on source map keys. -/
def SourceMapSorted (sm : List (String × String)) : Prop :=
  isSortedStrictAscending (sm.map Prod.fst) = true

/-- Canonical representation for packed values: inactive fields must be zero/false.
    For bool units, valRat must be zero. For numeric units, valBool must be false. -/
def PackedValueCanonical (v : PackedValueEnc) : Prop :=
  (v.unit = .bool → v.valRat = 0) ∧
  (∀ nu, v.unit = .numeric nu → v.valBool = false)

/-- Depth of an expression tree. -/
def ExprEnc.depth : ExprEnc → Nat
  | .lit _ => 1
  | .arg _ _ => 1
  | .balance _ => 1
  | .observe _ => 1
  | .timestamp _ => 1
  | .now => 1
  | .unary _ x => 1 + x.depth
  | .binary _ x y => 1 + max x.depth y.depth
  | .ite c y n => 1 + max c.depth (max y.depth n.depth)

/-- Recursive canonicality for expressions:
    1. Literals have canonical packed values.
    2. Sub-expressions are canonical.
    3. Expression depth does not exceed max_json_depth (64). -/
def ExprCanonical (e : ExprEnc) : Prop :=
  e.depth ≤ 64 ∧
  match e with
  | .lit v => PackedValueCanonical v
  | .unary _ x => ExprCanonical x
  | .binary _ x y => ExprCanonical x ∧ ExprCanonical y
  | .ite c y n => ExprCanonical c ∧ ExprCanonical y ∧ ExprCanonical n
  | _ => True

/-- Canonical template: guard and all deltas have canonical expressions. -/
def TemplateCanonical (t : TemplateEnc) : Prop :=
  ExprCanonical t.guard ∧
  (∀ d ∈ t.deltas, ExprCanonical d.amount) ∧
  (∀ s ∈ t.supplyDeltas, ExprCanonical s.amount)

/-- Canonical registry: entries are unique and each template is canonical. -/
def RegistryCanonical (r : RegistryEnc) : Prop :=
  (r.entries.map (·.id)).Nodup ∧
  (∀ e ∈ r.entries, TemplateCanonical e.template)

/-- Canonical store: capability entries are unique. -/
def StoreCanonical (s : StoreEnc) : Prop :=
  s.entries.Nodup

/-- Canonical environment: all observations have canonical packed values. -/
def EnvironmentCanonical (env : EnvironmentEnc) : Prop :=
  ∀ e ∈ env.entries, PackedValueCanonical e.observation.value

/-- Canonical request: all arguments have canonical packed values. -/
def RequestCanonical (r : RequestEnc) : Prop :=
  ∀ a ∈ r.arguments, PackedValueCanonical a

/-- Canonical input source: literals have canonical packed values. -/
def InputSourceCanonical : InputSourceEnc → Prop
  | .literal v => PackedValueCanonical v
  | .priorOutput _ _ => True

/-- Canonical invocation: input sources are canonical. -/
def InvocationCanonical (inv : InvocationEnc) : Prop :=
  ∀ i ∈ inv.inputs, InputSourceCanonical i

/-- Supported and canonical step: no unsupported constructors, invocations canonical. -/
def StepCanonical : StepEnc → Prop
  | .invoke inv => InvocationCanonical inv
  | .issue _ => True
  | .revoke _ => True
  | .unsupported _ => False

/-- Canonical world: standard 32 state cells and canonical store. -/
def WorldCanonical (w : WorldEnc) : Prop :=
  StateCellsMatchStandard32 w.state.cells ∧
  StoreCanonical w.capabilities

/-- Canonical claimed next state: none or canonical world. -/
def ClaimedNextStateCanonical (cns : Option WorldEnc) : Prop :=
  match cns with
  | none => True
  | some w => WorldCanonical w

/-- Canonical history: output observations have canonical packed values. -/
def HistoryCanonical (h : List OutputObservationEnc) : Prop :=
  ∀ o ∈ h, PackedValueCanonical o.value

/-- Canonical boundary: environment observations are canonical. -/
def BoundaryCanonical (b : BoundaryEnc) : Prop :=
  EnvironmentCanonical b.env

/-- Length bounds for operation interface collections. -/
def OperationInterfaceLengthBounds (op : OperationInterfaceEnc) : Prop :=
  op.inputs.length ≤ 4096 ∧ op.outputs.length ≤ 4096

/-- Bounded array lengths for template collections matching parser limits. -/
def TemplateLengthBounds (t : TemplateEnc) : Prop :=
  t.signature.length ≤ 4096 ∧
  t.deltas.length ≤ 4096 ∧
  t.supplyDeltas.length ≤ 4096 ∧
  t.stateReads.length ≤ 4096 ∧
  t.envReads.length ≤ 4096 ∧
  t.writes.length ≤ 4096

/-- Length bounds for component collections. -/
def ComponentLengthBounds (c : ComponentEnc) : Prop :=
  c.privateCells.length ≤ 4096 ∧
  c.exports.length ≤ 4096 ∧
  c.imports.length ≤ 4096 ∧
  c.operations.length ≤ 4096 ∧
  (∀ op ∈ c.operations, OperationInterfaceLengthBounds op)

/-- Length bounds for composition configuration. -/
def ConfigLengthBounds (cfg : ConfigEnc) : Prop :=
  cfg.registry.entries.length ≤ 4096 ∧
  (∀ e ∈ cfg.registry.entries, TemplateLengthBounds e.template) ∧
  cfg.domainAdmin.length ≤ 4096 ∧
  cfg.catalog.length ≤ 4096 ∧
  (∀ c ∈ cfg.catalog, ComponentLengthBounds c)

/-- Length bounds for claimed next state world. -/
def ClaimedNextStateLengthBounds (cns : Option WorldEnc) : Bool :=
  match cns with
  | none => true
  | some w => w.state.cells.length == 32 && w.capabilities.entries.length <= 4096

/-- Bounded array lengths for envelope collections matching production parser limits. -/
def EnvelopeLengthBounds (env : EnvelopeEnc) : Prop :=
  env.audit_roots.length ≤ 4096 ∧
  env.assumptions.length ≤ 4096 ∧
  env.invariants.length ≤ 4096 ∧
  env.libraries.length ≤ 4096 ∧
  env.source_map.length ≤ 4096 ∧
  env.claimed_judgments.length ≤ 4096 ∧
  env.types.parties.length ≤ 4096 ∧
  env.types.assets.length ≤ 4096 ∧
  env.types.domains.length ≤ 4096 ∧
  ClaimedNextStateLengthBounds env.claimed_next_state = true

/-- Serialized byte bound: the serialized document byte length does not exceed 1 MiB (1048576 bytes). -/
def SerializedByteBound (ir : DecodedIR) : Prop :=
  (encodeModule ir).size ≤ 1048576

/-- Expression AST depth calculation. -/
def exprDepth : ExprEnc → Nat
  | .lit _ => 1
  | .arg _ _ => 1
  | .balance _ => 1
  | .observe _ => 1
  | .timestamp _ => 1
  | .now => 1
  | .unary _ x => exprDepth x + 1
  | .binary _ x y => Nat.max (exprDepth x) (exprDepth y) + 1
  | .ite c t e => Nat.max (exprDepth c) (Nat.max (exprDepth t) (exprDepth e)) + 1

/-- Constructor-sensitive JSON nesting depth for expressions. -/
def exprMaxStackDepth : ExprEnc → Nat
  | .lit _ => 2
  | .arg _ _ => 2
  | .balance _ => 3
  | .observe _ => 3
  | .timestamp _ => 2
  | .now => 1
  | .unary _ x => 1 + exprMaxStackDepth x
  | .binary _ x y => 1 + Nat.max (exprMaxStackDepth x) (exprMaxStackDepth y)
  | .ite c y n => 1 + Nat.max (exprMaxStackDepth c) (Nat.max (exprMaxStackDepth y) (exprMaxStackDepth n))

/-- Expression depth bound: constructor-sensitive depth does not exceed 52,
    ensuring whole-document JSON stack depth ≤ 64 (10 outer levels + 52 ≤ 62 < 64). -/
def ExprDepthBounded (e : ExprEnc) : Prop :=
  exprMaxStackDepth e ≤ 52 ∧ exprDepth e ≤ 55

/-- Template depth bound: guard AND all delta amount expressions satisfy ExprDepthBounded. -/
def TemplateDepthBounded (t : TemplateEnc) : Prop :=
  ExprDepthBounded t.guard ∧
  (∀ d ∈ t.deltas, ExprDepthBounded d.amount) ∧
  (∀ s ∈ t.supplyDeltas, ExprDepthBounded s.amount)

/-- Bounded array lengths for typed execute payload matching production parser limits. -/
def TypedPayloadLengthBounds (p : TypedExecutePayloadEnc) : Prop :=
  p.state.cells.length = 32 ∧
  p.registry.entries.length ≤ 4096 ∧
  (∀ e ∈ p.registry.entries, TemplateLengthBounds e.template) ∧
  p.store.entries.length ≤ 4096 ∧
  p.env.entries.length ≤ 4096 ∧
  p.request.arguments.length ≤ 4096 ∧
  p.request.capabilityIds.length ≤ 4096 ∧
  p.request.parties.length ≤ 4096

/-- Length bounds for individual composition steps. -/
def StepLengthBounds (s : StepEnc) : Prop :=
  match s with
  | .invoke inv => inv.inputs.length ≤ 4096 ∧ inv.capabilityIds.length ≤ 4096 ∧ inv.parties.length ≤ 4096
  | _ => True

/-- Bounded array lengths for composition step payload matching production parser limits. -/
def StepPayloadLengthBounds (p : CompositionStepPayloadEnc) : Prop :=
  ConfigLengthBounds p.config ∧
  p.pre.state.cells.length = 32 ∧
  p.pre.capabilities.entries.length ≤ 4096 ∧
  p.boundary.env.entries.length ≤ 4096 ∧
  p.history.length ≤ 4096 ∧
  StepLengthBounds p.step

/-- Bounded array lengths for composition run payload matching production parser limits. -/
def RunPayloadLengthBounds (p : CompositionRunPayloadEnc) : Prop :=
  ConfigLengthBounds p.config ∧
  p.world.state.cells.length = 32 ∧
  p.world.capabilities.entries.length ≤ 4096 ∧
  p.boundaries.length ≤ 4096 ∧
  (∀ b ∈ p.boundaries, b.env.entries.length ≤ 4096) ∧
  p.steps.length ≤ 4096 ∧
  (∀ s ∈ p.steps, StepLengthBounds s)

/-- Depth bounds for typed execute payload. -/
def TypedPayloadDepthBounds (p : TypedExecutePayloadEnc) : Prop :=
  ∀ e ∈ p.registry.entries, TemplateDepthBounded e.template

/-- Depth bounds for composition step payload. -/
def StepPayloadDepthBounds (p : CompositionStepPayloadEnc) : Prop :=
  ∀ e ∈ p.config.registry.entries, TemplateDepthBounded e.template

/-- Depth bounds for composition run payload. -/
def RunPayloadDepthBounds (p : CompositionRunPayloadEnc) : Prop :=
  ∀ e ∈ p.config.registry.entries, TemplateDepthBounded e.template

/-- Supported IR predicate: schema version 1, modes, complete 32-cell layout, non-negative amounts,
    supported step constructors, unique store and registry entries, parser resource bounds,
    and serialized byte bound (≤ 1 MiB). -/
def SupportedIR (ir : DecodedIR) : Prop :=
  SerializedByteBound ir ∧
  match ir with
  | .execution (.typed env payload) =>
    env.schema_version = 1 ∧
    env.mode = "typed-execute" ∧
    StandardTypesEnum env.types ∧
    payload.state.cells.length = 32 ∧
    payload.state.cells.map (fun c ↦ (c.domain, c.party, c.asset)) = standard32CellKeys ∧
    payload.state.cells.all (fun c ↦ c.amount.den > 0 ∧ c.amount.num ≥ 0) = true ∧
    StoreCanonical payload.store ∧
    (payload.registry.entries.map (·.id)).Nodup ∧
    EnvelopeLengthBounds env ∧
    TypedPayloadLengthBounds payload ∧
    TypedPayloadDepthBounds payload
  | .execution (.step env payload) =>
    env.schema_version = 1 ∧
    env.mode = "composition-step" ∧
    StandardTypesEnum env.types ∧
    (match payload.step with | .unsupported _ => False | _ => True) ∧
    payload.pre.state.cells.length = 32 ∧
    payload.pre.state.cells.map (fun c ↦ (c.domain, c.party, c.asset)) = standard32CellKeys ∧
    payload.pre.state.cells.all (fun c ↦ c.amount.den > 0 ∧ c.amount.num ≥ 0) = true ∧
    StoreCanonical payload.pre.capabilities ∧
    (payload.config.registry.entries.map (·.id)).Nodup ∧
    EnvelopeLengthBounds env ∧
    StepPayloadLengthBounds payload ∧
    StepPayloadDepthBounds payload
  | .execution (.run env payload) =>
    env.schema_version = 1 ∧
    env.mode = "composition-run" ∧
    StandardTypesEnum env.types ∧
    payload.steps.all (fun s ↦ match s with | .unsupported _ => false | _ => true) = true ∧
    payload.world.state.cells.length = 32 ∧
    payload.world.state.cells.map (fun c ↦ (c.domain, c.party, c.asset)) = standard32CellKeys ∧
    payload.world.state.cells.all (fun c ↦ c.amount.den > 0 ∧ c.amount.num ≥ 0) = true ∧
    StoreCanonical payload.world.capabilities ∧
    (payload.config.registry.entries.map (·.id)).Nodup ∧
    EnvelopeLengthBounds env ∧
    RunPayloadLengthBounds payload ∧
    RunPayloadDepthBounds payload
  | .audit _ => False
  | .codec _ => False

/-- Canonical IR predicate: lexicographical source map order, canonical rationals,
    inactive packed-value fields in arguments, expressions, and observations,
    and canonical template/step forms. -/
def CanonicalIR (ir : DecodedIR) : Prop :=
  match ir with
  | .execution (.typed env payload) =>
    SourceMapSorted env.source_map ∧
    ClaimedNextStateCanonical env.claimed_next_state ∧
    payload.state.cells.all (fun c ↦ Int.gcd c.amount.num.natAbs c.amount.den = 1) = true ∧
    (∀ e ∈ payload.registry.entries, TemplateCanonical e.template) ∧
    RequestCanonical payload.request ∧
    EnvironmentCanonical payload.env
  | .execution (.step env payload) =>
    SourceMapSorted env.source_map ∧
    ClaimedNextStateCanonical env.claimed_next_state ∧
    payload.pre.state.cells.all (fun c ↦ Int.gcd c.amount.num.natAbs c.amount.den = 1) = true ∧
    StepCanonical payload.step ∧
    (∀ e ∈ payload.config.registry.entries, TemplateCanonical e.template) ∧
    HistoryCanonical payload.history ∧
    BoundaryCanonical payload.boundary
  | .execution (.run env payload) =>
    SourceMapSorted env.source_map ∧
    ClaimedNextStateCanonical env.claimed_next_state ∧
    payload.world.state.cells.all (fun c ↦ Int.gcd c.amount.num.natAbs c.amount.den = 1) = true ∧
    (∀ s ∈ payload.steps, StepCanonical s) ∧
    (∀ e ∈ payload.config.registry.entries, TemplateCanonical e.template) ∧
    (∀ b ∈ payload.boundaries, BoundaryCanonical b)
  | .audit _ => False
  | .codec _ => False

/-- Structurally admissible canonical IR domain covering the accepted 32-cell execution universe.
    Defined as the conjunction of SupportedIR and CanonicalIR. -/
def StructurallyAdmissibleIR (ir : DecodedIR) : Prop :=
  SupportedIR ir ∧ CanonicalIR ir

/-- Nonempty witness for StructurallyAdmissibleIR: a standard 32-cell zero-initialized state
    with canonical 0/1 rationals, schema version 1, and typed-execute mode. -/
def standard32Cells : List StateCellEnc :=
  let parties : List Party := [.alice, .bob, .vault, .pool]
  let assets : List Asset := [.usd, .share, .collateral, .debt]
  let domains : List Domain := [.main, .other]
  domains.flatMap fun d ↦
    parties.flatMap fun p ↦
      assets.map fun a ↦
        ⟨d, p, a, ⟨0, 1⟩⟩

def canonicalWitnessIR : DecodedIR :=
  .execution (.typed
    ⟨1, "typed-execute", ⟨"a12b7cac05a818cc8d35c2ca440b7170a2807e92", "leanprover/lean4:v4.33.0-rc2",
      "51e6992efd06126df61a496bebf8f49482a4e129", "", none, none⟩,
      ["DefiKernel.Certificates", "DefiKernel.Typed", "DefiKernel.Composition"],
      ⟨[.alice, .bob, .vault, .pool], [.usd, .share, .collateral, .debt], [.main, .other]⟩,
      ["environment-authenticity"], [], [], [], [], none, false, false⟩
    ⟨⟨[]⟩, ⟨[]⟩, ⟨.alice, .main⟩, ⟨[]⟩, 100, ⟨0, [.alice], [], [], some .alice⟩, ⟨standard32Cells⟩⟩)

set_option maxRecDepth 100000 in
/-- Theorem: StructurallyAdmissibleIR is nonempty. -/
theorem structurallyAdmissible_nonempty : StructurallyAdmissibleIR canonicalWitnessIR := by
  dsimp [StructurallyAdmissibleIR, SupportedIR, CanonicalIR, canonicalWitnessIR, StandardTypesEnum,
         SourceMapSorted, ClaimedNextStateCanonical, standard32Cells, standard32CellKeys,
         isSortedStrictAscending, StoreCanonical, RequestCanonical, EnvironmentCanonical,
         WorldCanonical, StateCellsMatchStandard32, EnvelopeLengthBounds, TypedPayloadLengthBounds,
         TypedPayloadDepthBounds, TemplateLengthBounds, TemplateDepthBounded, SerializedByteBound]
  refine ⟨⟨by decide, ⟨rfl, rfl, ⟨rfl, rfl, rfl⟩, rfl, rfl, by decide, List.nodup_nil, List.nodup_nil, by decide, ?_, ?_⟩⟩, ?_⟩
  · refine ⟨rfl, by decide, ?_, by decide, by decide, by decide, by decide, by decide⟩
    intro _ h; contradiction
  · intro _ h; contradiction
  · refine ⟨rfl, trivial, by decide, ?_, ?_, ?_⟩
    · intro _ h; contradiction
    · intro _ h; contradiction
    · intro _ h; contradiction

/-- Theorem: canonical byte decoding guarantees re-encoding identity (T-canonical-bytes). -/
theorem decodeBytes_encode_canonical (raw : ByteArray) (ir : DecodedIR)
    (h : decodeBytes raw = .ok ir) : encodeModule ir = raw := by
  unfold decodeBytes at h
  dsimp [bind, Except.bind, pure, Except.pure] at h
  split at h
  · contradiction
  · split at h
    · split at h
      · contradiction
      · split at h
        · contradiction
        · split at h
          · rename_i h_eq
            injection h with h_sub
            subst h_sub
            exact h_eq
          · contradiction
    · contradiction

/-- Theorem: any successfully decoded IR roundtrips through encodeModule and decodeBytes. -/
theorem decode_encode_roundtrip_of_decode (raw : ByteArray) (ir : DecodedIR)
    (h : decodeBytes raw = .ok ir) :
    decodeBytes (encodeModule ir) = .ok ir := by
  have h_eq := decodeBytes_encode_canonical raw ir h
  rw [h_eq]
  exact h

/-- Statement of universal roundtrip obligation (RC01 / P20 open obligation).
    Quantifies over every structurally admissible canonical IR. -/
def EncodeDecodeRoundtripStatement : Prop :=
  ∀ (ir : DecodedIR), StructurallyAdmissibleIR ir → decodeBytes (encodeModule ir) = .ok ir

/-- Statement of canonical bytes obligation (T-canonical-bytes). -/
def DecodeEncodeCanonicalBytesStatement : Prop :=
  ∀ raw ir, decodeBytes raw = .ok ir → StructurallyAdmissibleIR ir → encodeModule ir = raw

/-- Discharges T-canonical-bytes: universal canonical bytes theorem proven in the Lean kernel. -/
theorem decode_encode_canonical_bytes : DecodeEncodeCanonicalBytesStatement := by
  intro raw ir h _
  exact decodeBytes_encode_canonical raw ir h

/-- Refused decode returns no kernel object (S39-S40, S78). -/
theorem decode_error_no_kernel (raw : ByteArray) (e : DecodeFailure)
    (h : decodeBytes raw = .error e) (h_not_res : ∀ lim, e ≠ .resourceLimit lim) :
    checkBytes raw = .codec (.malformed e) := by
  dsimp [checkBytes]
  rw [h]
  cases e with
  | resourceLimit lim =>
    exfalso
    exact h_not_res lim rfl
  | emptyDocument => rfl
  | lexicalScientificOrFloat => rfl
  | notJsonObject => rfl
  | duplicateKey _ => rfl
  | noncanonicalWhitespace => rfl
  | schemaVersion => rfl
  | missingField _ => rfl
  | jsonType _ => rfl
  | unknownIdentifier _ => rfl
  | uniqueness _ => rfl
  | illegalRational _ => rfl
  | stateNonneg => rfl
  | unknownExecutableField _ => rfl
  | unsupportedForm _ => rfl

/-- Resource limit decode refusal maps to blocked codec result. -/
theorem decode_error_resource_limit (raw : ByteArray) (lim : String)
    (h : decodeBytes raw = .error (.resourceLimit lim)) :
    checkBytes raw = .codec (.blocked lim) := by
  dsimp [checkBytes]
  rw [h]

/-- Any decode error produces a CodecResult outcome, guaranteeing no kernel entrypoint is invoked. -/
theorem checkBytes_no_kernel_on_error (raw : ByteArray) (e : DecodeFailure)
    (h : decodeBytes raw = .error e) :
    ∃ (c : CodecResult), checkBytes raw = .codec c := by
  dsimp [checkBytes]
  rw [h]
  cases e with
  | resourceLimit lim => exact ⟨.blocked lim, rfl⟩
  | emptyDocument => exact ⟨.malformed .emptyDocument, rfl⟩
  | lexicalScientificOrFloat => exact ⟨.malformed .lexicalScientificOrFloat, rfl⟩
  | notJsonObject => exact ⟨.malformed .notJsonObject, rfl⟩
  | duplicateKey k => exact ⟨.malformed (.duplicateKey k), rfl⟩
  | noncanonicalWhitespace => exact ⟨.malformed .noncanonicalWhitespace, rfl⟩
  | schemaVersion => exact ⟨.malformed .schemaVersion, rfl⟩
  | missingField m => exact ⟨.malformed (.missingField m), rfl⟩
  | jsonType p => exact ⟨.malformed (.jsonType p), rfl⟩
  | unknownIdentifier u => exact ⟨.malformed (.unknownIdentifier u), rfl⟩
  | uniqueness k => exact ⟨.malformed (.uniqueness k), rfl⟩
  | illegalRational r => exact ⟨.malformed (.illegalRational r), rfl⟩
  | stateNonneg => exact ⟨.malformed .stateNonneg, rfl⟩
  | unknownExecutableField f => exact ⟨.malformed (.unknownExecutableField f), rfl⟩
  | unsupportedForm r => exact ⟨.malformed (DecodeFailure.unsupportedForm r), rfl⟩

/-- Successful decode routes directly to checkIR. -/
theorem checkBytes_ok (raw : ByteArray) (ir : DecodedIR)
    (h : decodeBytes raw = .ok ir) :
    checkBytes raw = checkIR ir := by
  dsimp [checkBytes]
  rw [h]

/-- CheckBytes for typed execution payload routes directly to checkTyped. -/
theorem checkBytes_typed_correspondence (raw : ByteArray) (env : EnvelopeEnc) (payload : TypedExecutePayloadEnc)
    (h_dec : decodeBytes raw = .ok (.execution (.typed env payload))) :
    checkBytes raw = .execution (checkTyped env payload) := by
  have h := checkBytes_ok raw (.execution (.typed env payload)) h_dec
  rw [h]
  rfl

/-- CheckBytes for composition step payload routes directly to checkStep. -/
theorem checkBytes_step_correspondence (raw : ByteArray) (env : EnvelopeEnc) (payload : CompositionStepPayloadEnc)
    (h_dec : decodeBytes raw = .ok (.execution (.step env payload))) :
    checkBytes raw = .execution (checkStep env payload) := by
  have h := checkBytes_ok raw (.execution (.step env payload)) h_dec
  rw [h]
  rfl

/-- CheckBytes for composition run payload routes directly to checkRun. -/
theorem checkBytes_run_correspondence (raw : ByteArray) (env : EnvelopeEnc) (payload : CompositionRunPayloadEnc)
    (h_dec : decodeBytes raw = .ok (.execution (.run env payload))) :
    checkBytes raw = .execution (checkRun env payload) := by
  have h := checkBytes_ok raw (.execution (.run env payload)) h_dec
  rw [h]
  rfl

/-- Canonical rational decoding theorem: canonical numerator/denominator pair decodes to RatEnc. -/
theorem rational_decode_canonical (num : Int) (den : Nat) (h_den : den ≠ 0) (h_gcd : Int.gcd num.natAbs den = 1) :
    decodeRational num den = .ok ⟨num, den⟩ := by
  unfold decodeRational
  split
  · contradiction
  · split
    · rename_i h_noncan
      have h1 : ¬ (Int.gcd num.natAbs den ≠ 1) := by
        intro h_contra
        exact h_contra h_gcd
      contradiction
    · rfl

/-- Exact correspondence between RatEnc and ℚ components. -/
theorem rat_fromRat_num_den (q : ℚ) :
    (RatEnc.fromRat q).num = q.num ∧ (RatEnc.fromRat q).den = q.den :=
  ⟨rfl, rfl⟩

/-- Rational encode/decode roundtrip: any canonical rational roundtrips via decodeRational. -/
theorem rational_roundtrip (r : RatEnc) (h_den : r.den ≠ 0) (h_gcd : Int.gcd r.num.natAbs r.den = 1) :
    decodeRational r.num r.den = .ok r :=
  rational_decode_canonical r.num r.den h_den h_gcd

/-- Party decode roundtrip. -/
theorem decodeParty_encodeParty (p : Party) :
    decodeParty (.str (match p with | .alice => "alice" | .bob => "bob" | .vault => "vault" | .pool => "pool")) = .ok p := by
  cases p <;> rfl

/-- Asset decode roundtrip. -/
theorem decodeAsset_encodeAsset (a : Asset) :
    decodeAsset (.str (match a with | .usd => "usd" | .share => "share" | .collateral => "collateral" | .debt => "debt")) = .ok a := by
  cases a <;> rfl

/-- Domain decode roundtrip. -/
theorem decodeDomain_encodeDomain (d : Domain) :
    decodeDomain (.str (match d with | .main => "main" | .other => "other")) = .ok d := by
  cases d <;> rfl

/-- Right decode roundtrip for invoke. -/
theorem decodeRight_invoke :
    decodeRight (Lean.Json.mkObj [("tag", Lean.Json.str "invoke")]) = .ok .invoke := by
  rfl

/-- PartyRef decode roundtrip for caller. -/
theorem decodePartyRef_caller :
    decodePartyRef (Lean.Json.mkObj [("tag", Lean.Json.str "caller")]) = .ok .caller := by
  rfl

/-- PartyRef decode roundtrip for literal party. -/
theorem decodePartyRef_literal (p : Party) :
    decodePartyRef (Lean.Json.mkObj [("tag", Lean.Json.str "literal"), ("party", match p with
      | .alice => Lean.Json.str "alice"
      | .bob => Lean.Json.str "bob"
      | .vault => Lean.Json.str "vault"
      | .pool => Lean.Json.str "pool")]) = .ok (.literal p) := by
  cases p <;> rfl

/-- NumericUnit decode roundtrip for scalar. -/
theorem decodeNumericUnit_scalar :
    decodeNumericUnit (Lean.Json.mkObj [("tag", Lean.Json.str "scalar")]) = .ok .scalar := by
  rfl

/-- NumericUnit decode roundtrip for amount. -/
theorem decodeNumericUnit_amount (a : Asset) :
    decodeNumericUnit (Lean.Json.mkObj [("tag", Lean.Json.str "amount"), ("asset", match a with
      | .usd => Lean.Json.str "usd"
      | .share => Lean.Json.str "share"
      | .collateral => Lean.Json.str "collateral"
      | .debt => Lean.Json.str "debt")]) = .ok (.amount a) := by
  cases a <;> rfl

/-- Unit decode roundtrip for bool. -/
theorem decodeUnit_bool :
    decodeUnit (Lean.Json.mkObj [("tag", Lean.Json.str "bool")]) = .ok .bool := by
  rfl

/-- Unit decode roundtrip for scalar. -/
theorem decodeUnit_scalar :
    decodeUnit (Lean.Json.mkObj [("tag", Lean.Json.str "scalar")]) = .ok (.numeric .scalar) := by
  rfl

/-- Unit decode roundtrip for amount. -/
theorem decodeUnit_amount (a : Asset) :
    decodeUnit (Lean.Json.mkObj [("tag", Lean.Json.str "amount"), ("asset", match a with
      | .usd => Lean.Json.str "usd"
      | .share => Lean.Json.str "share"
      | .collateral => Lean.Json.str "collateral"
      | .debt => Lean.Json.str "debt")]) = .ok (.numeric (.amount a)) := by
  cases a <;> rfl

/-- Registry decode roundtrip for empty registry. -/
theorem decodeRegistry_empty :
    decodeRegistry (Lean.Json.mkObj [("entries", Lean.Json.arr #[])]) = .ok ⟨[]⟩ := by
  rfl

/-- Store decode roundtrip for empty store. -/
theorem decodeStore_empty :
    decodeStore (Lean.Json.mkObj [("entries", Lean.Json.arr #[])]) = .ok ⟨[]⟩ := by
  rfl

/-- Right decode roundtrip for debit. -/
theorem decodeRight_debit (c : CellEnc) :
    decodeRight (Lean.Json.mkObj [("tag", Lean.Json.str "debit"), ("cell", Lean.Json.mkObj [
      ("domain", Lean.Json.str (match c.domain with | .main => "main" | .other => "other")),
      ("party", Lean.Json.str (match c.party with | .alice => "alice" | .bob => "bob" | .vault => "vault" | .pool => "pool")),
      ("asset", Lean.Json.str (match c.asset with | .usd => "usd" | .share => "share" | .collateral => "collateral" | .debt => "debt"))
    ])]) = .ok (.debit c) := by
  cases c with
  | mk d p a => cases d <;> cases p <;> cases a <;> rfl

/-- Right decode roundtrip for changeSupply. -/
theorem decodeRight_changeSupply (d : Domain) (a : Asset) :
    decodeRight (Lean.Json.mkObj [
      ("tag", Lean.Json.str "changeSupply"),
      ("domain", Lean.Json.str (match d with | .main => "main" | .other => "other")),
      ("asset", Lean.Json.str (match a with | .usd => "usd" | .share => "share" | .collateral => "collateral" | .debt => "debt"))
    ]) = .ok (.changeSupply d a) := by
  cases d <;> cases a <;> rfl

/-- PartyRef decode roundtrip for argument index. -/
theorem decodePartyRef_argument (idx : Nat) :
    decodePartyRef (Lean.Json.mkObj [("tag", Lean.Json.str "argument"), ("index", Lean.Json.num idx)]) = .ok (.argument idx) := by
  dsimp [decodePartyRef]
  rfl

/-- NumericUnit decode roundtrip for price. -/
theorem decodeNumericUnit_price (b q : Asset) :
    decodeNumericUnit (Lean.Json.mkObj [
      ("tag", Lean.Json.str "price"),
      ("base", Lean.Json.str (match b with | .usd => "usd" | .share => "share" | .collateral => "collateral" | .debt => "debt")),
      ("quote", Lean.Json.str (match q with | .usd => "usd" | .share => "share" | .collateral => "collateral" | .debt => "debt"))
    ]) = .ok (.price b q) := by
  cases b <;> cases q <;> rfl

/-- PackedValue decode roundtrip for bool values. -/
theorem decodePackedValue_bool (b : Bool) :
    decodePackedValue (Lean.Json.mkObj [
      ("unit", Lean.Json.mkObj [("tag", Lean.Json.str "bool")]),
      ("value", Lean.Json.bool b)
    ]) = .ok ⟨.bool, 0, b⟩ := by
  cases b <;> rfl

/-- PackedValue decode roundtrip for canonical boolean packed values. -/
theorem decodePackedValue_canonical_bool (v : PackedValueEnc) (h_u : v.unit = .bool) (h_can : PackedValueCanonical v) :
    decodePackedValue (Lean.Json.mkObj [
      ("unit", Lean.Json.mkObj [("tag", Lean.Json.str "bool")]),
      ("value", Lean.Json.bool v.valBool)
    ]) = .ok v := by
  have h_rat : v.valRat = 0 := h_can.1 h_u
  have h_eq : v = ⟨.bool, 0, v.valBool⟩ := by
    cases v
    dsimp at h_u h_rat
    subst h_u h_rat
    rfl
  rw [h_eq]
  cases v.valBool <;> rfl

/-- ObservationKey decode roundtrip for arbitrary domain and id. -/
theorem decodeObservationKey_roundtrip (k : ObservationKeyEnc) :
    decodeObservationKey (Lean.Json.mkObj [
      ("domain", Lean.Json.str (match k.domain with | .main => "main" | .other => "other")),
      ("id", Lean.Json.num k.id)
    ]) = .ok k := by
  cases k with
  | mk d id =>
    cases d <;> (dsimp [decodeObservationKey, decodeDomain, Lean.Json.mkObj]; rfl)

/-- EnvRead decode roundtrip for currentTime. -/
theorem decodeEnvRead_currentTime :
    decodeEnvRead (Lean.Json.mkObj [("tag", Lean.Json.str "currentTime")]) = .ok .currentTime := by
  rfl

/-- UnaryOp decode roundtrip for not. -/
theorem decodeUnaryOp_not :
    decodeUnaryOp (Lean.Json.mkObj [("tag", Lean.Json.str "not")]) = .ok .not := by
  rfl

/-- UnaryOp decode roundtrip for neg. -/
theorem decodeUnaryOp_neg (nu : NumericUnitEnc) :
    decodeUnaryOp (Lean.Json.mkObj [
      ("tag", Lean.Json.str "neg"),
      ("numeric", match nu with
        | .amount a => Lean.Json.mkObj [("tag", Lean.Json.str "amount"), ("asset", Lean.Json.str (match a with | .usd => "usd" | .share => "share" | .collateral => "collateral" | .debt => "debt"))]
        | .price b q => Lean.Json.mkObj [("tag", Lean.Json.str "price"), ("base", Lean.Json.str (match b with | .usd => "usd" | .share => "share" | .collateral => "collateral" | .debt => "debt")), ("quote", Lean.Json.str (match q with | .usd => "usd" | .share => "share" | .collateral => "collateral" | .debt => "debt"))]
        | .scalar => Lean.Json.mkObj [("tag", Lean.Json.str "scalar")])
    ]) = .ok (.neg nu) := by
  cases nu with
  | amount a => cases a <;> rfl
  | price b q => cases b <;> cases q <;> rfl
  | scalar => rfl

/-- BinaryOp decode roundtrip for and. -/
theorem decodeBinaryOp_and :
    decodeBinaryOp (Lean.Json.mkObj [("tag", Lean.Json.str "and")]) = .ok .and := by
  rfl

/-- BinaryOp decode roundtrip for or. -/
theorem decodeBinaryOp_or :
    decodeBinaryOp (Lean.Json.mkObj [("tag", Lean.Json.str "or")]) = .ok .or := by
  rfl

/-- CellRef decode roundtrip for literal owner. -/
theorem decodeCellRef_roundtrip (d : Domain) (p : Party) :
    decodeCellRef (Lean.Json.mkObj [
      ("domain", Lean.Json.str (match d with | .main => "main" | .other => "other")),
      ("owner", Lean.Json.mkObj [("tag", Lean.Json.str "literal"), ("party", Lean.Json.str (match p with | .alice => "alice" | .bob => "bob" | .vault => "vault" | .pool => "pool"))])
    ]) = .ok ⟨d, .literal p⟩ := by
  cases d <;> cases p <;> rfl

/-- Cell decode roundtrip across the full domain-party-asset space. -/
theorem decodeCell_roundtrip (c : CellEnc) :
    decodeCell (Lean.Json.mkObj [
      ("domain", Lean.Json.str (match c.domain with | .main => "main" | .other => "other")),
      ("party", Lean.Json.str (match c.party with | .alice => "alice" | .bob => "bob" | .vault => "vault" | .pool => "pool")),
      ("asset", Lean.Json.str (match c.asset with | .usd => "usd" | .share => "share" | .collateral => "collateral" | .debt => "debt"))
    ]) = .ok c := by
  cases c with
  | mk d p a => cases d <;> cases p <;> cases a <;> rfl

/-- Context decode roundtrip. -/
theorem decodeContext_roundtrip (c : ContextEnc) :
    decodeContext (Lean.Json.mkObj [
      ("principal", Lean.Json.str (match c.principal with | .alice => "alice" | .bob => "bob" | .vault => "vault" | .pool => "pool")),
      ("domain", Lean.Json.str (match c.domain with | .main => "main" | .other => "other"))
    ]) = .ok c := by
  cases c with
  | mk p d => cases p <;> cases d <;> (dsimp [decodeContext, decodeParty, decodeDomain, Lean.Json.mkObj]; rfl)

/-- DomainAdmin decode roundtrip. -/
theorem decodeDomainAdmin_roundtrip (d : DomainAdminEnc) :
    decodeDomainAdmin (Lean.Json.mkObj [
      ("domain", Lean.Json.str (match d.domain with | .main => "main" | .other => "other")),
      ("party", Lean.Json.str (match d.party with | .alice => "alice" | .bob => "bob" | .vault => "vault" | .pool => "pool"))
    ]) = .ok d := by
  cases d with
  | mk dm p => cases dm <;> cases p <;> (dsimp [decodeDomainAdmin, decodeDomain, decodeParty, Lean.Json.mkObj]; rfl)

/-- QualifiedPort decode roundtrip. -/
theorem decodeQualifiedPort_roundtrip (p : QualifiedPortEnc) :
    decodeQualifiedPort (Lean.Json.mkObj [("component", Lean.Json.num p.component), ("port", Lean.Json.num p.port)]) = .ok p := by
  cases p with
  | mk c port => dsimp [decodeQualifiedPort, Lean.Json.mkObj]; rfl

/-- Step decode roundtrip for revoke. -/
theorem decodeStep_revoke (id : Nat) :
    decodeStep (Lean.Json.mkObj [("tag", Lean.Json.str "revoke"), ("id", Lean.Json.num id)]) = .ok (.revoke id) := by
  dsimp [decodeStep, Lean.Json.mkObj]
  rfl

/-- ExprFuel decode roundtrip for now constructor. -/
theorem decodeExprFuel_now (fuel : Nat) :
    decodeExprFuel (fuel + 1) (Lean.Json.mkObj [("tag", Lean.Json.str "now")]) = .ok .now := by
  rfl

/-- ExprFuel decode roundtrip for argument constructor. -/
theorem decodeExprFuel_arg_bool (fuel : Nat) (idx : Nat) :
    decodeExprFuel (fuel + 1) (Lean.Json.mkObj [
      ("tag", Lean.Json.str "arg"),
      ("index", Lean.Json.num idx),
      ("unit", Lean.Json.mkObj [("tag", Lean.Json.str "bool")])
    ]) = .ok (.arg idx .bool) := by
  rfl

/-- ExprFuel decode roundtrip for boolean literal. -/
theorem decodeExprFuel_lit_bool (fuel : Nat) (b : Bool) :
    decodeExprFuel (fuel + 1) (Lean.Json.mkObj [
      ("tag", Lean.Json.str "lit"),
      ("unit", Lean.Json.mkObj [("tag", Lean.Json.str "bool")]),
      ("value", Lean.Json.bool b)
    ]) = .ok (.lit ⟨.bool, 0, b⟩) := by
  cases b <;> rfl

/-- Production decodeExpr roundtrip for now constructor. -/
theorem decodeExpr_now :
    decodeExpr (Lean.Json.mkObj [("tag", Lean.Json.str "now")]) = .ok .now := by
  rfl

/-- Production decodeExpr roundtrip for boolean literal. -/
theorem decodeExpr_lit_bool (b : Bool) :
    decodeExpr (Lean.Json.mkObj [
      ("tag", Lean.Json.str "lit"),
      ("unit", Lean.Json.mkObj [("tag", Lean.Json.str "bool")]),
      ("value", Lean.Json.bool b)
    ]) = .ok (.lit ⟨.bool, 0, b⟩) := by
  cases b <;> rfl

/-- ObservationRef decode roundtrip for all domains and units. -/
theorem decodeObservationRef_roundtrip (d : Domain) (id : Nat) (u : UnitEnc) :
    decodeObservationRef (Lean.Json.mkObj [
      ("key", Lean.Json.mkObj [
        ("domain", Lean.Json.str (match d with | .main => "main" | .other => "other")),
        ("id", Lean.Json.num id)
      ]),
      ("unit", match u with
        | .bool => Lean.Json.mkObj [("tag", Lean.Json.str "bool")]
        | .numeric .scalar => Lean.Json.mkObj [("tag", Lean.Json.str "scalar")]
        | .numeric (.amount a) => Lean.Json.mkObj [
            ("tag", Lean.Json.str "amount"),
            ("asset", Lean.Json.str (match a with | .usd => "usd" | .share => "share" | .collateral => "collateral" | .debt => "debt"))
          ]
        | .numeric (.price b q) => Lean.Json.mkObj [
            ("tag", Lean.Json.str "price"),
            ("base", Lean.Json.str (match b with | .usd => "usd" | .share => "share" | .collateral => "collateral" | .debt => "debt")),
            ("quote", Lean.Json.str (match q with | .usd => "usd" | .share => "share" | .collateral => "collateral" | .debt => "debt"))
          ])
    ]) = .ok ⟨⟨d, id⟩, u⟩ := by
  cases d
  · cases u with
    | bool => rfl
    | numeric nu =>
      cases nu with
      | scalar => rfl
      | amount a => cases a <;> rfl
      | price b q => cases b <;> cases q <;> rfl
  · cases u with
    | bool => rfl
    | numeric nu =>
      cases nu with
      | scalar => rfl
      | amount a => cases a <;> rfl
      | price b q => cases b <;> cases q <;> rfl

/-- Canonical zero rational decoding roundtrip. -/
theorem decodeRat_zero :
    decodeRat (Lean.Json.mkObj [("num", Lean.Json.num (0 : Int)), ("den", Lean.Json.num (1 : Nat))]) = .ok ⟨0, 1⟩ := by
  rfl

/-- PackedValue decode roundtrip for scalar zero value. -/
theorem decodePackedValue_scalar_zero :
    decodePackedValue (Lean.Json.mkObj [
      ("unit", Lean.Json.mkObj [("tag", Lean.Json.str "scalar")]),
      ("value", Lean.Json.mkObj [("num", Lean.Json.num (0 : Int)), ("den", Lean.Json.num (1 : Nat))])
    ]) = .ok ⟨.numeric .scalar, 0, false⟩ := by
  rfl

/-- PackedValue decode roundtrip for amount zero value. -/
theorem decodePackedValue_amount_zero (a : Asset) :
    decodePackedValue (Lean.Json.mkObj [
      ("unit", Lean.Json.mkObj [
        ("tag", Lean.Json.str "amount"),
        ("asset", Lean.Json.str (match a with | .usd => "usd" | .share => "share" | .collateral => "collateral" | .debt => "debt"))
      ]),
      ("value", Lean.Json.mkObj [("num", Lean.Json.num (0 : Int)), ("den", Lean.Json.num (1 : Nat))])
    ]) = .ok ⟨.numeric (.amount a), 0, false⟩ := by
  cases a <;> rfl

/-- BinaryOp decode roundtrip for addition. -/
theorem decodeBinaryOp_add (nu : NumericUnitEnc) :
    decodeBinaryOp (Lean.Json.mkObj [
      ("tag", Lean.Json.str "add"),
      ("numeric", match nu with
        | .scalar => Lean.Json.mkObj [("tag", Lean.Json.str "scalar")]
        | .amount a => Lean.Json.mkObj [
            ("tag", Lean.Json.str "amount"),
            ("asset", Lean.Json.str (match a with | .usd => "usd" | .share => "share" | .collateral => "collateral" | .debt => "debt"))
          ]
        | .price b q => Lean.Json.mkObj [
            ("tag", Lean.Json.str "price"),
            ("base", Lean.Json.str (match b with | .usd => "usd" | .share => "share" | .collateral => "collateral" | .debt => "debt")),
            ("quote", Lean.Json.str (match q with | .usd => "usd" | .share => "share" | .collateral => "collateral" | .debt => "debt"))
          ])
    ]) = .ok (.add nu) := by
  cases nu with
  | scalar => rfl
  | amount a => cases a <;> rfl
  | price b q => cases b <;> cases q <;> rfl

/-- BinaryOp decode roundtrip for currency conversion. -/
theorem decodeBinaryOp_convert (b q : Asset) :
    decodeBinaryOp (Lean.Json.mkObj [
      ("tag", Lean.Json.str "convert"),
      ("base", Lean.Json.str (match b with | .usd => "usd" | .share => "share" | .collateral => "collateral" | .debt => "debt")),
      ("quote", Lean.Json.str (match q with | .usd => "usd" | .share => "share" | .collateral => "collateral" | .debt => "debt"))
    ]) = .ok (.convert b q) := by
  cases b <;> cases q <;> rfl

/-- BinaryOp decode roundtrip for equality. -/
theorem decodeBinaryOp_eq (u : UnitEnc) :
    decodeBinaryOp (Lean.Json.mkObj [
      ("tag", Lean.Json.str "eq"),
      ("unit", match u with
        | .bool => Lean.Json.mkObj [("tag", Lean.Json.str "bool")]
        | .numeric .scalar => Lean.Json.mkObj [("tag", Lean.Json.str "scalar")]
        | .numeric (.amount a) => Lean.Json.mkObj [
            ("tag", Lean.Json.str "amount"),
            ("asset", Lean.Json.str (match a with | .usd => "usd" | .share => "share" | .collateral => "collateral" | .debt => "debt"))
          ]
        | .numeric (.price b q) => Lean.Json.mkObj [
            ("tag", Lean.Json.str "price"),
            ("base", Lean.Json.str (match b with | .usd => "usd" | .share => "share" | .collateral => "collateral" | .debt => "debt")),
            ("quote", Lean.Json.str (match q with | .usd => "usd" | .share => "share" | .collateral => "collateral" | .debt => "debt"))
          ])
    ]) = .ok (.eq u) := by
  cases u with
  | bool => rfl
  | numeric nu =>
    cases nu with
    | scalar => rfl
    | amount a => cases a <;> rfl
    | price b q => cases b <;> cases q <;> rfl

/-- Step decode roundtrip for grant issuance. -/
theorem decodeStep_issue (h : Party) (d : Domain) (op : Nat) :
    decodeStep (Lean.Json.mkObj [
      ("tag", Lean.Json.str "issue"),
      ("grant", Lean.Json.mkObj [
        ("holder", Lean.Json.str (match h with | .alice => "alice" | .bob => "bob" | .vault => "vault" | .pool => "pool")),
        ("domain", Lean.Json.str (match d with | .main => "main" | .other => "other")),
        ("operation", Lean.Json.num op),
        ("right", Lean.Json.mkObj [("tag", Lean.Json.str "invoke")])
      ])
    ]) = .ok (.issue ⟨h, d, op, .invoke⟩) := by
  cases h <;> cases d <;> rfl

/-- PackedCellRef decode roundtrip. -/
theorem decodePackedCellRef_roundtrip (a : Asset) (d : Domain) (p : Party) :
    decodePackedCellRef (Lean.Json.mkObj [
      ("asset", Lean.Json.str (match a with | .usd => "usd" | .share => "share" | .collateral => "collateral" | .debt => "debt")),
      ("cell", Lean.Json.mkObj [
        ("domain", Lean.Json.str (match d with | .main => "main" | .other => "other")),
        ("owner", Lean.Json.mkObj [("tag", Lean.Json.str "literal"), ("party", Lean.Json.str (match p with | .alice => "alice" | .bob => "bob" | .vault => "vault" | .pool => "pool"))])
      ])
    ]) = .ok ⟨a, ⟨d, .literal p⟩⟩ := by
  cases a <;> cases d <;> cases p <;> rfl

/-- EnvRead decode roundtrip for observation read. -/
theorem decodeEnvRead_observation (d : Domain) (id : Nat) :
    decodeEnvRead (Lean.Json.mkObj [
      ("tag", Lean.Json.str "observation"),
      ("key", Lean.Json.mkObj [
        ("domain", Lean.Json.str (match d with | .main => "main" | .other => "other")),
        ("id", Lean.Json.num id)
      ])
    ]) = .ok (.observation ⟨d, id⟩) := by
  cases d <;> rfl

/-- SourcePin decode roundtrip. -/
theorem decodeSourcePin_roundtrip (git toolchain mathlib checker : String) :
    decodeSourcePin (Lean.Json.mkObj [
      ("git", Lean.Json.str git),
      ("lean_toolchain", Lean.Json.str toolchain),
      ("mathlib_rev", Lean.Json.str mathlib),
      ("checker_candidate", Lean.Json.str checker)
    ]) = .ok ⟨git, toolchain, mathlib, checker, none, none⟩ := by
  rfl

/-- Grant decode roundtrip. -/
theorem decodeGrant_roundtrip (h : Party) (d : Domain) (op : Nat) :
    decodeGrant (Lean.Json.mkObj [
      ("holder", Lean.Json.str (match h with | .alice => "alice" | .bob => "bob" | .vault => "vault" | .pool => "pool")),
      ("domain", Lean.Json.str (match d with | .main => "main" | .other => "other")),
      ("operation", Lean.Json.num op),
      ("right", Lean.Json.mkObj [("tag", Lean.Json.str "invoke")])
    ]) = .ok ⟨h, d, op, .invoke⟩ := by
  cases h <;> cases d <;> rfl

/-- TypesEnum decode roundtrip for canonical universe. -/
theorem decodeTypesEnum_roundtrip :
    decodeTypesEnum (Lean.Json.mkObj [
      ("parties", Lean.Json.arr #[Lean.Json.str "alice", Lean.Json.str "bob", Lean.Json.str "vault", Lean.Json.str "pool"]),
      ("assets", Lean.Json.arr #[Lean.Json.str "usd", Lean.Json.str "share", Lean.Json.str "collateral", Lean.Json.str "debt"]),
      ("domains", Lean.Json.arr #[Lean.Json.str "main", Lean.Json.str "other"])
    ]) = .ok ⟨[.alice, .bob, .vault, .pool], [.usd, .share, .collateral, .debt], [.main, .other]⟩ := by
  rfl

/-- Capability decode roundtrip for invoke. -/
theorem decodeCapability_invoke (h : Party) (d : Domain) (op : Nat) (l : Bool) :
    decodeCapability (Lean.Json.mkObj [
      ("holder", Lean.Json.str (match h with | .alice => "alice" | .bob => "bob" | .vault => "vault" | .pool => "pool")),
      ("domain", Lean.Json.str (match d with | .main => "main" | .other => "other")),
      ("operation", Lean.Json.num op),
      ("right", Lean.Json.mkObj [("tag", Lean.Json.str "invoke")]),
      ("live", Lean.Json.bool l)
    ]) = .ok ⟨h, d, op, .invoke, l⟩ := by
  cases h <;> cases d <;> cases l <;> rfl

/-- ExprFuel decode roundtrip for balance. -/
theorem decodeExprFuel_balance (fuel : Nat) (a : Asset) (d : Domain) (p : Party) :
    decodeExprFuel (fuel + 1) (Lean.Json.mkObj [
      ("tag", Lean.Json.str "balance"),
      ("cell", Lean.Json.mkObj [
        ("asset", Lean.Json.str (match a with | .usd => "usd" | .share => "share" | .collateral => "collateral" | .debt => "debt")),
        ("cell", Lean.Json.mkObj [
          ("domain", Lean.Json.str (match d with | .main => "main" | .other => "other")),
          ("owner", Lean.Json.mkObj [("tag", Lean.Json.str "literal"), ("party", Lean.Json.str (match p with | .alice => "alice" | .bob => "bob" | .vault => "vault" | .pool => "pool"))])
        ])
      ])
    ]) = .ok (.balance ⟨a, ⟨d, .literal p⟩⟩) := by
  cases a <;> cases d <;> cases p <;> rfl

/-- ExprFuel decode roundtrip for timestamp. -/
theorem decodeExprFuel_timestamp (fuel : Nat) (d : Domain) (id : Nat) :
    decodeExprFuel (fuel + 1) (Lean.Json.mkObj [
      ("tag", Lean.Json.str "timestamp"),
      ("key", Lean.Json.mkObj [
        ("domain", Lean.Json.str (match d with | .main => "main" | .other => "other")),
        ("id", Lean.Json.num id)
      ])
    ]) = .ok (.timestamp ⟨d, id⟩) := by
  cases d <;> rfl

/-- ExprFuel decode roundtrip for unary not. -/
theorem decodeExprFuel_unary_not (fuel : Nat) :
    decodeExprFuel (fuel + 2) (Lean.Json.mkObj [
      ("tag", Lean.Json.str "unary"),
      ("op", Lean.Json.mkObj [("tag", Lean.Json.str "not")]),
      ("x", Lean.Json.mkObj [("tag", Lean.Json.str "now")])
    ]) = .ok (.unary .not .now) := by
  rfl

/-- ExprFuel decode roundtrip for binary and. -/
theorem decodeExprFuel_binary_and (fuel : Nat) :
    decodeExprFuel (fuel + 2) (Lean.Json.mkObj [
      ("tag", Lean.Json.str "binary"),
      ("op", Lean.Json.mkObj [("tag", Lean.Json.str "and")]),
      ("x", Lean.Json.mkObj [("tag", Lean.Json.str "now")]),
      ("y", Lean.Json.mkObj [("tag", Lean.Json.str "now")])
    ]) = .ok (.binary .and .now .now) := by
  rfl

/-- ExprFuel decode roundtrip for ite. -/
theorem decodeExprFuel_ite (fuel : Nat) :
    decodeExprFuel (fuel + 2) (Lean.Json.mkObj [
      ("tag", Lean.Json.str "ite"),
      ("condition", Lean.Json.mkObj [("tag", Lean.Json.str "now")]),
      ("yes", Lean.Json.mkObj [("tag", Lean.Json.str "now")]),
      ("no", Lean.Json.mkObj [("tag", Lean.Json.str "now")])
    ]) = .ok (.ite .now .now .now) := by
  rfl

/-- Production decodeExpr roundtrip for balance. -/
theorem decodeExpr_balance (a : Asset) (d : Domain) (p : Party) :
    decodeExpr (Lean.Json.mkObj [
      ("tag", Lean.Json.str "balance"),
      ("cell", Lean.Json.mkObj [
        ("asset", Lean.Json.str (match a with | .usd => "usd" | .share => "share" | .collateral => "collateral" | .debt => "debt")),
        ("cell", Lean.Json.mkObj [
          ("domain", Lean.Json.str (match d with | .main => "main" | .other => "other")),
          ("owner", Lean.Json.mkObj [("tag", Lean.Json.str "literal"), ("party", Lean.Json.str (match p with | .alice => "alice" | .bob => "bob" | .vault => "vault" | .pool => "pool"))])
        ])
      ])
    ]) = .ok (.balance ⟨a, ⟨d, .literal p⟩⟩) := by
  cases a <;> cases d <;> cases p <;> rfl

/-- Production decodeExpr roundtrip for timestamp. -/
theorem decodeExpr_timestamp (d : Domain) (id : Nat) :
    decodeExpr (Lean.Json.mkObj [
      ("tag", Lean.Json.str "timestamp"),
      ("key", Lean.Json.mkObj [
        ("domain", Lean.Json.str (match d with | .main => "main" | .other => "other")),
        ("id", Lean.Json.num id)
      ])
    ]) = .ok (.timestamp ⟨d, id⟩) := by
  cases d <;> rfl

/-- Production decodeExpr roundtrip for unary not. -/
theorem decodeExpr_unary_not :
    decodeExpr (Lean.Json.mkObj [
      ("tag", Lean.Json.str "unary"),
      ("op", Lean.Json.mkObj [("tag", Lean.Json.str "not")]),
      ("x", Lean.Json.mkObj [("tag", Lean.Json.str "now")])
    ]) = .ok (.unary .not .now) := by
  rfl

/-- Production decodeExpr roundtrip for binary and. -/
theorem decodeExpr_binary_and :
    decodeExpr (Lean.Json.mkObj [
      ("tag", Lean.Json.str "binary"),
      ("op", Lean.Json.mkObj [("tag", Lean.Json.str "and")]),
      ("x", Lean.Json.mkObj [("tag", Lean.Json.str "now")]),
      ("y", Lean.Json.mkObj [("tag", Lean.Json.str "now")])
    ]) = .ok (.binary .and .now .now) := by
  rfl

/-- Production decodeExpr roundtrip for ite. -/
theorem decodeExpr_ite :
    decodeExpr (Lean.Json.mkObj [
      ("tag", Lean.Json.str "ite"),
      ("condition", Lean.Json.mkObj [("tag", Lean.Json.str "now")]),
      ("yes", Lean.Json.mkObj [("tag", Lean.Json.str "now")]),
      ("no", Lean.Json.mkObj [("tag", Lean.Json.str "now")])
    ]) = .ok (.ite .now .now .now) := by
  rfl

/-- General string roundtrip theorem: any string roundtrips through canonical UTF-8 encoding and lexString. -/
theorem string_roundtrip (s : String) (rest : List Char) :
    String.fromUTF8? s.toUTF8 = some s ∧
    lexString [] (escapeChars s.toList ++ ('"' :: rest)) = .ok (s, rest) :=
  ⟨string_fromUTF8?_toUTF8 s, lexString_escapeJsonString s rest⟩

/-- Theorem: IR instances exceeding the serialized byte limit (1 MiB) are not supported. -/
theorem serialized_byte_bound_exceeded_not_supported (ir : DecodedIR)
    (h_size : (encodeModule ir).size > 1048576) :
    ¬ SupportedIR ir := by
  intro h_sup
  have h_bound := h_sup.1
  dsimp [SerializedByteBound] at h_bound
  omega

/-- DecodeRat helper: canonical numerator and denominator decodes to RatEnc. -/
theorem decodeRat_mkObj (num : Int) (den : Nat) (h_den : den ≠ 0) (h_gcd : Int.gcd num.natAbs den = 1) :
    decodeRat (Lean.Json.mkObj [("num", Lean.Json.num num), ("den", Lean.Json.num den)]) = .ok ⟨num, den⟩ := by
  dsimp [decodeRat, Lean.Json.mkObj, getField, checkExactObjectKeys]
  dsimp [bind, Except.bind]
  have h_dec : decodeRational num den = .ok ⟨num, den⟩ := rational_decode_canonical num den h_den h_gcd
  exact h_dec

/-- Arbitrary numeric packed value roundtrip for scalar natural values. -/
theorem decodePackedValue_scalar_val (v : Nat) :
    decodePackedValue (Lean.Json.mkObj [
      ("unit", Lean.Json.mkObj [("tag", Lean.Json.str "scalar")]),
      ("value", Lean.Json.mkObj [("num", Lean.Json.num v), ("den", Lean.Json.num 1)])
    ]) = .ok ⟨.numeric .scalar, (RatEnc.mk (v : Int) 1).toRat, false⟩ := by
  have h_step : decodePackedValue (Lean.Json.mkObj [
      ("unit", Lean.Json.mkObj [("tag", Lean.Json.str "scalar")]),
      ("value", Lean.Json.mkObj [("num", Lean.Json.num v), ("den", Lean.Json.num 1)])
    ]) = (decodeRational (v : Int) 1 >>= fun (r : RatEnc) ↦ .ok ⟨.numeric .scalar, r.toRat, false⟩) := rfl
  have h_dec : decodeRational (v : Int) 1 = .ok ⟨(v : Int), 1⟩ := by
    apply rational_decode_canonical
    · decide
    · simp
  rw [h_step, h_dec]
  rfl

/-- Arbitrary numeric packed value roundtrip for asset amount natural values. -/
theorem decodePackedValue_amount_val (a : Asset) (v : Nat) :
    decodePackedValue (Lean.Json.mkObj [
      ("unit", Lean.Json.mkObj [
        ("tag", Lean.Json.str "amount"),
        ("asset", Lean.Json.str (match a with | .usd => "usd" | .share => "share" | .collateral => "collateral" | .debt => "debt"))
      ]),
      ("value", Lean.Json.mkObj [("num", Lean.Json.num v), ("den", Lean.Json.num 1)])
    ]) = .ok ⟨.numeric (.amount a), (RatEnc.mk (v : Int) 1).toRat, false⟩ := by
  have h_dec : decodeRational (v : Int) 1 = .ok ⟨(v : Int), 1⟩ := by
    apply rational_decode_canonical
    · decide
    · simp
  cases a with
  | usd =>
    have h_step : decodePackedValue (Lean.Json.mkObj [
        ("unit", Lean.Json.mkObj [("tag", Lean.Json.str "amount"), ("asset", Lean.Json.str "usd")]),
        ("value", Lean.Json.mkObj [("num", Lean.Json.num v), ("den", Lean.Json.num 1)])
      ]) = (decodeRational (v : Int) 1 >>= fun (r : RatEnc) ↦ .ok ⟨.numeric (.amount .usd), r.toRat, false⟩) := rfl
    rw [h_step, h_dec]
    rfl
  | share =>
    have h_step : decodePackedValue (Lean.Json.mkObj [
        ("unit", Lean.Json.mkObj [("tag", Lean.Json.str "amount"), ("asset", Lean.Json.str "share")]),
        ("value", Lean.Json.mkObj [("num", Lean.Json.num v), ("den", Lean.Json.num 1)])
      ]) = (decodeRational (v : Int) 1 >>= fun (r : RatEnc) ↦ .ok ⟨.numeric (.amount .share), r.toRat, false⟩) := rfl
    rw [h_step, h_dec]
    rfl
  | collateral =>
    have h_step : decodePackedValue (Lean.Json.mkObj [
        ("unit", Lean.Json.mkObj [("tag", Lean.Json.str "amount"), ("asset", Lean.Json.str "collateral")]),
        ("value", Lean.Json.mkObj [("num", Lean.Json.num v), ("den", Lean.Json.num 1)])
      ]) = (decodeRational (v : Int) 1 >>= fun (r : RatEnc) ↦ .ok ⟨.numeric (.amount .collateral), r.toRat, false⟩) := rfl
    rw [h_step, h_dec]
    rfl
  | debt =>
    have h_step : decodePackedValue (Lean.Json.mkObj [
        ("unit", Lean.Json.mkObj [("tag", Lean.Json.str "amount"), ("asset", Lean.Json.str "debt")]),
        ("value", Lean.Json.mkObj [("num", Lean.Json.num v), ("den", Lean.Json.num 1)])
      ]) = (decodeRational (v : Int) 1 >>= fun (r : RatEnc) ↦ .ok ⟨.numeric (.amount .debt), r.toRat, false⟩) := rfl
    rw [h_step, h_dec]
    rfl


/-! ### Declarative JSON Encoders and Codec Inversion Theorems -/

def partyToJson (p : Party) : Lean.Json :=
  Lean.Json.str (match p with | .alice => "alice" | .bob => "bob" | .vault => "vault" | .pool => "pool")

def assetToJson (a : Asset) : Lean.Json :=
  Lean.Json.str (match a with | .usd => "usd" | .share => "share" | .collateral => "collateral" | .debt => "debt")

def domainToJson (d : Domain) : Lean.Json :=
  Lean.Json.str (match d with | .main => "main" | .other => "other")

def cellToJson (c : CellEnc) : Lean.Json :=
  Lean.Json.mkObj [("domain", domainToJson c.domain), ("party", partyToJson c.party), ("asset", assetToJson c.asset)]

def rightToJson : RightEnc → Lean.Json
  | .invoke => Lean.Json.mkObj [("tag", Lean.Json.str "invoke")]
  | .debit c => Lean.Json.mkObj [("tag", Lean.Json.str "debit"), ("cell", cellToJson c)]
  | .changeSupply d a => Lean.Json.mkObj [("tag", Lean.Json.str "changeSupply"), ("domain", domainToJson d), ("asset", assetToJson a)]

def grantToJson (g : GrantEnc) : Lean.Json :=
  Lean.Json.mkObj [
    ("holder", partyToJson g.holder),
    ("domain", domainToJson g.domain),
    ("operation", Lean.Json.num g.operation),
    ("right", rightToJson g.right)
  ]

def partyRefToJson : PartyRefEnc → Lean.Json
  | .caller => Lean.Json.mkObj [("tag", Lean.Json.str "caller")]
  | .argument idx => Lean.Json.mkObj [("tag", Lean.Json.str "argument"), ("index", Lean.Json.num idx)]
  | .literal p => Lean.Json.mkObj [("tag", Lean.Json.str "literal"), ("party", partyToJson p)]

def cellRefToJson (c : CellRefEnc) : Lean.Json :=
  Lean.Json.mkObj [("domain", domainToJson c.domain), ("owner", partyRefToJson c.owner)]

def packedCellRefToJson (c : PackedCellRefEnc) : Lean.Json :=
  Lean.Json.mkObj [("asset", assetToJson c.asset), ("cell", cellRefToJson c.cell)]

def observationKeyToJson (k : ObservationKeyEnc) : Lean.Json :=
  Lean.Json.mkObj [("domain", domainToJson k.domain), ("id", Lean.Json.num k.id)]

def numericUnitToJson : NumericUnitEnc → Lean.Json
  | .scalar => Lean.Json.mkObj [("tag", Lean.Json.str "scalar")]
  | .amount a => Lean.Json.mkObj [("tag", Lean.Json.str "amount"), ("asset", assetToJson a)]
  | .price b q => Lean.Json.mkObj [("tag", Lean.Json.str "price"), ("base", assetToJson b), ("quote", assetToJson q)]

def unitToJson : UnitEnc → Lean.Json
  | .bool => Lean.Json.mkObj [("tag", Lean.Json.str "bool")]
  | .numeric nu => numericUnitToJson nu

def observationRefToJson (r : ObservationRefEnc) : Lean.Json :=
  Lean.Json.mkObj [("key", observationKeyToJson r.key), ("unit", unitToJson r.unit)]

def ratToJson (r : RatEnc) : Lean.Json :=
  Lean.Json.mkObj [("num", Lean.Json.num r.num), ("den", Lean.Json.num r.den)]

def unaryOpToJson : UnaryOpEnc → Lean.Json
  | .not => Lean.Json.mkObj [("tag", Lean.Json.str "not")]
  | .neg nu => Lean.Json.mkObj [("tag", Lean.Json.str "neg"), ("numeric", numericUnitToJson nu)]

def binaryOpToJson : BinaryOpEnc → Lean.Json
  | .add nu => Lean.Json.mkObj [("tag", Lean.Json.str "add"), ("numeric", numericUnitToJson nu)]
  | .sub nu => Lean.Json.mkObj [("tag", Lean.Json.str "sub"), ("numeric", numericUnitToJson nu)]
  | .scale nu => Lean.Json.mkObj [("tag", Lean.Json.str "scale"), ("numeric", numericUnitToJson nu)]
  | .divide nu => Lean.Json.mkObj [("tag", Lean.Json.str "divide"), ("numeric", numericUnitToJson nu)]
  | .ratio nu => Lean.Json.mkObj [("tag", Lean.Json.str "ratio"), ("numeric", numericUnitToJson nu)]
  | .convert b q => Lean.Json.mkObj [("tag", Lean.Json.str "convert"), ("base", assetToJson b), ("quote", assetToJson q)]
  | .unconvert b q => Lean.Json.mkObj [("tag", Lean.Json.str "unconvert"), ("base", assetToJson b), ("quote", assetToJson q)]
  | .and => Lean.Json.mkObj [("tag", Lean.Json.str "and")]
  | .or => Lean.Json.mkObj [("tag", Lean.Json.str "or")]
  | .eq u => Lean.Json.mkObj [("tag", Lean.Json.str "eq"), ("unit", unitToJson u)]
  | .lt nu => Lean.Json.mkObj [("tag", Lean.Json.str "lt"), ("numeric", numericUnitToJson nu)]
  | .le nu => Lean.Json.mkObj [("tag", Lean.Json.str "le"), ("numeric", numericUnitToJson nu)]

def packedValueToJson (v : PackedValueEnc) : Lean.Json :=
  match v.unit with
  | .bool => Lean.Json.bool v.valBool
  | .numeric _ => ratToJson ⟨v.valRat.num, v.valRat.den⟩

def packedValueFullToJson (v : PackedValueEnc) : Lean.Json :=
  Lean.Json.mkObj [("unit", unitToJson v.unit), ("value", packedValueToJson v)]

def exprToJson : ExprEnc → Lean.Json
  | .lit v => Lean.Json.mkObj [("tag", Lean.Json.str "lit"), ("unit", unitToJson v.unit), ("value", packedValueToJson v)]
  | .arg idx u => Lean.Json.mkObj [("tag", Lean.Json.str "arg"), ("index", Lean.Json.num idx), ("unit", unitToJson u)]
  | .balance c => Lean.Json.mkObj [("tag", Lean.Json.str "balance"), ("cell", packedCellRefToJson c)]
  | .observe r => Lean.Json.mkObj [("tag", Lean.Json.str "observe"), ("ref", observationRefToJson r)]
  | .timestamp k => Lean.Json.mkObj [("tag", Lean.Json.str "timestamp"), ("key", observationKeyToJson k)]
  | .now => Lean.Json.mkObj [("tag", Lean.Json.str "now")]
  | .unary op x => Lean.Json.mkObj [("tag", Lean.Json.str "unary"), ("op", unaryOpToJson op), ("x", exprToJson x)]
  | .binary op x y => Lean.Json.mkObj [("tag", Lean.Json.str "binary"), ("op", binaryOpToJson op), ("x", exprToJson x), ("y", exprToJson y)]
  | .ite c y n => Lean.Json.mkObj [("tag", Lean.Json.str "ite"), ("condition", exprToJson c), ("yes", exprToJson y), ("no", exprToJson n)]

def stateCellToJson (c : StateCellEnc) : Lean.Json :=
  Lean.Json.mkObj [
    ("domain", domainToJson c.domain),
    ("party", partyToJson c.party),
    ("asset", assetToJson c.asset),
    ("amount", ratToJson c.amount)
  ]

/-- Component inversion: party roundtrip. -/
theorem decodeParty_partyToJson (p : Party) : decodeParty (partyToJson p) = .ok p := by
  cases p <;> rfl

/-- Component inversion: asset roundtrip. -/
theorem decodeAsset_assetToJson (a : Asset) : decodeAsset (assetToJson a) = .ok a := by
  cases a <;> rfl

/-- Component inversion: domain roundtrip. -/
theorem decodeDomain_domainToJson (d : Domain) : decodeDomain (domainToJson d) = .ok d := by
  cases d <;> rfl

/-- Component inversion: cell roundtrip. -/
theorem decodeCell_cellToJson (c : CellEnc) : decodeCell (cellToJson c) = .ok c := by
  cases c with | mk d p a =>
  cases d <;> cases p <;> cases a <;> rfl

/-- Component inversion: right roundtrip. -/
theorem decodeRight_rightToJson (r : RightEnc) : decodeRight (rightToJson r) = .ok r := by
  cases r with
  | invoke => rfl
  | debit c =>
    have h_c := decodeCell_cellToJson c
    have h_def : decodeRight (rightToJson (.debit c)) = (do
        let c_dec ← decodeCell (cellToJson c)
        .ok (.debit c_dec)) := rfl
    rw [h_def, h_c]
    rfl
  | changeSupply d a =>
    cases d <;> cases a <;> rfl

/-- Component inversion: grant roundtrip. -/
theorem decodeGrant_grantToJson (g : GrantEnc) : decodeGrant (grantToJson g) = .ok g := by
  cases g with | mk h d op r =>
  have h_r := decodeRight_rightToJson r
  cases h with
  | alice =>
    cases d with
    | main =>
      have h_def : decodeGrant (grantToJson ⟨.alice, .main, op, r⟩) = (do
          let r_dec ← decodeRight (rightToJson r)
          .ok ⟨.alice, .main, op, r_dec⟩) := rfl
      rw [h_def, h_r]
      rfl
    | other =>
      have h_def : decodeGrant (grantToJson ⟨.alice, .other, op, r⟩) = (do
          let r_dec ← decodeRight (rightToJson r)
          .ok ⟨.alice, .other, op, r_dec⟩) := rfl
      rw [h_def, h_r]
      rfl
  | bob =>
    cases d with
    | main =>
      have h_def : decodeGrant (grantToJson ⟨.bob, .main, op, r⟩) = (do
          let r_dec ← decodeRight (rightToJson r)
          .ok ⟨.bob, .main, op, r_dec⟩) := rfl
      rw [h_def, h_r]
      rfl
    | other =>
      have h_def : decodeGrant (grantToJson ⟨.bob, .other, op, r⟩) = (do
          let r_dec ← decodeRight (rightToJson r)
          .ok ⟨.bob, .other, op, r_dec⟩) := rfl
      rw [h_def, h_r]
      rfl
  | vault =>
    cases d with
    | main =>
      have h_def : decodeGrant (grantToJson ⟨.vault, .main, op, r⟩) = (do
          let r_dec ← decodeRight (rightToJson r)
          .ok ⟨.vault, .main, op, r_dec⟩) := rfl
      rw [h_def, h_r]
      rfl
    | other =>
      have h_def : decodeGrant (grantToJson ⟨.vault, .other, op, r⟩) = (do
          let r_dec ← decodeRight (rightToJson r)
          .ok ⟨.vault, .other, op, r_dec⟩) := rfl
      rw [h_def, h_r]
      rfl
  | pool =>
    cases d with
    | main =>
      have h_def : decodeGrant (grantToJson ⟨.pool, .main, op, r⟩) = (do
          let r_dec ← decodeRight (rightToJson r)
          .ok ⟨.pool, .main, op, r_dec⟩) := rfl
      rw [h_def, h_r]
      rfl
    | other =>
      have h_def : decodeGrant (grantToJson ⟨.pool, .other, op, r⟩) = (do
          let r_dec ← decodeRight (rightToJson r)
          .ok ⟨.pool, .other, op, r_dec⟩) := rfl
      rw [h_def, h_r]
      rfl

/-- Component inversion: partyRef roundtrip. -/
theorem decodePartyRef_partyRefToJson (p : PartyRefEnc) : decodePartyRef (partyRefToJson p) = .ok p := by
  cases p with
  | caller => rfl
  | argument idx => rfl
  | literal p => cases p <;> rfl

/-- Component inversion: cellRef roundtrip. -/
theorem decodeCellRef_cellRefToJson (c : CellRefEnc) : decodeCellRef (cellRefToJson c) = .ok c := by
  cases c with | mk d o =>
  have h_o := decodePartyRef_partyRefToJson o
  cases d with
  | main =>
    have h_def : decodeCellRef (cellRefToJson ⟨.main, o⟩) = (do
        let o_dec ← decodePartyRef (partyRefToJson o)
        .ok ⟨.main, o_dec⟩) := rfl
    rw [h_def, h_o]
    rfl
  | other =>
    have h_def : decodeCellRef (cellRefToJson ⟨.other, o⟩) = (do
        let o_dec ← decodePartyRef (partyRefToJson o)
        .ok ⟨.other, o_dec⟩) := rfl
    rw [h_def, h_o]
    rfl

/-- Component inversion: packedCellRef roundtrip. -/
theorem decodePackedCellRef_packedCellRefToJson (c : PackedCellRefEnc) : decodePackedCellRef (packedCellRefToJson c) = .ok c := by
  cases c with | mk a cell =>
  have h_cell := decodeCellRef_cellRefToJson cell
  cases a with
  | usd =>
    have h_def : decodePackedCellRef (packedCellRefToJson ⟨.usd, cell⟩) = (do
        let c_dec ← decodeCellRef (cellRefToJson cell)
        .ok ⟨.usd, c_dec⟩) := rfl
    rw [h_def, h_cell]
    rfl
  | share =>
    have h_def : decodePackedCellRef (packedCellRefToJson ⟨.share, cell⟩) = (do
        let c_dec ← decodeCellRef (cellRefToJson cell)
        .ok ⟨.share, c_dec⟩) := rfl
    rw [h_def, h_cell]
    rfl
  | collateral =>
    have h_def : decodePackedCellRef (packedCellRefToJson ⟨.collateral, cell⟩) = (do
        let c_dec ← decodeCellRef (cellRefToJson cell)
        .ok ⟨.collateral, c_dec⟩) := rfl
    rw [h_def, h_cell]
    rfl
  | debt =>
    have h_def : decodePackedCellRef (packedCellRefToJson ⟨.debt, cell⟩) = (do
        let c_dec ← decodeCellRef (cellRefToJson cell)
        .ok ⟨.debt, c_dec⟩) := rfl
    rw [h_def, h_cell]
    rfl

/-- Component inversion: observationKey roundtrip. -/
theorem decodeObservationKey_observationKeyToJson (k : ObservationKeyEnc) : decodeObservationKey (observationKeyToJson k) = .ok k := by
  cases k with | mk d id =>
  cases d with
  | main => rfl
  | other => rfl

/-- Component inversion: numericUnit roundtrip. -/
theorem decodeNumericUnit_numericUnitToJson (nu : NumericUnitEnc) : decodeNumericUnit (numericUnitToJson nu) = .ok nu := by
  cases nu with
  | scalar => rfl
  | amount a => cases a <;> rfl
  | price b q => cases b <;> cases q <;> rfl

/-- Component inversion: unit roundtrip. -/
theorem decodeUnit_unitToJson (u : UnitEnc) : decodeUnit (unitToJson u) = .ok u := by
  cases u with
  | bool => rfl
  | numeric nu =>
    cases nu with
    | scalar => rfl
    | amount a => cases a <;> rfl
    | price b q => cases b <;> cases q <;> rfl

/-- Component inversion: observationRef roundtrip. -/
theorem decodeObservationRef_observationRefToJson (r : ObservationRefEnc) : decodeObservationRef (observationRefToJson r) = .ok r := by
  cases r with | mk k u =>
  have h_k := decodeObservationKey_observationKeyToJson k
  have h_u := decodeUnit_unitToJson u
  have h_def : decodeObservationRef (observationRefToJson ⟨k, u⟩) = (do
      let k_dec ← decodeObservationKey (observationKeyToJson k)
      let u_dec ← decodeUnit (unitToJson u)
      .ok ⟨k_dec, u_dec⟩) := rfl
  rw [h_def, h_k, h_u]
  rfl

/-- Component inversion: unaryOp roundtrip. -/
theorem decodeUnaryOp_unaryOpToJson (op : UnaryOpEnc) : decodeUnaryOp (unaryOpToJson op) = .ok op := by
  cases op with
  | not => rfl
  | neg nu =>
    cases nu with
    | scalar => rfl
    | amount a => cases a <;> rfl
    | price b q => cases b <;> cases q <;> rfl

/-- Component inversion: binaryOp roundtrip. -/
theorem decodeBinaryOp_binaryOpToJson (op : BinaryOpEnc) : decodeBinaryOp (binaryOpToJson op) = .ok op := by
  cases op with
  | add nu => cases nu with | scalar => rfl | amount a => cases a <;> rfl | price b q => cases b <;> cases q <;> rfl
  | sub nu => cases nu with | scalar => rfl | amount a => cases a <;> rfl | price b q => cases b <;> cases q <;> rfl
  | scale nu => cases nu with | scalar => rfl | amount a => cases a <;> rfl | price b q => cases b <;> cases q <;> rfl
  | divide nu => cases nu with | scalar => rfl | amount a => cases a <;> rfl | price b q => cases b <;> cases q <;> rfl
  | ratio nu => cases nu with | scalar => rfl | amount a => cases a <;> rfl | price b q => cases b <;> cases q <;> rfl
  | convert b q => cases b <;> cases q <;> rfl
  | unconvert b q => cases b <;> cases q <;> rfl
  | and => rfl
  | or => rfl
  | eq u =>
    cases u with
    | bool => rfl
    | numeric nu => cases nu with | scalar => rfl | amount a => cases a <;> rfl | price b q => cases b <;> cases q <;> rfl
  | lt nu => cases nu with | scalar => rfl | amount a => cases a <;> rfl | price b q => cases b <;> cases q <;> rfl
  | le nu => cases nu with | scalar => rfl | amount a => cases a <;> rfl | price b q => cases b <;> cases q <;> rfl

/-- Component inversion: canonical state cell roundtrip. -/
theorem decodeStateCell_canonical (amt : RatEnc)
    (h_den : amt.den ≠ 0) (h_gcd : Int.gcd amt.num.natAbs amt.den = 1) (h_nonneg : amt.num ≥ 0) :
    decodeStateCell (stateCellToJson (StateCellEnc.mk .main .alice .usd amt)) = .ok (StateCellEnc.mk .main .alice .usd amt) := by
  have h_amt : decodeRat (ratToJson amt) = .ok amt := decodeRat_mkObj amt.num amt.den h_den h_gcd
  have h_def : decodeStateCell (stateCellToJson (StateCellEnc.mk .main .alice .usd amt)) =
    (decodeRat (ratToJson amt) >>= fun amount =>
      if amount.num < 0 then Except.error DecodeFailure.stateNonneg
      else Except.ok (StateCellEnc.mk .main .alice .usd amount)) := rfl
  rw [h_def, h_amt]
  change (if amt.num < 0 then Except.error DecodeFailure.stateNonneg else Except.ok (StateCellEnc.mk .main .alice .usd amt)) =
    Except.ok (StateCellEnc.mk .main .alice .usd amt)
  have h_not_neg : ¬ (amt.num < 0) := by omega
  rw [if_neg h_not_neg]

/-- Expression base case: now roundtrip with fuel + 1. -/
theorem exprToJson_decode_now (fuel : Nat) : decodeExprFuel (fuel + 1) (exprToJson .now) = .ok .now := rfl

/-- Expression base case: timestamp roundtrip with fuel + 1. -/
theorem exprToJson_decode_timestamp (fuel : Nat) (k : ObservationKeyEnc) :
    decodeExprFuel (fuel + 1) (exprToJson (.timestamp k)) = .ok (.timestamp k) := by
  have h_k := decodeObservationKey_observationKeyToJson k
  have h_def : decodeExprFuel (fuel + 1) (exprToJson (.timestamp k)) = (do
      let k_dec ← decodeObservationKey (observationKeyToJson k)
      .ok (.timestamp k_dec)) := rfl
  rw [h_def, h_k]
  rfl

/-- Expression base case: observe roundtrip with fuel + 1. -/
theorem exprToJson_decode_observe (fuel : Nat) (r : ObservationRefEnc) :
    decodeExprFuel (fuel + 1) (exprToJson (.observe r)) = .ok (.observe r) := by
  have h_r := decodeObservationRef_observationRefToJson r
  have h_def : decodeExprFuel (fuel + 1) (exprToJson (.observe r)) = (do
      let r_dec ← decodeObservationRef (observationRefToJson r)
      .ok (.observe r_dec)) := rfl
  rw [h_def, h_r]
  rfl

/-- Expression base case: balance roundtrip with fuel + 1. -/
theorem exprToJson_decode_balance (fuel : Nat) (c : PackedCellRefEnc) :
    decodeExprFuel (fuel + 1) (exprToJson (.balance c)) = .ok (.balance c) := by
  have h_c := decodePackedCellRef_packedCellRefToJson c
  have h_def : decodeExprFuel (fuel + 1) (exprToJson (.balance c)) = (do
      let c_dec ← decodePackedCellRef (packedCellRefToJson c)
      .ok (.balance c_dec)) := rfl
  rw [h_def, h_c]
  rfl

/-- Expression base case: argument roundtrip with fuel + 1. -/
theorem exprToJson_decode_arg (fuel : Nat) (idx : Nat) (u : UnitEnc) :
    decodeExprFuel (fuel + 1) (exprToJson (.arg idx u)) = .ok (.arg idx u) := by
  have h_u := decodeUnit_unitToJson u
  have h_def : decodeExprFuel (fuel + 1) (exprToJson (.arg idx u)) = (do
      let u_dec ← decodeUnit (unitToJson u)
      .ok (.arg idx u_dec)) := rfl
  rw [h_def, h_u]
  rfl

/-- Expression inductive step: unary operator roundtrip. -/
theorem exprToJson_decode_unary_step (fuel : Nat) (op : UnaryOpEnc) (x : ExprEnc)
    (h_x : decodeExprFuel fuel (exprToJson x) = .ok x) :
    decodeExprFuel (fuel + 1) (exprToJson (.unary op x)) = .ok (.unary op x) := by
  have h_def : decodeExprFuel (fuel + 1) (exprToJson (.unary op x)) = (do
      let op_dec ← decodeUnaryOp (unaryOpToJson op)
      let x_dec ← decodeExprFuel fuel (exprToJson x)
      .ok (.unary op_dec x_dec)) := rfl
  have h_op := decodeUnaryOp_unaryOpToJson op
  rw [h_def, h_op, h_x]
  rfl

/-- Expression inductive step: binary operator roundtrip. -/
theorem exprToJson_decode_binary_step (fuel : Nat) (op : BinaryOpEnc) (x y : ExprEnc)
    (h_x : decodeExprFuel fuel (exprToJson x) = .ok x)
    (h_y : decodeExprFuel fuel (exprToJson y) = .ok y) :
    decodeExprFuel (fuel + 1) (exprToJson (.binary op x y)) = .ok (.binary op x y) := by
  have h_def : decodeExprFuel (fuel + 1) (exprToJson (.binary op x y)) = (do
      let op_dec ← decodeBinaryOp (binaryOpToJson op)
      let x_dec ← decodeExprFuel fuel (exprToJson x)
      let y_dec ← decodeExprFuel fuel (exprToJson y)
      .ok (.binary op_dec x_dec y_dec)) := rfl
  have h_op := decodeBinaryOp_binaryOpToJson op
  rw [h_def, h_op, h_x, h_y]
  rfl

/-- Expression inductive step: conditional (ite) operator roundtrip. -/
theorem exprToJson_decode_ite_step (fuel : Nat) (c y n : ExprEnc)
    (h_c : decodeExprFuel fuel (exprToJson c) = .ok c)
    (h_y : decodeExprFuel fuel (exprToJson y) = .ok y)
    (h_n : decodeExprFuel fuel (exprToJson n) = .ok n) :
    decodeExprFuel (fuel + 1) (exprToJson (.ite c y n)) = .ok (.ite c y n) := by
  have h_def : decodeExprFuel (fuel + 1) (exprToJson (.ite c y n)) = (do
      let c_dec ← decodeExprFuel fuel (exprToJson c)
      let y_dec ← decodeExprFuel fuel (exprToJson y)
      let n_dec ← decodeExprFuel fuel (exprToJson n)
      .ok (.ite c_dec y_dec n_dec)) := rfl
  rw [h_def, h_c, h_y, h_n]
  rfl

/-- Theorem: converting from a Mathlib ℚ to RatEnc and back via toRat is the identity. -/
theorem rat_toRat_fromRat (q : ℚ) : (RatEnc.mk q.num q.den).toRat = q := by
  dsimp [RatEnc.toRat]
  exact Rat.num_divInt_den q

/-- Canonical rational decoder inversion: any reduced non-zero denominator rational roundtrips. -/
theorem decodeRat_ratToJson (r : RatEnc) (h_den : r.den ≠ 0) (h_gcd : Int.gcd r.num.natAbs r.den = 1) :
    decodeRat (ratToJson r) = .ok r :=
  decodeRat_mkObj r.num r.den h_den h_gcd

/-- Canonical rational decoder inversion from Mathlib ℚ: any ℚ roundtrips canonically. -/
theorem decodeRat_fromRat (q : ℚ) :
    decodeRat (ratToJson (RatEnc.fromRat q)) = .ok (RatEnc.fromRat q) := by
  have h_den : q.den ≠ 0 := q.den_nz
  have h_gcd : Int.gcd q.num.natAbs q.den = 1 := q.reduced
  exact decodeRat_mkObj q.num q.den h_den h_gcd

/-- Canonical packed value inversion for literal expression decoding. -/
theorem decodeExprFuel_lit_canonical (fuel : Nat) (v : PackedValueEnc) (h_can : PackedValueCanonical v) :
    decodeExprFuel (fuel + 1) (exprToJson (.lit v)) = .ok (.lit v) := by
  cases v with | mk u valRat valBool =>
  dsimp [PackedValueCanonical] at h_can
  cases u with
  | bool =>
    have h_rat := h_can.1 rfl
    have h_def : decodeExprFuel (fuel + 1) (exprToJson (.lit ⟨.bool, valRat, valBool⟩)) =
        .ok (.lit ⟨.bool, 0, valBool⟩) := by
      cases valBool <;> rfl
    rw [h_def, h_rat]
  | numeric nu =>
    have h_bool := h_can.2 nu rfl
    have h_den : valRat.den ≠ 0 := valRat.den_nz
    have h_gcd : Int.gcd valRat.num.natAbs valRat.den = 1 := valRat.reduced
    have h_rat : decodeRat (ratToJson ⟨valRat.num, valRat.den⟩) = .ok ⟨valRat.num, valRat.den⟩ :=
      decodeRat_mkObj valRat.num valRat.den h_den h_gcd
    have h_toRat : (RatEnc.mk valRat.num valRat.den).toRat = valRat := rat_toRat_fromRat valRat
    have h_u := decodeUnit_unitToJson (.numeric nu)
    have h_def : decodeExprFuel (fuel + 1) (exprToJson (.lit ⟨.numeric nu, valRat, valBool⟩)) = (do
        let u_dec ← decodeUnit (unitToJson (.numeric nu))
        match u_dec with
        | .bool => .error (.jsonType "boolValue")
        | .numeric nu' =>
          let r ← decodeRat (ratToJson ⟨valRat.num, valRat.den⟩)
          .ok (.lit ⟨.numeric nu', r.toRat, false⟩)) := rfl
    rw [h_def, h_u]
    dsimp [bind, Except.bind]
    rw [h_rat]
    dsimp [bind, Except.bind]
    rw [h_toRat, h_bool]

lemma exprDepth_pos (e : ExprEnc) : ExprEnc.depth e ≥ 1 := by
  cases e <;> simp [ExprEnc.depth]

/-- Expression inductive inversion theorem: any canonical expression roundtrips when given sufficient fuel. -/
theorem decodeExprFuel_exprToJson (e : ExprEnc) (fuel : Nat) (h_fuel : ExprEnc.depth e ≤ fuel) (h_can : ExprCanonical e) :
    decodeExprFuel fuel (exprToJson e) = .ok e := by
  induction fuel generalizing e with
  | zero =>
    have h_pos := exprDepth_pos e
    omega
  | succ f ih =>
    cases e with
    | lit v =>
      dsimp [ExprCanonical] at h_can
      exact decodeExprFuel_lit_canonical f v h_can.2
    | arg idx u =>
      exact exprToJson_decode_arg f idx u
    | balance c =>
      exact exprToJson_decode_balance f c
    | observe r =>
      exact exprToJson_decode_observe f r
    | timestamp k =>
      exact exprToJson_decode_timestamp f k
    | now =>
      exact exprToJson_decode_now f
    | unary op x =>
      simp only [ExprEnc.depth] at h_fuel
      have h_xfuel : ExprEnc.depth x ≤ f := by omega
      have h_x := ih x h_xfuel h_can.2
      exact exprToJson_decode_unary_step f op x h_x
    | binary op x y =>
      simp only [ExprEnc.depth] at h_fuel
      have h_xfuel : ExprEnc.depth x ≤ f := by omega
      have h_yfuel : ExprEnc.depth y ≤ f := by omega
      have h_x := ih x h_xfuel h_can.2.1
      have h_y := ih y h_yfuel h_can.2.2
      exact exprToJson_decode_binary_step f op x y h_x h_y
    | ite c y n =>
      simp only [ExprEnc.depth] at h_fuel
      have h_cfuel : ExprEnc.depth c ≤ f := by omega
      have h_yfuel : ExprEnc.depth y ≤ f := by omega
      have h_nfuel : ExprEnc.depth n ≤ f := by omega
      have h_c := ih c h_cfuel h_can.2.1
      have h_y := ih y h_yfuel h_can.2.2.1
      have h_n := ih n h_nfuel h_can.2.2.2
      exact exprToJson_decode_ite_step f c y n h_c h_y h_n

/-- Production expression decoder inversion theorem: decodeExpr inverts exprToJson for any bounded canonical expression. -/
theorem decodeExpr_exprToJson (e : ExprEnc) (h_depth : ExprEnc.depth e ≤ 64) (h_can : ExprCanonical e) :
    decodeExpr (exprToJson e) = .ok e := by
  dsimp [decodeExpr]
  exact decodeExprFuel_exprToJson e 64 h_depth h_can

def envReadToJson (er : EnvReadEnc) : Lean.Json :=
  match er with
  | .observation k => Lean.Json.mkObj [("tag", Lean.Json.str "observation"), ("key", observationKeyToJson k)]
  | .currentTime => Lean.Json.mkObj [("tag", Lean.Json.str "currentTime")]

theorem decodeEnvRead_envReadToJson (er : EnvReadEnc) :
    decodeEnvRead (envReadToJson er) = .ok er := by
  cases er with
  | observation k =>
    have h_k := decodeObservationKey_observationKeyToJson k
    have h_def : decodeEnvRead (envReadToJson (.observation k)) = (do
        let k_dec ← decodeObservationKey (observationKeyToJson k)
        .ok (.observation k_dec)) := rfl
    rw [h_def, h_k]
    rfl
  | currentTime => rfl

def cellDeltaToJson (d : CellDeltaEnc) : Lean.Json :=
  Lean.Json.mkObj [("asset", assetToJson d.asset), ("target", cellRefToJson d.target), ("amount", exprToJson d.amount)]

theorem decodeCellDelta_cellDeltaToJson (d : CellDeltaEnc)
    (h_depth : ExprEnc.depth d.amount ≤ 64) (h_can : ExprCanonical d.amount) :
    decodeCellDelta (cellDeltaToJson d) = .ok d := by
  cases d with | mk a t amt =>
  have h_a := decodeAsset_assetToJson a
  have h_t := decodeCellRef_cellRefToJson t
  have h_amt := decodeExpr_exprToJson amt h_depth h_can
  have h_def : decodeCellDelta (cellDeltaToJson ⟨a, t, amt⟩) = (do
      let a_dec ← decodeAsset (assetToJson a)
      let t_dec ← decodeCellRef (cellRefToJson t)
      let amt_dec ← decodeExpr (exprToJson amt)
      .ok ⟨a_dec, t_dec, amt_dec⟩) := rfl
  rw [h_def, h_a, h_t, h_amt]
  rfl

def supplyDeltaToJson (s : SupplyDeltaEnc) : Lean.Json :=
  Lean.Json.mkObj [("domain", domainToJson s.domain), ("asset", assetToJson s.asset), ("amount", exprToJson s.amount)]

theorem decodeSupplyDelta_supplyDeltaToJson (s : SupplyDeltaEnc)
    (h_depth : ExprEnc.depth s.amount ≤ 64) (h_can : ExprCanonical s.amount) :
    decodeSupplyDelta (supplyDeltaToJson s) = .ok s := by
  cases s with | mk d a amt =>
  have h_d := decodeDomain_domainToJson d
  have h_a := decodeAsset_assetToJson a
  have h_amt := decodeExpr_exprToJson amt h_depth h_can
  have h_def : decodeSupplyDelta (supplyDeltaToJson ⟨d, a, amt⟩) = (do
      let d_dec ← decodeDomain (domainToJson d)
      let a_dec ← decodeAsset (assetToJson a)
      let amt_dec ← decodeExpr (exprToJson amt)
      .ok ⟨d_dec, a_dec, amt_dec⟩) := rfl
  rw [h_def, h_d, h_a, h_amt]
  rfl

theorem list_mapM_decode_ok {α : Type} (xs : List α) (f : α → Lean.Json) (dec : Lean.Json → Except DecodeFailure α)
    (h : ∀ x ∈ xs, dec (f x) = .ok x) :
    (xs.map f).mapM dec = .ok xs := by
  induction xs with
  | nil => rfl
  | cons x xs ih =>
    simp only [List.map_cons, List.mapM_cons]
    have h_x := h x (List.Mem.head xs)
    have h_xs : ∀ y ∈ xs, dec (f y) = .ok y := fun y hy => h y (List.Mem.tail x hy)
    have ih_app := ih h_xs
    rw [h_x]
    dsimp [bind, Except.bind]
    rw [ih_app]
    rfl

def templateToJson (t : TemplateEnc) : Lean.Json :=
  Lean.Json.mkObj [
    ("signature", Lean.Json.arr (t.signature.map unitToJson).toArray),
    ("domain", domainToJson t.domain),
    ("partyArity", Lean.Json.num t.partyArity),
    ("guard", exprToJson t.guard),
    ("deltas", Lean.Json.arr (t.deltas.map cellDeltaToJson).toArray),
    ("supplyDeltas", Lean.Json.arr (t.supplyDeltas.map supplyDeltaToJson).toArray),
    ("stateReads", Lean.Json.arr (t.stateReads.map packedCellRefToJson).toArray),
    ("envReads", Lean.Json.arr (t.envReads.map envReadToJson).toArray),
    ("writes", Lean.Json.arr (t.writes.map packedCellRefToJson).toArray)
  ]

set_option maxHeartbeats 1000000 in
-- complex multi-field AST decoding requires increased heartbeats for kernel reduction
theorem decodeTemplate_templateToJson (t : TemplateEnc) (h_can : TemplateCanonical t) :
    decodeTemplate (templateToJson t) = .ok t := by
  cases t with | mk sig dom arity guard deltas supplyDeltas stateReads envReads writes =>
  dsimp [TemplateCanonical] at h_can
  have h_sig : (sig.map unitToJson).mapM decodeUnit = .ok sig := by
    apply list_mapM_decode_ok
    intro u _
    exact decodeUnit_unitToJson u
  have h_dom := decodeDomain_domainToJson dom
  have h_guard_can : ExprCanonical guard := h_can.1
  have h_guard_depth : ExprEnc.depth guard ≤ 64 := by
    unfold ExprCanonical at h_guard_can
    exact h_guard_can.1
  have h_guard := decodeExpr_exprToJson guard h_guard_depth h_guard_can
  have h_deltas : (deltas.map cellDeltaToJson).mapM decodeCellDelta = .ok deltas := by
    apply list_mapM_decode_ok
    intro d hd
    have hd_can : ExprCanonical d.amount := h_can.2.1 d hd
    have hd_depth : ExprEnc.depth d.amount ≤ 64 := by
      unfold ExprCanonical at hd_can
      exact hd_can.1
    exact decodeCellDelta_cellDeltaToJson d hd_depth hd_can
  have h_supply : (supplyDeltas.map supplyDeltaToJson).mapM decodeSupplyDelta = .ok supplyDeltas := by
    apply list_mapM_decode_ok
    intro s hs
    have hs_can : ExprCanonical s.amount := h_can.2.2 s hs
    have hs_depth : ExprEnc.depth s.amount ≤ 64 := by
      unfold ExprCanonical at hs_can
      exact hs_can.1
    exact decodeSupplyDelta_supplyDeltaToJson s hs_depth hs_can
  have h_sr : (stateReads.map packedCellRefToJson).mapM decodePackedCellRef = .ok stateReads := by
    apply list_mapM_decode_ok
    intro r _
    exact decodePackedCellRef_packedCellRefToJson r
  have h_er : (envReads.map envReadToJson).mapM decodeEnvRead = .ok envReads := by
    apply list_mapM_decode_ok
    intro r _
    exact decodeEnvRead_envReadToJson r
  have h_wr : (writes.map packedCellRefToJson).mapM decodePackedCellRef = .ok writes := by
    apply list_mapM_decode_ok
    intro w _
    exact decodePackedCellRef_packedCellRefToJson w
  have h_def : decodeTemplate (templateToJson ⟨sig, dom, arity, guard, deltas, supplyDeltas, stateReads, envReads, writes⟩) = (do
      let sigArr ← Except.ok (sig.map unitToJson).toArray
      let signature ← sigArr.toList.mapM decodeUnit
      let domain ← decodeDomain (domainToJson dom)
      let guard_dec ← decodeExpr (exprToJson guard)
      let deltasArr ← Except.ok (deltas.map cellDeltaToJson).toArray
      let deltas_dec ← deltasArr.toList.mapM decodeCellDelta
      let supArr ← Except.ok (supplyDeltas.map supplyDeltaToJson).toArray
      let supplyDeltas_dec ← supArr.toList.mapM decodeSupplyDelta
      let srArr ← Except.ok (stateReads.map packedCellRefToJson).toArray
      let stateReads_dec ← srArr.toList.mapM decodePackedCellRef
      let erArr ← Except.ok (envReads.map envReadToJson).toArray
      let envReads_dec ← erArr.toList.mapM decodeEnvRead
      let wArr ← Except.ok (writes.map packedCellRefToJson).toArray
      let writes_dec ← wArr.toList.mapM decodePackedCellRef
      .ok ⟨signature, domain, arity, guard_dec, deltas_dec, supplyDeltas_dec, stateReads_dec, envReads_dec, writes_dec⟩) := rfl
  rw [h_def]
  change (do
      let signature ← (sig.map unitToJson).mapM decodeUnit
      let domain ← decodeDomain (domainToJson dom)
      let guard_dec ← decodeExpr (exprToJson guard)
      let deltas_dec ← (deltas.map cellDeltaToJson).mapM decodeCellDelta
      let supplyDeltas_dec ← (supplyDeltas.map supplyDeltaToJson).mapM decodeSupplyDelta
      let stateReads_dec ← (stateReads.map packedCellRefToJson).mapM decodePackedCellRef
      let envReads_dec ← (envReads.map envReadToJson).mapM decodeEnvRead
      let writes_dec ← (writes.map packedCellRefToJson).mapM decodePackedCellRef
      Except.ok (TemplateEnc.mk signature domain arity guard_dec deltas_dec supplyDeltas_dec stateReads_dec envReads_dec writes_dec)) =
    (Except.ok (TemplateEnc.mk sig dom arity guard deltas supplyDeltas stateReads envReads writes) : Except DecodeFailure TemplateEnc)
  rw [h_sig, h_dom, h_guard, h_deltas, h_supply, h_sr, h_er, h_wr]
  rfl

theorem filter_not_beq_of_not_mem [BEq α] [LawfulBEq α] {a : α} {as : List α} (h : ∀ x ∈ as, a ≠ x) :
    List.filter (fun b => !(b == a)) as = as := by
  induction as with
  | nil => rfl
  | cons x xs ih =>
    have h_not_head : a ≠ x := h x (List.Mem.head xs)
    have h_not_tail : ∀ y ∈ xs, a ≠ y := fun y hy => h y (List.Mem.tail x hy)
    simp only [List.filter_cons]
    have h_ne : (x == a) = false := by
      cases h_eq : (x == a)
      · rfl
      · have h_true := eq_of_beq h_eq
        exact False.elim (h_not_head h_true.symm)
    rw [h_ne]
    dsimp
    rw [ih h_not_tail]

theorem eraseDups_eq_of_nodup [BEq α] [LawfulBEq α] {as : List α} (h : as.Nodup) :
    as.eraseDups = as := by
  induction as with
  | nil => exact List.eraseDups_nil
  | cons x xs ih =>
    cases h with
    | cons h_not_mem h_nodup =>
      rw [List.eraseDups_cons]
      have h_not_mem' : ∀ y ∈ xs, x ≠ y := fun y hy => (h_not_mem y hy)
      have h_filt := filter_not_beq_of_not_mem h_not_mem'
      rw [h_filt, ih h_nodup]

theorem nodup_eraseDups_length (ids : List Nat) (h_nodup : ids.Nodup) :
    (ids.length != ids.eraseDups.length) = false := by
  have h_eq : ids.eraseDups = ids := eraseDups_eq_of_nodup h_nodup
  rw [h_eq]
  exact bne_self_eq_false ids.length

def registryEntryToJson (e : RegistryEntryEnc) : Lean.Json :=
  Lean.Json.mkObj [("id", Lean.Json.num e.id), ("template", templateToJson e.template)]

set_option maxHeartbeats 1000000 in
-- nested template decoding requires increased heartbeats for kernel reduction
theorem decodeRegistryEntry_registryEntryToJson (e : RegistryEntryEnc) (h_can : TemplateCanonical e.template) :
    decodeRegistryEntry (registryEntryToJson e) = .ok e := by
  cases e with | mk id t =>
  have h_t := decodeTemplate_templateToJson t h_can
  have h_def : decodeRegistryEntry (registryEntryToJson ⟨id, t⟩) = (do
      let t_dec ← decodeTemplate (templateToJson t)
      .ok ⟨id, t_dec⟩) := rfl
  rw [h_def, h_t]
  rfl

def registryToJson (r : RegistryEnc) : Lean.Json :=
  Lean.Json.mkObj [("entries", Lean.Json.arr (r.entries.map registryEntryToJson).toArray)]

set_option maxHeartbeats 1000000 in
-- registry decoding and uniqueness check require increased heartbeats for kernel reduction
theorem decodeRegistry_registryToJson (r : RegistryEnc) (h_can : RegistryCanonical r) :
    decodeRegistry (registryToJson r) = .ok r := by
  cases r with | mk entries =>
  dsimp [RegistryCanonical] at h_can
  have h_entries : (entries.map registryEntryToJson).mapM decodeRegistryEntry = .ok entries := by
    apply list_mapM_decode_ok
    intro e he
    have he_can := h_can.2 e he
    exact decodeRegistryEntry_registryEntryToJson e he_can
  have h_def : decodeRegistry (registryToJson ⟨entries⟩) = (do
      let entArr ← Except.ok (entries.map registryEntryToJson).toArray
      let ents ← entArr.toList.mapM decodeRegistryEntry
      let ids := ents.map (·.id)
      if ids.length != ids.eraseDups.length then
        throw (.uniqueness "registry")
      .ok ⟨ents⟩) := rfl
  rw [h_def]
  change (do
      let ents ← (entries.map registryEntryToJson).mapM decodeRegistryEntry
      let ids := ents.map (·.id)
      if ids.length != ids.eraseDups.length then
        throw (.uniqueness "registry")
      Except.ok (RegistryEnc.mk ents)) =
    (Except.ok (RegistryEnc.mk entries) : Except DecodeFailure RegistryEnc)
  rw [h_entries]
  dsimp [bind, Except.bind]
  have h_uniq := nodup_eraseDups_length (entries.map (·.id)) h_can.1
  rw [h_uniq]
  rfl

def capabilityToJson (c : CapabilityEnc) : Lean.Json :=
  Lean.Json.mkObj [
    ("holder", partyToJson c.holder),
    ("domain", domainToJson c.domain),
    ("operation", Lean.Json.num c.operation),
    ("right", rightToJson c.right),
    ("live", Lean.Json.bool c.live)
  ]

theorem decodeCapability_capabilityToJson (c : CapabilityEnc) :
    decodeCapability (capabilityToJson c) = .ok c := by
  cases c with | mk holder domain op right live =>
  have h_h := decodeParty_partyToJson holder
  have h_d := decodeDomain_domainToJson domain
  have h_r := decodeRight_rightToJson right
  have h_def : decodeCapability (capabilityToJson ⟨holder, domain, op, right, live⟩) = (do
      let h ← decodeParty (partyToJson holder)
      let d ← decodeDomain (domainToJson domain)
      let r ← decodeRight (rightToJson right)
      .ok ⟨h, d, op, r, live⟩) := rfl
  rw [h_def, h_h, h_d, h_r]
  cases live <;> rfl

def storeToJson (s : StoreEnc) : Lean.Json :=
  Lean.Json.mkObj [("entries", Lean.Json.arr (s.entries.map capabilityToJson).toArray)]

theorem decodeStore_storeToJson (s : StoreEnc) :
    decodeStore (storeToJson s) = .ok s := by
  have h_map : (s.entries.map capabilityToJson).mapM decodeCapability = .ok s.entries := by
    apply list_mapM_decode_ok
    intro c _
    exact decodeCapability_capabilityToJson c
  have h_def : decodeStore (storeToJson s) = (do
      let entArr ← Except.ok (s.entries.map capabilityToJson).toArray
      let entries ← entArr.toList.mapM decodeCapability
      .ok ⟨entries⟩) := rfl
  rw [h_def]
  change (do
      let entries ← (s.entries.map capabilityToJson).mapM decodeCapability
      Except.ok (StoreEnc.mk entries)) =
    (Except.ok (StoreEnc.mk s.entries) : Except DecodeFailure StoreEnc)
  rw [h_map]
  rfl

def contextToJson (c : ContextEnc) : Lean.Json :=
  Lean.Json.mkObj [("principal", partyToJson c.principal), ("domain", domainToJson c.domain)]

theorem decodeContext_contextToJson (c : ContextEnc) :
    decodeContext (contextToJson c) = .ok c := by
  cases c with | mk p d =>
  have h_p := decodeParty_partyToJson p
  have h_d := decodeDomain_domainToJson d
  have h_def : decodeContext (contextToJson ⟨p, d⟩) = (do
      let p_dec ← decodeParty (partyToJson p)
      let d_dec ← decodeDomain (domainToJson d)
      .ok ⟨p_dec, d_dec⟩) := rfl
  rw [h_def, h_p, h_d]
  rfl

theorem decodePackedValue_canonical (v : PackedValueEnc) (h_can : PackedValueCanonical v) :
    decodePackedValue (packedValueFullToJson v) = .ok v := by
  cases v with | mk u valRat valBool =>
  dsimp [PackedValueCanonical] at h_can
  cases u with
  | bool =>
    have h_rat := h_can.1 rfl
    have h_def : decodePackedValue (packedValueFullToJson ⟨.bool, valRat, valBool⟩) =
        .ok ⟨.bool, 0, valBool⟩ := by
      cases valBool <;> rfl
    rw [h_def, h_rat]
  | numeric nu =>
    have h_bool := h_can.2 nu rfl
    have h_den : valRat.den ≠ 0 := valRat.den_nz
    have h_gcd : Int.gcd valRat.num.natAbs valRat.den = 1 := valRat.reduced
    have h_rat : decodeRat (ratToJson ⟨valRat.num, valRat.den⟩) = .ok ⟨valRat.num, valRat.den⟩ :=
      decodeRat_mkObj valRat.num valRat.den h_den h_gcd
    have h_toRat : (RatEnc.mk valRat.num valRat.den).toRat = valRat := rat_toRat_fromRat valRat
    have h_u := decodeUnit_unitToJson (.numeric nu)
    have h_def : decodePackedValue (packedValueFullToJson ⟨.numeric nu, valRat, valBool⟩) = (do
        let u_dec ← decodeUnit (unitToJson (.numeric nu))
        match u_dec with
        | .bool => .error (.jsonType "boolValue")
        | .numeric nu' =>
          let r ← decodeRat (ratToJson ⟨valRat.num, valRat.den⟩)
          .ok ⟨.numeric nu', r.toRat, false⟩) := rfl
    rw [h_def, h_u]
    dsimp [bind, Except.bind]
    rw [h_rat]
    dsimp [bind, Except.bind]
    rw [h_toRat, h_bool]

def observationToJson (o : ObservationEnc) : Lean.Json :=
  Lean.Json.mkObj [("value", packedValueFullToJson o.value), ("timestamp", Lean.Json.num o.timestamp)]

theorem decodeObservation_observationToJson (o : ObservationEnc) (h_can : PackedValueCanonical o.value) :
    decodeObservation (observationToJson o) = .ok o := by
  cases o with | mk val ts =>
  have h_val := decodePackedValue_canonical val h_can
  have h_def : decodeObservation (observationToJson ⟨val, ts⟩) = (do
      let v_dec ← decodePackedValue (packedValueFullToJson val)
      .ok ⟨v_dec, ts⟩) := rfl
  rw [h_def, h_val]
  rfl

def environmentEntryToJson (e : EnvironmentEntryEnc) : Lean.Json :=
  Lean.Json.mkObj [("key", observationKeyToJson e.key), ("observation", observationToJson e.observation)]

theorem decodeEnvironmentEntry_environmentEntryToJson (e : EnvironmentEntryEnc) (h_can : PackedValueCanonical e.observation.value) :
    decodeEnvironmentEntry (environmentEntryToJson e) = .ok e := by
  cases e with | mk k o =>
  have h_k := decodeObservationKey_observationKeyToJson k
  have h_o := decodeObservation_observationToJson o h_can
  have h_def : decodeEnvironmentEntry (environmentEntryToJson ⟨k, o⟩) = (do
      let k_dec ← decodeObservationKey (observationKeyToJson k)
      let o_dec ← decodeObservation (observationToJson o)
      .ok ⟨k_dec, o_dec⟩) := rfl
  rw [h_def, h_k, h_o]
  rfl

def environmentToJson (env : EnvironmentEnc) : Lean.Json :=
  Lean.Json.mkObj [("entries", Lean.Json.arr (env.entries.map environmentEntryToJson).toArray)]

theorem decodeEnvironment_environmentToJson (env : EnvironmentEnc) (h_can : EnvironmentCanonical env) :
    decodeEnvironment (environmentToJson env) = .ok env := by
  cases env with | mk entries =>
  dsimp [EnvironmentCanonical] at h_can
  have h_entries : (entries.map environmentEntryToJson).mapM decodeEnvironmentEntry = .ok entries := by
    apply list_mapM_decode_ok
    intro e he
    have he_can := h_can e he
    exact decodeEnvironmentEntry_environmentEntryToJson e he_can
  have h_def : decodeEnvironment (environmentToJson ⟨entries⟩) = (do
      let entArr ← Except.ok (entries.map environmentEntryToJson).toArray
      let ents ← entArr.toList.mapM decodeEnvironmentEntry
      .ok ⟨ents⟩) := rfl
  rw [h_def]
  change (do
      let ents ← (entries.map environmentEntryToJson).mapM decodeEnvironmentEntry
      Except.ok (EnvironmentEnc.mk ents)) =
    (Except.ok (EnvironmentEnc.mk entries) : Except DecodeFailure EnvironmentEnc)
  rw [h_entries]
  rfl

def domainAdminToJson (d : DomainAdminEnc) : Lean.Json :=
  Lean.Json.mkObj [("domain", domainToJson d.domain), ("party", partyToJson d.party)]

theorem decodeDomainAdmin_domainAdminToJson (d : DomainAdminEnc) :
    decodeDomainAdmin (domainAdminToJson d) = .ok d := by
  cases d with | mk dom p =>
  have h_dom := decodeDomain_domainToJson dom
  have h_p := decodeParty_partyToJson p
  have h_def : decodeDomainAdmin (domainAdminToJson ⟨dom, p⟩) = (do
      let d_dec ← decodeDomain (domainToJson dom)
      let p_dec ← decodeParty (partyToJson p)
      .ok ⟨d_dec, p_dec⟩) := rfl
  rw [h_def, h_dom, h_p]
  rfl

def inputPortToJson (p : InputPortEnc) : Lean.Json :=
  Lean.Json.mkObj [("id", Lean.Json.num p.id), ("unit", unitToJson p.unit)]

theorem decodeInputPort_inputPortToJson (p : InputPortEnc) :
    decodeInputPort (inputPortToJson p) = .ok p := by
  cases p with | mk id u =>
  have h_u := decodeUnit_unitToJson u
  have h_def : decodeInputPort (inputPortToJson ⟨id, u⟩) = (do
      let u_dec ← decodeUnit (unitToJson u)
      .ok ⟨id, u_dec⟩) := rfl
  rw [h_def, h_u]
  rfl

def outputPortToJson (p : OutputPortEnc) : Lean.Json :=
  Lean.Json.mkObj [("id", Lean.Json.num p.id), ("cell", cellToJson p.cell)]

theorem decodeOutputPort_outputPortToJson (p : OutputPortEnc) :
    decodeOutputPort (outputPortToJson p) = .ok p := by
  cases p with | mk id c =>
  have h_c := decodeCell_cellToJson c
  have h_def : decodeOutputPort (outputPortToJson ⟨id, c⟩) = (do
      let c_dec ← decodeCell (cellToJson c)
      .ok ⟨id, c_dec⟩) := rfl
  rw [h_def, h_c]
  rfl

def resourcePortToJson (rp : ResourcePortEnc) : Lean.Json :=
  Lean.Json.mkObj [("id", Lean.Json.num rp.id), ("cell", cellToJson rp.cell), ("writable", Lean.Json.bool rp.writable)]

theorem decodeResourcePort_resourcePortToJson (rp : ResourcePortEnc) :
    decodeResourcePort (resourcePortToJson rp) = .ok rp := by
  cases rp with | mk id c w =>
  have h_c := decodeCell_cellToJson c
  have h_def : decodeResourcePort (resourcePortToJson ⟨id, c, w⟩) = (do
      let c_dec ← decodeCell (cellToJson c)
      .ok ⟨id, c_dec, w⟩) := rfl
  rw [h_def, h_c]
  cases w <;> rfl

def qualifiedPortToJson (qp : QualifiedPortEnc) : Lean.Json :=
  Lean.Json.mkObj [("component", Lean.Json.num qp.component), ("port", Lean.Json.num qp.port)]

theorem decodeQualifiedPort_qualifiedPortToJson (qp : QualifiedPortEnc) :
    decodeQualifiedPort (qualifiedPortToJson qp) = .ok qp := by
  cases qp with | mk c p => rfl

def resourceImportToJson (ri : ResourceImportEnc) : Lean.Json :=
  Lean.Json.mkObj [("source", qualifiedPortToJson ri.source), ("cell", cellToJson ri.cell), ("writable", Lean.Json.bool ri.writable)]

theorem decodeResourceImport_resourceImportToJson (ri : ResourceImportEnc) :
    decodeResourceImport (resourceImportToJson ri) = .ok ri := by
  cases ri with | mk s c w =>
  have h_c := decodeCell_cellToJson c
  have h_def : decodeResourceImport (resourceImportToJson ⟨s, c, w⟩) = (do
      let c_dec ← decodeCell (cellToJson c)
      .ok ⟨s, c_dec, w⟩) := rfl
  rw [h_def, h_c]
  cases w <;> rfl

def sourcePinToJson (sp : SourcePinEnc) : Lean.Json :=
  Lean.Json.mkObj [
    ("git", Lean.Json.str sp.git),
    ("lean_toolchain", Lean.Json.str sp.lean_toolchain),
    ("mathlib_rev", Lean.Json.str sp.mathlib_rev),
    ("checker_candidate", Lean.Json.str sp.checker_candidate)
  ]

theorem decodeSourcePin_sourcePinToJson (sp : SourcePinEnc) (h_cr : sp.compiler_record = none) (h_ar : sp.audit_record = none) :
    decodeSourcePin (sourcePinToJson sp) = .ok sp := by
  cases sp with | mk git lt ml cc cr ar =>
  dsimp at h_cr h_ar
  subst h_cr h_ar
  rfl

def typesEnumToJson (te : TypesEnumEnc) : Lean.Json :=
  Lean.Json.mkObj [
    ("parties", Lean.Json.arr (te.parties.map partyToJson).toArray),
    ("assets", Lean.Json.arr (te.assets.map assetToJson).toArray),
    ("domains", Lean.Json.arr (te.domains.map domainToJson).toArray)
  ]

theorem decodeTypesEnum_typesEnumToJson (te : TypesEnumEnc) :
    decodeTypesEnum (typesEnumToJson te) = .ok te := by
  have h_p : (te.parties.map partyToJson).mapM decodeParty = .ok te.parties := by
    apply list_mapM_decode_ok; intro p _; exact decodeParty_partyToJson p
  have h_a : (te.assets.map assetToJson).mapM decodeAsset = .ok te.assets := by
    apply list_mapM_decode_ok; intro a _; exact decodeAsset_assetToJson a
  have h_d : (te.domains.map domainToJson).mapM decodeDomain = .ok te.domains := by
    apply list_mapM_decode_ok; intro d _; exact decodeDomain_domainToJson d
  have h_def : decodeTypesEnum (typesEnumToJson te) = (do
      let parties ← (te.parties.map partyToJson).mapM decodeParty
      let assets ← (te.assets.map assetToJson).mapM decodeAsset
      let domains ← (te.domains.map domainToJson).mapM decodeDomain
      .ok ⟨parties, assets, domains⟩) := rfl
  rw [h_def, h_p, h_a, h_d]
  rfl

theorem decodeStateCell_stateCellToJson (c : StateCellEnc)
    (h_den : c.amount.den ≠ 0) (h_gcd : Int.gcd c.amount.num.natAbs c.amount.den = 1) (h_nonneg : c.amount.num ≥ 0) :
    decodeStateCell (stateCellToJson c) = .ok c := by
  cases c with | mk d p a amt =>
  dsimp at h_nonneg
  have h_d := decodeDomain_domainToJson d
  have h_p := decodeParty_partyToJson p
  have h_a := decodeAsset_assetToJson a
  have h_amt : decodeRat (ratToJson amt) = .ok amt := decodeRat_ratToJson amt h_den h_gcd
  have h_def : decodeStateCell (stateCellToJson ⟨d, p, a, amt⟩) = (do
      let d_dec ← decodeDomain (domainToJson d)
      let p_dec ← decodeParty (partyToJson p)
      let a_dec ← decodeAsset (assetToJson a)
      let amt_dec ← decodeRat (ratToJson amt)
      if amt_dec.num < 0 then throw .stateNonneg
      .ok ⟨d_dec, p_dec, a_dec, amt_dec⟩) := rfl
  rw [h_def, h_d, h_p, h_a, h_amt]
  dsimp [bind, Except.bind]
  have h_neg : ¬ (amt.num < 0) := by omega
  rw [if_neg h_neg]


end DefiKernel.Certificates

