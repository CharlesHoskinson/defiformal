## Purpose

Specify the standalone token0 next-price observation, required wrap fallback, identity and refusal cases, and the Lean API that later implementation must inhabit under delivered Arithmetic and P15 contracts.

## ADDED Requirements

### Requirement: Pure helper has four inputs and no fee

The operation SHALL be `SqrtPriceMath.getNextSqrtPriceFromAmount0RoundingUp(uint160 sqrtPX96, uint128 liquidity, uint256 amount, bool add)` returning uint160. There is no fee parameter, ledger, tick, or capability field. Standalone helper admissibility is distinct from reachability inside `UniswapV3Pool.swap`.

#### Scenario: No invented ledger history
- **WHEN** a token0 observation is recorded
- **THEN** it contains only the four inputs, the uint160 result or a source revert, and no fabricated post-world

### Requirement: Zero amount is identity success

`if (amount == 0) return sqrtPX96` SHALL be treated as success identity, not a refusal.

#### Scenario: Planned identity vector
- **WHEN** inputs `(2^96, 1, 0, true)` or the same with `add=false` are applied
- **THEN** the result is `2^96`

### Requirement: Ordinary add and the removal require are both required

Planned add `(2^96, 1, 1, true)` SHALL return `2^95`. Planned removal `(2^96, 1, 1, false)` SHALL fail the source `require` that `numerator1 > product`. Ordinary removal with `numerator1 > product` SHALL succeed on the subtract-and-mulDivRoundingUp path and use `SafeCast.toUint160`, which is distinct from the add-path bare `uint160` casts.

#### Scenario: Planned add sibling
- **WHEN** inputs `(2^96, 1, 1, true)` are applied
- **THEN** product and denominator sum both fit and the result is `2^95`

#### Scenario: Removal denominator require
- **WHEN** inputs `(2^96, 1, 1, false)` are applied
- **THEN** `numerator1` equals product equals `2^96` and the helper refuses via `require`

### Requirement: Wrapped denominator-sum fallback cannot be excluded

When the product `amount * sqrtPX96` fits uint256 and `numerator1 + product` overflows uint256, Solidity 0.7.6 wraps the sum and takes `UnsafeMath.divRoundingUp(numerator1, (numerator1 / sqrtPX96).add(amount))`. Unbounded Lean `Nat` addition and `Operations.add` MUST NOT silently replace that branch. Product-overflow fallback is a separate partition.

#### Scenario: Required wrap branch
- **WHEN** sqrtP is `MAX_SQRT_RATIO-1`, liquidity is max uint128, and amount is the least value that makes the denominator sum overflow while the product still fits
- **THEN** the observation is the wrapped-sum fallback, not the primary FullMath path, and P16 MUST NOT exclude the branch to pass

### Requirement: Branch theorem states the implemented fallback under exact premises

A proved branch equation SHALL characterize the actual implemented fallback under its premises (add, amount ≠ 0, product fits, wrapped sum `< numerator1`, LowGasSafeMath.add on the inner sum). Restating an arbitrary helper is not that theorem. UnsafeMath `y==0` remains unspecified in source; Lean MUST NOT invent `divisionByZero` as if the assembly specified it.

#### Scenario: Fallback equation is premise-specific
- **WHEN** a wrap-fallback theorem is claimed
- **THEN** it names those premises and the `divRoundingUp` formula, and does not equate the result to unbounded `liquidity * sqrtP / (liquidity + amount * sqrtP)` alone

### Requirement: Typed wrap is optional for arithmetic-only P16/P18

Arithmetic-only delivery MAY return `Except Failure (Word 160)` without a Typed kernel wrapper. `P17.platform_reuse` SHALL still require an actual token0-to-kernel bridge and shared theorem instances in both cases. A P16 arithmetic-only increment MUST NOT be labelled platform reuse.

#### Scenario: Arithmetic-only increment omits Typed wrap
- **WHEN** P16 publishes model proofs and bounded source comparisons without `Typed.execute`
- **THEN** that is valid arithmetic-library scope and MUST NOT be labelled `P17.platform_reuse`
