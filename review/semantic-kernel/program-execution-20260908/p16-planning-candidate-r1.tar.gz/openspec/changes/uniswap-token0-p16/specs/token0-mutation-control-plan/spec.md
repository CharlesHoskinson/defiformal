## Purpose

Correct the original M09/F28 control plan by diagnosis, and define compiled production token0 mutants with designated witnesses and unaffected controls. Compiled M09 SwapMath execution remains P21.

## ADDED Requirements

### Requirement: M09 must not treat F28 as a protected control

Original mutant M09 flips `zeroForOne` from `current >= target` to `current < target`. On original F28 that change moves `amountIn` from 2 to 1. P16 SHALL exclude F28 as protected, preserve the failed original plan, and MUST NOT claim compiled M09 execution.

#### Scenario: F28 amountIn 2 becomes 1
- **WHEN** original F28 `(Q96, Q96-1, Q96, 1000, 3000)` is evaluated under the flipped predicate
- **THEN** `amountIn` changes from 2 to 1 and F28 is removed from M09's protected/sibling set

### Requirement: Named unaffected sibling is actually diagnosed

The repaired M09 unaffected sibling SHALL be original F32 (`feePips = 1e6` → `invalidFee`), because that refusal is decided before the direction predicate. F33 is an additional same-module control. F29 MUST NOT be named, even if some numeric fields stay put, because `zeroForOne` still flips.

#### Scenario: F32 invalidFee is unchanged under M09
- **WHEN** F32 is evaluated with the original and flipped predicates
- **THEN** both refuse `invalidFee` and F32 is the named sibling in the control plan

### Requirement: Production token0 mutants have designated false witnesses and controls

P16 production mutants SHALL edit the pinned helper (or the Lean implementation of that helper) at named sites, compile with the pinned compiler when source mutants are scored, and carry an individually verified unaffected control. Python-only edits earn no production credit. Compile failure is blocked, not detection.

#### Scenario: Skip wrap-fallback mutant
- **WHEN** mutant T0-WRAP-SKIP always takes the primary FullMath path
- **THEN** P16-WRAP is designated false and P16-ADD remains an unaffected control

#### Scenario: Skip identity short-circuit mutant
- **WHEN** mutant T0-ID-SKIP removes `if (amount == 0) return sqrtPX96`
- **THEN** P16-I-ADD is designated false and P16-ADD remains an unaffected control
