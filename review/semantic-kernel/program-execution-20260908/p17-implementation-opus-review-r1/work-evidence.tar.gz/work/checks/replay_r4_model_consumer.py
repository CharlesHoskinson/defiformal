#!/usr/bin/env python3
"""OPUS REVIEW: R3 model-consumer boundary falsifiers RETARGETED at the frozen R4 engine.

Provenance: this is a review-authored copy of the boundary checks in
review/semantic-kernel/program-execution-20260908/p17-agy-r3-model-consumer-precheck/replay.py.
That original script imports the FROZEN R3 engine
(p17-agy-r3-final-protocol-precheck/engine) and root repo paths, so running it
does NOT test R4. This copy points at the R4 candidate engine in the reviewer's
private sandbox and uses the reviewer's OWN fresh deployment, genesis and Lean
model rows produced in work/campaigns/vault-r1 and token0-r1.

Only the model recorder is substituted in the receipt checks; no fresh Lean
credit and no compiled-mutant credit is claimed here.
"""
from pathlib import Path
import sys, json, copy

SANDBOX = Path("/home/charl/.cache/defiformal-program/program-execution-20260908/p17-opus-review-sandbox")
ENGINE = SANDBOX / "scripts/platform_engine"
WORK = Path(__file__).resolve().parent
OUT = WORK / "r4-model-consumer"
sys.dont_write_bytecode = True
sys.path.insert(0, str(ENGINE))

import common, vault_exec, token0_campaign  # noqa: E402

VAULT_RUN = WORK.parent / "campaigns/vault-r1/opus-review-1"
TOKEN0_RUN = WORK.parent / "campaigns/token0-r1/opus-review-1"

addresses = json.loads((VAULT_RUN / "evm/execute/deploy/addresses.json").read_text())
genesis = VAULT_RUN / "evm/execute/deploy/create-proxy/genesis.json"
assert genesis.is_file(), genesis
vault_summary = json.loads((VAULT_RUN / "lean/vault/bindings-summary.json").read_text())
intact = vault_summary["parsed"]

results = []

model_cases = [
    ("intact", lambda x: x, 0),
    ("missing-all-cells", lambda x: (x["P17-DEP-D0"].pop("cells"), x)[1], 3),
    ("missing-one-cell", lambda x: (x["P17-DEP-D0"]["cells"].pop("susds.totalSupply"), x)[1], 3),
    ("missing-model-row", lambda x: {}, 3),
]
for name, modify, expected in model_cases:
    rows = modify(copy.deepcopy(intact))
    out = OUT / "execution" / name
    out.mkdir(parents=True, exist_ok=True)
    got = vault_exec.run_fixtures(out, addresses, genesis, fixture_ids=["P17-DEP-D0"], lean_rows=rows)
    results.append({
        "id": name,
        "kind": "actual R4 EVM public consumer with reviewer-run model rows, modified as named",
        "expected_consumer_exit": expected,
        "actual_score": got,
        "matched": got.get("exit") == expected,
    })

receipt_cases = [
    ("intact-receipt", {}, False),
    ("nonzero-receipt", {"exit": 1, "classification": "nonzero"}, True),
    ("blocked-receipt-zero-exit", {"exit": 0, "classification": "timeout_blocked", "valid": False, "timeout": True}, True),
]
for module, run_dir, prefix in [(vault_exec, VAULT_RUN, "vault"), (token0_campaign, TOKEN0_RUN, "token0")]:
    summary = json.loads((run_dir / f"lean/{prefix}/bindings-summary.json").read_text())
    stdout_path = run_dir / f"lean/{prefix}/bindings/stdout.bin"
    assert stdout_path.is_file(), stdout_path
    orig_record_cmd = module.record_cmd
    for name, changes, expect_block in receipt_cases:
        receipt = copy.deepcopy(summary["receipt"])
        receipt.update(changes)
        receipt.setdefault("_wrapper", {})["stdout_path"] = str(stdout_path)
        module.record_cmd = lambda *a, _rec=receipt, **k: copy.deepcopy(_rec)
        func = module.run_lean_vault_bindings if prefix == "vault" else module.run_lean_token0_bindings
        error, parsed = None, {}
        try:
            parsed = func(OUT / "parser-execution" / f"{prefix}-{name}")
        except Exception as exc:
            error = f"{type(exc).__name__}: {exc}"
        blocked = error is not None or not parsed
        results.append({
            "id": f"{prefix}-{name}",
            "kind": "R4 model parser with disclosed recorder substitution",
            "expected_blocked": expect_block,
            "actual_blocked": blocked,
            "rows_returned": len(parsed),
            "exception": error,
            "matched": blocked == expect_block,
        })
    module.record_cmd = orig_record_cmd

report = {
    "scope": "Reviewer-retargeted R3 boundary falsifiers against the frozen R4 candidate engine. "
             "Not full acceptance; no fresh Lean or compiled production mutant credit claimed here.",
    "engine": str(ENGINE),
    "checks": len(results),
    "matched": sum(x["matched"] for x in results),
    "results": results,
}
OUT.mkdir(parents=True, exist_ok=True)
(OUT / "results.json").write_text(json.dumps(report, indent=2) + "\n")
print(json.dumps({"checks": report["checks"], "matched": report["matched"],
                  "failed_ids": [x["id"] for x in results if not x["matched"]]}))
raise SystemExit(0 if report["matched"] == report["checks"] else 1)
