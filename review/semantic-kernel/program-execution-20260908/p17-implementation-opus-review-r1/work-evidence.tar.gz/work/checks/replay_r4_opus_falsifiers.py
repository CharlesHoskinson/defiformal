#!/usr/bin/env python3
"""OPUS REVIEW: additional falsifying controls authored by the reviewer against the
frozen R4 engine, beyond the author's 10-check boundary suite.

Purpose: show the R4 consumer's checks DISCRIMINATE (can fail) and are correctly
classified as 1 (demonstrated semantic false) vs 3 (missing/malformed/unavailable).
Model rows are the reviewer's own fresh Lean output, perturbed as named.
No fresh Lean or compiled-mutant credit is claimed here.
"""
from pathlib import Path
import sys, json, copy

SANDBOX = Path("/home/charl/.cache/defiformal-program/program-execution-20260908/p17-opus-review-sandbox")
ENGINE = SANDBOX / "scripts/platform_engine"
WORK = Path(__file__).resolve().parent
OUT = WORK / "r4-opus-falsifiers"
sys.dont_write_bytecode = True
sys.path.insert(0, str(ENGINE))
import vault_exec  # noqa: E402

VAULT_RUN = WORK.parent / "campaigns/vault-r1/opus-review-1"
addresses = json.loads((VAULT_RUN / "evm/execute/deploy/addresses.json").read_text())
genesis = VAULT_RUN / "evm/execute/deploy/create-proxy/genesis.json"
intact = json.loads((VAULT_RUN / "lean/vault/bindings-summary.json").read_text())["parsed"]


def perturb_cell(rows):
    rows["P17-DEP-D0"]["cells"]["usds.balance.vault"] = "1"
    return rows


def perturb_value(rows):
    rows["P17-DEP-D0"]["value"] = 12345
    return rows


def wrong_refusal_label(rows):
    rows["P17-DEP-BAD-RECV"]["failure"] = "SUsds/insufficient-balance"
    return rows


def unmapped_refusal_label(rows):
    rows["P17-DEP-BAD-RECV"]["failure"] = "SUsds/not-a-real-error"
    return rows


def model_ok_where_source_reverts(rows):
    rows["P17-DEP-BAD-RECV"] = {"id": "P17-DEP-BAD-RECV", "status": "ok", "value": 0,
                                "cells": copy.deepcopy(intact["P17-DEP-D0"]["cells"])}
    return rows


def model_error_where_source_succeeds(rows):
    rows["P17-DEP-D0"] = {"id": "P17-DEP-D0", "status": "error", "failure": "SUsds/invalid-address"}
    return rows


CASES = [
    # (name, fixture_ids, perturbation, expected_exit, why)
    ("c1-intact-control", ["P17-DEP-D0", "P17-DEP-BAD-RECV"], lambda r: r, 0,
     "intact control must stay green"),
    ("c2-model-cell-perturbed", ["P17-DEP-D0"], perturb_cell, 1,
     "one wrong model poststate cell is a demonstrated semantic false"),
    ("c3-model-return-value-perturbed", ["P17-DEP-D0"], perturb_value, 1,
     "wrong model return value is a demonstrated semantic false"),
    ("c4-wrong-refusal-label", ["P17-DEP-BAD-RECV"], wrong_refusal_label, 1,
     "mapped-but-wrong refusal reason is a semantic false"),
    ("c5-unmapped-refusal-label", ["P17-DEP-BAD-RECV"], unmapped_refusal_label, 3,
     "unmapped refusal label is unavailable evidence -> blocked"),
    ("c6-model-ok-where-source-reverts", ["P17-DEP-BAD-RECV"], model_ok_where_source_reverts, 1,
     "model claims success where source refuses: a demonstrated semantic false"),
    ("c7-model-error-where-source-succeeds", ["P17-DEP-D0"], model_error_where_source_succeeds, 1,
     "model claims refusal where source succeeds: a demonstrated semantic false"),
]

results = []
for name, fids, fn, expected, why in CASES:
    rows = fn(copy.deepcopy(intact))
    out = OUT / name
    out.mkdir(parents=True, exist_ok=True)
    got = vault_exec.run_fixtures(out, addresses, genesis, fixture_ids=fids, lean_rows=rows)
    results.append({
        "id": name, "rationale": why, "fixture_ids": fids,
        "expected_exit": expected, "actual_exit": got.get("exit"),
        "actual_status": got.get("status"), "actual_reason": got.get("reason"),
        "counts": {k: got.get(k) for k in ("ok", "fail", "blocked", "denominator")},
        "matched": got.get("exit") == expected,
    })

report = {
    "scope": "Reviewer-authored discrimination controls against the frozen R4 candidate engine.",
    "engine": str(ENGINE),
    "checks": len(results),
    "matched": sum(r["matched"] for r in results),
    "results": results,
}
OUT.mkdir(parents=True, exist_ok=True)
(OUT / "results.json").write_text(json.dumps(report, indent=2) + "\n")
print(json.dumps({"checks": report["checks"], "matched": report["matched"],
                  "failed_ids": [r["id"] for r in results if not r["matched"]]}))
