# P35 Atlas repair candidate r2 — native Grok 4.6

**Result: a scoped repair candidate is ready for independent GPT-6 review. It does not accept itself, close P35, or validate P36.**

Author: native Grok 4.6 (`grok-4.6-build` in this session). Checker: independent GPT-6 next. No Foreman. No subagents. No commit or push.

Worktree: `/home/charl/defiformal-wt-atlas-grok-gpt6-20260908`  
Frozen failed candidate archive (unchanged, not overwritten): SHA-256 `56c3a1d532669f229e9c67f7e25f3253bedabd9baad5ae4942f306ef9c487db6` (89 members).  
This candidate dist: `viz/dist/index.html` SHA-256 `2049b65f9f8b617d8ea2470ad3d73f22b1acee2c88f93c88fa5b7c2a722fa9e8` (173989 bytes, gzip 52811).

## Required repairs

| ID | Review finding | This candidate |
|---|---|---|
| AR1 | Four of six Flat combinations were a permutation of the selected order; order change left `#live` empty | All six Flat arrangement/order combinations match declared DOM/accessibility order. Packed depth/family visual structure remains (5 bands; family blocks). Live region is outside `render()` wipe; order change announces `Reading order: …`. Pre-fix probe: permutation + empty live. Post-fix probe and e2e: exact order + announcement. The old permutation exemption is removed; a permutation-only assertion is a fail. |
| AR2 | CSS3D camera spring still interpolated under `prefers-reduced-motion`; `getAnimations()==0` and tile-local transforms missed it | `scene3d.ts` snaps yaw/pitch/target when `reduce` is set. Reduced-motion 3D focus: rendered dy=0 over 40 frames. Normal-motion control still moves (dy≈5.3). Flat focus control is stationary. |
| AR3 | `render()` re-entered 3D on Laws/Hazards and overlaid 59 tiles | Scene re-entry is `state.three && state.view === "elements"` only. Flat and 3D → Laws/Hazards: 0 tiles, rules visible, no tile-over-rule hit test. Return to The table restores tiles; 3D state is kept. |

Pre-fix red probe (frozen before dist `a807f92d…`): 14 fails / 1 ok, exit 1. Post-fix green probe: 15 ok / 0 fail, exit 0. Those 15 are not the e2e suite.

## Remaining P35 work executed in this candidate

- **Search list:** `#search-results` listbox; unique `E001` yields one visible option and 1 accessibility-exposed table tile; Enter opens that detail; zero-results shows `No matching elements.` and announces `0 of 59`. Dimming-only is no longer the find path.
- **Visible badges:** face text is the visual-language phrase (`core`, `candidate: recurrence evidence short`, `contested: note required`, `degenerate limit: not an element`). 59/59 table badges matched. Accessible names already had the nine fields and still do.
- **Dimension `aria-pressed`:** immediately after 3D, Flat=`false`, 3D=`true`.
- **200% zoom:** Playwright Chromium 149.0.7827.55 accepts `Emulation.setPageScaleFactor(2)` but layout metrics do not change. That is **not** 200% browser zoom and is **not** a pass. Root `font-size` 16px→32px is a proxy: name 11px→22px, badge 10.4px→20.8px, no horizontal document overflow. Ctrl-F UI was not observed. `window.find` found a real name and rejected an impossible string.
- **Print:** `emulate_media(print)` DOM innerText contains 59 table IDs (bounded print text). Chromium `page.pdf` **without** `beforeprint` omitted those IDs (retained as a failed print-PDF observation). With `beforeprint` (the browser print event), `pdftotext` finds `E001` and `CSM`. Visual print quality is not accepted.
- **Deep link:** fresh `#E001` load opens the E001 detail dialog.
- **Screenshots:** actual UI at 1600×1000, 1920×1200, 1280×800, 900×700 plus `root-font-200.png`. Disavowal in first viewport; no overlapping visible tiles in those captures. Not a contrast audit.
- **README / atlas document** still point at each other and `viz/` exists. `design.md` bytes were not edited (`e643c5e7033cf7f8b7d4e11fb7dd676d79725151cbad277e6e4ee61c5d63c5fb`). Open-question dispositions remain those already registered there.

## Preserved checks (fresh, not the historical 238)

| Check | Result | Notes |
|---|---|---|
| Nine-field table names | 59/59, 0 missing fields | e2e `run_names`; not author-238 |
| Per-element status | fixture-positive exit 0; 69 rows compared | Isolated copy only |
| Count-preserving E001/E057 status swap | fixture-status-swap exit 1 | Negative control; names the two drifted rows |
| Missing E001 document row | fixture-missing-row exit 1 | Negative control; `uncovered for E001` |
| Restored fixture | exit 0 | |
| TypeScript `--noEmit` | exit 0 | |
| Isolated Vite build + conformance | exit 0 | gzip 52811 < current 150 KiB harness threshold; CSS3D remains admitted |
| 12 keyboard combinations | 12/12 DOM order, 12/12 ArrowRight, Enter/Escape/focus restore | Settled `dialog.open`; not whole accessibility acceptance |
| README cross-reference | true | |

e2e on the resulting page: **328 `ok` lines, 0 `FAIL`, exit 0**, plus **2 residual lines** that are not passes. Semantic e2e assertions and the isolated conformance mutations are counted separately. An arbitrary nonzero command is not a caught regression; the swap/missing-row controls are.

## Explicit residuals (not passes)

1. Actual 200% **browser zoom** was not observed on installed Playwright Chromium 149. CDP page-scale is a no-op for layout.
2. **Ctrl-F find-in-page UI** was not exercised; only `window.find`.
3. **Visual print quality** is not accepted. PDF text with `beforeprint` is bounded evidence only.
4. Root-font proxy grew glyph size; overlay tile **width** stayed ~131px while height/fonts grew. Not claimed as complete all-layout 200% parity.
5. Browser accessibility-tree / screen-reader session: not a real AT run.
6. Historical author 238 remains author evidence, not acceptance.
7. P36 scientific ontology/graph was not started. Frozen planning bytes were not edited.
8. Independent GPT-6 review of this candidate has not run.

## Failed attempts retained

- `logs/red-probe.json` / `red-probe.stdout.log`: pre-fix product fails, exit 1.
- `logs/e2e.failed-zoom-r1.*`: first full e2e, exit 1, treated ineffective CDP zoom as a product fail. Later reclassified as residual; not erased.
- Chromium PDF without `beforeprint` omitted table IDs. Regenerated PDF after dispatching that event.

Harness/setup: Playwright 1.60.0, cached Chromium 149.0.7827.55 executable SHA-256 `2d18db9d8608b052b6a552ee00ec1e830f93692e928b65ecc67d693bd33fe801`. Node v24.18.1, npm 11.16.0, three 0.185.1, vite 8.2.0, typescript 7.0.2. File URL bound to this worktree. No network install campaign.

## Scope limits

Lean, corpus, kernel, and frozen OpenSpec planning bytes were not edited. `viz/src/data.ts` remains `4227433a8a965f9890a6c277991189f1c5087fab336a3ba146d9949026dfeb84`. Packed Flat/3D and depth/family layouts are kept. The 16×5 matrix, 3D ban, and superseded 150KB-no-three budget were not revived.

This directory is author evidence for independent GPT-6. Do not treat worker authorship as P35 acceptance.
