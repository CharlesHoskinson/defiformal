"""Pre-fix probe: the new assertions must fail on the frozen candidate page."""
from __future__ import annotations

import json
import sys
from pathlib import Path

from playwright.sync_api import sync_playwright

sys.path.insert(0, str(Path("/home/charl/defiformal-wt-atlas-grok-gpt6-20260908/viz/test")))
from atlas_contract import STATUS_WORD, declared_order, load_atlas

ROOT = Path("/home/charl/defiformal-wt-atlas-grok-gpt6-20260908")
URL = (ROOT / "viz/dist/index.html").resolve().as_uri()
CHROME = str(Path.home() / ".cache/ms-playwright/chromium-1228/chrome-linux64/chrome")
OUT = Path(__file__).resolve().parent / "logs"
OUT.mkdir(parents=True, exist_ok=True)

fails, notes = [], []


def check(cond, msg):
    (notes if cond else fails).append(("ok  " if cond else "FAIL ") + msg)
    return bool(cond)


def click(page, name):
    page.get_by_role("button", name=name, exact=True).click()
    page.wait_for_timeout(250)


atlas = load_atlas()
expected = {k: [e.id for e in declared_order(atlas["elements"], k)] for k in ("group", "stratum", "id")}
result = {"url": URL, "chrome": CHROME}

with sync_playwright() as pw:
    browser = pw.chromium.launch(executable_path=CHROME, args=["--no-sandbox", "--disable-gpu"])
    page = browser.new_page(viewport={"width": 1600, "height": 1000})
    page.goto(URL)
    page.wait_for_function("() => document.querySelectorAll('#table .tile').length >= 1")
    result["dom_orders"] = {}
    for arr, ord_label, key in (("By depth", "By group", "group"), ("By depth", "By ID", "id"), ("By family", "By ID", "id")):
        click(page, "Flat")
        click(page, arr)
        click(page, ord_label)
        ids = page.evaluate("() => Array.from(document.querySelectorAll('#table button.tile')).map(t => t.dataset.id)")
        live = page.locator("#live").inner_text()
        perm = sorted(ids) == sorted(expected[key]) and ids != expected[key]
        result["dom_orders"][f"{arr}/{ord_label}"] = {"dom0": ids[:5], "exp0": expected[key][:5], "equal": ids == expected[key], "permutation": perm, "live": live}
        check(not perm, f"AR1 {arr}/{ord_label}: permutation-only is a fail")
        check(ids == expected[key], f"AR1 {arr}/{ord_label}: exact DOM order")
        check(bool(live.strip()), f"AR1 live after {ord_label} ({live!r})")

    badges = page.evaluate("() => Array.from(document.querySelectorAll('#table button.tile')).map(t => ({id:t.dataset.id, badge:(t.querySelector('.t-badge')||{}).innerText||''}))")
    by_id = {e.id: e for e in atlas["elements"]}
    bad = [b for b in badges if by_id[b["id"]].status != "core" and STATUS_WORD[by_id[b["id"]].status] not in (b["badge"] or "")]
    result["bad_badges"] = bad[:8]
    check(not bad, f"badges full phrases ({len(bad)} short)")

    page.get_by_role("button", name="3D", exact=True).click()
    page.wait_for_timeout(50)
    aria = page.evaluate("""() => {
      const btns = Array.from(document.querySelectorAll('.controls .seg button'));
      const hit = (l) => (btns.find(b => b.textContent.trim()===l)||{}).getAttribute('aria-pressed');
      return {flat: hit('Flat'), three: hit('3D')};
    }""")
    result["aria_after_3d"] = aria
    check(aria["flat"] == "false" and aria["three"] == "true", f"Dimension aria-pressed after 3D {aria}")
    page.wait_for_timeout(800)
    click(page, "Laws")
    page.wait_for_timeout(300)
    laws = page.evaluate("() => ({tiles: document.querySelectorAll('#table button.tile').length, rules: document.querySelectorAll('#table .rule').length})")
    result["laws_after_3d"] = laws
    check(laws["tiles"] == 0, f"AR3 3D->Laws tiles={laws['tiles']}")
    check(laws["rules"] >= 20, f"AR3 3D->Laws rules={laws['rules']}")
    click(page, "The table")
    page.wait_for_timeout(400)
    click(page, "Flat")
    page.fill("#q", "E001")
    page.wait_for_timeout(150)
    search = page.evaluate("""() => ({
      listbox: !!document.querySelector('#search-results, [role=listbox]'),
      tiles: document.querySelectorAll('#table button.tile').length,
    })""")
    result["search"] = search
    check(search["listbox"], "search listbox exists")

    rm = browser.new_page(viewport={"width": 1600, "height": 1000})
    rm.emulate_media(reduced_motion="reduce")
    rm.goto(URL)
    rm.wait_for_function("() => document.querySelectorAll('#table .tile').length >= 1")
    click(rm, "3D")
    rm.wait_for_timeout(200)
    handle = rm.locator('#table .tile[tabindex="0"]')
    handle.first.focus()
    frames = rm.evaluate("""() => new Promise(resolve => {
      const t = document.querySelector('#table .tile[tabindex="0"]') || document.querySelector('#table .tile');
      const out = [];
      let i = 0;
      const tick = () => {
        const r = t.getBoundingClientRect();
        let n = t, anc = null;
        while (n && n !== document.body) {
          const tr = getComputedStyle(n).transform;
          if (tr && tr !== 'none') { anc = tr; break; }
          n = n.parentElement;
        }
        out.push({y:r.y, h:r.height, anc});
        i++;
        if (i < 40) requestAnimationFrame(tick); else resolve(out);
      };
      requestAnimationFrame(tick);
    })""")
    ys = [f["y"] for f in frames]
    hs = [f["h"] for f in frames]
    ancs = {f["anc"] for f in frames}
    motion = {"dy": max(ys)-min(ys), "dh": max(hs)-min(hs), "ancestors": len(ancs)}
    result["reduced_focus"] = motion
    check(motion["dy"] < 1 and motion["dh"] < 1 and len(ancs) <= 2, f"AR2 reduced focus stable {motion}")
    browser.close()

result["fails"] = fails
result["notes"] = notes
(OUT / "red-probe.json").write_text(json.dumps(result, indent=2) + "\n")
print("\n".join(notes + fails))
print(f"FAILS {len(fails)} OK {len(notes)}")
sys.exit(1 if fails else 0)
