import DefiKernel.Certificates.Schema
import DefiKernel.Certificates.Decode
import DefiKernel.Certificates.Check
import DefiKernel.Certificates.Observation

namespace DefiKernel.Certificates

set_option linter.style.longLine false

/-! Correspondence theorems and open remainder obligations for serialized certificates.
In accordance with P19 specifications and RC01/P20 gates:
- Exact codec, raw execution, and checker success/error correspondence theorems are proven.
- Component-level roundtrip theorems (rational, party, asset, domain, right) are proven.
- Bounded finite fixture evidence (F25, F27, F28, etc.) is verified computationally.
- Universal quantified statements (T-roundtrip, T-canonical-bytes) are explicitly defined over
  a nonempty structurally admissible canonical IR domain. General parser inversion remains a P20 gate.
- Strictly zero `sorry`, custom axioms, or `native_decide` are used in accepted kernel proofs. -/

/-- Structurally admissible canonical IR domain covering the accepted 32-cell execution universe.
    Requires:
    1. Schema version 1, mode matching the payload type.
    2. Complete 32-cell state table with amounts satisfying canonical lowest-terms:
       num ≥ 0, den > 0, gcd(num.natAbs, den) = 1.
    3. Unique registry entries, unique store entries, and supported step forms (invoke, issue, revoke). -/
def StructurallyAdmissibleIR (ir : DecodedIR) : Prop :=
  match ir with
  | .execution (.typed env payload) =>
    env.schema_version = 1 ∧
    env.mode = "typed-execute" ∧
    payload.state.cells.length = 32 ∧
    payload.state.cells.all (fun c ↦ c.amount.den > 0 ∧ c.amount.num ≥ 0 ∧ Int.gcd c.amount.num.natAbs c.amount.den = 1) = true ∧
    (payload.registry.entries.map (·.id)).Nodup
  | .execution (.step env payload) =>
    env.schema_version = 1 ∧
    env.mode = "composition-step" ∧
    (match payload.step with | .unsupported _ => False | _ => True) ∧
    payload.pre.state.cells.length = 32 ∧
    payload.pre.state.cells.all (fun c ↦ c.amount.den > 0 ∧ c.amount.num ≥ 0 ∧ Int.gcd c.amount.num.natAbs c.amount.den = 1) = true ∧
    (payload.config.registry.entries.map (·.id)).Nodup
  | .execution (.run env payload) =>
    env.schema_version = 1 ∧
    env.mode = "composition-run" ∧
    payload.steps.all (fun s ↦ match s with | .unsupported _ => false | _ => true) = true ∧
    payload.world.state.cells.length = 32 ∧
    payload.world.state.cells.all (fun c ↦ c.amount.den > 0 ∧ c.amount.num ≥ 0 ∧ Int.gcd c.amount.num.natAbs c.amount.den = 1) = true ∧
    (payload.config.registry.entries.map (·.id)).Nodup
  | .audit _ => False
  | .codec _ => False

/-- Nonempty witness for StructurallyAdmissibleIR: a standard 32-cell zero-initialized state
    with canonical 0/1 rationals, schema version 1, and typed-execute mode. -/
def standard32Cells : List StateCellEnc :=
  let parties : List Party := [.alice, .bob, .vault, .pool]
  let assets : List Asset := [.usd, .share, .collateral, .debt]
  let domains : List Domain := [.main, .other]
  domains.flatMap fun d ↦
    parties.flatMap fun p ↦
      assets.map fun a ↦
        ⟨d, p, a, ⟨0, 1⟩⟩

def canonicalWitnessIR : DecodedIR :=
  .execution (.typed
    ⟨1, "typed-execute", ⟨"a12b7cac05a818cc8d35c2ca440b7170a2807e92", "leanprover/lean4:v4.33.0-rc2",
      "51e6992efd06126df61a496bebf8f49482a4e129", "", none, none⟩,
      ["DefiKernel.Certificates", "DefiKernel.Typed", "DefiKernel.Composition"],
      ⟨[.alice, .bob, .vault, .pool], [.usd, .share, .collateral, .debt], [.main, .other]⟩,
      ["environment-authenticity"], [], [], [], [], none, false, false⟩
    ⟨⟨[]⟩, ⟨[]⟩, ⟨.alice, .main⟩, ⟨[]⟩, 100, ⟨0, [.alice], [], [], some .alice⟩, ⟨standard32Cells⟩⟩)

/-- Theorem: StructurallyAdmissibleIR is nonempty. -/
theorem structurallyAdmissible_nonempty : StructurallyAdmissibleIR canonicalWitnessIR := by
  dsimp [canonicalWitnessIR, StructurallyAdmissibleIR, standard32Cells]
  refine ⟨rfl, rfl, rfl, ?_, List.nodup_nil⟩
  decide

/-- Statement of universal roundtrip obligation (RC01 / P20 open obligation).
    Quantifies over every structurally admissible canonical IR. -/
def EncodeDecodeRoundtripStatement : Prop :=
  ∀ (ir : DecodedIR), StructurallyAdmissibleIR ir → decodeBytes (encodeModule ir) = .ok ir

/-- Statement of canonical bytes obligation (P20 open obligation). -/
def DecodeEncodeCanonicalBytesStatement : Prop :=
  ∀ raw ir, decodeBytes raw = .ok ir → StructurallyAdmissibleIR ir → encodeModule ir = raw

/-- Refused decode returns no kernel object (S39-S40, S78). -/
theorem decode_error_no_kernel (raw : ByteArray) (e : DecodeFailure)
    (h : decodeBytes raw = .error e) (h_not_res : ∀ lim, e ≠ .resourceLimit lim) :
    checkBytes raw = .codec (.malformed e) := by
  dsimp [checkBytes]
  rw [h]
  cases e with
  | resourceLimit lim =>
    exfalso
    exact h_not_res lim rfl
  | emptyDocument => rfl
  | lexicalScientificOrFloat => rfl
  | notJsonObject => rfl
  | duplicateKey _ => rfl
  | noncanonicalWhitespace => rfl
  | schemaVersion => rfl
  | missingField _ => rfl
  | jsonType _ => rfl
  | unknownIdentifier _ => rfl
  | uniqueness _ => rfl
  | illegalRational _ => rfl
  | stateNonneg => rfl
  | unknownExecutableField _ => rfl
  | unsupportedForm _ => rfl

/-- Resource limit decode refusal maps to blocked codec result. -/
theorem decode_error_resource_limit (raw : ByteArray) (lim : String)
    (h : decodeBytes raw = .error (.resourceLimit lim)) :
    checkBytes raw = .codec (.blocked lim) := by
  dsimp [checkBytes]
  rw [h]

/-- Any decode error produces a CodecResult outcome, guaranteeing no kernel entrypoint is invoked. -/
theorem checkBytes_no_kernel_on_error (raw : ByteArray) (e : DecodeFailure)
    (h : decodeBytes raw = .error e) :
    ∃ (c : CodecResult), checkBytes raw = .codec c := by
  dsimp [checkBytes]
  rw [h]
  cases e with
  | resourceLimit lim => exact ⟨.blocked lim, rfl⟩
  | emptyDocument => exact ⟨.malformed .emptyDocument, rfl⟩
  | lexicalScientificOrFloat => exact ⟨.malformed .lexicalScientificOrFloat, rfl⟩
  | notJsonObject => exact ⟨.malformed .notJsonObject, rfl⟩
  | duplicateKey k => exact ⟨.malformed (.duplicateKey k), rfl⟩
  | noncanonicalWhitespace => exact ⟨.malformed .noncanonicalWhitespace, rfl⟩
  | schemaVersion => exact ⟨.malformed .schemaVersion, rfl⟩
  | missingField m => exact ⟨.malformed (.missingField m), rfl⟩
  | jsonType p => exact ⟨.malformed (.jsonType p), rfl⟩
  | unknownIdentifier u => exact ⟨.malformed (.unknownIdentifier u), rfl⟩
  | uniqueness k => exact ⟨.malformed (.uniqueness k), rfl⟩
  | illegalRational r => exact ⟨.malformed (.illegalRational r), rfl⟩
  | stateNonneg => exact ⟨.malformed .stateNonneg, rfl⟩
  | unknownExecutableField f => exact ⟨.malformed (.unknownExecutableField f), rfl⟩
  | unsupportedForm r => exact ⟨.malformed (DecodeFailure.unsupportedForm r), rfl⟩

/-- Successful decode routes directly to checkIR. -/
theorem checkBytes_ok (raw : ByteArray) (ir : DecodedIR)
    (h : decodeBytes raw = .ok ir) :
    checkBytes raw = checkIR ir := by
  dsimp [checkBytes]
  rw [h]

/-- CheckBytes for typed execution payload routes directly to checkTyped. -/
theorem checkBytes_typed_correspondence (raw : ByteArray) (env : EnvelopeEnc) (payload : TypedExecutePayloadEnc)
    (h_dec : decodeBytes raw = .ok (.execution (.typed env payload))) :
    checkBytes raw = .execution (checkTyped env payload) := by
  have h := checkBytes_ok raw (.execution (.typed env payload)) h_dec
  rw [h]
  rfl

/-- CheckBytes for composition step payload routes directly to checkStep. -/
theorem checkBytes_step_correspondence (raw : ByteArray) (env : EnvelopeEnc) (payload : CompositionStepPayloadEnc)
    (h_dec : decodeBytes raw = .ok (.execution (.step env payload))) :
    checkBytes raw = .execution (checkStep env payload) := by
  have h := checkBytes_ok raw (.execution (.step env payload)) h_dec
  rw [h]
  rfl

/-- CheckBytes for composition run payload routes directly to checkRun. -/
theorem checkBytes_run_correspondence (raw : ByteArray) (env : EnvelopeEnc) (payload : CompositionRunPayloadEnc)
    (h_dec : decodeBytes raw = .ok (.execution (.run env payload))) :
    checkBytes raw = .execution (checkRun env payload) := by
  have h := checkBytes_ok raw (.execution (.run env payload)) h_dec
  rw [h]
  rfl

/-- Canonical rational decoding theorem: canonical numerator/denominator pair decodes to RatEnc. -/
theorem rational_decode_canonical (num : Int) (den : Nat) (h_den : den ≠ 0) (h_gcd : Int.gcd num.natAbs den = 1) :
    decodeRational num den = .ok ⟨num, den⟩ := by
  unfold decodeRational
  split
  · contradiction
  · split
    · rename_i h_noncan
      have h1 : ¬ (Int.gcd num.natAbs den ≠ 1) := by
        intro h_contra
        exact h_contra h_gcd
      contradiction
    · rfl

/-- Exact correspondence between RatEnc and ℚ components. -/
theorem rat_fromRat_num_den (q : ℚ) :
    (RatEnc.fromRat q).num = q.num ∧ (RatEnc.fromRat q).den = q.den :=
  ⟨rfl, rfl⟩

/-- Rational encode/decode roundtrip: any canonical rational roundtrips via decodeRational. -/
theorem rational_roundtrip (r : RatEnc) (h_den : r.den ≠ 0) (h_gcd : Int.gcd r.num.natAbs r.den = 1) :
    decodeRational r.num r.den = .ok r :=
  rational_decode_canonical r.num r.den h_den h_gcd

/-- Party decode roundtrip. -/
theorem decodeParty_encodeParty (p : Party) :
    decodeParty (.str (match p with | .alice => "alice" | .bob => "bob" | .vault => "vault" | .pool => "pool")) = .ok p := by
  cases p <;> rfl

/-- Asset decode roundtrip. -/
theorem decodeAsset_encodeAsset (a : Asset) :
    decodeAsset (.str (match a with | .usd => "usd" | .share => "share" | .collateral => "collateral" | .debt => "debt")) = .ok a := by
  cases a <;> rfl

/-- Domain decode roundtrip. -/
theorem decodeDomain_encodeDomain (d : Domain) :
    decodeDomain (.str (match d with | .main => "main" | .other => "other")) = .ok d := by
  cases d <;> rfl

/-- Right decode roundtrip for invoke. -/
theorem decodeRight_invoke :
    decodeRight (Lean.Json.mkObj [("tag", Lean.Json.str "invoke")]) = .ok .invoke := by
  dsimp [decodeRight, checkObjectKeys, getField, Lean.Json.mkObj]
  rfl

end DefiKernel.Certificates
