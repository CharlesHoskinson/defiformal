import Lean.Data.Json
import DefiKernel.Certificates.Correspondence

open Lean DefiKernel.Certificates

#eval match canonicalWitnessIR with
  | .execution (.typed env p) =>
    let encStr := encodeModuleString canonicalWitnessIR
    let p_json := parseCanonicalJson encStr
    match p_json with
    | .ok j =>
      let dec := decodeDecodedIR j encStr
      match dec with
      | .ok ir => (ir == canonicalWitnessIR)
      | .error e => false
    | .error e => false
  | _ => false

