## Why

Current capability lemmas establish individual issue/use/revoke behavior, while sequential traces already record actual administration. The remaining composition work needs initialized provenance across those traces and explicit state/store support for component observations. Denying writes alone cannot establish confidentiality.

## What Changes

- Prove that every capability entry in an actual sequential prefix has its original grant scope from an explicitly trusted initial entry or a causally preceding authorized issue, with exact fresh-ID counts and permanent tombstones.
- Connect accepted invocation, debit and supply authority to the current pre-step store and that entry's provenance; preserve exact rejection behavior and halted prefixes.
- Define explicit observation support over finite ledger cells, selected capability IDs and optional allocation length, then prove conditional component frames from actual ledger/admin effects.
- Prove direct peer-private read/write exclusion for a validated catalog while recording published output snapshots as disclosure. Provide negative companions for untrusted roots, unsupported observations, read-only information flow and store-sensitive frames.
- Add read-only queries over actual sequential execution, complete independent financial observations, scoped mutation sensitivity, source-bound audits and separate planning/implementation acceptance gates.

## Capabilities

### New Capabilities

- `initialized-capability-provenance`: Causal origins, current-store authorization and tombstone/nonreuse induction over actual sequential prefixes.
- `supported-component-isolation`: Explicit ledger/store/allocation support and conditional frames, with direct-read and disclosure boundaries.
- `capability-provenance-evidence`: Independent observations, finite mutations, defensive controls, immutable source evidence and review gates.

### Modified Capabilities

None. Existing authority, sequential, parallel, interleaving and atomic semantics remain unchanged.

## Impact

Official planning freeze, not implementation or planning-gate acceptance. Intended additions belong in `lean/DefiKernel/CapabilityProvenance/` plus a dedicated Verify root import and new runner/spec files only after independent GPT-6 official planning acceptance. No Lean implementation or `DefiKernel.lean` import is authorized by this freeze.

Accepted sequential basis is Typed/Composition/S9. Sprint9 source `eec499d613688137a341f3556cd80ca461dd2ee9` and Sprint10 source `b165bc586080d668f689fbc18dfa09eb8739d688` are delivered predecessor evidence, not pending gates. M3 source candidate `94f70e502c75132656bd0902a17be60ca45ab1c2` is delivered; administrative delivery D is `a12b7cac05a818cc8d35c2ca440b7170a2807e92`. Those commits differ: bind Lean/runtime identity to the source candidate and administrative receipts to D. Current M3 top-level receipts live at `review/semantic-kernel/sprint11/{delivery,archive-delivery,bookkeeping-delivery}.json`, not under `implementation/`. M3 Nary exists and stays outside these proofs. M4/M5/M6 are not prerequisites. Corpus planning remains a separate package.

Current author is native Grok 4.6. Independent checker is GPT-6. Historical GPT-author/Fable-review identities in the original author draft are preserved, not relabelled. Concurrent allocation, delegation, atomic administration and general confidentiality remain later work.
