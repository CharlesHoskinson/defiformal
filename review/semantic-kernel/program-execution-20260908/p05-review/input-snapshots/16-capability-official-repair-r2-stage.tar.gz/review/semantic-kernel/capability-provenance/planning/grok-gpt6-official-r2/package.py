#!/usr/bin/env python3
"""Prepare and read-only-check the capability-provenance official r2 planning freeze.

CP1/CP2 repair only. Planning-package completeness and integrity. No Lean
implementation, no production mutations, and no planning-gate acceptance.

--prepare writes deterministic derived artifacts.
--seal writes MANIFEST.json (no self-hash) and ANCHOR.json (external trust anchor).
--check is read-only: stored hashes, exact path/ID sets, uniqueness. No writes.
--controls runs intact and defeating copies through the same --check entrypoint.
Exit 0: nonempty sealed package holds. Exit 1: property false. Exit 3: blocked.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import re
import shutil
import subprocess
import sys
import tarfile
import tempfile
from pathlib import Path

HEAD_EXPECTED = 'a12b7cac05a818cc8d35c2ca440b7170a2807e92'
SOURCE_CANDIDATE = '94f70e502c75132656bd0902a17be60ca45ab1c2'
ARCHIVE_SHA = 'bac7880e0ba650023192789f803eea35c2018a9dc9212d18c3e8b2c8922a89e3'
ORIGINAL_MANIFEST_SHA = '0fa167e28cafcaf0bb4730161fe3681682fdf9809f893a2e5eda6a6e88cb0af6'
PACKAGE_REL = 'review/semantic-kernel/capability-provenance/planning/grok-gpt6-official-r2'
R1_REL = 'review/semantic-kernel/capability-provenance/planning/grok-gpt6-official-r1'
PLAN_REL = 'openspec/changes/capability-provenance-isolation'
AUTHOR_REL = 'review/semantic-kernel/capability-provenance/planning/author-draft'
ARCHIVE_REL = 'review/semantic-kernel/capability-provenance/planning/pre-official-r1/original-draft.tar.gz'
R1_STAGE_ARCHIVE = 'review/semantic-kernel/program-loop-20260908/native-worker/capability-official-freeze-r1-stage.tar.gz'
R1_STAGE_SHA = 'ad1b07a4c8285216e137770d375ee49080ade59278c01f251f57a3f9b4852d5a'
R1_MANIFEST_SHA = '5b0150b918bdbe3a18e230aadba0165a8f0b044fda8a95a31896f636ab258036'
R1_INVENTORY_SHA = 'da41fa655fb1e6b0fb621d8d53f5752782cba7bb50e2c74b8004b2bbec25415f'
R1_REPORT_SHA = '3d6a3dc2f1e69acbe1b072642c04ab4665fe4ad9c97a0ee798b801763c48506d'
R1_PACKAGE_SHA = '10fe1101834cab6cbbfea647a40631128c5537a070a05553eb629533f163007f'
R1_PLANNED_MUTATIONS_SHA = 'de3745449d8b39111bd52b17719abab71c61cd9523e76f592cf83b43c8f04b48'
REVIEW_SHA = '1a3fde800e26d5b1da8a6af00e87b14ccc3814ad7604ffefc32560efbb58fc8e'
INPUTS_SHA = '0b6859f8c49c612e218afcc4bdb7d724e132f627d9ced917582fa33a076ccaa8'
FUNDED_PEER = 'capability.positive.funded-peer'
INITIAL_ORIGIN = 'capability.positive.initial-origin'
WRONG_FUNDED_PEER_EXCEPTION = (
    'capability.positive.funded-peer unless a mutant deliberately deletes initial origins'
)
WRONG_EXCEPTION_CLAUSE = 'unless a mutant deliberately deletes initial origins'
CHANGE_NAME = 'capability-provenance-isolation'
OPENSPEC_STRICT_STDOUT = "Change 'capability-provenance-isolation' is valid\n"
OPENSPEC_VERSION_PREFIX = '1.10.0'
PINNED_LEAN_SHA = 'e8baaa71855a616dc351028f3ad2200051b0671f423a1696a100e809302d5550'
PINNED_LAKE_SHA = '60330ab6f07dce20f3fa9ebb08e8b984ea9549eac172afeb15d9d2227060e2b3'

UNCHANGED_PLAN = (
    '.openspec.yaml',
    'specs/initialized-capability-provenance/spec.md',
    'specs/supported-component-isolation/spec.md',
)
CHANGED_PLAN = (
    'proposal.md', 'design.md', 'tasks.md',
    'specs/capability-provenance-evidence/spec.md',
)
NEW_PLAN = (
    'accepted-api.json', 'proposed-api.json', 'dependency-baseline.json',
    'fixtures.json', 'planned-mutations.json', 'runner-adaptation.json',
    'scenario-map.json',
)
ORIGINAL_PLAN = tuple(sorted(UNCHANGED_PLAN + CHANGED_PLAN))
PLAN_FILES = tuple(sorted(ORIGINAL_PLAN + NEW_PLAN))
FIXTURE_IDS = tuple(f'F{i:02d}' for i in range(1, 21))
MUTATION_IDS = tuple(f'M{i:02d}' for i in range(1, 15))
TASK_IDS = (
    '1.1', '1.2', '1.3', '2.1', '2.2', '2.3', '2.4', '2.5', '2.6',
    '3.1', '3.2', '4.1', '4.2', '4.3', '4.4', '4.5', '4.6',
    '5.1', '5.2', '5.3', '6.1', '6.2', '6.3', '6.4', '6.5', '6.6', '6.7',
)
SCENARIO_IDS = (
    'E01', 'E02', 'E03', 'E04', 'E05', 'E06', 'E07', 'E08', 'E09', 'E10', 'E11', 'E12',
    'P01', 'P02', 'P03', 'P04', 'P05', 'P06', 'P07', 'P08', 'P09', 'P10', 'P11', 'P12',
    'P13', 'P14', 'P15', 'P16', 'P17', 'P18',
    'I01', 'I02', 'I03', 'I04', 'I05', 'I06', 'I07', 'I08', 'I09', 'I10', 'I11', 'I12',
    'I13', 'I14', 'I15',
)
LAKE_FILES = (
    'lean/lakefile.toml', 'lean/lake-manifest.json', 'lean/lean-toolchain', 'lean/DefiKernel.lean',
)
CITED_DOCS = (
    'docs/superpowers/specs/2026-09-06-semantic-kernel-design.md',
    'docs/research/semantic-kernel-progress.md',
    '.claude/skills/defi-footguns/SKILL.md',
    'formal/v3/GATE-REGISTER.md',
    'AGENTS.md',
    'roadmap.md',
    'wiki-llm/autonomous-execution-agenda.md',
    'wiki-llm/capability-provenance-isolation-plan.md',
    'review/semantic-kernel/program-loop-20260908/lifecycle-readiness-gpt6-review.md',
    'review/semantic-kernel/program-loop-20260908/lifecycle-readiness-gpt6-inputs.json',
    'review/semantic-kernel/program-loop-20260908/briefs/capability-official-freeze-r1.md',
    'review/semantic-kernel/program-loop-20260908/capability-official-r1-gpt6-review.md',
    'review/semantic-kernel/program-loop-20260908/capability-official-r1-gpt6-inputs.json',
)
R1_IDENTITY_FILES = (
    f'{R1_REL}/ANCHOR.json',
    f'{R1_REL}/MANIFEST.json',
    f'{R1_REL}/source-inventory.json',
    f'{R1_REL}/REPORT.md',
    f'{R1_REL}/package.py',
    f'{R1_REL}/identity.json',
    f'{R1_REL}/STATUS.json',
    f'{R1_REL}/ENTRYPOINT.md',
)
M3_RECEIPTS = (
    'review/semantic-kernel/sprint11/delivery.json',
    'review/semantic-kernel/sprint11/archive-delivery.json',
    'review/semantic-kernel/sprint11/bookkeeping-delivery.json',
)
RUNNER_FILES = (
    'scripts/check_metatheory_mutations.py',
    'scripts/test_metatheory_mutation_runner.py',
    'mutations/metatheory.json',
)
DETERMINISTIC_PACKAGE_FILES = tuple(
    [
        'identity.json',
        'findings.json',
        'before-manifest.json',
        'appendices/A-normative-map.json',
        'appendices/B-dependency-index.json',
        'appendices/C-historical-evidence.json',
        'appendices/E-module-plan.json',
        'appendices/F-r1-control-telemetry.json',
    ] + [f'appendices/D-mutation-specs/{i}.json' for i in MUTATION_IDS]
)


class Blocked(Exception):
    pass


class Failed(Exception):
    pass


class Ctx:
    def __init__(self, root: Path, package: Path):
        self.root = root.resolve()
        self.out = package.resolve()
        self.plan = self.root / PLAN_REL
        self.before = self.out / 'before'
        self.author = self.root / AUTHOR_REL
        self.validation = self.out / 'validation'
        self.inventory = self.out / 'source-inventory.json'
        self.manifest = self.out / 'MANIFEST.json'
        self.anchor = self.out / 'ANCHOR.json'
        self.script = Path(__file__).resolve()


def default_ctx() -> Ctx:
    script = Path(__file__).resolve()
    return Ctx(script.parents[5], script.parent)


def sha(raw: bytes) -> str:
    return hashlib.sha256(raw).hexdigest()


def rec(ctx: Ctx, path: Path) -> dict:
    raw = path.read_bytes()
    return {'path': str(path.relative_to(ctx.root)), 'sha256': sha(raw), 'bytes': len(raw)}


def load(path: Path):
    return json.loads(path.read_text())


def dump_det(path: Path, data) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, indent=2, ensure_ascii=False) + '\n')


def git(ctx: Ctx, *args: str) -> str:
    return subprocess.check_output(['git', *args], cwd=ctx.root, text=True).strip()


def git_available(ctx: Ctx) -> bool:
    return (ctx.root / '.git').exists() or (ctx.root / '.git').is_file()


def which(name: str) -> Path:
    found = shutil.which(name)
    if not found:
        raise Blocked(f'tool unavailable: {name}')
    return Path(found)


def unique(seq) -> bool:
    return len(seq) == len(set(seq))


def verify_rows(ctx: Ctx, rows, label: str) -> int:
    if not rows:
        raise Blocked(f'{label}: empty selection (denominator 0 of 0)')
    paths = [row['path'] for row in rows]
    if len(paths) != len(set(paths)):
        dup = sorted({p for p in paths if paths.count(p) > 1})
        raise Failed(f'{label}: duplicate inventory paths {dup[:8]}')
    missing, mismatched = [], []
    for row in rows:
        path = ctx.root / row['path']
        if not path.is_file():
            missing.append(row['path'])
            continue
        raw = path.read_bytes()
        digest = sha(raw)
        if digest != row['sha256'] or ('bytes' in row and len(raw) != row['bytes']):
            mismatched.append({'path': row['path'], 'expected': row['sha256'],
                               'actual': digest, 'actual_bytes': len(raw)})
    n = len(rows)
    if missing:
        raise Blocked(f'{label}: missing {len(missing)} of {n}: {missing[:8]}')
    if mismatched:
        raise Failed(f'{label}: hash mismatch {len(mismatched)} of {n}: {mismatched[:4]}')
    return n


def require_exact_set(actual, expected, label: str) -> None:
    actual_t = tuple(actual)
    expected_t = tuple(expected)
    if not unique(actual_t):
        raise Failed(f'{label}: duplicate entries in actual list')
    if not unique(expected_t):
        raise Failed(f'{label}: duplicate entries in expected list')
    if len(actual_t) != len(expected_t) or set(actual_t) != set(expected_t):
        missing = sorted(set(expected_t) - set(actual_t))
        extra = sorted(set(actual_t) - set(expected_t))
        raise Failed(f'{label}: set mismatch missing={missing[:8]} extra={extra[:8]} '
                     f'len_actual={len(actual_t)} len_expected={len(expected_t)}')


def unique_extend(dst: list[str], items) -> None:
    for item in items:
        if item not in dst:
            dst.append(item)


def expected_plan_paths() -> list[str]:
    return [f'{PLAN_REL}/{rel}' for rel in PLAN_FILES]


def expected_before_paths() -> list[str]:
    return [f'{PACKAGE_REL}/before/{rel}' for rel in ORIGINAL_PLAN] + [
        f'{PACKAGE_REL}/before/planned-mutations.json',
    ]


def count_scope(ctx: Ctx):
    reqs, scenarios = [], []
    for spec in sorted((ctx.plan / 'specs').glob('*/spec.md')):
        text = spec.read_text()
        cap = spec.parent.name
        current = None
        lines = text.splitlines()
        for i, line in enumerate(lines):
            if line.startswith('### Requirement: '):
                current = line.split(': ', 1)[1]
                reqs.append((cap, current))
            if line.startswith('#### Scenario: '):
                title = line.split(': ', 1)[1]
                sid = title.split()[0]
                body = lines[i + 1:i + 4]
                if not (len(body) == 3 and body[0].startswith('- **GIVEN**')
                        and body[1].startswith('- **WHEN**')
                        and body[2].startswith('- **THEN**')):
                    raise Failed(f'scenario {sid} missing consecutive GIVEN/WHEN/THEN')
                scenarios.append((cap, current, sid, title))
    tasks = re.findall(r'^- \[([ xX])\] (\d+\.\d+) (.+)$',
                       (ctx.plan / 'tasks.md').read_text(), re.M)
    return reqs, scenarios, tasks


def run_captured(ctx: Ctx, args: list[str]) -> dict:
    exe = which(args[0])
    proc = subprocess.run(args, cwd=ctx.root, capture_output=True)
    return {
        'command': args,
        'cwd': str(ctx.root),
        'exit': proc.returncode,
        'executable': str(exe),
        'executable_sha256': sha(exe.read_bytes()) if exe.is_file() else None,
        'stdout': proc.stdout.decode('utf-8', 'replace'),
        'stderr': proc.stderr.decode('utf-8', 'replace'),
        'stdout_sha256': sha(proc.stdout),
        'stderr_sha256': sha(proc.stderr),
        'stdout_bytes': len(proc.stdout),
        'stderr_bytes': len(proc.stderr),
    }


def original_manifest(ctx: Ctx) -> dict:
    return load(ctx.author / 'artifact-manifest.json')


def closure_paths(ctx: Ctx) -> list[str]:
    dep = load(ctx.plan / 'dependency-baseline.json')
    return [row['path'] for row in dep['transitive_import_closure']]


def declared_authoritative_paths(ctx: Ctx) -> dict:
    man = original_manifest(ctx)
    author_paths = [r['path'] for r in man['files']]
    if len(author_paths) != 23 or not unique(author_paths):
        raise Failed(f'original author-draft manifest is not 23 unique files: {len(author_paths)}')
    dep = load(ctx.plan / 'dependency-baseline.json')
    api = load(ctx.plan / 'accepted-api.json')
    closure = [r['path'] for r in dep['transitive_import_closure']]
    if len(closure) != 23 or not unique(closure):
        raise Failed(f'import closure is not 23 unique files: {len(closure)}')
    api_paths = []
    unique_extend(api_paths, [d['path'] for d in api['original_declarations']])
    unique_extend(api_paths, [d['path'] for d in api['recovered_used_existing_declarations']])
    expected = []
    unique_extend(expected, expected_plan_paths())
    unique_extend(expected, expected_before_paths())
    unique_extend(expected, author_paths)
    unique_extend(expected, [
        ARCHIVE_REL,
        'review/semantic-kernel/capability-provenance/planning/pre-official-r1/preservation.json',
        f'{AUTHOR_REL}/artifact-manifest.json',
        R1_STAGE_ARCHIVE,
    ])
    unique_extend(expected, R1_IDENTITY_FILES)
    unique_extend(expected, closure)
    unique_extend(expected, [r['path'] for r in dep['constructibility_and_atomic_context']])
    unique_extend(expected, LAKE_FILES)
    unique_extend(expected, RUNNER_FILES)
    unique_extend(expected, M3_RECEIPTS)
    unique_extend(expected, [
        'review/semantic-kernel/sprint11/primary-integration.json',
        'review/semantic-kernel/sprint9/delivery.json',
        'review/semantic-kernel/sprint10/delivery.json',
        'review/semantic-kernel/sprint10/archive-delivery.json',
        'review/semantic-kernel/sprint9/implementation/runner-controls-r2/summary.json',
        'openspec/config.yaml',
        f'{PACKAGE_REL}/package.py',
        f'{PACKAGE_REL}/ENTRYPOINT.md',
        f'{PACKAGE_REL}/REPORT.md',
        f'{PACKAGE_REL}/STATUS.json',
    ])
    unique_extend(expected, CITED_DOCS)
    unique_extend(expected, api_paths)
    return {
        'expected_paths': expected,
        'author_draft_paths': author_paths,
        'closure_paths': closure,
        'author_index': {r['path']: r for r in man['files']},
    }


def write_identity(ctx: Ctx) -> dict:
    reqs, scenarios, tasks = count_scope(ctx)
    identity = {
        'kind': 'capability_provenance_official_r2_identity',
        'gate_accepted': False,
        'package_review': 'pending independent GPT-6',
        'implementation_tasks_checked': False,
        'capability_provenance_implemented': False,
        'isolated_baseline': HEAD_EXPECTED,
        'head': HEAD_EXPECTED,
        'm3_source_candidate': SOURCE_CANDIDATE,
        'administrative_delivery_D': HEAD_EXPECTED,
        'source_and_administrative_differ': True,
        'package_worker': 'grok-4.6',
        'independent_checker': 'GPT-6',
        'historical_author_draft': 'stock GPT-6 Codex author draft; preserved, not relabelled',
        'historical_fable_instruction': 'preserved original-draft identity; not this gate',
        'no_foreman': True,
        'plan_files': {
            'unchanged_from_original_draft': list(UNCHANGED_PLAN),
            'changed_in_r1_from_original_draft': list(CHANGED_PLAN),
            'new_official_contracts': list(NEW_PLAN),
            'r2_normative_correction': ['planned-mutations.json'],
        },
        'r1_stage_archive_sha256': R1_STAGE_SHA,
        'cp_repairs': ['CP1', 'CP2'],
        'exact_ids': {
            'fixtures': list(FIXTURE_IDS),
            'mutations': list(MUTATION_IDS),
            'tasks': list(TASK_IDS),
            'scenarios': list(SCENARIO_IDS),
        },
        'recovery_observation': {
            'capabilities': 3,
            'requirements': len(reqs),
            'scenarios': len(scenarios),
            'tasks': len(tasks),
            'fixtures': 20,
            'mutations': 14,
            'controls': 65,
            'original_api_declarations': 47,
            'recovered_used_existing_declarations': 38,
            'used_api_count': 85,
            'import_closure_files': 23,
            'note': 'Counts recover the existing draft. They are not an acceptance target that can replace meaning.',
        },
    }
    dump_det(ctx.out / 'identity.json', identity)
    return identity


def write_findings(ctx: Ctx) -> dict:
    findings = {
        'kind': 'official_r2_cp1_cp2_repair_findings',
        'gate_accepted': False,
        'r1_package_preserved': True,
        'r1_report_not_rewritten': True,
        'resolved': [
            {
                'item': 'CP1',
                'was': WRONG_FUNDED_PEER_EXCEPTION,
                'now': FUNDED_PEER,
                'scope': 'all fourteen mutants retain capability.positive.funded-peer as protected positive',
                'm01_exception': 'capability.positive.initial-origin may be omitted for M01 only; it is not attached to funded-peer',
            },
            {
                'item': 'CP2',
                'was': 'r1 REPORT claimed complete control argv under validation/controls; run_check_on/record stored exits and truncated output only',
                'now': 'r2 reruns controls and stores actual subprocess command, cwd, executable, full stdout/stderr, hashes and byte counts',
                'historical_r1': 'r1 REPORT and control JSON/logs remain historical. Any argv inferred from r1 package.py is reconstructed, not original telemetry.',
            },
        ],
        'historical_r1_refresh_notes_not_relabelled': [
            {
                'item': 'author_checker_roles',
                'was': 'GPT-6 author plus native Fable 5.1 medium planning/source review',
                'now': 'native Grok 4.6 author; independent GPT-6 checker',
                'historical': 'original author-draft identities preserved byte-for-byte',
            },
            {
                'item': 'pending_sprint10',
                'was': 'Sprint10 and corpus planning pending their own gates',
                'now': 'Sprint10 delivered; corpus remains a separate package; M3 delivered and not a prerequisite',
            },
            {
                'item': 'm3_receipt_location',
                'was': 'implementation/ delivery records in some later notes',
                'now': 'review/semantic-kernel/sprint11/{delivery,archive-delivery,bookkeeping-delivery}.json',
            },
            {
                'item': 'source_candidate_vs_D',
                'was': 'single HEAD treated as both source and delivery',
                'now': 'source candidate 94f70e50 vs administrative D a12b7cac; bind only relevant evidence',
            },
            {
                'item': 'stale_api_map_coverage',
                'was': '47 declaration files without full import closure or used run/Step/nextId names',
                'now': 'original 47 retained and verified; 38 recovered used existing APIs; 23-file import closure bound',
            },
            {
                'item': 'inherited_harness',
                'was': 'Metatheory runner hashes recorded at author-draft time',
                'now': 'same three files still equal those hashes; Nary runner present and not substituted',
            },
            {
                'item': 'mutation_needles',
                'was': 'planned descriptions without claiming compile-valid needles',
                'now': 'explicit BLOCKED_UNTIL_ACCEPTED_APIS_AND_IMPLEMENTATION_FREEZE; no invented implementation',
            },
            {
                'item': 'toolchain_path',
                'was': 'historical pin v4.33.0-rc2',
                'now': 'pin retained; PATH lean currently reports 4.33.1 via elan stable and is not the implementation pin',
            },
        ],
        'not_invented': [
            'No new concurrent allocator, Tree, Extension, AtomicNary, or claims store.',
            'No Lean CapabilityProvenance modules.',
            'No root import.',
            'No design/spec/task scientific rewrite beyond the planned-mutations funded-peer contract.',
        ],
    }
    dump_det(ctx.out / 'findings.json', findings)
    return findings


def write_module_plan(ctx: Ctx) -> dict:
    plan = {
        'kind': 'proposed_implementation_module_order',
        'namespace': 'DefiKernel.CapabilityProvenance',
        'gate': 'Independent GPT-6 official planning acceptance of this package. Native coding only after that gate. This worker does not self-accept.',
        'order': [
            {'module': 'Origins', 'role': 'TrustedRoot, RootsAccepted, Origin, issuedOrigin, originOf',
             'depends_on': ['Typed.Authority', 'Composition.Sequence.Event']},
            {'module': 'Observation', 'role': 'SupportPolicy, WorldAgrees, observeWorld, capEq, viewEq, currentAuthorityOrigin',
             'depends_on': ['Origins', 'Typed.Authority', 'Composition.Contracts.World']},
            {'module': 'Trace', 'role': 'OriginAt and lifetime/current-use/refusal induction on TraceSound',
             'depends_on': ['Origins', 'Composition.Sequence.TraceSound', 'Composition.Execution.StepSound']},
            {'module': 'Isolation', 'role': 'SupportsObservation, actual-effect frames, peer-private exclusion, disclosure companions',
             'depends_on': ['Observation', 'Trace', 'Composition.Interfaces']},
            {'module': 'Examples', 'role': 'F01–F20 finite worlds and independent expected tables',
             'depends_on': ['Origins', 'Observation', 'Typed.Examples constructibility only']},
            {'module': 'Tests', 'role': 'executable comparisons against independent oracles',
             'depends_on': ['Examples']},
            {'module': 'Audit', 'role': 'auditRun exact Composition.run delegation plus requested readbacks',
             'depends_on': ['Origins', 'Observation', 'Composition.Sequence.run']},
            {'module': 'Verify', 'role': 'dedicated root import only after implementation acceptance',
             'depends_on': ['Trace', 'Isolation', 'Tests', 'Audit']},
        ],
        'runtime_before_proof_marker': ['Origins', 'Observation', 'Examples', 'Tests', 'Audit'],
        'proof_modules': ['Trace', 'Isolation', 'Verify'],
        'do_not_import_until_accepted': 'lean/DefiKernel.lean',
        'inherited_runner_adaptation': 'scripts/check_metatheory_mutations.py via runner-adaptation.json literal map',
    }
    dump_det(ctx.out / 'appendices' / 'E-module-plan.json', plan)
    return plan


def write_appendices(ctx: Ctx) -> None:
    a_files = []
    for rel in PLAN_FILES:
        a_files.append(rec(ctx, ctx.plan / rel))
    dump_det(ctx.out / 'appendices' / 'A-normative-map.json', {
        'kind': 'normative_plan_files',
        'expected_paths': expected_plan_paths(),
        'unchanged': [f'{PLAN_REL}/{r}' for r in UNCHANGED_PLAN],
        'changed': [f'{PLAN_REL}/{r}' for r in CHANGED_PLAN],
        'new': [f'{PLAN_REL}/{r}' for r in NEW_PLAN],
        'r2_normative_correction': [f'{PLAN_REL}/planned-mutations.json'],
        'r1_equality': 'all other r1-stage normative files must equal the frozen r1 archive; planned-mutations.json must differ',
        'files': a_files,
    })
    dep = load(ctx.plan / 'dependency-baseline.json')
    api = load(ctx.plan / 'accepted-api.json')
    dump_det(ctx.out / 'appendices' / 'B-dependency-index.json', {
        'kind': 'accepted_dependency_index',
        'worktree_baseline_administrative_D': HEAD_EXPECTED,
        'm3_source_candidate': SOURCE_CANDIDATE,
        'source_and_administrative_differ': True,
        'original_declarations': api['original_declarations'],
        'recovered_used_existing_declarations': api['recovered_used_existing_declarations'],
        'transitive_import_closure': dep['transitive_import_closure'],
        'lake_pins': dep['lake_pins'],
        'm3_receipts': dep['m3_receipts'],
        'runner': [rec(ctx, ctx.root / p) for p in RUNNER_FILES],
        'not_prerequisites': dep['not_prerequisites'],
        'namespaces': dep['namespaces'],
    })
    man = original_manifest(ctx)
    dump_det(ctx.out / 'appendices' / 'C-historical-evidence.json', {
        'kind': 'historical_author_draft_preservation',
        'original_manifest_sha256': ORIGINAL_MANIFEST_SHA,
        'archive_sha256': ARCHIVE_SHA,
        'archive_path': ARCHIVE_REL,
        'original_entries': 23,
        'archive_entries': 24,
        'files': man['files'],
        'self_excluded_manifest': f'{AUTHOR_REL}/artifact-manifest.json',
        'note': 'Never regenerate the old manifest or overwrite author-draft bytes. Verify originals from the preserved archive and Git.',
        'r1_stage_archive': {
            'path': R1_STAGE_ARCHIVE,
            'sha256': R1_STAGE_SHA,
            'files': 80,
            'use': 'historical r1 equality after the authorized planned-mutations correction. Do not rerun the r1 inventory against changed live planned-mutations.json as if unchanged.',
        },
    })
    pm = load(ctx.plan / 'planned-mutations.json')
    specs = ctx.out / 'appendices' / 'D-mutation-specs'
    specs.mkdir(parents=True, exist_ok=True)
    by_id = {m['id']: m for m in pm['mutations']}
    for mid in MUTATION_IDS:
        dump_det(specs / f'{mid}.json', {
            'schema_version': 1,
            'id': mid,
            'status': 'planned_not_executed',
            'exact_source_needle': 'BLOCKED_UNTIL_ACCEPTED_APIS_AND_IMPLEMENTATION_FREEZE',
            **{k: by_id[mid][k] for k in (
                'name', 'proposed_runtime_site', 'mutation', 'designated_check',
                'fixture', 'supplemental_successful_sibling')},
            'protected_positives': list(by_id[mid]['protected_positives']),
        })
    write_r1_control_telemetry(ctx)
    write_module_plan(ctx)


def write_r1_control_telemetry(ctx: Ctx) -> dict:
    rows = []
    for name in (
        'valid-unchanged-sibling', 'missing-source', 'changed-bytes', 'empty-inventory',
        'bad-binding', 'overwritten-author-draft', 'missing-cited-design', 'changed-m3-receipt',
        'summary',
    ):
        path = f'{R1_REL}/validation/controls/{name}.json'
        rec_row = rec(ctx, ctx.root / path)
        body = load(ctx.root / path)
        rec_row['has_command'] = 'command' in body
        rec_row['has_cwd'] = 'cwd' in body
        rec_row['telemetry'] = 'historical_r1_exits_and_output_only'
        rec_row['argv_cwd'] = 'not_retained'
        rec_row['reconstructed_argv_from_r1_package_py'] = {
            'status': 'reconstructed_not_original_telemetry',
            'inferred_from': f'{R1_REL}/package.py run_check_on',
            'inferred_shape': [
                'python3', f'{R1_REL}/package.py', '--check', '--root', '<temp>',
                '--package', f'<temp>/{R1_REL}',
            ],
            'note': 'r1 did not store per-control argv/cwd. This shape is inferred from hashed r1 source, not a captured subprocess record.',
        }
        rows.append(rec_row)
    data = {
        'kind': 'historical_r1_control_telemetry',
        'r1_report_sha256': R1_REPORT_SHA,
        'r1_package_sha256': R1_PACKAGE_SHA,
        'r1_report_overclaim': 'r1 REPORT.md said complete command argv are under validation/controls. Stored case JSON omitted command and cwd.',
        'argv_cwd_status': 'not_retained_in_r1_records',
        'files': rows,
        'r2_policy': 'r2 reruns the same --check entrypoint and stores actual subprocess command, cwd, executable, full stdout/stderr, hashes and byte counts with telemetry=actual_subprocess.',
    }
    dump_det(ctx.out / 'appendices' / 'F-r1-control-telemetry.json', data)
    return data


def write_before_manifest(ctx: Ctx) -> dict:
    files = []
    for rel in ORIGINAL_PLAN:
        snap = ctx.before / rel
        if not snap.is_file():
            raise Blocked(f'original-byte snapshot missing: {snap}')
        raw = snap.read_bytes()
        files.append({
            'source': f'{PLAN_REL}/{rel}',
            'snapshot': f'{PACKAGE_REL}/before/{rel}',
            'sha256': sha(raw),
            'bytes': len(raw),
            'class': 'unchanged' if rel in UNCHANGED_PLAN else 'changed',
        })
    r1_pm = ctx.before / 'planned-mutations.json'
    if not r1_pm.is_file():
        raise Blocked('r1 planned-mutations snapshot missing')
    raw = r1_pm.read_bytes()
    if sha(raw) != R1_PLANNED_MUTATIONS_SHA:
        raise Failed('r2 before/planned-mutations.json is not frozen r1 bytes')
    files.append({
        'source': f'{PLAN_REL}/planned-mutations.json',
        'snapshot': f'{PACKAGE_REL}/before/planned-mutations.json',
        'sha256': sha(raw),
        'bytes': len(raw),
        'class': 'r1-historical',
    })
    data = {'kind': 'original_and_r1_normative_bytes', 'count': len(files), 'files': files}
    dump_det(ctx.out / 'before-manifest.json', data)
    return data


def write_inventory(ctx: Ctx) -> dict:
    declared = declared_authoritative_paths(ctx)
    rows = []
    seen = set()

    def add(path: str, klass: str, extra=None):
        if path in seen:
            return
        seen.add(path)
        row = rec(ctx, ctx.root / path)
        row['class'] = klass
        if extra:
            row.update(extra)
        rows.append(row)

    for rel in PLAN_FILES:
        if rel == 'planned-mutations.json':
            klass = 'plan-r2-cp1-correction'
        elif rel in UNCHANGED_PLAN:
            klass = 'plan-unchanged'
        elif rel in CHANGED_PLAN:
            klass = 'plan-changed'
        else:
            klass = 'plan-new'
        add(f'{PLAN_REL}/{rel}', klass)
    for rel in ORIGINAL_PLAN:
        add(f'{PACKAGE_REL}/before/{rel}', 'plan-before')
    add(f'{PACKAGE_REL}/before/planned-mutations.json', 'r1-historical-planned-mutations')
    add(R1_STAGE_ARCHIVE, 'historical-r1-stage-archive')
    for path in R1_IDENTITY_FILES:
        add(path, 'historical-r1')
    author_index = declared['author_index']
    for path, meta in author_index.items():
        add(path, 'original-author-draft', {
            'original_sha256': meta['sha256'],
            'original_bytes': meta['bytes'],
        })
    add(ARCHIVE_REL, 'original-archive')
    add('review/semantic-kernel/capability-provenance/planning/pre-official-r1/preservation.json',
        'original-archive')
    add(f'{AUTHOR_REL}/artifact-manifest.json', 'original-author-draft-manifest')
    for path in declared['closure_paths']:
        add(path, 'import-closure')
    dep = load(ctx.plan / 'dependency-baseline.json')
    for row in dep['constructibility_and_atomic_context']:
        add(row['path'], 'constructibility-or-atomic-context')
    for path in LAKE_FILES:
        add(path, 'lake')
    for path in RUNNER_FILES:
        add(path, 'inherited-runner')
    for path in M3_RECEIPTS:
        add(path, 'm3-receipt')
    add('review/semantic-kernel/sprint11/primary-integration.json', 'administrative-D')
    add('review/semantic-kernel/sprint9/delivery.json', 'predecessor-receipt')
    add('review/semantic-kernel/sprint10/delivery.json', 'predecessor-receipt')
    add('review/semantic-kernel/sprint10/archive-delivery.json', 'predecessor-receipt')
    add('review/semantic-kernel/sprint9/implementation/runner-controls-r2/summary.json',
        'inherited-control-summary')
    add('openspec/config.yaml', 'openspec-config')
    for path in CITED_DOCS:
        add(path, 'cited-doc')
    add(f'{PACKAGE_REL}/package.py', 'package')
    add(f'{PACKAGE_REL}/ENTRYPOINT.md', 'package')
    add(f'{PACKAGE_REL}/REPORT.md', 'package')
    add(f'{PACKAGE_REL}/STATUS.json', 'package')
    expected = list(declared['expected_paths'])
    unique_extend(expected, [f'{PACKAGE_REL}/{rel}' for rel in DETERMINISTIC_PACKAGE_FILES])
    for rel in DETERMINISTIC_PACKAGE_FILES:
        add(f'{PACKAGE_REL}/{rel}', 'derived-package')
    require_exact_set([r['path'] for r in rows], expected, 'inventory rows vs expected_paths')
    inventory = {
        'kind': 'sealed_source_inventory',
        'head': HEAD_EXPECTED,
        'expected_plan_paths': expected_plan_paths(),
        'expected_before_paths': expected_before_paths(),
        'expected_author_draft_paths': declared['author_draft_paths'],
        'expected_closure_paths': declared['closure_paths'],
        'expected_fixture_ids': list(FIXTURE_IDS),
        'expected_mutation_ids': list(MUTATION_IDS),
        'expected_task_ids': list(TASK_IDS),
        'expected_scenario_ids': list(SCENARIO_IDS),
        'expected_paths': expected,
        'rows': rows,
        'row_count': len(rows),
        'note': 'expected_paths is the union of cited inventories. Stored hashes. --check must not rec() current bytes as expected values.',
    }
    dump_det(ctx.inventory, inventory)
    return inventory


def prepare(ctx: Ctx) -> None:
    ctx.out.mkdir(parents=True, exist_ok=True)
    ctx.validation.mkdir(parents=True, exist_ok=True)
    if not (ctx.out / 'ENTRYPOINT.md').is_file():
        raise Blocked('ENTRYPOINT.md missing')
    if not (ctx.out / 'REPORT.md').is_file():
        raise Blocked('REPORT.md missing; write the report before prepare')
    identity = write_identity(ctx)
    write_findings(ctx)
    write_appendices(ctx)
    write_before_manifest(ctx)
    dump_det(ctx.out / 'STATUS.json', {
        'kind': 'capability_provenance_official_r2_status',
        'gate_accepted': False,
        'implementation_tasks_checked': False,
        'capability_provenance_implemented': False,
        'package_review': 'pending independent GPT-6',
        'worker': 'grok-4.6',
        'independent_checker': 'GPT-6',
        'isolated_baseline': HEAD_EXPECTED,
        'm3_source_candidate': SOURCE_CANDIDATE,
        'check_command': f'python3 {PACKAGE_REL}/package.py --check',
        'trust_anchor': f'{PACKAGE_REL}/ANCHOR.json',
        'manifest_path': f'{PACKAGE_REL}/MANIFEST.json',
        'manifest_self_hash': False,
        'entrypoint': f'{PACKAGE_REL}/ENTRYPOINT.md',
    })
    write_inventory(ctx)
    openspec_v = run_captured(ctx, ['openspec', '--version'])
    dump_det(ctx.validation / 'openspec-version.json', openspec_v)
    (ctx.validation / 'openspec-version.stdout.log').write_text(openspec_v['stdout'])
    (ctx.validation / 'openspec-version.stderr.log').write_text(openspec_v['stderr'])
    strict = run_captured(ctx, ['openspec', 'validate', CHANGE_NAME, '--strict', '--no-interactive'])
    dump_det(ctx.validation / 'openspec-strict.json', {
        k: strict[k] for k in ('command', 'cwd', 'exit', 'executable', 'executable_sha256',
                               'stdout_sha256', 'stderr_sha256', 'stdout_bytes', 'stderr_bytes')
    } | {'stdout': strict['stdout'], 'stderr': strict['stderr']})
    (ctx.validation / 'openspec-strict.stdout.log').write_bytes(strict['stdout'].encode())
    (ctx.validation / 'openspec-strict.stderr.log').write_bytes(strict['stderr'].encode())
    if strict['exit'] != 0 or strict['stdout'] != OPENSPEC_STRICT_STDOUT:
        raise Failed(f'openspec strict failed during prepare: exit={strict["exit"]} stdout={strict["stdout"]!r}')
    print(json.dumps({
        'prepared': True,
        'gate_accepted': False,
        'identity': identity['recovery_observation'],
        'openspec_stdout': strict['stdout'],
    }, indent=2))


def check_inventory_structure(inventory: dict) -> None:
    if not isinstance(inventory, dict):
        raise Blocked('inventory is not an object')
    rows = inventory.get('rows')
    if not isinstance(rows, list):
        raise Blocked('inventory rows missing')
    if not rows:
        raise Blocked('empty inventory (denominator 0 of 0)')
    paths = [row.get('path') for row in rows]
    if any(not p for p in paths):
        raise Failed('inventory row missing path')
    if not unique(paths):
        dup = sorted({p for p in paths if paths.count(p) > 1})
        raise Failed(f'duplicate inventory paths: {dup[:8]}')
    expected = inventory.get('expected_paths')
    if not isinstance(expected, list) or not expected:
        raise Blocked('inventory expected_paths missing or empty')
    if not unique(expected):
        raise Failed('duplicate expected_paths in inventory')
    require_exact_set(paths, expected, 'inventory rows vs expected_paths')


def check_apis(ctx: Ctx) -> None:
    api = load(ctx.plan / 'accepted-api.json')
    if api.get('original_declaration_count') != 47:
        raise Failed('original_declaration_count is not the recovered 47')
    if len(api['original_declarations']) != 47:
        raise Failed('original_declarations list is not 47')
    if len(api['recovered_used_existing_declarations']) != 38:
        raise Failed('recovered used existing declarations is not 38')
    if len(api['original_declarations']) + len(api['recovered_used_existing_declarations']) != 85:
        raise Failed('used API count is not the recovered 85')
    for d in api['original_declarations'] + api['recovered_used_existing_declarations']:
        text = (ctx.root / d['path']).read_text()
        matches = list(re.finditer(
            r'^(?:def|theorem|structure|inductive|abbrev) ' + re.escape(d['declaration']) + r'(?=\s|\(|$)',
            text, re.M))
        if len(matches) != 1:
            raise Failed(f'API {d["declaration"]} in {d["path"]} match count {len(matches)}')
        line = text[:matches[0].start()].count('\n') + 1
        if line != d['line']:
            raise Failed(f'API {d["declaration"]} line {line} != recorded {d["line"]}')
        raw = (ctx.root / d['path']).read_bytes()
        if sha(raw) != d['source_sha256']:
            raise Failed(f'API source hash drifted: {d["path"]}')
    proposed = load(ctx.plan / 'proposed-api.json')
    if 'proposed' not in proposed['status'].lower():
        raise Failed('proposed-api is not labelled proposed')
    if (ctx.root / 'lean/DefiKernel/CapabilityProvenance').exists():
        raise Failed('CapabilityProvenance implementation directory exists')
    root = (ctx.root / 'lean/DefiKernel.lean').read_text()
    if 'CapabilityProvenance' in root:
        raise Failed('DefiKernel.lean already imports CapabilityProvenance')


def check_original_preservation(ctx: Ctx) -> None:
    arch = ctx.root / ARCHIVE_REL
    if sha(arch.read_bytes()) != ARCHIVE_SHA:
        raise Failed('original-draft.tar.gz hash drifted')
    with tarfile.open(arch, 'r:gz') as tar:
        names = tar.getnames()
    if len(names) != 24:
        raise Failed(f'archive entries {len(names)} != 24')
    man = original_manifest(ctx)
    if sha((ctx.author / 'artifact-manifest.json').read_bytes()) != ORIGINAL_MANIFEST_SHA:
        raise Failed('original artifact-manifest.json hash drifted')
    if len(man['files']) != 23:
        raise Failed('original manifest file count is not 23')
    changed_live = {f'{PLAN_REL}/{rel}' for rel in CHANGED_PLAN}
    with tarfile.open(arch, 'r:gz') as tar:
        members = {m.name: m for m in tar.getmembers() if m.isfile()}
        for row in man['files']:
            info = members.get(row['path'])
            if info is None:
                raise Failed(f'archive missing original path {row["path"]}')
            extracted = tar.extractfile(info).read()
            if sha(extracted) != row['sha256'] or len(extracted) != row['bytes']:
                raise Failed(f'archive bytes differ from original manifest: {row["path"]}')
            live = ctx.root / row['path']
            if not live.is_file():
                raise Blocked(f'original path missing: {row["path"]}')
            live_raw = live.read_bytes()
            if row['path'] in changed_live:
                if sha(live_raw) == row['sha256']:
                    raise Failed(f'authorized changed original unexpectedly equals archive: {row["path"]}')
                rel = str(Path(row['path']).relative_to(PLAN_REL))
                snap = (ctx.before / rel).read_bytes()
                if sha(snap) != row['sha256']:
                    raise Failed(f'before/ snapshot does not match original archive: {row["path"]}')
            else:
                if sha(live_raw) != row['sha256'] or len(live_raw) != row['bytes']:
                    raise Failed(f'original preserved path overwritten: {row["path"]}')


def check_funded_peer_contract(ctx: Ctx) -> dict:
    """Lift the live planned-mutations contract. Do not reimplement it in a private copy."""
    pm = load(ctx.plan / 'planned-mutations.json')
    if pm.get('protected_global') != FUNDED_PEER:
        raise Failed(f'protected_global is not unconditional funded-peer: {pm.get("protected_global")!r}')
    if WRONG_EXCEPTION_CLAUSE in str(pm.get('protected_global')):
        raise Failed('protected_global still attaches the initial-origin exception to funded-peer')
    if pm.get('protected_global') == WRONG_FUNDED_PEER_EXCEPTION:
        raise Failed('protected_global equals the r1 wrong exception literal')
    required = pm.get('protected_global_required_for')
    if required != list(MUTATION_IDS):
        raise Failed(f'protected_global_required_for is not all 14 mutants: {required}')
    if len(pm['mutations']) != 14:
        raise Failed('planned-mutations is not 14')
    missing = []
    for mutant in pm['mutations']:
        positives = mutant.get('protected_positives')
        if not isinstance(positives, list) or FUNDED_PEER not in positives:
            missing.append(mutant.get('id'))
    if missing:
        raise Failed(f'mutants missing funded-peer protected positive: {missing}')
    origin = pm.get('initial_origin_positive')
    if not isinstance(origin, dict) or origin.get('label') != INITIAL_ORIGIN:
        raise Failed('initial_origin_positive label is not the separate initial-origin positive')
    if origin.get('omissible_only_for') != ['M01']:
        raise Failed('initial-origin omission is not restricted to M01')
    if FUNDED_PEER in origin.get('omissible_only_for', []):
        raise Failed('funded-peer listed as omissible')
    return {
        'protected_global': pm['protected_global'],
        'mutants_with_funded_peer': 14,
        'initial_origin_omissible_only_for': origin['omissible_only_for'],
    }


def check_r1_stage_archive(ctx: Ctx) -> dict:
    """Historical r1 equality from the frozen 80-file archive, not from r1 inventory vs live CP1 path."""
    arch_path = ctx.root / R1_STAGE_ARCHIVE
    if sha(arch_path.read_bytes()) != R1_STAGE_SHA:
        raise Failed('frozen r1 stage archive hash drifted')
    live_pm = f'{PLAN_REL}/planned-mutations.json'
    compared = 0
    with tarfile.open(arch_path, 'r:gz') as tar:
        names = tar.getnames()
        if len(names) != 80:
            raise Failed(f'r1 stage archive files {len(names)} != 80')
        for name in names:
            info = tar.getmember(name)
            if not info.isfile():
                continue
            data = tar.extractfile(info).read()
            live = ctx.root / name
            if name == live_pm:
                if not live.is_file():
                    raise Blocked('live planned-mutations.json missing')
                if sha(live.read_bytes()) == sha(data):
                    raise Failed('live planned-mutations.json still equals frozen r1; CP1 not applied')
                snap = (ctx.before / 'planned-mutations.json').read_bytes()
                if sha(snap) != sha(data) or sha(snap) != R1_PLANNED_MUTATIONS_SHA:
                    raise Failed('r2 before/planned-mutations.json is not frozen r1 bytes')
                archived_pm = json.loads(data.decode())
                if archived_pm.get('protected_global') != WRONG_FUNDED_PEER_EXCEPTION:
                    raise Failed('frozen r1 planned-mutations.json is not the CP1 defect literal')
                compared += 1
                continue
            if name.startswith(R1_REL + '/') and not live.is_file():
                if git_available(ctx):
                    raise Blocked(f'r1 folder member missing: {name}')
                compared += 1
                continue
            if not live.is_file():
                raise Blocked(f'r1-stage member missing live: {name}')
            if live.read_bytes() != data:
                raise Failed(f'r1-equal path drifted versus frozen r1 archive: {name}')
            compared += 1
    if not (ctx.root / f'{R1_REL}/MANIFEST.json').is_file():
        if git_available(ctx):
            raise Blocked('r1 MANIFEST missing in real tree')
        return {'archive_files': 80, 'compared': compared, 'live_planned_mutations_differs': True,
                'r1_tree': 'not_copied_into_temp_control'}
    if sha((ctx.root / f'{R1_REL}/MANIFEST.json').read_bytes()) != R1_MANIFEST_SHA:
        raise Failed('r1 MANIFEST rewritten')
    if sha((ctx.root / f'{R1_REL}/source-inventory.json').read_bytes()) != R1_INVENTORY_SHA:
        raise Failed('r1 inventory rewritten')
    if sha((ctx.root / f'{R1_REL}/REPORT.md').read_bytes()) != R1_REPORT_SHA:
        raise Failed('r1 REPORT rewritten')
    if sha((ctx.root / f'{R1_REL}/package.py').read_bytes()) != R1_PACKAGE_SHA:
        raise Failed('r1 package.py rewritten')
    if sha((ctx.root / 'review/semantic-kernel/program-loop-20260908/capability-official-r1-gpt6-review.md').read_bytes()) != REVIEW_SHA:
        raise Failed('r1 GPT-6 review hash drifted')
    if sha((ctx.root / 'review/semantic-kernel/program-loop-20260908/capability-official-r1-gpt6-inputs.json').read_bytes()) != INPUTS_SHA:
        raise Failed('r1 GPT-6 inputs hash drifted')
    return {'archive_files': 80, 'compared': compared, 'live_planned_mutations_differs': True}


def check_sealed(ctx: Ctx) -> dict:
    checks = []

    def note(name: str, ok: bool, detail=None):
        checks.append({'name': name, 'passed': bool(ok), 'detail': detail})
        if not ok:
            raise Failed(f'{name}: {detail}')

    if not ctx.inventory.is_file():
        raise Blocked('source-inventory.json missing')
    if not ctx.manifest.is_file():
        raise Blocked('MANIFEST.json missing')
    if not ctx.anchor.is_file():
        raise Blocked('ANCHOR.json missing; MANIFEST has no self-hash')
    peer = check_funded_peer_contract(ctx)
    note('cp1_funded_peer_unconditional', True, peer)
    inventory = load(ctx.inventory)
    check_inventory_structure(inventory)
    n_inv = verify_rows(ctx, inventory['rows'], 'source-inventory')
    note('source_inventory_nonempty', n_inv > 0, n_inv)
    declared = declared_authoritative_paths(ctx)
    expected_full = list(declared['expected_paths'])
    unique_extend(expected_full, [f'{PACKAGE_REL}/{rel}' for rel in DETERMINISTIC_PACKAGE_FILES])
    require_exact_set(inventory['expected_paths'], expected_full,
                      'inventory expected_paths vs cited inventories')
    require_exact_set(inventory['expected_plan_paths'], expected_plan_paths(), 'expected_plan_paths')
    require_exact_set(inventory['expected_before_paths'], expected_before_paths(), 'expected_before_paths')
    require_exact_set(inventory['expected_fixture_ids'], FIXTURE_IDS, 'expected_fixture_ids')
    require_exact_set(inventory['expected_mutation_ids'], MUTATION_IDS, 'expected_mutation_ids')
    require_exact_set(inventory['expected_task_ids'], TASK_IDS, 'expected_task_ids')
    require_exact_set(inventory['expected_scenario_ids'], SCENARIO_IDS, 'expected_scenario_ids')

    appendix_a = load(ctx.out / 'appendices' / 'A-normative-map.json')
    require_exact_set([r['path'] for r in appendix_a['files']], expected_plan_paths(), 'appendix A paths')
    n_a = verify_rows(ctx, appendix_a['files'], 'appendix-A')
    note('appendix_A_frozen_rows', n_a == len(PLAN_FILES), n_a)

    pm = load(ctx.plan / 'planned-mutations.json')
    require_exact_set([m['id'] for m in pm['mutations']], MUTATION_IDS, 'planned mutation ids')
    if pm['count'] != len(pm['mutations']) or len(pm['mutations']) != 14:
        raise Failed('planned-mutations declared count != list length 14')
    stored_specs = []
    for mutant in pm['mutations']:
        spec_path = f'{PACKAGE_REL}/appendices/D-mutation-specs/{mutant["id"]}.json'
        spec = load(ctx.root / spec_path)
        if spec['id'] != mutant['id'] or spec['designated_check'] != mutant['designated_check']:
            raise Failed(f'mutation spec drift {mutant["id"]}')
        if spec['exact_source_needle'] != 'BLOCKED_UNTIL_ACCEPTED_APIS_AND_IMPLEMENTATION_FREEZE':
            raise Failed(f'{mutant["id"]} claimed a compile-valid needle')
        if FUNDED_PEER not in spec.get('protected_positives', []):
            raise Failed(f'{mutant["id"]} mutation spec missing funded-peer protected positive')
        if FUNDED_PEER not in mutant.get('protected_positives', []):
            raise Failed(f'{mutant["id"]} planned mutation missing funded-peer protected positive')
        stored_specs.append(rec(ctx, ctx.root / spec_path))
    n_specs = verify_rows(ctx, stored_specs, 'mutation_specs_stored_hashes')
    note('mutation_specs_stored', n_specs == 14, n_specs)

    fx = load(ctx.plan / 'fixtures.json')
    fids = [x['id'] for x in fx['fixtures']]
    if fx['count'] != len(fx['fixtures']):
        raise Failed('fixtures declared count != list length')
    require_exact_set(fids, FIXTURE_IDS, 'fixture ids')
    ra = load(ctx.plan / 'runner-adaptation.json')
    cids = [x['id'] for x in ra['controls']]
    if len(ra['controls']) != 65 or ra['count'] != 65:
        raise Failed('control list length is not 65')
    if not unique(cids):
        raise Failed('duplicate control ids')
    counts = {0: 0, 1: 0, 3: 0}
    for c in ra['controls']:
        counts[c['expected_exit']] += 1
    if counts != {0: 10, 1: 5, 3: 50}:
        raise Failed(f'inherited classification counts {counts}')
    for p in RUNNER_FILES:
        raw = (ctx.root / p).read_bytes()
        recorded = next(x for x in ra['original_recorded'] if x['path'] == p)
        if sha(raw) != recorded['sha256']:
            raise Failed(f'inherited runner hash drifted: {p}')

    before = load(ctx.out / 'before-manifest.json')
    if before['count'] != len(before['files']) or len(before['files']) != 8:
        raise Failed(f'before-manifest is not 7 original plus r1 planned-mutations: {len(before["files"])}')
    verify_rows(ctx, [{'path': r['snapshot'], 'sha256': r['sha256'], 'bytes': r['bytes']}
                      for r in before['files']], 'before_snapshot')
    for row in before['files']:
        rel = str(Path(row['source']).relative_to(PLAN_REL))
        current = sha((ctx.plan / rel).read_bytes())
        if row.get('class') == 'r1-historical' or rel == 'planned-mutations.json':
            if current == row['sha256']:
                raise Failed('live planned-mutations.json unexpectedly equals frozen r1 snapshot')
            if row['sha256'] != R1_PLANNED_MUTATIONS_SHA:
                raise Failed('r1 planned-mutations snapshot hash drifted')
        elif rel in UNCHANGED_PLAN:
            if current != row['sha256']:
                raise Failed(f'unchanged plan drifted: {rel}')
        elif rel in CHANGED_PLAN:
            if current == row['sha256']:
                raise Failed(f'changed plan unexpectedly equals before: {rel}')
        else:
            raise Failed(f'unclassified original plan file {rel}')

    check_original_preservation(ctx)
    note('original_23_and_archive', True, {'archive': ARCHIVE_SHA, 'manifest': ORIGINAL_MANIFEST_SHA})
    r1_eq = check_r1_stage_archive(ctx)
    note('r1_stage_archive_equality', True, r1_eq)
    check_apis(ctx)
    note('accepted_and_proposed_apis', True, {'original': 47, 'recovered_used': 38, 'used': 85})

    appendix_b = load(ctx.out / 'appendices' / 'B-dependency-index.json')
    n_close = verify_rows(ctx, appendix_b['transitive_import_closure'], 'import-closure')
    if n_close != 23:
        raise Failed(f'import closure {n_close} != 23')
    note('import_closure', True, n_close)
    if appendix_b['lake_pins']['pinned_lean']['sha256'] != PINNED_LEAN_SHA:
        raise Failed('pinned lean sha drifted')
    if appendix_b['lake_pins']['pinned_lake']['sha256'] != PINNED_LAKE_SHA:
        raise Failed('pinned lake sha drifted')

    reqs, scenarios, tasks = count_scope(ctx)
    if len(reqs) != 15 or not unique(reqs):
        raise Failed(f'requirements recovery {len(reqs)} unique={unique(reqs)}')
    sids = [s[2] for s in scenarios]
    if len(scenarios) != 45 or set(sids) != set(SCENARIO_IDS):
        raise Failed(f'scenarios recovery {len(scenarios)} ids={sids}')
    task_ids = [tid for _, tid, _ in tasks]
    require_exact_set(task_ids, TASK_IDS, 'task ids')
    if any(mark != ' ' for mark, _, _ in tasks):
        raise Failed('implementation tasks were checked')
    if not all('Verification:' in body for _, _, body in tasks):
        raise Failed('a task is missing Verification')
    design = (ctx.plan / 'design.md').read_text()
    if len(re.findall(r'^\| F\d\d \|', design, re.M)) != 20:
        raise Failed('design fixture table is not 20 recovered families')
    if len(re.findall(r'^\| M\d\d \|', design, re.M)) != 14:
        raise Failed('design mutation table is not 14 recovered mutants')
    note('scope_recovered_with_meaning', True, {
        'requirements': 15, 'scenarios': 45, 'tasks': 27, 'fixtures': 20, 'mutants': 14,
    })

    identity = load(ctx.out / 'identity.json')
    if identity.get('gate_accepted') is not False or identity.get('package_review') != 'pending independent GPT-6':
        raise Failed('identity claims gate acceptance or completed package review')
    if identity.get('utc') or 'working_tree_porcelain_sha256' in identity:
        raise Failed('identity embeds non-deterministic invocation metadata')
    if identity.get('capability_provenance_implemented') is not False:
        raise Failed('identity claims implementation')

    if git_available(ctx):
        head = git(ctx, 'rev-parse', 'HEAD')
        if head != HEAD_EXPECTED:
            raise Failed(f'HEAD {head} != {HEAD_EXPECTED}')
        note('git_head', True, head)

    openspec_v = run_captured(ctx, ['openspec', '--version'])
    if openspec_v['exit'] != 0 or not openspec_v['stdout'].startswith(OPENSPEC_VERSION_PREFIX):
        raise Blocked(f'openspec version unavailable or unexpected: {openspec_v["stdout"]!r}')
    strict = run_captured(ctx, ['openspec', 'validate', CHANGE_NAME, '--strict', '--no-interactive'])
    if CHANGE_NAME not in strict['command'] or '--strict' not in strict['command']:
        raise Failed('openspec command did not select capability-provenance-isolation')
    if strict['exit'] != 0:
        raise Failed(f'openspec strict exit {strict["exit"]}')
    if strict['stdout'] != OPENSPEC_STRICT_STDOUT:
        raise Failed({'wanted': OPENSPEC_STRICT_STDOUT, 'got': strict['stdout']})
    note('openspec_strict_exact', True, {'stdout': strict['stdout'], 'bytes': strict['stdout_bytes']})

    anchor = load(ctx.anchor)
    if 'manifest_sha256' not in anchor or 'inventory_sha256' not in anchor:
        raise Blocked('ANCHOR.json missing trust-anchor fields')
    manifest_raw = ctx.manifest.read_bytes()
    inventory_raw = ctx.inventory.read_bytes()
    if sha(manifest_raw) != anchor['manifest_sha256']:
        raise Failed('MANIFEST.json does not match ANCHOR.manifest_sha256')
    if sha(inventory_raw) != anchor['inventory_sha256']:
        raise Failed('source-inventory.json does not match ANCHOR.inventory_sha256')
    note('anchor_external', True, {
        'manifest_sha256': anchor['manifest_sha256'],
        'inventory_sha256': anchor['inventory_sha256'],
    })
    manifest = load(ctx.manifest)
    files = manifest.get('files')
    if not isinstance(files, list) or not files:
        raise Blocked('MANIFEST files empty (denominator 0 of 0)')
    mpaths = [row['path'] for row in files]
    if str(ctx.manifest.relative_to(ctx.root)) in mpaths:
        raise Failed('MANIFEST lists itself; self-hash is forbidden')
    if str(ctx.anchor.relative_to(ctx.root)) in mpaths:
        raise Failed('MANIFEST lists ANCHOR.json; trust anchor must stay external')
    if not unique(mpaths):
        raise Failed('duplicate MANIFEST paths')
    if manifest.get('file_count') != len(files):
        raise Failed('MANIFEST file_count != len(files)')
    n_man = verify_rows(ctx, files, 'MANIFEST')
    required_pkg = [
        f'{PACKAGE_REL}/package.py',
        f'{PACKAGE_REL}/ENTRYPOINT.md',
        f'{PACKAGE_REL}/REPORT.md',
        f'{PACKAGE_REL}/STATUS.json',
        f'{PACKAGE_REL}/source-inventory.json',
        f'{PACKAGE_REL}/identity.json',
        f'{PACKAGE_REL}/findings.json',
        f'{PACKAGE_REL}/appendices/A-normative-map.json',
        f'{PACKAGE_REL}/appendices/E-module-plan.json',
    ] + [f'{PACKAGE_REL}/appendices/D-mutation-specs/{i}.json' for i in MUTATION_IDS]
    missing_pkg = [p for p in required_pkg if p not in set(mpaths)]
    if missing_pkg:
        raise Failed(f'MANIFEST omitted required package files: {missing_pkg[:8]}')
    note('manifest_stored_hashes', n_man == len(files), n_man)

    summary_path = ctx.validation / 'controls' / 'summary.json'
    if summary_path.is_file():
        summary = load(summary_path)
        if summary.get('all_matched') is not True or summary.get('count') != 9:
            raise Failed(f'stored controls summary is not 9 matched cases: {summary.get("count")}')
        expected_cases = {
            'valid-unchanged-sibling': 0,
            'missing-source': 3,
            'changed-bytes': 1,
            'empty-inventory': 3,
            'bad-binding': 1,
            'overwritten-author-draft': 1,
            'missing-cited-design': 3,
            'changed-m3-receipt': 1,
            'wrong-funded-peer-exception': 1,
        }
        got = {c['name']: c['actual_exit'] for c in summary['cases']}
        if got != expected_cases or not all(c['matched'] for c in summary['cases']):
            raise Failed('stored control exits do not match the required nonvacuous set')
        for c in summary['cases']:
            case_path = ctx.validation / 'controls' / f'{c["name"]}.json'
            body = load(case_path)
            if body.get('telemetry') != 'actual_subprocess':
                raise Failed(f'{c["name"]} telemetry is not actual_subprocess')
            if not isinstance(body.get('command'), list) or '--check' not in body['command']:
                raise Failed(f'{c["name"]} missing actual --check argv')
            if not body.get('cwd'):
                raise Failed(f'{c["name"]} missing actual cwd')
            if 'reconstructed' in str(body.get('telemetry', '')).lower():
                raise Failed(f'{c["name"]} labelled reconstructed despite r2 rerun')
        note('stored_controls', True, got)

    return {
        'status': 'PASS',
        'kind': 'sealed_read_only_package_check_not_planning_acceptance',
        'gate_accepted': False,
        'package_review': 'pending independent GPT-6',
        'head_expected': HEAD_EXPECTED,
        'm3_source_candidate': SOURCE_CANDIDATE,
        'denominator': {
            'checks': len(checks),
            'source_inventory_rows': n_inv,
            'appendix_A': n_a,
            'mutation_specs': n_specs,
            'manifest_files': n_man,
            'fixtures': 20,
            'mutants': 14,
            'controls': 65,
            'requirements': 15,
            'scenarios': 45,
            'unchecked_tasks': 27,
            'original_apis': 47,
            'import_closure': 23,
        },
        'passed': len(checks),
        'failed': [],
        'checks': checks,
        'openspec': {
            'command': strict['command'],
            'exit': strict['exit'],
            'stdout': strict['stdout'],
            'executable': strict['executable'],
            'executable_sha256': strict['executable_sha256'],
        },
        'anchor': {
            'path': str(ctx.anchor.relative_to(ctx.root)),
            'manifest_sha256': anchor['manifest_sha256'],
            'inventory_sha256': anchor['inventory_sha256'],
        },
        'limits': [
            '--check writes no files.',
            'No CapabilityProvenance Lean, production mutants, inherited CLI controls, or financial/Lean suites ran.',
            'This checker does not set the planning gate accepted.',
        ],
    }


def emit_check(ctx: Ctx) -> int:
    try:
        result = check_sealed(ctx)
        print(json.dumps(result, indent=2, ensure_ascii=False))
        return 0
    except Blocked as exc:
        print(json.dumps({'status': 'BLOCKED', 'gate_accepted': False, 'reason': str(exc)},
                         indent=2, ensure_ascii=False))
        print(f'BLOCKED: {exc}', file=sys.stderr)
        return 3
    except Failed as exc:
        print(json.dumps({'status': 'FAIL', 'gate_accepted': False, 'reason': str(exc)},
                         indent=2, ensure_ascii=False))
        print(f'FAIL: {exc}', file=sys.stderr)
        return 1
    except FileNotFoundError as exc:
        print(json.dumps({'status': 'BLOCKED', 'gate_accepted': False,
                          'reason': f'missing input: {exc}'}, indent=2, ensure_ascii=False))
        print(f'BLOCKED: missing input: {exc}', file=sys.stderr)
        return 3
    except json.JSONDecodeError as exc:
        print(json.dumps({'status': 'BLOCKED', 'gate_accepted': False,
                          'reason': f'malformed inventory/manifest JSON: {exc}'},
                         indent=2, ensure_ascii=False))
        print(f'BLOCKED: malformed JSON: {exc}', file=sys.stderr)
        return 3


def skip_name(path: Path) -> bool:
    return path.name in {'__pycache__', 'MANIFEST.json', 'ANCHOR.json'} or path.suffix == '.pyc'


def seal(ctx: Ctx) -> dict:
    files = []
    for p in sorted(ctx.out.rglob('*')):
        if not p.is_file() or skip_name(p) or any(part == '__pycache__' for part in p.parts):
            continue
        files.append(rec(ctx, p))
    if not files:
        raise Blocked('seal: empty package file list')
    if not unique([r['path'] for r in files]):
        raise Failed('seal: duplicate package paths')
    manifest = {
        'kind': 'capability_provenance_official_r1_manifest',
        'gate_accepted': False,
        'package_review': 'pending independent GPT-6',
        'head': HEAD_EXPECTED,
        'file_count': len(files),
        'files': files,
        'script_sha256': sha(ctx.script.read_bytes()),
        'note': 'This file does not contain its own hash. Compare its SHA-256 to ANCHOR.json.',
    }
    dump_det(ctx.manifest, manifest)
    inventory_raw = ctx.inventory.read_bytes()
    manifest_raw = ctx.manifest.read_bytes()
    anchor = {
        'kind': 'external_trust_anchor_not_a_self_hash',
        'manifest_path': str(ctx.manifest.relative_to(ctx.root)),
        'manifest_sha256': sha(manifest_raw),
        'manifest_bytes': len(manifest_raw),
        'inventory_path': str(ctx.inventory.relative_to(ctx.root)),
        'inventory_sha256': sha(inventory_raw),
        'inventory_bytes': len(inventory_raw),
        'head': HEAD_EXPECTED,
        'note': 'Independently hash MANIFEST.json and source-inventory.json. Do not trust a hash stored inside MANIFEST.json.',
    }
    dump_det(ctx.anchor, anchor)
    print(json.dumps({
        'file_count': len(files),
        'gate_accepted': False,
        'manifest_sha256': anchor['manifest_sha256'],
        'inventory_sha256': anchor['inventory_sha256'],
        'anchor_path': str(ctx.anchor.relative_to(ctx.root)),
    }, indent=2))
    return anchor


def copy_bound(ctx: Ctx, dest_root: Path) -> None:
    inventory = load(ctx.inventory)
    manifest = load(ctx.manifest)
    paths = [ctx.root / row['path'] for row in inventory['rows']]
    paths.extend(ctx.root / row['path'] for row in manifest['files'])
    paths.extend([ctx.manifest, ctx.anchor, ctx.inventory])
    seen = set()
    for src in paths:
        if src in seen or not src.is_file():
            continue
        seen.add(src)
        rel = src.relative_to(ctx.root)
        dst = dest_root / rel
        dst.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(src, dst)


def run_check_on(root: Path, package: Path) -> dict:
    argv = [sys.executable, str(package / 'package.py'), '--check',
            '--root', str(root), '--package', str(package)]
    cwd = str(root)
    proc = subprocess.run(argv, cwd=cwd, capture_output=True)
    return {
        'telemetry': 'actual_subprocess',
        'command': argv,
        'cwd': cwd,
        'executable': sys.executable,
        'exit': proc.returncode,
        'stdout': proc.stdout.decode('utf-8', 'replace'),
        'stderr': proc.stderr.decode('utf-8', 'replace'),
        'stdout_sha256': sha(proc.stdout),
        'stderr_sha256': sha(proc.stderr),
        'stdout_bytes': len(proc.stdout),
        'stderr_bytes': len(proc.stderr),
    }


def controls(ctx: Ctx) -> dict:
    snapshot = Path(tempfile.mkdtemp(prefix='cap-off-snapshot-'))
    copy_bound(ctx, snapshot)
    out = ctx.validation / 'controls'
    if out.exists():
        shutil.rmtree(out)
    out.mkdir(parents=True, exist_ok=True)
    cases = []

    def record(name: str, expected: int, mutate) -> None:
        tmp = Path(tempfile.mkdtemp(prefix=f'cap-off-{name}-'))
        try:
            copy_bound(Ctx(snapshot, snapshot / PACKAGE_REL), tmp)
            mutate(tmp)
            result = run_check_on(tmp, tmp / PACKAGE_REL)
            row = {
                'name': name,
                'expected_exit': expected,
                'actual_exit': result['exit'],
                'matched': result['exit'] == expected,
                'telemetry': result['telemetry'],
                'command': result['command'],
                'cwd': result['cwd'],
                'executable': result['executable'],
                'stdout': result['stdout'],
                'stderr': result['stderr'],
                'stdout_sha256': result['stdout_sha256'],
                'stderr_sha256': result['stderr_sha256'],
                'stdout_bytes': result['stdout_bytes'],
                'stderr_bytes': result['stderr_bytes'],
            }
            dump_det(out / f'{name}.json', row)
            (out / f'{name}.stdout.log').write_text(result['stdout'])
            (out / f'{name}.stderr.log').write_text(result['stderr'])
            cases.append(row)
        finally:
            shutil.rmtree(tmp, ignore_errors=True)

    record('valid-unchanged-sibling', 0, lambda root: None)

    def missing(root: Path):
        (root / PLAN_REL / 'proposed-api.json').unlink()
    record('missing-source', 3, missing)

    def changed(root: Path):
        p = root / PLAN_REL / 'proposed-api.json'
        p.write_bytes(p.read_bytes() + b'\n')
    record('changed-bytes', 1, changed)

    def empty_inv(root: Path):
        inv = json.loads((root / PACKAGE_REL / 'source-inventory.json').read_text())
        inv['rows'] = []
        (root / PACKAGE_REL / 'source-inventory.json').write_text(json.dumps(inv, indent=2) + '\n')
    record('empty-inventory', 3, empty_inv)

    def bad_binding(root: Path):
        inv = json.loads((root / PACKAGE_REL / 'source-inventory.json').read_text())
        inv['rows'][0]['sha256'] = '0' * 64
        (root / PACKAGE_REL / 'source-inventory.json').write_text(json.dumps(inv, indent=2) + '\n')
    record('bad-binding', 1, bad_binding)

    def overwrite_author(root: Path):
        p = root / AUTHOR_REL / 'REPORT.md'
        p.write_bytes(p.read_bytes() + b'\n')
    record('overwritten-author-draft', 1, overwrite_author)

    def missing_cited(root: Path):
        (root / 'docs/superpowers/specs/2026-09-06-semantic-kernel-design.md').unlink()
    record('missing-cited-design', 3, missing_cited)

    def changed_receipt(root: Path):
        p = root / 'review/semantic-kernel/sprint11/delivery.json'
        p.write_bytes(p.read_bytes() + b'\n')
    record('changed-m3-receipt', 1, changed_receipt)

    def wrong_exception(root: Path):
        path = root / PLAN_REL / 'planned-mutations.json'
        body = json.loads(path.read_text())
        body['protected_global'] = WRONG_FUNDED_PEER_EXCEPTION
        path.write_text(json.dumps(body, indent=2) + '\n')
    record('wrong-funded-peer-exception', 1, wrong_exception)

    summary = {
        'kind': 'nonvacuous_package_controls',
        'all_matched': all(c['matched'] for c in cases),
        'count': len(cases),
        'cases': [{'name': c['name'], 'expected_exit': c['expected_exit'],
                   'actual_exit': c['actual_exit'], 'matched': c['matched'],
                   'telemetry': c['telemetry'], 'command': c['command'],
                   'cwd': c['cwd']} for c in cases],
        'note': 'Same python3 package.py --check entrypoint on temporary copies. command/cwd are actual subprocess fields, not reconstructed r1 telemetry. Real repo not mutated.',
    }
    dump_det(out / 'summary.json', summary)
    shutil.rmtree(snapshot, ignore_errors=True)
    print(json.dumps(summary, indent=2))
    if not summary['all_matched']:
        raise Failed('control cases did not all match expected exits')
    return summary


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument('--prepare', action='store_true')
    parser.add_argument('--seal', action='store_true')
    parser.add_argument('--check', action='store_true')
    parser.add_argument('--controls', action='store_true')
    parser.add_argument('--root')
    parser.add_argument('--package')
    args = parser.parse_args()
    if args.root or args.package:
        if not (args.root and args.package):
            print('BLOCKED: --root and --package must be used together', file=sys.stderr)
            return 3
        ctx = Ctx(Path(args.root), Path(args.package))
    else:
        ctx = default_ctx()
    selected = [args.prepare, args.seal, args.check, args.controls]
    if sum(bool(x) for x in selected) != 1:
        print('BLOCKED: select exactly one of --prepare --seal --check --controls', file=sys.stderr)
        return 3
    try:
        if args.prepare:
            prepare(ctx)
            return 0
        if args.seal:
            seal(ctx)
            return 0
        if args.controls:
            controls(ctx)
            return 0
        return emit_check(ctx)
    except Blocked as exc:
        print(f'BLOCKED: {exc}', file=sys.stderr)
        return 3
    except Failed as exc:
        print(f'FAIL: {exc}', file=sys.stderr)
        return 1


if __name__ == '__main__':
    sys.exit(main())
