# Capability provenance / isolation official r2 planning freeze

Package worker: native Grok 4.6. Independent checker: GPT-6. This report does not accept the planning gate. It repairs CP1 and CP2 from the independent GPT-6 r1 review. It does not rewrite r1 REPORT or r1 control logs.

## Status

Frozen r2 package is ready for a narrow independent GPT-6 check of CP1 and CP2. Implementation task boxes remain unchecked. `lean/DefiKernel/CapabilityProvenance` does not exist.

Isolated baseline / administrative D is `a12b7cac05a818cc8d35c2ca440b7170a2807e92`. M3 source candidate is `94f70e502c75132656bd0902a17be60ca45ab1c2`. Frozen r1 stage archive SHA-256 is `ad1b07a4c8285216e137770d375ee49080ade59278c01f251f57a3f9b4852d5a` (80 files). Original 23-file draft archive remains `bac7880e0ba650023192789f803eea35c2018a9dc9212d18c3e8b2c8922a89e3`.

## Exact review entrypoint

```
python3 review/semantic-kernel/capability-provenance/planning/grok-gpt6-official-r2/package.py --check
```

Hash `MANIFEST.json` independently and compare to `ANCHOR.json`. `MANIFEST.json` does not contain its own hash.

## CP1

r1 `planned-mutations.json` set `protected_global` to `capability.positive.funded-peer unless a mutant deliberately deletes initial origins`. That attached an M01 initial-origin exception to funded-peer, contrary to design and E04.

The live contract is now:

- `protected_global`: `capability.positive.funded-peer`
- required for all fourteen mutants
- each mutant lists `protected_positives: ["capability.positive.funded-peer"]`
- `capability.positive.initial-origin` may be omitted for M01 only

The checker lifts this from live `planned-mutations.json`. Intact copies pass. Restoring the exact r1 exception literal is a required failing control (`wrong-funded-peer-exception`, exit 1). Design, scientific specs, fixtures, and mutation meanings are otherwise unchanged.

## CP2

r1 REPORT claimed complete control argv under `validation/controls`. r1 `run_check_on` executed `--check --root --package` but returned only exit/stdout/stderr. Stored r1 case JSON omitted `command` and `cwd`. Those r1 files remain historical at `grok-gpt6-official-r1/`. Appendix F classifies any argv inferred from r1 `package.py` as reconstructed, not original telemetry.

r2 reruns the package controls. Each case JSON stores actual subprocess `command`, `cwd`, `executable`, full stdout/stderr, hashes and byte counts, with `telemetry: actual_subprocess`.

## Preserved accepted planning semantics

3 capabilities, 15 requirements, 45 scenarios, 27 unchecked tasks, 20 fixtures, 14 mutants, 65 inherited Metatheory CLI controls (10/5/50), 47 original plus 38 recovered used APIs (85), 23-file local import closure. M4/M5/M6 are not prerequisites. Sequential TraceSound, actual issue/use/revoke, supported observation isolation, trusted-root/refusal/confidentiality limits, source candidate 94 versus administrative D, and current M3 receipts are unchanged.

## Historical r1

Do not run r1 `--check` against live `planned-mutations.json`. Historical r1 equality is the frozen 80-file stage archive versus live r1 folder and versus all r1-equal normative files. Live `planned-mutations.json` must differ from that archive. r1 REPORT SHA-256 `3d6a3dc2f1e69acbe1b072642c04ab4665fe4ad9c97a0ee798b801763c48506d` is preserved.

Independent GPT-6 r1 review SHA-256 `1a3fde800e26d5b1da8a6af00e87b14ccc3814ad7604ffefc32560efbb58fc8e`. This r2 package still needs independent GPT-6 review. Gate accepted is false.
