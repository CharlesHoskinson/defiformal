# Capability provenance / isolation official planning freeze r2 (grok-gpt6-official-r2)

This is the independent GPT-6 review entrypoint for the CP1/CP2 repair. It is a hashed local map.

**Do not treat this package as planning-gate acceptance.** Independent GPT-6 review of this frozen r2 package remains pending. Native Grok 4.6 is the package worker, not the checker. No Foreman. No Lean implementation.

## Reviewer command (read-only)

```
python3 review/semantic-kernel/capability-provenance/planning/grok-gpt6-official-r2/package.py --check
```

Optional: `--root ROOT --package PACKAGE`. `--check` writes no files.

Independently hash `MANIFEST.json` and compare to `ANCHOR.json` field `manifest_sha256`. Hash `source-inventory.json` and compare to `ANCHOR.json` field `inventory_sha256`. `MANIFEST.json` does not contain its own hash.

## Bound identities

| Item | Value |
| --- | --- |
| Isolated baseline / administrative D | `a12b7cac05a818cc8d35c2ca440b7170a2807e92` |
| M3 source candidate | `94f70e502c75132656bd0902a17be60ca45ab1c2` |
| Frozen r1 stage archive | `ad1b07a4c8285216e137770d375ee49080ade59278c01f251f57a3f9b4852d5a` (80 files) |
| Original 23+manifest archive | `bac7880e0ba650023192789f803eea35c2018a9dc9212d18c3e8b2c8922a89e3` |
| r1 GPT-6 review | `1a3fde800e26d5b1da8a6af00e87b14ccc3814ad7604ffefc32560efbb58fc8e` |
| Package worker | grok-4.6 |
| Independent checker | GPT-6 (this package; pending) |

Do not run `grok-gpt6-official-r1/package.py --check` against live `planned-mutations.json`. Historical r1 equality uses the frozen r1 stage archive. The r1 folder, r1 REPORT, r1 control logs, and original author-draft are preserved and not rewritten.

## Repairs in this package

- **CP1.** `protected_global` is unconditional `capability.positive.funded-peer` for all 14 mutants. The M01 exception applies only to the separate `capability.positive.initial-origin` positive.
- **CP2.** r2 control records store actual subprocess `command` and `cwd`. r1 records remain historical without those fields; inferred r1 argv is labelled reconstructed.

## What this package is not

- Not CapabilityProvenance Lean implementation or a `DefiKernel.lean` import.
- Not production mutation or 65-control execution.
- Not planning-gate acceptance.
- Not a rewrite of r1 REPORT/logs or the original author-draft.
- Not an M4/M5/M6 prerequisite claim.
