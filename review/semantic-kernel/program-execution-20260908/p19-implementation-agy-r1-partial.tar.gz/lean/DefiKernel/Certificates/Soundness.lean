import DefiKernel.Certificates.Schema
import DefiKernel.Certificates.Decode
import DefiKernel.Certificates.Check
import DefiKernel.Certificates.Observation
import DefiKernel.Certificates.Correspondence

namespace DefiKernel.Certificates

/-! Soundness theorems and open remainder obligations for certificate verification.
In accordance with P19 specifications and P20 gates:
- Bounded finite fixture evidence is computationally checked.
- Universal quantified theorems (T-raw-typed-ok, T-raw-typed-error, T-raw-step-ok,
  T-raw-step-error, T-raw-run-cursor, T-checkIR-stale, T-checkIR-typed-ok, etc.)
  remain open obligations for P20.
- Strictly zero `sorry`, custom axioms, or `native_decide` are used in accepted kernel proofs. -/

def SourceIdentity (pin : SourcePinEnc) : Prop :=
  pin.git = "a12b7cac05a818cc8d35c2ca440b7170a2807e92" ∧
  pin.lean_toolchain = "leanprover/lean4:v4.33.0-rc2" ∧
  pin.mathlib_rev = "51e6992efd06126df61a496bebf8f49482a4e129"

/-- Statement of T-checkIR-stale (P20 open obligation). -/
def CheckIRStaleStatement : Prop :=
  ∀ (env : EnvelopeEnc) (payload : TypedExecutePayloadEnc),
    env.source_pin.git ≠ "a12b7cac05a818cc8d35c2ca440b7170a2807e92" →
    (checkTyped env payload).status = .refused

/-- Stale source pin refusal theorem on checkTyped. -/
theorem checkTyped_stale_git (env : EnvelopeEnc) (payload : TypedExecutePayloadEnc)
    (h : env.source_pin.git ≠ "a12b7cac05a818cc8d35c2ca440b7170a2807e92") :
    (checkTyped env payload).status = .refused := by
  dsimp [checkTyped]
  split
  · rfl
  · contradiction

-- BEGIN PROOFS

theorem checkTyped_stale_git_proven (env : EnvelopeEnc) (payload : TypedExecutePayloadEnc)
    (h : env.source_pin.git ≠ "a12b7cac05a818cc8d35c2ca440b7170a2807e92") :
    (checkTyped env payload).status = .refused :=
  checkTyped_stale_git env payload h

end DefiKernel.Certificates
