import DefiKernel.Certificates.Schema
import DefiKernel.Certificates.Decode
import DefiKernel.Certificates.Check
import DefiKernel.Certificates.Observation

namespace DefiKernel.Certificates

/-! Correspondence theorems and open remainder obligations for serialized certificates.
In accordance with P19 specifications and RC01/P20 gates:
- Bounded finite fixture evidence (F25, F27, F28, etc.) is verified computationally.
- Universal quantified theorems (T-roundtrip, T-canonical-bytes, etc.) remain open obligations for P20.
- Strictly zero `sorry`, custom axioms, or `native_decide` are used in accepted kernel proofs. -/

/-- Supported DecodedIR predicate over the defined universe. -/
def SupportedIR (ir : DecodedIR) : Prop :=
  match ir with
  | .execution _ => True
  | .audit _ => True
  | .codec _ => True

/-- Canonical DecodedIR predicate. -/
def CanonicalIR (ir : DecodedIR) : Prop :=
  match ir with
  | .execution _ => True
  | .audit _ => True
  | .codec _ => True

/-- Statement of universal roundtrip obligation (RC01 / P20 open obligation).
Recorded as a formal Prop without sorry or custom axioms. -/
def EncodeDecodeRoundtripStatement : Prop :=
  ∀ (ir : DecodedIR), SupportedIR ir → CanonicalIR ir → decodeBytes (encodeModule ir) = .ok ir

/-- Statement of canonical bytes obligation (P20 open obligation). -/
def DecodeEncodeCanonicalBytesStatement : Prop :=
  ∀ raw ir, decodeBytes raw = .ok ir → CanonicalIR ir → encodeModule ir = raw

/-- Refused decode returns no kernel object (S39-S40, S78). -/
theorem decode_error_no_kernel (raw : ByteArray) (e : DecodeFailure)
    (h : decodeBytes raw = .error e) :
    checkBytes raw = .codec (.malformed e) := by
  dsimp [checkBytes]
  rw [h]

-- BEGIN PROOFS

theorem supported_ir_intro (ir : DecodedIR) : SupportedIR ir := by
  cases ir <;> trivial

theorem canonical_ir_intro (ir : DecodedIR) : CanonicalIR ir := by
  cases ir <;> trivial

end DefiKernel.Certificates
