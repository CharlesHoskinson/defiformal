import DefiKernel.Certificates.Schema
import DefiKernel.Certificates.Decode
import DefiKernel.Certificates.Check
import DefiKernel.Certificates.Observation

namespace DefiKernel.Certificates

set_option linter.style.longLine false

/-! Correspondence theorems and open remainder obligations for serialized certificates.
In accordance with P19 specifications and RC01/P20 gates:
- Exact codec, raw execution, and checker success/error correspondence theorems are proven.
- Component-level roundtrip theorems (rational, party, asset, domain, right) are proven.
- Bounded finite fixture evidence (F25, F27, F28, etc.) is verified computationally.
- Universal quantified statements (T-roundtrip, T-canonical-bytes) are explicitly defined over
  a nonempty structurally admissible canonical IR domain. General parser inversion remains a P20 gate.
- Strictly zero `sorry`, custom axioms, or `native_decide` are used in accepted kernel proofs. -/

/-- Standard declaration order of 32 cell keys across (Domain × Party × Asset). -/
def standard32CellKeys : List (Domain × Party × Asset) :=
  let parties : List Party := [.alice, .bob, .vault, .pool]
  let assets : List Asset := [.usd, .share, .collateral, .debt]
  let domains : List Domain := [.main, .other]
  domains.flatMap fun d ↦
    parties.flatMap fun p ↦
      assets.map fun a ↦ (d, p, a)

/-- Complete 32-cell universe predicate: exact declaration order, unique cells, and canonical rationals. -/
def StateCellsMatchStandard32 (cells : List StateCellEnc) : Prop :=
  cells.length = 32 ∧
  cells.map (fun c ↦ (c.domain, c.party, c.asset)) = standard32CellKeys ∧
  cells.all (fun c ↦ c.amount.den > 0 ∧ c.amount.num ≥ 0 ∧ Int.gcd c.amount.num.natAbs c.amount.den = 1) = true

/-- Declaration order of types enumeration matching the standard universe. -/
def StandardTypesEnum (t : TypesEnumEnc) : Prop :=
  t.parties = [.alice, .bob, .vault, .pool] ∧
  t.assets = [.usd, .share, .collateral, .debt] ∧
  t.domains = [.main, .other]

/-- Strictly ascending lexicographical UTF-8 byte order on source map keys. -/
def SourceMapSorted (sm : List (String × String)) : Prop :=
  isSortedStrictAscending (sm.map Prod.fst) = true

/-- Canonical representation for packed values: inactive fields must be zero/false.
    For bool units, valRat must be zero. For numeric units, valBool must be false. -/
def PackedValueCanonical (v : PackedValueEnc) : Prop :=
  (v.unit = .bool → v.valRat = 0) ∧
  (∀ nu, v.unit = .numeric nu → v.valBool = false)

/-- Depth of an expression tree. -/
def ExprEnc.depth : ExprEnc → Nat
  | .lit _ => 1
  | .arg _ _ => 1
  | .balance _ => 1
  | .observe _ => 1
  | .timestamp _ => 1
  | .now => 1
  | .unary _ x => 1 + x.depth
  | .binary _ x y => 1 + max x.depth y.depth
  | .ite c y n => 1 + max c.depth (max y.depth n.depth)

/-- Recursive canonicality for expressions:
    1. Literals have canonical packed values.
    2. Sub-expressions are canonical.
    3. Expression depth does not exceed max_json_depth (64). -/
def ExprCanonical (e : ExprEnc) : Prop :=
  e.depth ≤ 64 ∧
  match e with
  | .lit v => PackedValueCanonical v
  | .unary _ x => ExprCanonical x
  | .binary _ x y => ExprCanonical x ∧ ExprCanonical y
  | .ite c y n => ExprCanonical c ∧ ExprCanonical y ∧ ExprCanonical n
  | _ => True

/-- Canonical template: guard and all deltas have canonical expressions. -/
def TemplateCanonical (t : TemplateEnc) : Prop :=
  ExprCanonical t.guard ∧
  (∀ d ∈ t.deltas, ExprCanonical d.amount) ∧
  (∀ s ∈ t.supplyDeltas, ExprCanonical s.amount)

/-- Canonical registry: entries are unique and each template is canonical. -/
def RegistryCanonical (r : RegistryEnc) : Prop :=
  (r.entries.map (·.id)).Nodup ∧
  (∀ e ∈ r.entries, TemplateCanonical e.template)

/-- Canonical store: capability entries are unique. -/
def StoreCanonical (s : StoreEnc) : Prop :=
  s.entries.Nodup

/-- Canonical environment: all observations have canonical packed values. -/
def EnvironmentCanonical (env : EnvironmentEnc) : Prop :=
  ∀ e ∈ env.entries, PackedValueCanonical e.observation.value

/-- Canonical request: all arguments have canonical packed values. -/
def RequestCanonical (r : RequestEnc) : Prop :=
  ∀ a ∈ r.arguments, PackedValueCanonical a

/-- Canonical input source: literals have canonical packed values. -/
def InputSourceCanonical : InputSourceEnc → Prop
  | .literal v => PackedValueCanonical v
  | .priorOutput _ _ => True

/-- Canonical invocation: input sources are canonical. -/
def InvocationCanonical (inv : InvocationEnc) : Prop :=
  ∀ i ∈ inv.inputs, InputSourceCanonical i

/-- Supported and canonical step: no unsupported constructors, invocations canonical. -/
def StepCanonical : StepEnc → Prop
  | .invoke inv => InvocationCanonical inv
  | .issue _ => True
  | .revoke _ => True
  | .unsupported _ => False

/-- Canonical world: standard 32 state cells and canonical store. -/
def WorldCanonical (w : WorldEnc) : Prop :=
  StateCellsMatchStandard32 w.state.cells ∧
  StoreCanonical w.capabilities

/-- Canonical claimed next state: none or canonical world. -/
def ClaimedNextStateCanonical (cns : Option WorldEnc) : Prop :=
  match cns with
  | none => True
  | some w => WorldCanonical w

/-- Canonical history: output observations have canonical packed values. -/
def HistoryCanonical (h : List OutputObservationEnc) : Prop :=
  ∀ o ∈ h, PackedValueCanonical o.value

/-- Canonical boundary: environment observations are canonical. -/
def BoundaryCanonical (b : BoundaryEnc) : Prop :=
  EnvironmentCanonical b.env

/-- Supported IR predicate: schema version 1, modes, complete 32-cell layout, non-negative amounts,
    supported step constructors, unique store and registry entries. -/
def SupportedIR (ir : DecodedIR) : Prop :=
  match ir with
  | .execution (.typed env payload) =>
    env.schema_version = 1 ∧
    env.mode = "typed-execute" ∧
    StandardTypesEnum env.types ∧
    payload.state.cells.length = 32 ∧
    payload.state.cells.map (fun c ↦ (c.domain, c.party, c.asset)) = standard32CellKeys ∧
    payload.state.cells.all (fun c ↦ c.amount.den > 0 ∧ c.amount.num ≥ 0) = true ∧
    StoreCanonical payload.store ∧
    (payload.registry.entries.map (·.id)).Nodup
  | .execution (.step env payload) =>
    env.schema_version = 1 ∧
    env.mode = "composition-step" ∧
    StandardTypesEnum env.types ∧
    (match payload.step with | .unsupported _ => False | _ => True) ∧
    payload.pre.state.cells.length = 32 ∧
    payload.pre.state.cells.map (fun c ↦ (c.domain, c.party, c.asset)) = standard32CellKeys ∧
    payload.pre.state.cells.all (fun c ↦ c.amount.den > 0 ∧ c.amount.num ≥ 0) = true ∧
    StoreCanonical payload.pre.capabilities ∧
    (payload.config.registry.entries.map (·.id)).Nodup
  | .execution (.run env payload) =>
    env.schema_version = 1 ∧
    env.mode = "composition-run" ∧
    StandardTypesEnum env.types ∧
    payload.steps.all (fun s ↦ match s with | .unsupported _ => false | _ => true) = true ∧
    payload.world.state.cells.length = 32 ∧
    payload.world.state.cells.map (fun c ↦ (c.domain, c.party, c.asset)) = standard32CellKeys ∧
    payload.world.state.cells.all (fun c ↦ c.amount.den > 0 ∧ c.amount.num ≥ 0) = true ∧
    StoreCanonical payload.world.capabilities ∧
    (payload.config.registry.entries.map (·.id)).Nodup
  | .audit _ => False
  | .codec _ => False

/-- Canonical IR predicate: lexicographical source map order, canonical rationals,
    inactive packed-value fields in arguments, expressions, and observations,
    and canonical template/step forms. -/
def CanonicalIR (ir : DecodedIR) : Prop :=
  match ir with
  | .execution (.typed env payload) =>
    SourceMapSorted env.source_map ∧
    ClaimedNextStateCanonical env.claimed_next_state ∧
    payload.state.cells.all (fun c ↦ Int.gcd c.amount.num.natAbs c.amount.den = 1) = true ∧
    (∀ e ∈ payload.registry.entries, TemplateCanonical e.template) ∧
    RequestCanonical payload.request ∧
    EnvironmentCanonical payload.env
  | .execution (.step env payload) =>
    SourceMapSorted env.source_map ∧
    ClaimedNextStateCanonical env.claimed_next_state ∧
    payload.pre.state.cells.all (fun c ↦ Int.gcd c.amount.num.natAbs c.amount.den = 1) = true ∧
    StepCanonical payload.step ∧
    (∀ e ∈ payload.config.registry.entries, TemplateCanonical e.template) ∧
    HistoryCanonical payload.history ∧
    BoundaryCanonical payload.boundary
  | .execution (.run env payload) =>
    SourceMapSorted env.source_map ∧
    ClaimedNextStateCanonical env.claimed_next_state ∧
    payload.world.state.cells.all (fun c ↦ Int.gcd c.amount.num.natAbs c.amount.den = 1) = true ∧
    (∀ s ∈ payload.steps, StepCanonical s) ∧
    (∀ e ∈ payload.config.registry.entries, TemplateCanonical e.template) ∧
    (∀ b ∈ payload.boundaries, BoundaryCanonical b)
  | .audit _ => False
  | .codec _ => False

/-- Structurally admissible canonical IR domain covering the accepted 32-cell execution universe.
    Defined as the conjunction of SupportedIR and CanonicalIR. -/
def StructurallyAdmissibleIR (ir : DecodedIR) : Prop :=
  SupportedIR ir ∧ CanonicalIR ir

/-- Nonempty witness for StructurallyAdmissibleIR: a standard 32-cell zero-initialized state
    with canonical 0/1 rationals, schema version 1, and typed-execute mode. -/
def standard32Cells : List StateCellEnc :=
  let parties : List Party := [.alice, .bob, .vault, .pool]
  let assets : List Asset := [.usd, .share, .collateral, .debt]
  let domains : List Domain := [.main, .other]
  domains.flatMap fun d ↦
    parties.flatMap fun p ↦
      assets.map fun a ↦
        ⟨d, p, a, ⟨0, 1⟩⟩

def canonicalWitnessIR : DecodedIR :=
  .execution (.typed
    ⟨1, "typed-execute", ⟨"a12b7cac05a818cc8d35c2ca440b7170a2807e92", "leanprover/lean4:v4.33.0-rc2",
      "51e6992efd06126df61a496bebf8f49482a4e129", "", none, none⟩,
      ["DefiKernel.Certificates", "DefiKernel.Typed", "DefiKernel.Composition"],
      ⟨[.alice, .bob, .vault, .pool], [.usd, .share, .collateral, .debt], [.main, .other]⟩,
      ["environment-authenticity"], [], [], [], [], none, false, false⟩
    ⟨⟨[]⟩, ⟨[]⟩, ⟨.alice, .main⟩, ⟨[]⟩, 100, ⟨0, [.alice], [], [], some .alice⟩, ⟨standard32Cells⟩⟩)

/-- Theorem: StructurallyAdmissibleIR is nonempty. -/
theorem structurallyAdmissible_nonempty : StructurallyAdmissibleIR canonicalWitnessIR := by
  dsimp [StructurallyAdmissibleIR, SupportedIR, CanonicalIR, canonicalWitnessIR, StandardTypesEnum,
         SourceMapSorted, ClaimedNextStateCanonical, standard32Cells, standard32CellKeys,
         isSortedStrictAscending, StoreCanonical, RequestCanonical, EnvironmentCanonical,
         WorldCanonical, StateCellsMatchStandard32]
  refine ⟨⟨rfl, rfl, ⟨rfl, rfl, rfl⟩, rfl, rfl, ?_, List.nodup_nil, List.nodup_nil⟩,
          ⟨rfl, trivial, ?_, ?_, ?_, ?_⟩⟩
  · decide
  · decide
  · intro _ h; contradiction
  · intro _ h; contradiction
  · intro _ h; contradiction

/-- Theorem: canonical byte decoding guarantees re-encoding identity (T-canonical-bytes). -/
theorem decodeBytes_encode_canonical (raw : ByteArray) (ir : DecodedIR)
    (h : decodeBytes raw = .ok ir) : encodeModule ir = raw := by
  unfold decodeBytes at h
  dsimp [bind, Except.bind, pure, Except.pure] at h
  split at h
  · contradiction
  · split at h
    · split at h
      · contradiction
      · split at h
        · contradiction
        · split at h
          · rename_i h_eq
            injection h with h_sub
            subst h_sub
            exact h_eq
          · contradiction
    · contradiction

/-- Statement of universal roundtrip obligation (RC01 / P20 open obligation).
    Quantifies over every structurally admissible canonical IR. -/
def EncodeDecodeRoundtripStatement : Prop :=
  ∀ (ir : DecodedIR), StructurallyAdmissibleIR ir → decodeBytes (encodeModule ir) = .ok ir

/-- Statement of canonical bytes obligation (T-canonical-bytes). -/
def DecodeEncodeCanonicalBytesStatement : Prop :=
  ∀ raw ir, decodeBytes raw = .ok ir → StructurallyAdmissibleIR ir → encodeModule ir = raw

/-- Discharges T-canonical-bytes: universal canonical bytes theorem proven in the Lean kernel. -/
theorem decode_encode_canonical_bytes : DecodeEncodeCanonicalBytesStatement := by
  intro raw ir h _
  exact decodeBytes_encode_canonical raw ir h

/-- Refused decode returns no kernel object (S39-S40, S78). -/
theorem decode_error_no_kernel (raw : ByteArray) (e : DecodeFailure)
    (h : decodeBytes raw = .error e) (h_not_res : ∀ lim, e ≠ .resourceLimit lim) :
    checkBytes raw = .codec (.malformed e) := by
  dsimp [checkBytes]
  rw [h]
  cases e with
  | resourceLimit lim =>
    exfalso
    exact h_not_res lim rfl
  | emptyDocument => rfl
  | lexicalScientificOrFloat => rfl
  | notJsonObject => rfl
  | duplicateKey _ => rfl
  | noncanonicalWhitespace => rfl
  | schemaVersion => rfl
  | missingField _ => rfl
  | jsonType _ => rfl
  | unknownIdentifier _ => rfl
  | uniqueness _ => rfl
  | illegalRational _ => rfl
  | stateNonneg => rfl
  | unknownExecutableField _ => rfl
  | unsupportedForm _ => rfl

/-- Resource limit decode refusal maps to blocked codec result. -/
theorem decode_error_resource_limit (raw : ByteArray) (lim : String)
    (h : decodeBytes raw = .error (.resourceLimit lim)) :
    checkBytes raw = .codec (.blocked lim) := by
  dsimp [checkBytes]
  rw [h]

/-- Any decode error produces a CodecResult outcome, guaranteeing no kernel entrypoint is invoked. -/
theorem checkBytes_no_kernel_on_error (raw : ByteArray) (e : DecodeFailure)
    (h : decodeBytes raw = .error e) :
    ∃ (c : CodecResult), checkBytes raw = .codec c := by
  dsimp [checkBytes]
  rw [h]
  cases e with
  | resourceLimit lim => exact ⟨.blocked lim, rfl⟩
  | emptyDocument => exact ⟨.malformed .emptyDocument, rfl⟩
  | lexicalScientificOrFloat => exact ⟨.malformed .lexicalScientificOrFloat, rfl⟩
  | notJsonObject => exact ⟨.malformed .notJsonObject, rfl⟩
  | duplicateKey k => exact ⟨.malformed (.duplicateKey k), rfl⟩
  | noncanonicalWhitespace => exact ⟨.malformed .noncanonicalWhitespace, rfl⟩
  | schemaVersion => exact ⟨.malformed .schemaVersion, rfl⟩
  | missingField m => exact ⟨.malformed (.missingField m), rfl⟩
  | jsonType p => exact ⟨.malformed (.jsonType p), rfl⟩
  | unknownIdentifier u => exact ⟨.malformed (.unknownIdentifier u), rfl⟩
  | uniqueness k => exact ⟨.malformed (.uniqueness k), rfl⟩
  | illegalRational r => exact ⟨.malformed (.illegalRational r), rfl⟩
  | stateNonneg => exact ⟨.malformed .stateNonneg, rfl⟩
  | unknownExecutableField f => exact ⟨.malformed (.unknownExecutableField f), rfl⟩
  | unsupportedForm r => exact ⟨.malformed (DecodeFailure.unsupportedForm r), rfl⟩

/-- Successful decode routes directly to checkIR. -/
theorem checkBytes_ok (raw : ByteArray) (ir : DecodedIR)
    (h : decodeBytes raw = .ok ir) :
    checkBytes raw = checkIR ir := by
  dsimp [checkBytes]
  rw [h]

/-- CheckBytes for typed execution payload routes directly to checkTyped. -/
theorem checkBytes_typed_correspondence (raw : ByteArray) (env : EnvelopeEnc) (payload : TypedExecutePayloadEnc)
    (h_dec : decodeBytes raw = .ok (.execution (.typed env payload))) :
    checkBytes raw = .execution (checkTyped env payload) := by
  have h := checkBytes_ok raw (.execution (.typed env payload)) h_dec
  rw [h]
  rfl

/-- CheckBytes for composition step payload routes directly to checkStep. -/
theorem checkBytes_step_correspondence (raw : ByteArray) (env : EnvelopeEnc) (payload : CompositionStepPayloadEnc)
    (h_dec : decodeBytes raw = .ok (.execution (.step env payload))) :
    checkBytes raw = .execution (checkStep env payload) := by
  have h := checkBytes_ok raw (.execution (.step env payload)) h_dec
  rw [h]
  rfl

/-- CheckBytes for composition run payload routes directly to checkRun. -/
theorem checkBytes_run_correspondence (raw : ByteArray) (env : EnvelopeEnc) (payload : CompositionRunPayloadEnc)
    (h_dec : decodeBytes raw = .ok (.execution (.run env payload))) :
    checkBytes raw = .execution (checkRun env payload) := by
  have h := checkBytes_ok raw (.execution (.run env payload)) h_dec
  rw [h]
  rfl

/-- Canonical rational decoding theorem: canonical numerator/denominator pair decodes to RatEnc. -/
theorem rational_decode_canonical (num : Int) (den : Nat) (h_den : den ≠ 0) (h_gcd : Int.gcd num.natAbs den = 1) :
    decodeRational num den = .ok ⟨num, den⟩ := by
  unfold decodeRational
  split
  · contradiction
  · split
    · rename_i h_noncan
      have h1 : ¬ (Int.gcd num.natAbs den ≠ 1) := by
        intro h_contra
        exact h_contra h_gcd
      contradiction
    · rfl

/-- Exact correspondence between RatEnc and ℚ components. -/
theorem rat_fromRat_num_den (q : ℚ) :
    (RatEnc.fromRat q).num = q.num ∧ (RatEnc.fromRat q).den = q.den :=
  ⟨rfl, rfl⟩

/-- Rational encode/decode roundtrip: any canonical rational roundtrips via decodeRational. -/
theorem rational_roundtrip (r : RatEnc) (h_den : r.den ≠ 0) (h_gcd : Int.gcd r.num.natAbs r.den = 1) :
    decodeRational r.num r.den = .ok r :=
  rational_decode_canonical r.num r.den h_den h_gcd

/-- Party decode roundtrip. -/
theorem decodeParty_encodeParty (p : Party) :
    decodeParty (.str (match p with | .alice => "alice" | .bob => "bob" | .vault => "vault" | .pool => "pool")) = .ok p := by
  cases p <;> rfl

/-- Asset decode roundtrip. -/
theorem decodeAsset_encodeAsset (a : Asset) :
    decodeAsset (.str (match a with | .usd => "usd" | .share => "share" | .collateral => "collateral" | .debt => "debt")) = .ok a := by
  cases a <;> rfl

/-- Domain decode roundtrip. -/
theorem decodeDomain_encodeDomain (d : Domain) :
    decodeDomain (.str (match d with | .main => "main" | .other => "other")) = .ok d := by
  cases d <;> rfl

/-- Right decode roundtrip for invoke. -/
theorem decodeRight_invoke :
    decodeRight (Lean.Json.mkObj [("tag", Lean.Json.str "invoke")]) = .ok .invoke := by
  rfl

/-- PartyRef decode roundtrip for caller. -/
theorem decodePartyRef_caller :
    decodePartyRef (Lean.Json.mkObj [("tag", Lean.Json.str "caller")]) = .ok .caller := by
  rfl

/-- PartyRef decode roundtrip for literal party. -/
theorem decodePartyRef_literal (p : Party) :
    decodePartyRef (Lean.Json.mkObj [("tag", Lean.Json.str "literal"), ("party", match p with
      | .alice => Lean.Json.str "alice"
      | .bob => Lean.Json.str "bob"
      | .vault => Lean.Json.str "vault"
      | .pool => Lean.Json.str "pool")]) = .ok (.literal p) := by
  cases p <;> rfl

/-- NumericUnit decode roundtrip for scalar. -/
theorem decodeNumericUnit_scalar :
    decodeNumericUnit (Lean.Json.mkObj [("tag", Lean.Json.str "scalar")]) = .ok .scalar := by
  rfl

/-- NumericUnit decode roundtrip for amount. -/
theorem decodeNumericUnit_amount (a : Asset) :
    decodeNumericUnit (Lean.Json.mkObj [("tag", Lean.Json.str "amount"), ("asset", match a with
      | .usd => Lean.Json.str "usd"
      | .share => Lean.Json.str "share"
      | .collateral => Lean.Json.str "collateral"
      | .debt => Lean.Json.str "debt")]) = .ok (.amount a) := by
  cases a <;> rfl

/-- Unit decode roundtrip for bool. -/
theorem decodeUnit_bool :
    decodeUnit (Lean.Json.mkObj [("tag", Lean.Json.str "bool")]) = .ok .bool := by
  rfl

/-- Unit decode roundtrip for scalar. -/
theorem decodeUnit_scalar :
    decodeUnit (Lean.Json.mkObj [("tag", Lean.Json.str "scalar")]) = .ok (.numeric .scalar) := by
  rfl

/-- Unit decode roundtrip for amount. -/
theorem decodeUnit_amount (a : Asset) :
    decodeUnit (Lean.Json.mkObj [("tag", Lean.Json.str "amount"), ("asset", match a with
      | .usd => Lean.Json.str "usd"
      | .share => Lean.Json.str "share"
      | .collateral => Lean.Json.str "collateral"
      | .debt => Lean.Json.str "debt")]) = .ok (.numeric (.amount a)) := by
  cases a <;> rfl

/-- Registry decode roundtrip for empty registry. -/
theorem decodeRegistry_empty :
    decodeRegistry (Lean.Json.mkObj [("entries", Lean.Json.arr #[])]) = .ok ⟨[]⟩ := by
  rfl

/-- Store decode roundtrip for empty store. -/
theorem decodeStore_empty :
    decodeStore (Lean.Json.mkObj [("entries", Lean.Json.arr #[])]) = .ok ⟨[]⟩ := by
  rfl

/-- Right decode roundtrip for debit. -/
theorem decodeRight_debit (c : CellEnc) :
    decodeRight (Lean.Json.mkObj [("tag", Lean.Json.str "debit"), ("cell", Lean.Json.mkObj [
      ("domain", Lean.Json.str (match c.domain with | .main => "main" | .other => "other")),
      ("party", Lean.Json.str (match c.party with | .alice => "alice" | .bob => "bob" | .vault => "vault" | .pool => "pool")),
      ("asset", Lean.Json.str (match c.asset with | .usd => "usd" | .share => "share" | .collateral => "collateral" | .debt => "debt"))
    ])]) = .ok (.debit c) := by
  cases c with
  | mk d p a => cases d <;> cases p <;> cases a <;> rfl

/-- Right decode roundtrip for changeSupply. -/
theorem decodeRight_changeSupply (d : Domain) (a : Asset) :
    decodeRight (Lean.Json.mkObj [
      ("tag", Lean.Json.str "changeSupply"),
      ("domain", Lean.Json.str (match d with | .main => "main" | .other => "other")),
      ("asset", Lean.Json.str (match a with | .usd => "usd" | .share => "share" | .collateral => "collateral" | .debt => "debt"))
    ]) = .ok (.changeSupply d a) := by
  cases d <;> cases a <;> rfl

/-- PartyRef decode roundtrip for argument index. -/
theorem decodePartyRef_argument (idx : Nat) :
    decodePartyRef (Lean.Json.mkObj [("tag", Lean.Json.str "argument"), ("index", Lean.Json.num idx)]) = .ok (.argument idx) := by
  dsimp [decodePartyRef]
  rfl

/-- NumericUnit decode roundtrip for price. -/
theorem decodeNumericUnit_price (b q : Asset) :
    decodeNumericUnit (Lean.Json.mkObj [
      ("tag", Lean.Json.str "price"),
      ("base", Lean.Json.str (match b with | .usd => "usd" | .share => "share" | .collateral => "collateral" | .debt => "debt")),
      ("quote", Lean.Json.str (match q with | .usd => "usd" | .share => "share" | .collateral => "collateral" | .debt => "debt"))
    ]) = .ok (.price b q) := by
  cases b <;> cases q <;> rfl

/-- PackedValue decode roundtrip for bool values. -/
theorem decodePackedValue_bool (b : Bool) :
    decodePackedValue (Lean.Json.mkObj [
      ("unit", Lean.Json.mkObj [("tag", Lean.Json.str "bool")]),
      ("value", Lean.Json.bool b)
    ]) = .ok ⟨.bool, 0, b⟩ := by
  cases b <;> rfl

/-- PackedValue decode roundtrip for canonical boolean packed values. -/
theorem decodePackedValue_canonical_bool (v : PackedValueEnc) (h_u : v.unit = .bool) (h_can : PackedValueCanonical v) :
    decodePackedValue (Lean.Json.mkObj [
      ("unit", Lean.Json.mkObj [("tag", Lean.Json.str "bool")]),
      ("value", Lean.Json.bool v.valBool)
    ]) = .ok v := by
  have h_rat : v.valRat = 0 := h_can.1 h_u
  have h_eq : v = ⟨.bool, 0, v.valBool⟩ := by
    cases v
    dsimp at h_u h_rat
    subst h_u h_rat
    rfl
  rw [h_eq]
  cases v.valBool <;> rfl

/-- ObservationKey decode roundtrip for arbitrary domain and id. -/
theorem decodeObservationKey_roundtrip (k : ObservationKeyEnc) :
    decodeObservationKey (Lean.Json.mkObj [
      ("domain", Lean.Json.str (match k.domain with | .main => "main" | .other => "other")),
      ("id", Lean.Json.num k.id)
    ]) = .ok k := by
  cases k with
  | mk d id =>
    cases d <;> (dsimp [decodeObservationKey, decodeDomain, Lean.Json.mkObj]; rfl)

/-- EnvRead decode roundtrip for currentTime. -/
theorem decodeEnvRead_currentTime :
    decodeEnvRead (Lean.Json.mkObj [("tag", Lean.Json.str "currentTime")]) = .ok .currentTime := by
  rfl

/-- UnaryOp decode roundtrip for not. -/
theorem decodeUnaryOp_not :
    decodeUnaryOp (Lean.Json.mkObj [("tag", Lean.Json.str "not")]) = .ok .not := by
  rfl

/-- UnaryOp decode roundtrip for neg. -/
theorem decodeUnaryOp_neg (nu : NumericUnitEnc) :
    decodeUnaryOp (Lean.Json.mkObj [
      ("tag", Lean.Json.str "neg"),
      ("numeric", match nu with
        | .amount a => Lean.Json.mkObj [("tag", Lean.Json.str "amount"), ("asset", Lean.Json.str (match a with | .usd => "usd" | .share => "share" | .collateral => "collateral" | .debt => "debt"))]
        | .price b q => Lean.Json.mkObj [("tag", Lean.Json.str "price"), ("base", Lean.Json.str (match b with | .usd => "usd" | .share => "share" | .collateral => "collateral" | .debt => "debt")), ("quote", Lean.Json.str (match q with | .usd => "usd" | .share => "share" | .collateral => "collateral" | .debt => "debt"))]
        | .scalar => Lean.Json.mkObj [("tag", Lean.Json.str "scalar")])
    ]) = .ok (.neg nu) := by
  cases nu with
  | amount a => cases a <;> rfl
  | price b q => cases b <;> cases q <;> rfl
  | scalar => rfl

/-- BinaryOp decode roundtrip for and. -/
theorem decodeBinaryOp_and :
    decodeBinaryOp (Lean.Json.mkObj [("tag", Lean.Json.str "and")]) = .ok .and := by
  rfl

/-- BinaryOp decode roundtrip for or. -/
theorem decodeBinaryOp_or :
    decodeBinaryOp (Lean.Json.mkObj [("tag", Lean.Json.str "or")]) = .ok .or := by
  rfl

/-- CellRef decode roundtrip for literal owner. -/
theorem decodeCellRef_roundtrip (d : Domain) (p : Party) :
    decodeCellRef (Lean.Json.mkObj [
      ("domain", Lean.Json.str (match d with | .main => "main" | .other => "other")),
      ("owner", Lean.Json.mkObj [("tag", Lean.Json.str "literal"), ("party", Lean.Json.str (match p with | .alice => "alice" | .bob => "bob" | .vault => "vault" | .pool => "pool"))])
    ]) = .ok ⟨d, .literal p⟩ := by
  cases d <;> cases p <;> rfl

/-- Cell decode roundtrip across the full domain-party-asset space. -/
theorem decodeCell_roundtrip (c : CellEnc) :
    decodeCell (Lean.Json.mkObj [
      ("domain", Lean.Json.str (match c.domain with | .main => "main" | .other => "other")),
      ("party", Lean.Json.str (match c.party with | .alice => "alice" | .bob => "bob" | .vault => "vault" | .pool => "pool")),
      ("asset", Lean.Json.str (match c.asset with | .usd => "usd" | .share => "share" | .collateral => "collateral" | .debt => "debt"))
    ]) = .ok c := by
  cases c with
  | mk d p a => cases d <;> cases p <;> cases a <;> rfl

/-- Context decode roundtrip. -/
theorem decodeContext_roundtrip (c : ContextEnc) :
    decodeContext (Lean.Json.mkObj [
      ("principal", Lean.Json.str (match c.principal with | .alice => "alice" | .bob => "bob" | .vault => "vault" | .pool => "pool")),
      ("domain", Lean.Json.str (match c.domain with | .main => "main" | .other => "other"))
    ]) = .ok c := by
  cases c with
  | mk p d => cases p <;> cases d <;> (dsimp [decodeContext, decodeParty, decodeDomain, Lean.Json.mkObj]; rfl)

/-- DomainAdmin decode roundtrip. -/
theorem decodeDomainAdmin_roundtrip (d : DomainAdminEnc) :
    decodeDomainAdmin (Lean.Json.mkObj [
      ("domain", Lean.Json.str (match d.domain with | .main => "main" | .other => "other")),
      ("party", Lean.Json.str (match d.party with | .alice => "alice" | .bob => "bob" | .vault => "vault" | .pool => "pool"))
    ]) = .ok d := by
  cases d with
  | mk dm p => cases dm <;> cases p <;> (dsimp [decodeDomainAdmin, decodeDomain, decodeParty, Lean.Json.mkObj]; rfl)

/-- QualifiedPort decode roundtrip. -/
theorem decodeQualifiedPort_roundtrip (p : QualifiedPortEnc) :
    decodeQualifiedPort (Lean.Json.mkObj [("component", Lean.Json.num p.component), ("port", Lean.Json.num p.port)]) = .ok p := by
  cases p with
  | mk c port => dsimp [decodeQualifiedPort, Lean.Json.mkObj]; rfl

/-- Step decode roundtrip for revoke. -/
theorem decodeStep_revoke (id : Nat) :
    decodeStep (Lean.Json.mkObj [("tag", Lean.Json.str "revoke"), ("id", Lean.Json.num id)]) = .ok (.revoke id) := by
  dsimp [decodeStep, Lean.Json.mkObj]
  rfl

/-- ExprFuel decode roundtrip for now constructor. -/
theorem decodeExprFuel_now (fuel : Nat) :
    decodeExprFuel (fuel + 1) (Lean.Json.mkObj [("tag", Lean.Json.str "now")]) = .ok .now := by
  rfl

/-- ExprFuel decode roundtrip for argument constructor. -/
theorem decodeExprFuel_arg_bool (fuel : Nat) (idx : Nat) :
    decodeExprFuel (fuel + 1) (Lean.Json.mkObj [
      ("tag", Lean.Json.str "arg"),
      ("index", Lean.Json.num idx),
      ("unit", Lean.Json.mkObj [("tag", Lean.Json.str "bool")])
    ]) = .ok (.arg idx .bool) := by
  rfl

/-- ExprFuel decode roundtrip for boolean literal. -/
theorem decodeExprFuel_lit_bool (fuel : Nat) (b : Bool) :
    decodeExprFuel (fuel + 1) (Lean.Json.mkObj [
      ("tag", Lean.Json.str "lit"),
      ("unit", Lean.Json.mkObj [("tag", Lean.Json.str "bool")]),
      ("value", Lean.Json.bool b)
    ]) = .ok (.lit ⟨.bool, 0, b⟩) := by
  cases b <;> rfl

/-- Production decodeExpr roundtrip for now constructor. -/
theorem decodeExpr_now :
    decodeExpr (Lean.Json.mkObj [("tag", Lean.Json.str "now")]) = .ok .now := by
  rfl

/-- Production decodeExpr roundtrip for boolean literal. -/
theorem decodeExpr_lit_bool (b : Bool) :
    decodeExpr (Lean.Json.mkObj [
      ("tag", Lean.Json.str "lit"),
      ("unit", Lean.Json.mkObj [("tag", Lean.Json.str "bool")]),
      ("value", Lean.Json.bool b)
    ]) = .ok (.lit ⟨.bool, 0, b⟩) := by
  cases b <;> rfl

end DefiKernel.Certificates
