#!/usr/bin/env python3
"""Record a command with argv, cwd, UTC, full stdout/stderr, exit, and tool hashes."""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import shutil
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def sha256_file(path: Path) -> str | None:
    if not path.is_file():
        return None
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def resolve_tool(argv0: str, cwd: Path) -> dict:
    path = Path(argv0)
    if not path.is_absolute():
        found = shutil.which(argv0)
        path = Path(found) if found else (cwd / argv0)
    resolved = path.resolve() if path.exists() else path
    return {
        "argv0": argv0,
        "resolved": str(resolved),
        "exists": resolved.is_file(),
        "sha256": sha256_file(resolved) if resolved.is_file() else None,
        "mode": oct(resolved.stat().st_mode) if resolved.exists() else None,
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--name", required=True)
    parser.add_argument("--cwd", required=True)
    parser.add_argument("--out", required=True, help="JSON receipt path")
    parser.add_argument("--stdout-path", required=True)
    parser.add_argument("--stderr-path", required=True)
    parser.add_argument("--timeout", type=float, default=None)
    parser.add_argument("--env", action="append", default=[], help="KEY=VALUE extras")
    parser.add_argument("cmd", nargs=argparse.REMAINDER)
    args = parser.parse_args()
    cmd = args.cmd
    if cmd and cmd[0] == "--":
        cmd = cmd[1:]
    if not cmd:
        print("missing command", file=sys.stderr)
        return 3
    cwd = Path(args.cwd).resolve()
    if not cwd.is_dir():
        print(f"cwd missing: {cwd}", file=sys.stderr)
        return 3
    env = os.environ.copy()
    for item in args.env:
        if "=" not in item:
            print(f"bad --env {item}", file=sys.stderr)
            return 3
        k, v = item.split("=", 1)
        env[k] = v
    start = utc_now()
    try:
        proc = subprocess.run(
            cmd,
            cwd=str(cwd),
            env=env,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            timeout=args.timeout,
            check=False,
        )
        timeout = False
        exit_code = proc.returncode
        stdout = proc.stdout
        stderr = proc.stderr
    except subprocess.TimeoutExpired as exc:
        timeout = True
        exit_code = None
        stdout = exc.stdout or b""
        stderr = exc.stderr or b""
    end = utc_now()
    stdout_path = Path(args.stdout_path)
    stderr_path = Path(args.stderr_path)
    stdout_path.parent.mkdir(parents=True, exist_ok=True)
    stderr_path.parent.mkdir(parents=True, exist_ok=True)
    stdout_path.write_bytes(stdout)
    stderr_path.write_bytes(stderr)
    receipt = {
        "name": args.name,
        "argv": cmd,
        "cwd": str(cwd),
        "start_utc": start,
        "end_utc": end,
        "timeout": timeout,
        "exit": exit_code,
        "stdout_path": str(stdout_path),
        "stderr_path": str(stderr_path),
        "stdout_sha256": sha256_bytes(stdout),
        "stderr_sha256": sha256_bytes(stderr),
        "stdout_bytes": len(stdout),
        "stderr_bytes": len(stderr),
        "tool": resolve_tool(cmd[0], cwd),
        "python": sys.version,
        "record_cmd_sha256": sha256_file(Path(__file__).resolve()),
    }
    out = Path(args.out)
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(receipt, indent=2) + "\n")
    print(json.dumps({"name": args.name, "exit": exit_code, "timeout": timeout}))
    if timeout:
        return 3
    return 0 if exit_code == 0 else 0


if __name__ == "__main__":
    raise SystemExit(main())
