import DefiKernel.Certificates.Decode
import DefiKernel.Certificates.Encode
import DefiKernel.Certificates.Check
open DefiKernel.Certificates
open Lean

def main : IO Unit := do
  let s ← IO.FS.readFile "/tmp/f25_rep.json"
  match Json.parse s with
  | .error e => IO.println s!"Json.parse error: {e}"
  | .ok j =>
    match decodeReport j with
    | .ok _ => IO.println "decodeReport ok!"
    | .error e => IO.println s!"decodeReport error: {encodeDecodeFailure e}"
