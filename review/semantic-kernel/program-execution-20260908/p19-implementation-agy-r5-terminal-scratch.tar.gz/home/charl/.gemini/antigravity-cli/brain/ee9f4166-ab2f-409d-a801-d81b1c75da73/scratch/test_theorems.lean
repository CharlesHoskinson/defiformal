import DefiKernel.Certificates.Schema
import DefiKernel.Certificates.Decode
import DefiKernel.Certificates.Check
import DefiKernel.Certificates.Observation
import DefiKernel.Certificates.Correspondence
import DefiKernel.Composition.Sequence

namespace DefiKernel.Certificates

open DefiKernel.Composition

theorem rawExecute_run_cursor (env : EnvelopeEnc) (payload : CompositionRunPayloadEnc)
    (cfg : Config Party Asset Domain)
    (h_cfg : configToTyped? payload.config = some cfg)
    (initialWorld : World Party Asset Domain)
    (h_world : payload.world.toWorld? = some initialWorld) :
    let bList := payload.boundaries.map boundaryToTyped
    let defaultBoundary : Boundary Party Asset Domain :=
      ⟨⟨.alice, .main⟩, fun _ ↦ none, 100⟩
    let boundaries : Nat → Boundary Party Asset Domain :=
      fun idx ↦ match bList[idx]? with
      | some b => b
      | none => bList.head?.getD defaultBoundary
    let steps : List (Composition.Step Party Asset Domain) :=
      payload.steps.filterMap StepEnc.toStep?
    let cursor := Composition.run cfg boundaries initialWorld steps
    (rawExecute (.run env payload)).outputs = cursor.outputs.map OutputObservationEnc.fromOutputObservation ∧
    (rawExecute (.run env payload)).nextIndex = cursor.nextIndex ∧
    (rawExecute (.run env payload)).cursorFailure =
      cursor.failure.map fun cf ↦
        let stepEnc := cf.step.map fun s ↦ match s with
          | .invoke inv => StepEnc.invoke ⟨inv.component.value, inv.operation.value, inv.parties, [], inv.capabilityIds.map (·.value), inv.claimedActor⟩
          | .issue g => StepEnc.issue ⟨g.holder, g.domain, g.operation.value, match g.right with | .invoke => .invoke | .debit c => .debit ⟨c.1, c.2.1, c.2.2⟩ | .changeSupply d a => .changeSupply d a⟩
          | .revoke id => StepEnc.revoke id.value
        ⟨cf.index, stepEnc, failureToPath cf.reason⟩ := by
  dsimp [rawExecute]
  rw [h_cfg]
  dsimp
  rw [h_world]
  dsimp
  refine ⟨rfl, rfl, rfl⟩

end DefiKernel.Certificates

theorem checkStep_step_ok (cert : EnvelopeEnc) (payload : CompositionStepPayloadEnc)
    (cfg : Config Party Asset Domain)
    (h_cfg : configToTyped? payload.config = some cfg)
    (pre : World Party Asset Domain)
    (h_pre : payload.pre.toWorld? = some pre)
    (step : Composition.Step Party Asset Domain)
    (h_step : payload.step.toStep? = some step)
    (res : StepResult Party Asset Domain)
    (h_exec : Composition.executeStep cfg (boundaryToTyped payload.boundary) payload.index
        (payload.history.map OutputObservationEnc.toOutputObservation) step pre = .ok res) :
    (checkStep cert payload).outputs = res.outputs.map OutputObservationEnc.fromOutputObservation ∧
    (checkStep cert payload).nextIndex = payload.index := by
  dsimp [checkStep]
  rw [h_cfg]
  dsimp
  rw [h_pre]
  dsimp
  rw [h_step]
  dsimp
  rw [h_exec]
  dsimp
  refine ⟨rfl, rfl⟩
