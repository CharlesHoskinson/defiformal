def main : IO Unit := do
  let content ← IO.FS.readFile "../openspec/changes/serialized-kernel-certificates/planned-mutations.json"
  IO.println s!"Read {content.length} chars"

#eval main
