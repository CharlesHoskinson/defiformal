structure FailurePath where
  ctor : String
  deriving DecidableEq, Repr

structure Report where
  failure : Option FailurePath
  deriving DecidableEq, Repr

def reportEq (r1 r2 : Report) : Bool :=
  let failure := r1.failure
  let other := r2
  decide (failure = other.failure)

def r1 : Report := ⟨some ⟨"insufficientFunds"⟩⟩
def r2 : Report := ⟨some ⟨"unauthorizedDebit"⟩⟩

#eval reportEq r1 r2
