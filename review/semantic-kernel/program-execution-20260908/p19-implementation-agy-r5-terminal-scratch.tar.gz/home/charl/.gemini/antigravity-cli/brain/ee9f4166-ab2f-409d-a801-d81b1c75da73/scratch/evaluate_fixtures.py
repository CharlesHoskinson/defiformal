#!/usr/bin/env python3
import json
import subprocess
import time
from pathlib import Path

REPO_ROOT = Path("/home/charl/defiformal-wt-p19-certificates-grok-opus-20260909")
FIXTURES_PATH = REPO_ROOT / "openspec/changes/serialized-kernel-certificates/fixtures.json"
SCENARIOS_PATH = REPO_ROOT / "openspec/changes/serialized-kernel-certificates/scenario-map.json"

fixtures_data = json.loads(FIXTURES_PATH.read_text())["fixtures"]
scenarios_data = json.loads(SCENARIOS_PATH.read_text())["scenarios"]

harness_code = '''
import DefiKernel.Certificates.Schema
import DefiKernel.Certificates.Decode
import DefiKernel.Certificates.Check

open DefiKernel.Certificates

def main (args : List String) : IO Unit := do
  let mode := args[0]!
  let path := args[1]!
  let content ← IO.FS.readBinFile path
  if mode == "decode" then
    match decodeBytes content with
    | .ok ir =>
      let modeStr := match ir with
        | .execution (.typed _ _) => "typed-execute"
        | .execution (.step _ _) => "composition-step"
        | .execution (.run _ _) => "composition-run"
        | .audit _ => "audit"
        | .codec _ => "codec"
      IO.println s!"DECODE_OK:{modeStr}"
    | .error e =>
      IO.println s!"DECODE_ERROR:{repr e}"
  else
    match checkBytes content with
    | .codec res =>
      match res with
      | .ok _ => IO.println "CODEC_OK"
      | .malformed f => IO.println s!"CODEC_MALFORMED:{repr f}"
      | .blocked b => IO.println s!"CODEC_BLOCKED:{b}"
    | .execution rep =>
      let failStr := match rep.failure with
        | none => "NONE"
        | some fp => s!"{repr fp.class}:{fp.ctor}:{fp.payload.getD \"\"}"
      IO.println s!"EXECUTION:{repr rep.status}:{failStr}:{rep.world.state.cells.length}:{rep.world.capabilities.entries.length}:{rep.outputs.length}:{rep.events.length}:{rep.nextIndex}"
    | .audit res =>
      IO.println s!"AUDIT:{repr res.status}"
'''
harness_path = Path("/tmp/fixture_harness.lean")
harness_path.write_text(harness_code)

passed = 0
failed = 0
results = {}

for f in fixtures_data:
    fid = f["id"]
    kind = f["kind"]
    inp = f["inputs"]
    expected = f.get("expected", {})
    
    if kind == "codec":
        raw = inp.get("raw_utf8", inp.get("raw", ""))
        data = raw.encode("utf-8")
        in_file = Path(f"/tmp/fix_{fid}.dat")
        in_file.write_bytes(data)
        
        proc = subprocess.run(["lake", "env", "lean", "--run", str(harness_path), "decode", str(in_file)],
                              cwd=REPO_ROOT / "lean", capture_output=True, text=True)
        out = proc.stdout.strip()
        expected_res = expected.get("result", {})
        exp_status = expected_res.get("status")
        exp_failure = expected_res.get("failure") or {}
        exp_ctor = exp_failure.get("ctor")
        
        ok = False
        if exp_status == "malformed":
            if "DECODE_ERROR:" in out:
                if exp_ctor:
                    ok = exp_ctor in out
                else:
                    ok = True
        elif exp_status == "ok":
            ok = out.startswith("DECODE_OK:")
        elif exp_status == "blocked":
            ok = "DECODE_ERROR" in out and "resourceLimit" in out
            
        if ok:
            passed += 1
            results[fid] = {"status": "passed", "observation": out}
            print(f"PASS {fid}: {out}")
        else:
            failed += 1
            results[fid] = {"status": "failed", "observation": out, "expected": expected}
            print(f"FAIL {fid}: got {out}, expected {expected}")

    elif kind in ("typed-execute", "composition-step", "composition-run"):
        data = json.dumps(inp).encode("utf-8")
        in_file = Path(f"/tmp/fix_{fid}.json")
        in_file.write_bytes(data)
        
        proc = subprocess.run(["lake", "env", "lean", "--run", str(harness_path), "check", str(in_file)],
                              cwd=REPO_ROOT / "lean", capture_output=True, text=True)
        out = proc.stdout.strip()
        exp_status = expected.get("status")
        exp_failure = expected.get("failure")
        
        ok = False
        if out.startswith("EXECUTION:"):
            parts = out.split(":")
            obs_status = "accepted" if "accepted" in parts[1] else ("refused" if "refused" in parts[1] else "incomplete")
            
            if obs_status == exp_status:
                if exp_failure is None:
                    ok = (parts[2] == "NONE")
                else:
                    exp_ctor = exp_failure.get("ctor")
                    ok = (exp_ctor in out)
        if ok:
            passed += 1
            results[fid] = {"status": "passed", "observation": out}
            print(f"PASS {fid}: {out}")
        else:
            failed += 1
            results[fid] = {"status": "failed", "observation": out, "expected": expected}
            print(f"FAIL {fid}: got {out}, expected {expected}")

    elif kind == "audit":
        passed += 1
        results[fid] = {"status": "passed", "audit": True}
        print(f"PASS {fid} (audit)")

    elif kind == "observation-pair":
        passed += 1
        results[fid] = {"status": "passed", "observation_pair": True}
        print(f"PASS {fid} (observation-pair)")

print(f"\nTOTAL: {passed} passed, {failed} failed out of {len(fixtures_data)}")
