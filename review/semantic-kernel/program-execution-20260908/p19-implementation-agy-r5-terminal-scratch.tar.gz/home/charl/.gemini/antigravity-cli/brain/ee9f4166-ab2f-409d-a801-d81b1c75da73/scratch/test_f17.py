import json
import subprocess
from pathlib import Path

with open("openspec/changes/serialized-kernel-certificates/fixtures.json") as f:
    d = json.load(f)
f17 = [fix for fix in d["fixtures"] if fix["id"] == "F17"][0]
s = json.dumps(f17["inputs"], separators=(",", ":"))

lean_code = """import DefiKernel.Certificates.Schema
import DefiKernel.Certificates.Decode
import DefiKernel.Certificates.Encode

open DefiKernel.Certificates
open Lean

def main : IO Unit := do
  let bytes ← IO.FS.readBinFile "/tmp/f17.json"
  let some str := String.fromUTF8? bytes | do IO.println "utf8 err"; return
  match Json.parse str with
  | .error e => IO.println s!"parse error: {e}"
  | .ok j =>
    match decodeDecodedIR j str with
    | .error e => IO.println s!"decodeDecodedIR error: {repr e}"
    | .ok ir =>
      let enc := encodeModule ir
      IO.println s!"decoded ok! enc length: {enc.size}, orig length: {bytes.size}"
      if enc == bytes then
        IO.println "MATCH EXACTLY!"
      else
        let s_orig := str
        let s_enc := String.fromUTF8? enc |>.getD ""
        for i in [0:min s_orig.length s_enc.length] do
          if s_orig.toList[i]! != s_enc.toList[i]! then
            IO.println s!"Diff at index {i}"
            let start := if i > 30 then i - 30 else 0
            IO.println s!"orig: {s_orig.drop start |>.take 80}"
            IO.println s!"enc:  {s_enc.drop start |>.take 80}"
            break
"""

with open("/tmp/f17.json", "w") as f:
    f.write(s)
with open("lean/TestF17.lean", "w") as f:
    f.write(lean_code)
proc = subprocess.run(["lake", "env", "lean", "--run", "TestF17.lean"], cwd="lean", capture_output=True, text=True)
print(proc.stdout)
print(proc.stderr)
