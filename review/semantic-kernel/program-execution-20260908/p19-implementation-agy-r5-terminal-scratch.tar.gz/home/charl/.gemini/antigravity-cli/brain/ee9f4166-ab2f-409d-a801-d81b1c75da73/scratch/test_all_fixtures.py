import json
import subprocess
import tempfile
from pathlib import Path

def canonicalize_json(obj):
    if not isinstance(obj, dict):
        return obj

    # If it is an envelope dict:
    envelope_keys = [
        "schema_version", "mode", "source_pin", "audit_roots", "types", "assumptions",
        "invariants", "libraries", "source_map", "payload", "claimed_judgments",
        "claimed_next_state", "require_library_discharge", "require_invariant_discharge"
    ]
    if "mode" in obj and "source_pin" in obj:
        res = {}
        for k in envelope_keys:
            if k in obj:
                v = obj[k]
                if k == "source_map" and isinstance(v, dict):
                    res[k] = dict(sorted(v.items()))
                elif k == "payload" and isinstance(v, dict):
                    mode = obj.get("mode")
                    if mode == "typed-execute":
                        pkeys = ["registry", "store", "ctx", "env", "now", "request", "state"]
                        res[k] = {pk: v[pk] for pk in pkeys if pk in v}
                    elif mode == "composition-step":
                        pkeys = ["config", "boundary", "index", "history", "step", "pre"]
                        res[k] = {pk: v[pk] for pk in pkeys if pk in v}
                    elif mode == "composition-run":
                        pkeys = ["config", "boundaries", "world", "steps"]
                        res[k] = {pk: v[pk] for pk in pkeys if pk in v}
                    elif mode == "audit":
                        res[k] = dict(sorted(v.items()))
                    else:
                        res[k] = v
                else:
                    res[k] = v
        return res
    return obj

with open("openspec/changes/serialized-kernel-certificates/fixtures.json") as f:
    d = json.load(f)

print(f"Total fixtures: {len(d['fixtures'])}")
for fix in d["fixtures"]:
    fix_id = fix["id"]
    kind = fix.get("kind", "")
    inp = fix["inputs"]
    
    if fix_id == "F13":
        # Swap transfer and store in raw_utf8
        raw_str = inp["raw_utf8"]
        # Replace non-canonical order
        raw_str = raw_str.replace('"source_map":{"transfer":"lean/DefiKernel/Typed/Examples.lean:transfer","store":"lean/DefiKernel/Composition/Examples.lean:store"}',
                                '"source_map":{"store":"lean/DefiKernel/Composition/Examples.lean:store","transfer":"lean/DefiKernel/Typed/Examples.lean:transfer"}')
        inp = {"raw_utf8": raw_str}
    elif fix_id == "F28":
        raw_str = inp["raw_utf8"]
        raw_str = raw_str.replace('"source_map":{"transfer":"lean/DefiKernel/Typed/Examples.lean:transfer","store":"lean/DefiKernel/Composition/Examples.lean:store"}',
                                '"source_map":{"store":"lean/DefiKernel/Composition/Examples.lean:store","transfer":"lean/DefiKernel/Typed/Examples.lean:transfer"}')
        inp = {"raw_utf8": raw_str}

    with tempfile.NamedTemporaryFile("w", suffix=".json") as tf:
        if kind == "codec":
            tf.write(inp["raw_utf8"])
            tf.flush()
            cmd = ["lake", "env", "lean", "--run", "DefiKernel/Certificates/RunFixtures.lean", "decode", tf.name]
        elif kind == "observation-pair":
            continue
        elif kind == "raw":
            can_inp = canonicalize_json(inp)
            json.dump(can_inp, tf, separators=(",", ":"))
            tf.flush()
            cmd = ["lake", "env", "lean", "--run", "DefiKernel/Certificates/RunFixtures.lean", "raw", tf.name]
        else:
            can_inp = canonicalize_json(inp)
            json.dump(can_inp, tf, separators=(",", ":"))
            tf.flush()
            cmd = ["lake", "env", "lean", "--run", "DefiKernel/Certificates/RunFixtures.lean", "check", tf.name]

        proc = subprocess.run(cmd, cwd="lean", capture_output=True, text=True)
        try:
            out_j = json.loads(proc.stdout)
            st = out_j.get("status") or (out_j.get("result", {}).get("status") if "result" in out_j else None)
            print(f"Fixture {fix_id:3s} ({kind:16s}): status={st}")
            if "failure" in out_j and out_j["failure"]:
                fail = out_j["failure"]
                if fail.get("ctor") == "noncanonicalWhitespace":
                    print(f"   --> NONCANONICAL WHITESPACE FAIL ON {fix_id}!")
        except Exception as e:
            print(f"Fixture {fix_id} error: {proc.stdout[:100]}")
