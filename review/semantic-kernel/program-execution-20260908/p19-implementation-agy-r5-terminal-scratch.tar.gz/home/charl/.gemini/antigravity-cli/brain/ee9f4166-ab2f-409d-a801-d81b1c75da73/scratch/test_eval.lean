import DefiKernel.Certificates.Schema
import DefiKernel.Certificates.Decode
import DefiKernel.Certificates.Check

open DefiKernel.Certificates

def main (args : List String) : IO Unit := do
  let path := args.head!
  let content ← IO.FS.readBinFile path
  let outcome := checkBytes content
  match outcome with
  | .codec res => IO.println s!"codec: {repr res}"
  | .execution rep => IO.println s!"execution: status={repr rep.status}, failure={repr rep.failure}, nextIndex={rep.nextIndex}"
  | .audit res => IO.println s!"audit: {repr res}"
