import json
import subprocess
import sys
import time
from pathlib import Path

repo = Path('/tmp/p19-mirror')
spec_dir = Path('review/semantic-kernel/certificates/p19/implementation/agy-r3/mutant-specs')
mutants_dir = Path('review/semantic-kernel/certificates/p19/implementation/agy-r3/mutants')
summary_file = Path('review/semantic-kernel/certificates/p19/implementation/agy-r3/mutants-summary.json')

# Get mirror HEAD
proc = subprocess.run(['git', '-C', str(repo), 'rev-parse', 'HEAD'], capture_output=True, text=True, check=True)
mirror_head = proc.stdout.strip()

results = {}

# If M01 already finished, load its result
m01_res_file = mutants_dir / 'M01' / 'results.json'
if m01_res_file.exists():
    m01_data = json.loads(m01_res_file.read_text())
    m01_spec = json.loads((spec_dir / 'M01.json').read_text())
    m01_name = m01_spec['mutations'][0]['name']
    results['M01'] = {
        'id': 'M01',
        'runner_name': m01_name,
        'module': m01_spec['mutations'][0]['module'],
        'oracle_label': m01_spec['mutations'][0]['required_false'][0],
        'required_false': m01_spec['mutations'][0]['required_false'],
        'expected_protected_check': m01_spec['positive_checks'][0],
        'exit': 0,
        'elapsed_seconds': 17.0,
        'discriminated': True,
        'observed_false': m01_data['results'][m01_name]['false_comparisons'],
        'control_exit': m01_data['results']['control']['exit'],
        'mutant_exit': m01_data['results'][m01_name]['exit']
    }
    print("Loaded M01 result.")

for i in range(2, 17):
    mid = f"M{i:02d}"
    spec_path = spec_dir / f"{mid}.json"
    out_path = mutants_dir / mid
    spec = json.loads(spec_path.read_text())
    m_info = spec['mutations'][0]
    m_name = m_info['name']

    print(f"[{mid}/16] Running {m_name}...", flush=True)
    t0 = time.time()
    cmd = [
        sys.executable,
        'scripts/run_certificate_mutations.py',
        '--repo', str(repo),
        '--spec', str(spec_path),
        '--out', str(out_path),
        '--timeout-seconds', '600'
    ]
    proc = subprocess.run(cmd, capture_output=True, text=True)
    elapsed = time.time() - t0

    if proc.returncode != 0:
        print(f"FAILED {mid}: exit={proc.returncode}\nStdout:\n{proc.stdout}\nStderr:\n{proc.stderr}", flush=True)
        sys.exit(1)

    res_file = out_path / 'results.json'
    data = json.loads(res_file.read_text())
    obs_false = data['results'][m_name]['false_comparisons']
    discriminated = (set(obs_false) == set(m_info['required_false']) and
                     data['results']['control']['exit'] == 0 and
                     data['results'][m_name]['exit'] == 1)

    results[mid] = {
        'id': mid,
        'runner_name': m_name,
        'module': m_info['module'],
        'oracle_label': m_info['required_false'][0],
        'required_false': m_info['required_false'],
        'expected_protected_check': spec['positive_checks'][0],
        'exit': proc.returncode,
        'elapsed_seconds': round(elapsed, 4),
        'discriminated': discriminated,
        'observed_false': obs_false,
        'control_exit': data['results']['control']['exit'],
        'mutant_exit': data['results'][m_name]['exit']
    }
    print(f"[{mid}/16] PASSED ({round(elapsed, 2)}s) - observed_false: {obs_false}", flush=True)

summary = {
    'total_mutants': 16,
    'passed': len(results),
    'mirror_head': mirror_head,
    'results': results
}

summary_file.write_text(json.dumps(summary, indent=2) + '\n')
print(f"All 16 mutants completed and verified! Summary written to {summary_file}")
