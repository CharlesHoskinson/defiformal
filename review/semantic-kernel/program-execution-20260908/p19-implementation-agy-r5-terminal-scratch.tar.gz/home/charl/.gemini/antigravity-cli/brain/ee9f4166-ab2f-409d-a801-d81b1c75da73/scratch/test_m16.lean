import Lean

inductive DecodeFailure where
  | unsupportedForm (reason : String)
  deriving DecidableEq, Repr

macro_rules
  | `(.unsupportedForm _) => `(.unsupportedForm "treeJoin")

inductive StepEnc where
  | invoke
  deriving DecidableEq, Repr

def decodeInvoke (_rest : Unit) : Except DecodeFailure StepEnc :=
  .ok .invoke

def decodeStep (tag : String) (rest : Unit) : Except DecodeFailure StepEnc :=
  match tag with
  | "invoke" => decodeInvoke rest
  | "treeJoin" | "naryAdvance" => .error (.unsupportedForm _)
  | _ => .error (.unsupportedForm "other")
