import json, shutil, subprocess, sys, time
from pathlib import Path

worktree = Path('/home/charl/defiformal-wt-p19-certificates-grok-opus-20260909')
evidence_root = worktree / 'review/semantic-kernel/certificates/p19/implementation/agy-r2'
mutants_dir = evidence_root / 'mutants'
specs_dir = evidence_root / 'mutant-specs'
specs_dir.mkdir(parents=True, exist_ok=True)
mutants_dir.mkdir(parents=True, exist_ok=True)

fake = Path('/tmp/p19-mirror')
if fake.exists():
    shutil.rmtree(fake)
fake.mkdir(parents=True)

subprocess.run(['git', 'init', '--quiet', str(fake)], check=True)
lean = fake / 'lean'
shutil.copytree(worktree / 'lean', lean, ignore=shutil.ignore_patterns('.lake', '.lake/*'))
(lean / '.lake').mkdir(parents=True)
(lean / '.lake/packages').symlink_to(worktree / 'lean/.lake/packages', target_is_directory=True)

subprocess.run(['git', '-C', str(fake), 'add', '-A'], check=True)
subprocess.run(['git', '-C', str(fake), '-c', 'user.name=P19 Author', '-c', 'user.email=p19@invalid', 'commit', '-m', 'Mirror worktree for mutations'], check=True)

head_proc = subprocess.run(['git', '-C', str(fake), 'rev-parse', 'HEAD'], capture_output=True, text=True, check=True)
fake_head = head_proc.stdout.strip()
print('Isolated mirror initialized at HEAD:', fake_head)

with open(worktree / 'openspec/changes/serialized-kernel-certificates/planned-mutations.json') as f:
    planned = json.load(f)['mutations']

results = {}
commands = []

for m in planned:
    mid = m['id']
    runner_name = m['runner_name']
    modules = [m['module']]
    if 'DefiKernel.Certificates.Audit' not in modules:
        modules.append('DefiKernel.Certificates.Audit')
    spec = {
        'schema_version': 1,
        'modules': modules,
        'mutations': [{
            'name': runner_name,
            'module': m['module'],
            'needle': m['needle'],
            'replacement': m['replacement'],
            'required_false': m['required_false']
        }],
        'positive_checks': [m['expected_protected_check']]
    }
    spec_path = specs_dir / f'{mid}.json'
    spec_path.write_text(json.dumps(spec, indent=2) + '\n')
    
    out_dir = mutants_dir / mid
    if out_dir.exists():
        shutil.rmtree(out_dir)
        
    cmd = [sys.executable, str(worktree / 'scripts/run_certificate_mutations.py'),
           '--repo', str(fake), '--spec', str(spec_path), '--out', str(out_dir),
           '--timeout-seconds', '600']
    print(f'Starting {mid} ({runner_name})...', flush=True)
    tick = time.monotonic()
    proc = subprocess.run(cmd, capture_output=True, text=True)
    elapsed = time.monotonic() - tick
    
    commands.append({
        'mutant': mid,
        'command': cmd,
        'exit': proc.returncode,
        'elapsed_seconds': round(elapsed, 4),
        'stdout': proc.stdout.strip(),
        'stderr': proc.stderr.strip()
    })
    
    # Read mutant results
    m_results_file = out_dir / 'results.json'
    m_data = json.loads(m_results_file.read_text()) if m_results_file.exists() else {}
    
    passed = (proc.returncode == 0)
    print(f'Completed {mid}: exit={proc.returncode} in {elapsed:.2f}s, passed={passed}', flush=True)
    if not passed:
        print('STDERR:', proc.stderr, flush=True)
        print('STDOUT:', proc.stdout, flush=True)
        sys.exit(1)
        
    results[mid] = {
        'id': mid,
        'runner_name': runner_name,
        'module': m['module'],
        'oracle_label': m.get('oracle_label'),
        'required_false': m['required_false'],
        'expected_protected_check': m['expected_protected_check'],
        'exit': proc.returncode,
        'elapsed_seconds': round(elapsed, 4),
        'discriminated': True,
        'observed_false': m_data.get('results', {}).get(runner_name, {}).get('false_comparisons', []),
        'control_exit': m_data.get('results', {}).get('control', {}).get('exit'),
        'mutant_exit': m_data.get('results', {}).get(runner_name, {}).get('exit')
    }

summary = {
    'total_mutants': len(planned),
    'passed': len(results),
    'mirror_head': fake_head,
    'results': results,
    'commands': commands
}
(evidence_root / 'mutants-summary.json').write_text(json.dumps(summary, indent=2) + '\n')
print(f'ALL {len(planned)} MUTANTS PASSED DISCRIMINATION!')
