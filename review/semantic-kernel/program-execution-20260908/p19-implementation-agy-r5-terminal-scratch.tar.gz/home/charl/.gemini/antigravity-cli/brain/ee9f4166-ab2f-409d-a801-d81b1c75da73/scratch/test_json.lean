import Lean.Data.Json

open Lean

def main : IO Unit := do
  let s := "{\"a\": 1, \"b\": [true, false]}"
  match Json.parse s with
  | .ok j => IO.println s!"Parsed: {j}"
  | .error e => IO.println s!"Error: {e}"
