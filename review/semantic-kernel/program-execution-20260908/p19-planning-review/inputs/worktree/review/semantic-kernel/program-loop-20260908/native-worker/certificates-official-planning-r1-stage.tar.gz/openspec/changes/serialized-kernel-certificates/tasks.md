## 1. Independent planning gate

- [ ] 1.1 Freeze this OpenSpec package and `review/semantic-kernel/certificates/planning/grok-gpt6-official-r1/` with `STATUS.gate_accepted=false`; verify independent GPT-6 reviews the frozen bytes and that no Lean/Python certificate implementation exists outside the planning checker.
- [ ] 1.2 Bind used Typed/Composition sources and the three Lean/Lake pins to Git `a12b7cac05a818cc8d35c2ca440b7170a2807e92`; verify each listed path's blob equals D and that original 53 readiness hashes are unchanged.
- [ ] 1.3 Preserve the attempt-1 root-setup failure and every later failed planning check; verify `native-worker/certificates-official-planning-r1-attempt1/` bytes still exist and receive no authorship credit.

## 2. Schema, rationals and decode/encode

- [ ] 2.1 Implement `DefiKernel.Certificates.Schema` with the version-1 envelope, `RatEnc`, decode failures and unsupported forms as proposed-api.json; verify the module remains unelaborated until a recorded compiler check, then that F01–F07 decode failures match `schema.json`.
- [ ] 2.2 Implement canonical rational decode/encode (`num`/`den`, lowest terms, den>0); verify F03 unreduced, F04 float, F05 zero-denominator and F25 `{"num":3,"den":1}` against independent literals.
- [ ] 2.3 Implement identifier, enumeration, duplicate and canonical-key contracts; verify F06 unknown party, F07 negative id, F08 duplicate component ids and F11 unknown executable field.
- [ ] 2.4 Implement encode/decode roundtrip on supported modules; verify F25 decode∘encode identity and that refused decode returns no kernel object (S39–S40).

## 3. Recomputing typed judgments

- [ ] 3.1 Implement `checkCertificate` typing via actual `Args.check`; verify F15 unit mismatch is `evaluation argumentUnit` and F16 claimed TypeCorrect tag does not pass.
- [ ] 3.2 Implement footprint recomputation from delivered template inventories including conservative `ite` reads; verify F17 stateReadFootprint, F18 envReadFootprint and F19 writeFootprint.
- [ ] 3.3 Implement authority via `hasAuthority`/`issueCapability`/`revokeCapability`; verify F20 unauthorizedInvoke, F21 unauthorizedDebit, F22 revoked id and F10 duplicate ids confer no extra debit rights.
- [ ] 3.4 Implement accounting and funds via `Evaluated.accountingOK` and nonnegative post-state; verify F23 unbalanced `accounting`, F24 `insufficientFunds` and F25 alice7/bob3/vault20 with unchanged store.
- [ ] 3.5 Implement exact refusal constructors and D8 precedence; verify F29 actorMismatch-before-unauthorizedInvoke, F30 unknownOperation-first and F31 boolean-failed-without-constructor rejection.

## 4. Sequential composition

- [ ] 4.1 Implement catalog validation through actual `validateCatalog`; verify F08/F26 `configuration` and that empty-document F01 never becomes a catalog pass.
- [ ] 4.2 Implement invoke/issue/revoke through actual `executeStep` and receipt extraction against the pre-state; verify F27 success equals `executeStep` and F32 future priorOutput is `unavailableOutput`.
- [ ] 4.3 Implement sequential `run` correspondence; verify event prefix, inert continuation after refusal, and F09 repeated-delta addition `-6`.
- [ ] 4.4 Reject unsupported composition and Claims operators; verify F14 tree/nary ctor and nonempty obligations_created/discharged are `unsupported`, not complete.

## 5. Correspondence, pins and observations

- [ ] 5.1 Prove or computationally check accepted-path equality of checker report versus `Typed.execute` and `Composition.run` on F25/F27; verify independent fixture literals, not candidate oracles.
- [ ] 5.2 Prove or computationally check refused-path constructor equality on F15–F24, F26, F29–F30; verify no generic failed bit is accepted.
- [ ] 5.3 Implement source-pin checking against D; verify F37 stale SHA refuses and F25 complete pin equals `a12b7cac05a818cc8d35c2ca440b7170a2807e92`.
- [ ] 5.4 Implement full `Report`/`reportEq`; verify F36 claimed next-state 10 after transfer 3 is observation mismatch.

## 6. Runtime/proof boundary and audit roots

- [ ] 6.1 Classify `ComponentContract` propositions and theorem-name library fields as outstanding; verify F33/F34/F38 do not complete the certificate.
- [ ] 6.2 Record registry/context/observation/environment trust as assumptions and keep missing observation executable; verify F39 classification, F40 `missingObservation` not zero, and F41 missing class incomplete.
- [ ] 6.3 Keep LibraryTheoremsInstantiated and SourceRefinement outstanding without recorded compiler checks; verify F42/F43 and that Arithmetic/Atomic theorems are not new certificate acceptance.
- [ ] 6.4 Declare audit roots as imported Certificates plus listed Typed/Composition modules; verify F44/F45/F46, empty theorem scope blocked, no unimported-universe claim.

## 7. Fixtures, mutations and runner

- [ ] 7.1 Materialize every fixture in `fixtures.json` with independent expected fields and unique check ids; verify nonempty unique F01–F46 coverage of S61–S62.
- [ ] 7.2 Implement `Certificates.Audit` with unique nonempty check names that count false checks correctly; verify F25 positives remain true on intact source.
- [ ] 7.3 Adapt `scripts/run_certificate_mutations.py` from the Interface SPEC protocol; verify field-set equality, outside-repo output, timeout/empty blocked, outer invocation record (S66–S67).
- [ ] 7.4 Freeze M01–M16 needles as unique runtime sites (future_anchor until present, then actual source); run each as its own one-mutant SPEC and verify designated false plus protected positive (S63–S65).
- [ ] 7.5 Preserve every compiler failure, timeout, cancellation and malformed output without semantic credit; verify intact sibling F25 still passes after each isolated mutant restore.

## 8. Integration and evidence

- [ ] 8.1 Add only parent-owned root import after planning acceptance and run fresh Lean plus runtime checks; verify delivered Typed/Composition semantics unchanged.
- [ ] 8.2 Run `#audit_axioms DefiKernel.Certificates` with nonempty imported theorems, standard axioms only, no sorry/custom axioms/`native_decide`; verify declared-root coverage.
- [ ] 8.3 Reconcile every requirement, scenario, fixture, mutant and task with actual commands; verify nonempty counts and that roadmap §5 boxes remain unchecked.
- [ ] 8.4 Obtain independent GPT-6 implementation/evidence review on the same frozen candidate, preserve this planning review identity, and keep historical Fable/Opus/GPT reports unrelabelled; verify actual returned model and input hashes.
- [ ] 8.5 Publish accepted source/evidence to `semantic-kernel-pivot` only after that later evidence review; verify no merge to main and that Claims/Tree/Nary/Quint/fidelity remainder stays open.
