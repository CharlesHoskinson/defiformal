# Serialized kernel certificates official planning r1

Native Grok 4.6 authored this OpenSpec package. Independent GPT-6 / gpt-6-astra must review it. This is not planning-gate acceptance and not an implemented feature.

## Reviewer command (read-only)

```
python3 review/semantic-kernel/certificates/planning/grok-gpt6-official-r1/package.py --check
```

`--check` writes nothing. Independently hash `MANIFEST.json` and compare to `ANCHOR.json` field `manifest_sha256`. `MANIFEST.json` does not contain its own hash and does not list `ANCHOR.json`.

## Bound identities

| Item | Value |
| --- | --- |
| Source D / HEAD | `a12b7cac05a818cc8d35c2ca440b7170a2807e92` |
| Branch | `work/certificates-grok-gpt6-20260908` |
| Worker | grok-4.6 |
| Independent checker | GPT-6 / gpt-6-astra |
| Foreman | not used |
| Readiness review | SHA-256 `9173e34ce186104f9593831d0f8061682656ea2de4eb888dcc424fc22014d9c2` |
| Readiness inputs | SHA-256 `341f00291a943e9f7d89684dc02a2f86fd7c9b58af315edc3f8ae783b082bffc` |
| Gate accepted | false |

The GPT-6 readiness recovery is not a scientific design and not an accepted plan. No dedicated certificate package existed before this revision.

Original root launch failure (missing briefs directory, empty jsonl, exit 1) is preserved at `review/semantic-kernel/program-loop-20260908/native-worker/certificates-official-planning-r1-attempt1/` with no authorship or acceptance credit.
