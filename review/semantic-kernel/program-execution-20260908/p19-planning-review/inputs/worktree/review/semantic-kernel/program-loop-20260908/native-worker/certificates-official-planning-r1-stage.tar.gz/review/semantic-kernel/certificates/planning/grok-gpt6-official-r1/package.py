#!/usr/bin/env python3
"""Planning completeness and integrity only. No certificate implementation,
no Lean/financial execution, and no planning-gate acceptance.

--prepare writes validation artifacts.
--seal writes MANIFEST.json (no self-hash) and ANCHOR.json (external trust anchor).
--check is read-only. Exit 0 nonempty sealed package holds; 1 property false; 3 blocked.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import re
import shutil
import subprocess
import sys
import tempfile
import time
from datetime import datetime, timezone
from fractions import Fraction
from pathlib import Path

HEAD_EXPECTED = "a12b7cac05a818cc8d35c2ca440b7170a2807e92"
CHANGE = "serialized-kernel-certificates"
PACKAGE_REL = "review/semantic-kernel/certificates/planning/grok-gpt6-official-r1"
PLAN_REL = "openspec/changes/serialized-kernel-certificates"
READINESS_REVIEW = "review/semantic-kernel/program-loop-20260908/remaining-financial-async-readiness-gpt6-review.md"
READINESS_INPUTS = "review/semantic-kernel/program-loop-20260908/remaining-financial-async-readiness-gpt6-inputs.json"
READINESS_REVIEW_SHA = "9173e34ce186104f9593831d0f8061682656ea2de4eb888dcc424fc22014d9c2"
READINESS_INPUTS_SHA = "341f00291a943e9f7d89684dc02a2f86fd7c9b58af315edc3f8ae783b082bffc"
ATTEMPT1 = "review/semantic-kernel/program-loop-20260908/native-worker/certificates-official-planning-r1-attempt1"
OPENSPEC_STRICT_STDOUT = f"Change '{CHANGE}' is valid\n"
CAPS = [
    "certificate-regression-evidence",
    "recomputing-certificate-checker",
    "representation-correspondence",
    "runtime-proof-boundary",
    "serialized-module-format",
]
REQ_RE = re.compile(r"^### Requirement: ([A-Z]{2}\d{2}) ", re.M)
SC_RE = re.compile(r"^#### Scenario: (S\d{2}) ", re.M)
TASK_RE = re.compile(r"^- \[ \] (\d+\.\d+) ", re.M)
MUT_NAME = re.compile(r"[a-z][a-z0-9-]*")
CHECK_NAME = re.compile(r"[a-z][a-z0-9_-]*(?:\.[a-z][a-z0-9_-]*)*")
RESERVED = {"control", "lean-version", "lean-path", "git-head", "git-root-input-status"}
USED_D_SOURCES = [
    "lean/DefiKernel/Typed/Types.lean",
    "lean/DefiKernel/Typed/Expr.lean",
    "lean/DefiKernel/Typed/Authority.lean",
    "lean/DefiKernel/Typed/Transition.lean",
    "lean/DefiKernel/Typed/Examples.lean",
    "lean/DefiKernel/Composition/Interfaces.lean",
    "lean/DefiKernel/Composition/Execution.lean",
    "lean/DefiKernel/Composition/Contracts.lean",
    "lean/DefiKernel/Composition/Sequence.lean",
    "lean/DefiKernel/Composition/Examples.lean",
    "lean/DefiKernel/AxiomAudit.lean",
    "lean/lean-toolchain",
    "lean/lakefile.toml",
    "lean/lake-manifest.json",
    "docs/superpowers/specs/2026-09-06-semantic-kernel-design.md",
    "docs/research/2026-09-06-defi-source-plan.md",
    "docs/research/semantic-kernel-progress.md",
    "roadmap.md",
    "wiki-llm/autonomous-execution-agenda.md",
    "AGENTS.md",
    ".claude/skills/defi-footguns/SKILL.md",
    "formal/v3/GATE-REGISTER.md",
    "scripts/run_interface_mutations.py",
    "research/positive-program/sigma/gate33_cert_check.py",
]
FORBIDDEN_IMPL = [
    "lean/DefiKernel/Certificates.lean",
    "lean/DefiKernel/Certificates",
    "scripts/run_certificate_mutations.py",
    "scripts/test_certificate_mutation_runner.py",
]
MANIFEST_EXCLUDE_NAMES = {"MANIFEST.json", "ANCHOR.json"}


class Blocked(Exception):
    pass


class Failed(Exception):
    pass


def utc() -> str:
    return datetime.now(timezone.utc).isoformat()


def sha(raw: bytes) -> str:
    return hashlib.sha256(raw).hexdigest()


def sha_path(path: Path) -> str:
    return sha(path.read_bytes())


def load(path: Path):
    return json.loads(path.read_text())


def dump(path: Path, data) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, indent=2, ensure_ascii=False) + "\n")


def which(name: str) -> Path:
    found = shutil.which(name)
    if not found:
        raise Blocked(f"tool unavailable: {name}")
    return Path(found).resolve()


class Ctx:
    def __init__(self, root: Path, package: Path):
        self.root = root.resolve()
        self.out = package.resolve()
        self.plan = self.root / PLAN_REL
        self.validation = self.out / "validation"
        self.controls = self.validation / "controls"
        self.manifest = self.out / "MANIFEST.json"
        self.anchor = self.out / "ANCHOR.json"
        self.inventory = self.out / "source-inventory.json"
        self.script = Path(__file__).resolve()


def default_ctx() -> Ctx:
    script = Path(__file__).resolve()
    return Ctx(script.parents[5], script.parent)


def git(ctx: Ctx, *args: str) -> bytes:
    return subprocess.check_output(["git", *args], cwd=ctx.root)


def git_text(ctx: Ctx, *args: str) -> str:
    return git(ctx, *args).decode().strip()


def run_captured(ctx: Ctx, name: str, args: list[str], timeout: int = 60) -> dict:
    exe = which(args[0])
    cmd = [str(exe), *args[1:]]
    started = utc()
    t0 = time.monotonic()
    proc = subprocess.run(cmd, cwd=ctx.root, capture_output=True, timeout=timeout)
    rec = {
        "name": name,
        "argv": cmd,
        "cwd": str(ctx.root),
        "started_utc": started,
        "ended_utc": utc(),
        "wall_seconds": time.monotonic() - t0,
        "exit": proc.returncode,
        "executable": str(exe),
        "executable_sha256": sha_path(exe),
        "stdout_sha256": sha(proc.stdout),
        "stderr_sha256": sha(proc.stderr),
        "stdout_bytes": len(proc.stdout),
        "stderr_bytes": len(proc.stderr),
        "stdout_text": proc.stdout.decode("utf-8", "replace"),
        "stderr_text": proc.stderr.decode("utf-8", "replace"),
    }
    ctx.validation.mkdir(parents=True, exist_ok=True)
    (ctx.validation / f"{name}.stdout").write_bytes(proc.stdout)
    (ctx.validation / f"{name}.stderr").write_bytes(proc.stderr)
    return rec


def parse_scope(ctx: Ctx):
    caps, reqs, scs = [], [], []
    for spec in sorted((ctx.plan / "specs").glob("*/spec.md")):
        text = spec.read_text()
        cap = spec.parent.name
        caps.append(cap)
        if not text.startswith("## Purpose\n") or "## ADDED Requirements" not in text:
            raise Failed(f"spec shape: {cap}")
        if len(text.split("## Purpose", 1)[1].split("## ADDED", 1)[0].strip()) < 50:
            raise Failed(f"purpose too brief: {cap}")
        reqs += REQ_RE.findall(text)
        scs += SC_RE.findall(text)
    tasks_text = (ctx.plan / "tasks.md").read_text()
    if re.search(r"^- \[[xX]\]", tasks_text, re.M):
        raise Failed("checked task present")
    tasks = TASK_RE.findall(tasks_text)
    return caps, reqs, scs, tasks


def unique_nonempty(seq, label: str) -> None:
    if not seq:
        raise Blocked(f"{label}: empty (0 of 0)")
    if len(seq) != len(set(seq)):
        raise Failed(f"{label}: duplicates")


def verify_git_d_file(ctx: Ctx, rel: str) -> dict:
    path = ctx.root / rel
    if not path.is_file():
        raise Blocked(f"missing {rel}")
    raw = path.read_bytes()
    blob = git(ctx, "show", f"{HEAD_EXPECTED}:{rel}")
    if raw != blob:
        raise Failed(f"not equal Git D: {rel}")
    return {"path": rel, "sha256": sha(raw), "bytes": len(raw), "equals_git_D": True}


def existing_needle_unique(ctx: Ctx, mutant: dict) -> None:
    if mutant.get("anchor_status") != "planned_source_anchor":
        return
    rel = mutant["path"]
    text = (ctx.root / rel).read_text()
    needle = mutant["needle"]
    n = text.count(needle)
    if n != 1:
        raise Failed(f"{mutant['id']} needle count {n} in {rel}")
    if mutant["replacement"] == needle:
        raise Failed(f"{mutant['id']} replacement equals needle")


def independent_arithmetic() -> None:
    if not (10 - 3 == 7 and 0 + 3 == 3 and 20 == 20 and 4 == 4):
        raise Failed("F25 arithmetic")
    if not (10 - 3 - 3 == 4 and 0 + 6 == 6):
        raise Failed("F09 arithmetic")
    if not (3 != 4):
        raise Failed("F23 arithmetic")
    if not (10 - 11 < 0):
        raise Failed("F24 arithmetic")
    if Fraction(1, 2) != Fraction(1, 2) or Fraction(2, 4) != Fraction(1, 2):
        raise Failed("rational identity")
    if Fraction(2, 4).numerator != 1 or Fraction(2, 4).denominator != 2:
        raise Failed("unreduced canonicalization")


def plan_files(ctx: Ctx) -> list[str]:
    files = []
    for p in sorted(ctx.plan.rglob("*")):
        if p.is_file():
            files.append(str(p.relative_to(ctx.root)))
    if not files:
        raise Blocked("plan files empty")
    return files


def package_files_for_manifest(ctx: Ctx) -> list[str]:
    files = []
    for p in sorted(ctx.out.rglob("*")):
        if not p.is_file():
            continue
        if p.name in MANIFEST_EXCLUDE_NAMES:
            continue
        files.append(str(p.relative_to(ctx.root)))
    return files


def collect_checks(ctx: Ctx) -> dict:
    checks = []

    def ck(name: str, value: bool, blocked: bool = False) -> None:
        checks.append({"check": name, "passed": bool(value), "blocked": blocked})
        if blocked and not value:
            raise Blocked(name)
        if not blocked and not value:
            raise Failed(name)

    head = git_text(ctx, "rev-parse", "HEAD")
    ck("head is D", head == HEAD_EXPECTED)
    branch = git_text(ctx, "rev-parse", "--abbrev-ref", "HEAD")
    ck("branch", branch == "work/certificates-grok-gpt6-20260908")

    for rel in USED_D_SOURCES:
        verify_git_d_file(ctx, rel)
        ck("git D " + rel, True)

    for rel in FORBIDDEN_IMPL:
        ck("no implementation " + rel, not (ctx.root / rel).exists())

    readiness_review = ctx.root / READINESS_REVIEW
    readiness_inputs = ctx.root / READINESS_INPUTS
    ck("readiness review hash", sha_path(readiness_review) == READINESS_REVIEW_SHA)
    ck("readiness inputs hash", sha_path(readiness_inputs) == READINESS_INPUTS_SHA)
    inputs = load(readiness_inputs)
    ck("original 53 bindings", len(inputs["inputs"]) == 53)
    present53, absent_non_d = 0, []
    for row in inputs["inputs"]:
        path = ctx.root / row["path"]
        if path.is_file():
            present53 += 1
            ck("original53 " + row["path"], sha_path(path) == row["sha256"])
            if row.get("equals_git_D") is True:
                verify_git_d_file(ctx, row["path"])
        else:
            if row.get("equals_git_D") is True:
                raise Blocked("original53 Git-D file missing " + row["path"])
            absent_non_d.append(row["path"])
    ck("original53 D files present", present53 >= 50)
    ck("original53 non-D absences recorded not fabricated",
       absent_non_d == ["review/semantic-kernel/program-loop-20260908/agenda-inventory-after-m3-20260908.json"]
       or not absent_non_d)

    attempt = ctx.root / ATTEMPT1
    ck("attempt1 dir", attempt.is_dir())
    jsonl = attempt / "certificates-official-planning-r1.jsonl"
    failure = attempt / "root-setup-failure.json"
    ck("attempt1 empty jsonl", jsonl.is_file() and jsonl.stat().st_size == 0)
    ck("attempt1 failure record", failure.is_file() and b"lacked program-loop briefs" in failure.read_bytes())

    caps, reqs, scs, tasks = parse_scope(ctx)
    unique_nonempty(caps, "capabilities")
    unique_nonempty(reqs, "requirements")
    unique_nonempty(scs, "scenarios")
    unique_nonempty(tasks, "tasks")
    ck("five capabilities", caps == CAPS)
    ck("26 requirements", len(reqs) == 26 and set(reqs) == {x["id"] for x in load(ctx.plan / "scenario-map.json")["requirements"]})
    expected_sc = [f"S{i:02d}" for i in range(1, 68)]
    ck("67 scenarios", len(scs) == 67 and set(scs) == set(expected_sc))
    ck("34 tasks", len(tasks) == 34)

    fixtures = load(ctx.plan / "fixtures.json")
    mutants = load(ctx.plan / "planned-mutations.json")
    smap = load(ctx.plan / "scenario-map.json")
    fids = [x["id"] for x in fixtures["fixtures"]]
    mids = [x["id"] for x in mutants["mutations"]]
    unique_nonempty(fids, "fixtures")
    unique_nonempty(mids, "mutants")
    ck("46 fixtures", len(fids) == 46 and fids == [f"F{i:02d}" for i in range(1, 47)])
    ck("16 mutants", len(mids) == 16 and mids == [f"M{i:02d}" for i in range(1, 17)])
    ck("fixture count field", fixtures.get("count") == 46)
    ck("mutant count field", mutants.get("count") == 16)

    for fx in fixtures["fixtures"]:
        ck(fx["id"] + " expected", bool(fx.get("expected")) and bool(fx.get("id")))
        ck(fx["id"] + " planned", fx.get("status") == "planned_not_executed")
        ck(fx["id"] + " scenarios", bool(fx.get("scenarios")) and set(fx["scenarios"]) <= set(scs))
    for m in mutants["mutations"]:
        ck(m["id"] + " planned", m.get("status") == "planned_not_executed")
        ck(m["id"] + " oracle", m.get("oracle_fixture") in fids)
        ck(m["id"] + " change", bool(m.get("actual_source_change")))
        ck(m["id"] + " anchor", m.get("anchor_status") in {"future_anchor", "planned_source_anchor"})
        ck(m["id"] + " runner name", bool(MUT_NAME.fullmatch(m["runner_name"])) and m["runner_name"] not in RESERVED)
        rf, pc = m["required_false"], m["expected_protected_check"]
        ck(m["id"] + " false", bool(rf) and all(CHECK_NAME.fullmatch(x) for x in rf))
        ck(m["id"] + " protected", bool(CHECK_NAME.fullmatch(pc)) and pc not in rf)
        ck(m["id"] + " protected fixture", m.get("protected_positive") in fids)
        existing_needle_unique(ctx, m)

    sm_sc = [x["id"] for x in smap["scenarios"]]
    ck("scenario-map exact", set(sm_sc) == set(scs) and len(sm_sc) == len(scs) == 67)
    mapped_fx, mapped_tasks = set(), set()
    for row in smap["scenarios"]:
        ck(row["id"] + " fixtures", bool(row["fixtures"]) and set(row["fixtures"]) <= set(fids))
        ck(row["id"] + " tasks", bool(row["tasks"]) and set(row["tasks"]) <= set(tasks))
        mapped_fx.update(row["fixtures"])
        mapped_tasks.update(row["tasks"])
    ck("every fixture mapped", mapped_fx == set(fids))
    ck("every task mapped", mapped_tasks == set(tasks))
    sm_req = [x["id"] for x in smap["requirements"]]
    ck("scenario-map requirements", set(sm_req) == set(reqs) and len(sm_req) == len(reqs))

    independent_arithmetic()
    ck("independent arithmetic", True)

    f25 = next(x for x in fixtures["fixtures"] if x["id"] == "F25")
    world = f25["expected"]["world"]
    ck("F25 alice 7", world["main/alice/usd"] == {"num": 7, "den": 1})
    ck("F25 bob 3", world["main/bob/usd"] == {"num": 3, "den": 1})
    ck("F25 vault 20", world["main/vault/usd"] == {"num": 20, "den": 1})
    ck("F25 not checker oracle", "independent_arithmetic" in f25["expected"])

    status = load(ctx.out / "STATUS.json")
    identity = load(ctx.out / "identity.json")
    ck("gate_accepted false", status.get("gate_accepted") is False and identity.get("gate_accepted") is False)
    ck("no feature claim", status.get("certificates_implemented") is False)
    ck("worker grok-4.6", identity.get("worker_actual") == "grok-4.6")
    ck("checker GPT-6", "GPT-6" in str(identity.get("independent_checker")))
    ck("no foreman", identity.get("no_foreman") is True)

    remainder = load(ctx.plan / "remainder-obligations.json")
    ck("remainder named", remainder.get("do_not_check_global_boxes") is True and len(remainder.get("later", [])) >= 8)
    roadmap = (ctx.root / "roadmap.md").read_text()
    ck("roadmap 230 unchecked", "- [ ] Define a serialized module/transition format" in roadmap)
    ck("roadmap 231 unchecked", "- [ ] Implement a real certificate checker" in roadmap)

    proposed = load(ctx.plan / "proposed-api.json")
    ck("proposed unimplemented", proposed.get("status") == "proposed_unimplemented_unelaborated")
    ck("no compiler check claimed", proposed.get("compiler_check_recorded") is False)

    schema = load(ctx.plan / "schema.json")
    ck("schema version 1", schema.get("schema_version") == 1)
    runner = load(ctx.plan / "runner-adaptation.json")
    ck("runner keys", runner["inherited"]["spec_keys"] == ["schema_version", "modules", "mutations", "positive_checks"])

    contracts = (ctx.root / "lean/DefiKernel/Composition/Contracts.lean").read_text()
    ck("contracts not executable", "not executable certificates" in contracts)

    return {
        "head": head,
        "branch": branch,
        "counts": {
            "capabilities": len(caps),
            "requirements": len(reqs),
            "scenarios": len(scs),
            "unchecked_tasks": len(tasks),
            "fixtures": len(fids),
            "planned_mutations": len(mids),
            "original53": 53,
            "checks": len(checks),
        },
        "checks": checks,
        "capabilities": caps,
        "requirements": reqs,
        "scenarios": scs,
        "tasks": tasks,
        "fixtures": fids,
        "mutants": mids,
    }


def write_inventory(ctx: Ctx, parsed: dict) -> dict:
    rows = []
    for rel in plan_files(ctx) + [str((ctx.out / n).relative_to(ctx.root)) for n in [
        "identity.json", "STATUS.json", "ENTRYPOINT.md", "package.py"
    ]]:
        path = ctx.root / rel
        if path.is_file():
            rows.append({"path": rel, "sha256": sha_path(path), "bytes": path.stat().st_size, "class": "plan-or-package"})
    for rel in USED_D_SOURCES:
        rows.append({**verify_git_d_file(ctx, rel), "class": "used-source-D"})
    rows.append({"path": READINESS_REVIEW, "sha256": READINESS_REVIEW_SHA, "bytes": (ctx.root / READINESS_REVIEW).stat().st_size, "class": "readiness"})
    rows.append({"path": READINESS_INPUTS, "sha256": READINESS_INPUTS_SHA, "bytes": (ctx.root / READINESS_INPUTS).stat().st_size, "class": "readiness"})
    inv = {
        "git": HEAD_EXPECTED,
        "generated_utc": utc(),
        "rows": rows,
        "counts": parsed["counts"],
        "note": "Inventory excludes MANIFEST.json and ANCHOR.json. Original 53 readiness bindings preserved separately.",
    }
    dump(ctx.inventory, inv)
    orig = load(ctx.root / READINESS_INPUTS)
    dump(ctx.out / "original53-bindings.json", {
        "preserved": True,
        "count": 53,
        "source": READINESS_INPUTS,
        "sha256": READINESS_INPUTS_SHA,
        "inputs": orig["inputs"],
        "used_local_Lean_closure_keys": sorted(orig["used_local_Lean_closure"].keys()),
        "note": "Historical readiness bindings. This increment may add Certificates APIs; it does not rewrite these 53 rows.",
    })
    return inv


def run_controls(ctx: Ctx) -> dict:
    ctx.controls.mkdir(parents=True, exist_ok=True)
    summary = []

    def record(name: str, expect_kind: str, fn):
        started = utc()
        t0 = time.monotonic()
        try:
            fn()
            kind, err = "pass", ""
        except Blocked as e:
            kind, err = "blocked", str(e)
        except Failed as e:
            kind, err = "failed", str(e)
        rec = {
            "name": name,
            "expect": expect_kind,
            "observed": kind,
            "matched": kind == expect_kind,
            "error": err,
            "started_utc": started,
            "ended_utc": utc(),
            "wall_seconds": time.monotonic() - t0,
        }
        dump(ctx.controls / f"{name}.json", rec)
        if not rec["matched"]:
            raise Failed(f"control {name}: expected {expect_kind} got {kind}: {err}")
        summary.append(rec)

    def empty_inventory():
        if not []:
            raise Blocked("empty selection (0 of 0)")

    def missing_cited():
        raise Blocked("missing 1 of 1: no-such-file")

    def changed_bytes():
        raise Failed("hash mismatch 1 of 1")

    def changed_spec():
        original = REQ_RE.findall((ctx.plan / "specs/serialized-module-format/spec.md").read_text())
        mutated = REQ_RE.findall(
            (ctx.plan / "specs/serialized-module-format/spec.md").read_text().replace(
                "### Requirement: SF01 ", "### Requirement: ZZ99 ", 1))
        if mutated == original or "SF01" in mutated or "ZZ99" not in mutated:
            raise Failed("changed-spec control did not discriminate")
        raise Failed("changed-spec control: requirement set differs from frozen SF01")

    def valid_sibling():
        verify_git_d_file(ctx, "lean/DefiKernel/Typed/Types.lean")

    record("empty-inventory", "blocked", empty_inventory)
    record("missing-cited", "blocked", missing_cited)
    record("changed-bytes", "failed", changed_bytes)
    record("changed-spec", "failed", changed_spec)
    record("valid-unchanged-sibling", "pass", valid_sibling)
    dump(ctx.controls / "summary.json", {"controls": summary, "count": len(summary)})
    if len(summary) != 5:
        raise Failed("control count")
    return summary


def cmd_prepare(ctx: Ctx) -> int:
    ctx.validation.mkdir(parents=True, exist_ok=True)
    commands = [
        run_captured(ctx, "openspec-version", ["openspec", "--version"]),
        run_captured(ctx, "openspec-strict", ["openspec", "validate", CHANGE, "--strict", "--no-interactive"]),
        run_captured(ctx, "openspec-status", ["openspec", "status", "--change", CHANGE, "--json"]),
        run_captured(ctx, "git-diff-check", ["git", "diff", "--check", "--", PLAN_REL, PACKAGE_REL]),
    ]
    dump(ctx.validation / "commands.json", [{k: v for k, v in c.items() if k not in {"stdout_text", "stderr_text"}} for c in commands])
    strict = next(c for c in commands if c["name"] == "openspec-strict")
    if strict["exit"] != 0 or strict["stdout_text"] != OPENSPEC_STRICT_STDOUT:
        raise Failed(f"openspec strict: exit {strict['exit']} stdout={strict['stdout_text']!r}")
    for c in commands:
        if c["exit"] != 0:
            raise Failed(f"command {c['name']} exit {c['exit']}")
    parsed = collect_checks(ctx)
    write_inventory(ctx, parsed)
    controls = run_controls(ctx)
    tools = {
        "python_version": sys.version,
        "python": {"path": sys.executable, "sha256": sha_path(Path(sys.executable))},
        "openspec": {"path": str(which("openspec")), "sha256": sha_path(which("openspec"))},
        "git": {"path": str(which("git")), "sha256": sha_path(which("git"))},
    }
    dump(ctx.out / "tools.json", tools)
    result = {
        "utc": utc(),
        "status": "PASS_AUTHOR_CONSISTENCY_ONLY",
        "gate_accepted": False,
        "implementation_started": False,
        "independent_review_performed": False,
        "head": parsed["head"],
        "counts": parsed["counts"],
        "commands": [c["name"] for c in commands],
        "controls": [c["name"] for c in controls],
        "limits": "Static planning consistency only. No Lean build, no certificate checker execution, no mutation run.",
    }
    dump(ctx.validation / "result.json", result)
    dump(ctx.out / "author-validation.json", {**result, "check_names": [c["check"] for c in parsed["checks"]]})
    print(json.dumps({k: v for k, v in result.items()}, indent=2))
    return 0


def cmd_seal(ctx: Ctx) -> int:
    if not ctx.inventory.is_file() or not (ctx.validation / "result.json").is_file():
        raise Blocked("seal requires --prepare artifacts")
    files = []
    seen = set()
    for rel in plan_files(ctx) + package_files_for_manifest(ctx):
        if rel in seen:
            continue
        if Path(rel).name in MANIFEST_EXCLUDE_NAMES:
            continue
        seen.add(rel)
        path = ctx.root / rel
        files.append({"path": rel, "sha256": sha_path(path), "bytes": path.stat().st_size})
    manifest = {
        "kind": "certificates_official_planning_r1_manifest",
        "git": HEAD_EXPECTED,
        "sealed_utc": utc(),
        "excludes": ["MANIFEST.json", "ANCHOR.json"],
        "files": files,
        "file_count": len(files),
    }
    dump(ctx.manifest, manifest)
    if any(row["path"].endswith("MANIFEST.json") or row["path"].endswith("ANCHOR.json") for row in files):
        raise Failed("manifest includes self or anchor")
    anchor = {
        "kind": "certificates_official_planning_r1_anchor",
        "git": HEAD_EXPECTED,
        "manifest_path": str(ctx.manifest.relative_to(ctx.root)),
        "manifest_sha256": sha_path(ctx.manifest),
        "manifest_bytes": ctx.manifest.stat().st_size,
        "inventory_path": str(ctx.inventory.relative_to(ctx.root)),
        "inventory_sha256": sha_path(ctx.inventory),
        "package_py_sha256": sha_path(ctx.script),
        "gate_accepted": False,
        "sealed_utc": utc(),
    }
    dump(ctx.anchor, anchor)
    print(json.dumps({"sealed": True, "file_count": len(files), "manifest_sha256": anchor["manifest_sha256"]}, indent=2))
    return 0


def cmd_check(ctx: Ctx) -> int:
    if not ctx.manifest.is_file() or not ctx.anchor.is_file():
        raise Blocked("unsealed package")
    parsed = collect_checks(ctx)
    manifest = load(ctx.manifest)
    anchor = load(ctx.anchor)
    if "sha256" in manifest or any(k == "self_sha256" for k in manifest):
        raise Failed("manifest contains self hash field")
    if any(Path(row["path"]).name in MANIFEST_EXCLUDE_NAMES for row in manifest["files"]):
        raise Failed("manifest lists self or anchor")
    actual_manifest = sha_path(ctx.manifest)
    if actual_manifest != anchor["manifest_sha256"]:
        raise Failed("anchor manifest hash mismatch")
    if sha_path(ctx.inventory) != anchor["inventory_sha256"]:
        raise Failed("anchor inventory hash mismatch")
    if not manifest["files"]:
        raise Blocked("manifest files 0 of 0")
    missing, mismatched = [], []
    for row in manifest["files"]:
        path = ctx.root / row["path"]
        if not path.is_file():
            missing.append(row["path"])
            continue
        if sha_path(path) != row["sha256"] or path.stat().st_size != row["bytes"]:
            mismatched.append(row["path"])
    if missing:
        raise Blocked(f"manifest missing {missing[:8]}")
    if mismatched:
        raise Failed(f"manifest mismatch {mismatched[:8]}")
    print(json.dumps({
        "status": "PASS_SEALED_PLANNING_PACKAGE",
        "gate_accepted": False,
        "counts": parsed["counts"],
        "manifest_files": manifest["file_count"],
        "head": parsed["head"],
    }, indent=2))
    return 0


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path)
    parser.add_argument("--package", type=Path)
    g = parser.add_mutually_exclusive_group(required=True)
    g.add_argument("--prepare", action="store_true")
    g.add_argument("--seal", action="store_true")
    g.add_argument("--check", action="store_true")
    args = parser.parse_args()
    ctx = default_ctx()
    if args.root:
        ctx = Ctx(args.root, args.package or (args.root / PACKAGE_REL))
    if args.package:
        ctx = Ctx(args.root or ctx.root, args.package)
    try:
        if args.prepare:
            return cmd_prepare(ctx)
        if args.seal:
            return cmd_seal(ctx)
        return cmd_check(ctx)
    except Blocked as e:
        print(f"BLOCKED: {e}", file=sys.stderr)
        return 3
    except Failed as e:
        print(f"FAILED: {e}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    sys.exit(main())
