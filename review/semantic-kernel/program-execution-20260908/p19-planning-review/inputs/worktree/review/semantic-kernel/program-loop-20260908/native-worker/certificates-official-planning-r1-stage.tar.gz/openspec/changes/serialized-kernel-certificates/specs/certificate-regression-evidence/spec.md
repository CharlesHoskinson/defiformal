## Purpose

Defines independent fixtures, planned mutations, malformed and stale controls, declared audit-root evidence and the mutation-runner protocol for this certificate increment.

## ADDED Requirements

### Requirement: EV01 Independent fixtures and discriminating controls

Every fixture SHALL have independent literal expected fields, a nonempty scenario list and a status of planned-not-executed until implementation. The inventory SHALL include malformed, empty, missing, unsupported, stale and changed-judgment controls plus funded success and exact-constructor refusal siblings. Count-only summaries SHALL NOT substitute for constructor identity.

#### Scenario: S61 Every fixture has literal expected fields

- **WHEN** `fixtures.json` is validated
- **THEN** each fixture has nonempty `id`, `expected` object with constructor or decode-failure identity, and does not store checker-generated oracles.

#### Scenario: S62 Discriminating negative controls exist

- **WHEN** empty, missing-field, unreduced-rational, unsupported-step, stale-SHA and claimed-next-state fixtures are listed
- **THEN** each has a distinct expected failure distinct from an intact sibling's expected success.

### Requirement: EV02 Planned mutations with designated false and protected positives

Each mutant SHALL name the semantic change, a planned source needle or `future_anchor` status, one designated false observation, and at least one unaffected positive. Production execution SHALL use one-mutant SPECs. Future composition-operator coverage remains a named later obligation, not silent closure. Existing arithmetic and Atomic cases SHALL NOT be new certificate mutants.

#### Scenario: S63 Each mutant has change anchor false and protected positive

- **WHEN** `planned-mutations.json` is validated
- **THEN** every mutant has unique id, `actual_source_change` or `future_anchor`, `oracle_fixture`, `required_false` and `expected_protected_check`, with those two check names distinct.

#### Scenario: S64 One-mutant SPEC protocol is required

- **WHEN** production mutations run
- **THEN** each invocation has exactly one mutation and `positive_checks` equal to that mutant's protected check; a unioned multi-mutant SPEC is forbidden.

#### Scenario: S65 Arithmetic and Atomic cases are not certificate acceptance

- **WHEN** mutation and fixture inventories are inspected
- **THEN** no mutant claims Arithmetic word/fee theorems or Atomic settlement as newly accepted certificate coverage.

### Requirement: EV03 Runner protocol mapping and blocked evidence

The certificate mutation driver SHALL reuse the inherited Interface SPEC fields `schema_version`, `modules`, `mutations` and `positive_checks` with literal field-set equality. Timeout, empty output, missing module, parse error and compiler error SHALL be blocked evidence (exit 3), never semantic detection. Output SHALL live outside the repository.

#### Scenario: S66 Inherited SPEC field set is reused

- **WHEN** a production mutant SPEC is written
- **THEN** its JSON keys are exactly `schema_version`, `modules`, `mutations`, `positive_checks` with `schema_version` 1.

#### Scenario: S67 Timeout or empty output is blocked

- **WHEN** a mutant Lean command times out or prints zero checks
- **THEN** the record is blocked, not a detected false observation, and an outer invocation record is required.
