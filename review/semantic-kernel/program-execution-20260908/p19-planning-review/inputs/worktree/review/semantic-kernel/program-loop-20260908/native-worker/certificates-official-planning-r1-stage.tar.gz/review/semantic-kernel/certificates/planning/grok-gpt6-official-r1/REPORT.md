# Certificates official planning r1

Native Grok 4.6 authored OpenSpec change `serialized-kernel-certificates` over delivered Typed and sequential Composition at Git D `a12b7cac05a818cc8d35c2ca440b7170a2807e92`. Independent GPT-6 / gpt-6-astra review is pending. `STATUS.gate_accepted` is false. No certificate feature is implemented or claimed.

The GPT-6 readiness recovery (`remaining-financial-async-readiness-gpt6-review.md` SHA-256 `9173e34ce186104f9593831d0f8061682656ea2de4eb888dcc424fc22014d9c2`) is a dependency audit, not this plan and not an accepted design.

## Increment

Serialized first-order Typed modules plus sequential Composition catalog/step certificates. The checker must call actual `Typed.execute`, `Composition.executeStep`/`run`, `validateCatalog`, `checkAccess`, `Args.check`, `issueCapability` and `revokeCapability`. Claimed tags, theorem names, keyword labels and `ComponentContract` propositions do not discharge judgments.

Hard forms are rejected or named outstanding: Claims create/discharge, Tree/Nary/parallel/interleave/atomic constructors, Quint, crypto-valid, arbitrary Prop executability. Remainder is `remainder-obligations.json`. Roadmap §5 boxes stay unchecked.

## Counts

| Item | Count |
| --- | --- |
| Capabilities | 5 |
| Requirements | 26 |
| Scenarios | 67 (S01–S67) |
| Unchecked tasks | 34 |
| Fixtures | 46 (F01–F46) |
| Planned mutations | 16 (M01–M16) |
| Original readiness bindings | 53 |
| Author checks | 520 |

Independent literals: transfer-3 yields alice USD 7, bob USD 3, vault USD 20 (`10-3=7`, `0+3=3`). Repeated deltas `10-3-3=4`. Unbalanced `3≠4`. Overdraft `10-11<0`.

## Evidence (prepare)

CWD `/home/charl/defiformal-wt-certificates-grok-gpt6-20260908`. OpenSpec 1.10.0.

| Command | Exit | Executable SHA-256 |
| --- | --- | --- |
| openspec --version | 0 | `ca136f0e9fd4951dcf93d8ed729ebc97b2d97d3980cd9dc9d42fc80e32e797c6` |
| openspec validate serialized-kernel-certificates --strict --no-interactive | 0 | same |
| openspec status --change serialized-kernel-certificates --json | 0 | same |
| git diff --check | 0 | git `5516c9f362c29376ab9a499a33082f9f611941d8c75930c880e30ad109e39c9a` |

Python 3.14.4 SHA-256 `b8d8288faefdd300201f43fcf00f6f539a27218eeed3a3dff5ab10b9c4c99700`. Full stdout/stderr live under `validation/`. Strict stdout is `Change 'serialized-kernel-certificates' is valid`.

Negative controls (discriminating, not count-only): empty inventory BLOCKED; missing cited BLOCKED; changed bytes FAILED; changed spec FAILED; valid unchanged sibling PASS (`Typed/Types.lean` equals D).

## Role and preservation

Worker grok-4.6. Checker GPT-6. No Foreman. Original launch failure remains at `native-worker/certificates-official-planning-r1-attempt1/` (empty jsonl, missing briefs directory, no credit). Prepare failures are in `attempts.json`. Old OpenSpec archives, roadmap unchecked boxes, AGENTS.md, and delivered Lean at D are unmutated. `gate33_cert_check.py` PASS is not reused. No corpus/holdout/assessment payload was read.

Original 53 readiness hashes are preserved. One non-D row (`agenda-inventory-after-m3-20260908.json`) is absent from this isolated tree and is recorded, not fabricated.

## Unknowns and risks

- `Lean.Data.Json` is a proposed import, unelaborated; no compiler check is recorded.
- M06 skip-readAccess needs a component that cannot read a required cell; F27 is the protected success sibling, not that companion.
- Future Certificates needles remain `future_anchor` until those files exist.
- Claims/Tree export shapes wait for those packages.
- Unresolved source-plan citation tokens are unused.
- Empty imported theorem audit is specified as blocked; it cannot run until Certificates modules exist.

## Not claimed

Implementation, Lean proofs, mutation detection, arithmetic/Atomic re-acceptance, package 8 completion, or planning-gate acceptance.
