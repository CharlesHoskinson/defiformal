#!/usr/bin/env python3
"""Record argv/cwd/exit/input/output hashes for one command."""
from __future__ import annotations

import hashlib
import json
import os
import subprocess
import sys
import time
from datetime import datetime, timezone
from pathlib import Path


def sha_file(path: Path):
    if not path.is_file():
        return None
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    label = sys.argv[1]
    out_dir = Path(sys.argv[2])
    cwd = Path(sys.argv[3])
    command = sys.argv[4:]
    out_dir.mkdir(parents=True, exist_ok=True)
    started = datetime.now(timezone.utc).isoformat()
    tick = time.monotonic()
    proc = subprocess.run(command, cwd=str(cwd), capture_output=True)
    elapsed = time.monotonic() - tick
    stdout = proc.stdout
    stderr = proc.stderr
    (out_dir / f"{label}.stdout").write_bytes(stdout)
    (out_dir / f"{label}.stderr").write_bytes(stderr)
    rec = {
        "label": label,
        "utc": started,
        "argv": command,
        "cwd": str(cwd),
        "exit": proc.returncode,
        "elapsed_seconds": round(elapsed, 6),
        "stdout_sha256": hashlib.sha256(stdout).hexdigest(),
        "stderr_sha256": hashlib.sha256(stderr).hexdigest(),
        "stdout_bytes": len(stdout),
        "stderr_bytes": len(stderr),
        "env_subset": {
            "PATH": os.environ.get("PATH"),
            "HOME": os.environ.get("HOME"),
        },
    }
    (out_dir / f"{label}.command.json").write_text(json.dumps(rec, indent=2) + "\n")
    sys.stdout.buffer.write(stdout)
    sys.stderr.buffer.write(stderr)
    print(f"RECORDED {label} exit={proc.returncode} elapsed={rec['elapsed_seconds']}", flush=True)
    return proc.returncode


if __name__ == "__main__":
    raise SystemExit(main())
