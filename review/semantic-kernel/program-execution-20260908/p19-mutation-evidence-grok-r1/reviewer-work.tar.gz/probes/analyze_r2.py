#!/usr/bin/env python3
"""Static reconciliation of frozen P19 R2 mutation records. Read-only on sandbox."""
from __future__ import annotations

import hashlib
import json
import re
from datetime import datetime, timezone
from pathlib import Path

OUT = Path("/home/charl/defiformal/review/semantic-kernel/program-execution-20260908/p19-mutation-evidence-grok-r1")
SANDBOX = Path("/home/charl/.cache/defiformal-program/program-execution-20260908/p19-mutation-evidence-grok-r1-sandbox")
CLONE = OUT / "clone/p19-r2-mutation-source"
EVIDENCE = SANDBOX / "review/semantic-kernel/certificates/p19/implementation/agy-r2"
CHECK_NAME = r"[a-z][a-z0-9_-]*(?:\.[a-z][a-z0-9_-]*)*"


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def sha_bytes(raw: bytes) -> str:
    return hashlib.sha256(raw).hexdigest()


def load_json(path: Path):
    return json.loads(path.read_text())


def parse_log_observations(log: str):
    observations = re.findall(rf"^({CHECK_NAME}): (true|false)$", log, re.MULTILINE)
    diagnostic_prefixes = (
        "Hint: The binding can be removed (if unused) or named ",
        "Note: This linter can be disabled with ",
    )
    candidates = [
        line
        for line in log.splitlines()
        if re.match(r"^[A-Za-z0-9_.-]+:", line) and not line.startswith(diagnostic_prefixes)
    ]
    errors = [line for line in log.splitlines() if re.search(r": error(?:\([^)]*\))?:", line)]
    checks = dict(observations)
    false_names = sorted(name for name, value in checks.items() if value == "false")
    expected_error = f"error: Certificate runtime comparisons failed: {len(false_names)}"
    sole_runtime = len(errors) == 1 and errors[0].endswith(expected_error)
    return {
        "observation_count": len(observations),
        "candidate_count": len(candidates),
        "duplicate_or_empty": not (checks and len(checks) == len(observations)),
        "malformed_candidate_mismatch": len(candidates) != len(observations),
        "checks": checks,
        "false": false_names,
        "errors": errors,
        "sole_runtime_comparison_failure": sole_runtime,
        "error_count": len(errors),
    }


def main():
    started = datetime.now(timezone.utc).isoformat()
    inputs = load_json(OUT / "inputs.json")
    planned = load_json(SANDBOX / "openspec/changes/serialized-kernel-certificates/planned-mutations.json")
    summary = load_json(EVIDENCE / "mutants-summary.json")
    completeness = load_json(
        SANDBOX / "review/semantic-kernel/program-execution-20260908/p19-implementation-agy-r2-root-completeness.json"
    )
    terminal = load_json(
        SANDBOX / "review/semantic-kernel/program-execution-20260908/p19-implementation-agy-r2-terminal-manifest.json"
    )

    hash_checks = []
    for rel, expected in [
        ("scripts/run_certificate_mutations.py", "883a40b14c6f8857632b9eef5e54b1ceb37a441ad334a84a130fdf60b7c8c701"),
        ("scripts/test_certificate_mutation_runner.py", "e2bd8d6d14e1b4c27e61c4242d6d6dc1d93fa26e0c9a171e83adf4fb1a428946"),
        ("p19-implementation-agy-r2-mutation-source.bundle", "875707986fc294616ca2e19845812d638cabbbe2f39e816043ab74b3528a7614"),
        ("openspec/changes/serialized-kernel-certificates/planned-mutations.json", "64f6d3321b1060a0560f7a4e85375108fb5ce2cd0fe836ac6167a2ba35ca31d0"),
        ("review/semantic-kernel/program-execution-20260908/p19-implementation-agy-r2-root-completeness.json", "cdc10cf2918016a600843269fe0070febccdd9291c0be6e1faaa78be3ded3547"),
        ("review/semantic-kernel/program-execution-20260908/p19-implementation-agy-r2-terminal-manifest.json", "77be294cfad06a613d114045e67d063de39735a785ead2ff6f037dc7c126016f"),
        ("review/semantic-kernel/program-execution-20260908/P19-PLANNING-ACCEPTANCE.md", "eaaaab3a67eac278afe91abc40c839b05f6ccf5d5d0ad12722c1ca2c1bbaca73"),
    ]:
        actual = sha(SANDBOX / rel)
        listed = inputs["files"].get(rel)
        hash_checks.append(
            {
                "path": rel,
                "actual": actual,
                "inputs_json": listed,
                "expected_constant": expected,
                "match_inputs": actual == listed,
                "match_expected": actual == expected,
            }
        )

    archive_sha = completeness["archive_sha256"]
    planned_by_id = {m["id"]: m for m in planned["mutations"]}
    nineteen = [
        "cert.typing.recomputed",
        "cert.transfer.alice7",
        "cert.execute.recomputed",
        "cert.accounting.recomputed",
        "cert.authority.debit",
        "cert.catalog.nodup",
        "cert.catalog.export-not-private",
        "cert.access.reads",
        "cert.step.alice7",
        "cert.rational.canonical",
        "cert.rational.zero-den",
        "cert.precedence.actor-mismatch",
        "cert.library.outstanding",
        "cert.prop.not-executable",
        "cert.refusal.constructor",
        "cert.funds.insufficient",
        "cert.capability.fresh-id",
        "cert.env.missing-observation",
        "cert.unsupported.rejected",
    ]

    module_to_path = {
        "DefiKernel.Certificates.Check": "lean/DefiKernel/Certificates/Check.lean",
        "DefiKernel.Certificates.Decode": "lean/DefiKernel/Certificates/Decode.lean",
        "DefiKernel.Certificates.Observation": "lean/DefiKernel/Certificates/Observation.lean",
        "DefiKernel.Typed.Transition": "lean/DefiKernel/Typed/Transition.lean",
        "DefiKernel.Typed.Authority": "lean/DefiKernel/Typed/Authority.lean",
        "DefiKernel.Typed.Expr": "lean/DefiKernel/Typed/Expr.lean",
        "DefiKernel.Composition.Interfaces": "lean/DefiKernel/Composition/Interfaces.lean",
    }

    rows = []
    issues = []
    control_fixture_hashes = set()
    source_sets = []
    git_heads = set()
    lean_versions = set()
    script_hashes = set()

    for mid in [f"M{i:02d}" for i in range(1, 17)]:
        planned_m = planned_by_id[mid]
        spec_path = EVIDENCE / "mutant-specs" / f"{mid}.json"
        spec = load_json(spec_path)
        run_dir = EVIDENCE / "mutants" / mid
        results = load_json(run_dir / "results.json")
        manifest = load_json(run_dir / "source-manifest.json")
        stored_spec = load_json(run_dir / "mutation-spec.json")
        summary_row = summary["results"][mid]
        mut = spec["mutations"][0]
        name = mut["name"]
        module = mut["module"]
        rel = module_to_path[module]
        production = (SANDBOX / rel).read_text()
        clone_src = (CLONE / rel).read_text()
        stored_src = (run_dir / "inputs" / rel).read_text()
        needle = mut["needle"]
        replacement = mut["replacement"]
        prod_count = production.count(needle)
        repl_count_prod = production.count(replacement)
        clone_count = clone_src.count(needle)
        stored_count = stored_src.count(needle)
        control_lean = (run_dir / "control.lean").read_text()
        mutant_lean = (run_dir / f"{name}.lean").read_text()
        control_needle = control_lean.count(needle)
        mutant_needle = mutant_lean.count(needle)
        control_repl = control_lean.count(replacement)
        mutant_repl = mutant_lean.count(replacement)
        control_log = (run_dir / "control.log").read_text()
        mutant_log = (run_dir / f"{name}.log").read_text()
        control_obs = parse_log_observations(control_log)
        mutant_obs = parse_log_observations(mutant_log)
        control_run = next(r for r in results["runs"] if r["label"] == "control")
        mutant_run = next(r for r in results["runs"] if r["label"] == name)
        control_hash = sha(run_dir / "control.lean")
        mutant_hash = sha(run_dir / f"{name}.lean")
        control_fixture_hashes.add(results["results"]["control"]["fixture_sha256"])
        git_heads.add(manifest["git_head"])
        lean_versions.add(manifest["lean_version"])
        script_hashes.add(manifest["script_sha256"])
        source_sets.append(manifest["sources"])

        # unique edit between generated control and mutant
        if control_lean == mutant_lean:
            unique_edit = "IDENTICAL_CONTROL_AND_MUTANT"
        else:
            # cheap uniqueness: replacement of needle once should be the only difference
            reconstructed = control_lean.replace(needle, replacement, 1)
            unique_edit = "single_needle_replacement" if reconstructed == mutant_lean else "NOT_SINGLE_NEEDLE_REPLACEMENT"

        protected = spec["positive_checks"]
        required = mut["required_false"]
        observed_false = results["results"][name]["false_comparisons"]
        control_false = results["results"]["control"]["false_comparisons"]
        control_checks = results["results"]["control"]["checks"]
        mutant_checks = results["results"][name]["checks"]

        row_issues = []
        if spec != stored_spec:
            row_issues.append("spec_bytes_differ_from_stored_mutation-spec.json")
        if mut["needle"] != planned_m["needle"] or mut["replacement"] != planned_m["replacement"]:
            row_issues.append("needle_or_replacement_differs_from_planned")
        if mut["module"] != planned_m["module"]:
            row_issues.append("module_differs_from_planned")
        if mut["name"] != planned_m["runner_name"]:
            row_issues.append("runner_name_differs_from_planned")
        if required != planned_m["required_false"]:
            row_issues.append("required_false_differs_from_planned")
        if protected != [planned_m["expected_protected_check"]]:
            row_issues.append("positive_checks_differ_from_planned_protected")
        if prod_count != 1:
            row_issues.append(f"production_needle_count={prod_count}")
        if clone_count != 1:
            row_issues.append(f"clone_needle_count={clone_count}")
        if stored_count != 1:
            row_issues.append(f"stored_input_needle_count={stored_count}")
        if control_needle != 1:
            row_issues.append(f"generated_control_needle_count={control_needle}")
        if mutant_needle != 0:
            row_issues.append(f"generated_mutant_still_has_needle_count={mutant_needle}")
        if mutant_repl < 1:
            row_issues.append("generated_mutant_missing_replacement")
        if unique_edit != "single_needle_replacement":
            row_issues.append(unique_edit)
        if sha_bytes(control_lean.encode()) != results["results"]["control"]["fixture_sha256"]:
            row_issues.append("control_lean_hash_mismatch")
        if sha_bytes(mutant_lean.encode()) != results["results"][name]["fixture_sha256"]:
            row_issues.append("mutant_lean_hash_mismatch")
        if sha(run_dir / "control.log") != control_run["log_sha256"]:
            row_issues.append("control_log_hash_mismatch")
        if sha(run_dir / f"{name}.log") != mutant_run["log_sha256"]:
            row_issues.append("mutant_log_hash_mismatch")
        if control_obs["checks"] != control_checks:
            row_issues.append("control_log_observations_disagree_with_results_json")
        if mutant_obs["checks"] != mutant_checks:
            row_issues.append("mutant_log_observations_disagree_with_results_json")
        if control_obs["false"] != control_false:
            row_issues.append("control_false_disagree")
        if mutant_obs["false"] != observed_false:
            row_issues.append("mutant_false_disagree")
        if list(control_checks.keys()) != nineteen:
            row_issues.append("control_check_order_or_set_is_not_the_19")
        if set(control_checks) != set(nineteen) or set(mutant_checks) != set(nineteen):
            row_issues.append("check_set_is_not_exactly_the_19")
        if any(v != "true" for v in control_checks.values()):
            row_issues.append("control_has_false_observation")
        if control_run["exit"] != 0:
            row_issues.append("control_exit_not_0")
        if mutant_run["exit"] != 1:
            row_issues.append(f"mutant_exit_{mutant_run['exit']}")
        if not mutant_obs["sole_runtime_comparison_failure"]:
            row_issues.append("mutant_failure_not_sole_runtime_comparison")
        if control_obs["error_count"] != 0:
            row_issues.append("control_has_error_lines")
        if not set(required) <= set(observed_false):
            row_issues.append("required_false_not_observed")
        if any(mutant_checks[p] != "true" for p in protected):
            row_issues.append("protected_positive_failed")
        extra_false = sorted(set(observed_false) - set(required))
        if extra_false and mid != "M12":
            row_issues.append(f"unexpected_collateral_false={extra_false}")
        if mid == "M12" and set(extra_false) != {"cert.execute.recomputed", "cert.step.alice7"}:
            # transfer is required; execute/step are extra
            if set(observed_false) != {"cert.execute.recomputed", "cert.step.alice7", "cert.transfer.alice7"}:
                row_issues.append(f"m12_unexpected_false_set={observed_false}")
        if manifest["git_head"] != "a38f2b87bd412f3ad48c04f404fb2f5c4374c52c":
            row_issues.append("unexpected_git_head")
        if manifest["input_status"] != "":
            row_issues.append("dirty_git_input_status")
        if not manifest.get("input_sources_unchanged"):
            row_issues.append("sources_changed_flag")
        if "BEGIN PROOFS" in control_lean or "BEGIN PROOFS" in mutant_lean:
            row_issues.append("proof_boundary_present_in_generated_fixture")
        if "sorry" in control_lean or "sorry" in mutant_lean:
            row_issues.append("sorry_in_generated_fixture")
        # production invocation: Tests checks call checkTyped/checkStep/decode
        if "def checkTypingRecomputed" not in control_lean:
            row_issues.append("runtime_checks_missing_from_generated_control")
        if "checkTyped" not in control_lean or "checkStep" not in control_lean:
            row_issues.append("generated_fixture_missing_checkTyped_or_checkStep")
        if "Typed.execute" not in control_lean:
            row_issues.append("generated_fixture_missing_Typed.execute")

        row = {
            "id": mid,
            "runner_name": name,
            "planned_module": planned_m["module"],
            "actual_module": module,
            "planned_grouping": planned_m["grouping"],
            "oracle_label": planned_m["oracle_label"],
            "oracle_fixture": planned_m["oracle_fixture"],
            "required_false": required,
            "protected_positive": protected,
            "planned_protected_positive": planned_m["protected_positive"],
            "observed_false": observed_false,
            "extra_false": extra_false,
            "production_needle_count": prod_count,
            "clone_needle_count": clone_count,
            "stored_input_needle_count": stored_count,
            "generated_control_needle_count": control_needle,
            "generated_mutant_needle_count": mutant_needle,
            "generated_mutant_replacement_count": mutant_repl,
            "unique_edit": unique_edit,
            "control_exit": control_run["exit"],
            "mutant_exit": mutant_run["exit"],
            "mutant_sole_runtime_failure": mutant_obs["sole_runtime_comparison_failure"],
            "control_comparisons": len(control_checks),
            "mutant_comparisons": len(mutant_checks),
            "control_all_true": all(v == "true" for v in control_checks.values()),
            "protected_held": all(mutant_checks[p] == "true" for p in protected),
            "required_observed": set(required) <= set(observed_false),
            "control_fixture_sha256": results["results"]["control"]["fixture_sha256"],
            "mutant_fixture_sha256": results["results"][name]["fixture_sha256"],
            "control_lean_sha256": control_hash,
            "mutant_lean_sha256": mutant_hash,
            "git_head": manifest["git_head"],
            "script_sha256": manifest["script_sha256"],
            "spec_sha256": manifest["spec_sha256"],
            "lean_version": manifest["lean_version"],
            "bound_source_count": len(manifest["sources"]),
            "projection_order": manifest.get("projection_order"),
            "historical_repo_cwd": control_run["cwd"],
            "issues": row_issues,
            "supported_as_historical_19check_discrimination": not row_issues,
        }
        rows.append(row)
        issues.extend({"id": mid, "issue": x} for x in row_issues)

    source_identity_stable = all(s == source_sets[0] for s in source_sets)
    control_fixture_stable = len(control_fixture_hashes) == 1

    # Git blob identity from clone
    blob_checks = []
    m01_manifest = load_json(EVIDENCE / "mutants/M01/source-manifest.json")
    for rel, binding in m01_manifest["git_input_bindings"].items():
        import subprocess

        ident = subprocess.run(
            ["git", "-C", str(CLONE), "rev-parse", f"{m01_manifest['git_head']}:{rel}"],
            capture_output=True,
            text=True,
            timeout=30,
        )
        blob = subprocess.run(
            ["git", "-C", str(CLONE), "cat-file", "blob", binding["git_object"]],
            capture_output=True,
            timeout=30,
        )
        blob_sha = sha_bytes(blob.stdout) if blob.returncode == 0 else None
        blob_checks.append(
            {
                "path": rel,
                "recorded_object": binding["git_object"],
                "clone_object": ident.stdout.strip() if ident.returncode == 0 else None,
                "object_match": ident.returncode == 0 and ident.stdout.strip() == binding["git_object"],
                "blob_sha256": blob_sha,
                "recorded_sha256": binding["sha256"],
                "blob_match": blob.returncode == 0 and blob_sha == binding["sha256"],
                "bytes_match_clone_file": blob.returncode == 0 and blob.stdout == (CLONE / rel).read_bytes(),
            }
        )

    # Cross-mutant source identity
    all_manifest_sources_equal = True
    for mid in [f"M{i:02d}" for i in range(2, 17)]:
        m = load_json(EVIDENCE / "mutants" / mid / "source-manifest.json")
        if m["sources"] != m01_manifest["sources"]:
            all_manifest_sources_equal = False

    tests = (SANDBOX / "lean/DefiKernel/Certificates/Tests.lean").read_text()
    runtime_check_names = re.findall(r'\("cert\.[^"]+", ([a-zA-Z0-9]+)\)', tests)
    invocations = {
        "checkTyped_in_tests": tests.count("checkTyped"),
        "checkStep_in_tests": tests.count("checkStep"),
        "decodeRational_in_tests": tests.count("decodeRational"),
        "decodeStep_in_tests": tests.count("decodeStep"),
        "reportEq_in_tests": tests.count("reportEq"),
        "runtime_check_count": tests.count("cert."),
        "runtimeChecks_len": len(runtime_check_names),
    }

    decode = (SANDBOX / "lean/DefiKernel/Certificates/Decode.lean").read_text()
    m16_context = {
        "has_let_rest": "  let rest := j\n" in decode,
        "unsupported_site": '| "treeJoin" | "naryAdvance" => .error (.unsupportedForm _)',
        "unsupported_count": decode.count('| "treeJoin" | "naryAdvance" => .error (.unsupportedForm _)'),
        "decodeInvoke_def_present": "def decodeInvoke (j : Json)" in decode,
    }

    report = {
        "schema": "defiformal-p19-r2-mutation-static-reconciliation/v1",
        "utc": started,
        "disposition_marker": "DIAGNOSTIC_ONLY_NO_ACCEPTANCE",
        "archive_sha256": archive_sha,
        "inputs_json_candidate_archive_sha256": inputs["candidate_archive_sha256"],
        "archive_match": archive_sha == inputs["candidate_archive_sha256"] == "e0d89571f3783199aa1b8b250ef88c1577308654d7b3cd97a55053899a9a9b7e",
        "hash_checks": hash_checks,
        "hash_checks_ok": all(h["match_inputs"] and h["match_expected"] for h in hash_checks),
        "nineteen_checks": nineteen,
        "nineteen_distinct_from_54_fixtures": True,
        "control_fixture_stable": control_fixture_stable,
        "control_fixture_hashes": sorted(control_fixture_hashes),
        "git_heads": sorted(git_heads),
        "lean_versions": sorted(lean_versions),
        "script_hashes": sorted(script_hashes),
        "all_manifest_sources_equal": all_manifest_sources_equal,
        "source_identity_stable": source_identity_stable,
        "blob_checks": blob_checks,
        "blob_checks_ok": all(b["object_match"] and b["blob_match"] and b["bytes_match_clone_file"] for b in blob_checks),
        "invocations": invocations,
        "m16_context": m16_context,
        "rows": rows,
        "issue_count": len(issues),
        "issues": issues,
        "supported_count": sum(1 for r in rows if r["supported_as_historical_19check_discrimination"]),
        "terminal_worktree_recorded": terminal.get("worktree"),
        "completeness_disposition": completeness["disposition"],
        "not_acceptance": {
            "full54_fixture_campaign": False,
            "99_scenarios": False,
            "checker_accepted": False,
            "encoder_stub_known": True,
        },
    }
    (OUT / "probes/static-reconciliation.json").write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps({
        "supported_count": report["supported_count"],
        "issue_count": report["issue_count"],
        "hash_checks_ok": report["hash_checks_ok"],
        "blob_checks_ok": report["blob_checks_ok"],
        "control_fixture_stable": control_fixture_stable,
        "issues": issues,
        "unique_edits": {r["id"]: r["unique_edit"] for r in rows},
        "extra_false": {r["id"]: r["extra_false"] for r in rows if r["extra_false"]},
    }, indent=2))


if __name__ == "__main__":
    main()
