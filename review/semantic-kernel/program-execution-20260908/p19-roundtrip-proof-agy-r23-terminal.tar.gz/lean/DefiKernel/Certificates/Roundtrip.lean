import DefiKernel.Certificates.Correspondence

namespace DefiKernel.Certificates

set_option linter.style.longLine false

open Lean

/-! # Universal Roundtrip Module for P19 Typed/Sequential Certificates
    Provides TreeJson structural representations, encoding/toJson lemmas,
    and parser roundtrip proofs for all accepted certificate forms. -/

theorem toJsonList_map {α : Type} (f : α → TreeJson) (xs : List α) :
    TreeJson.toJsonList (xs.map f) = xs.map (fun x => (f x).toJson) := by
  induction xs with
  | nil => rfl
  | cons x xs ih =>
    dsimp [List.map, TreeJson.toJsonList]
    rw [ih]

theorem encodeList_map {α : Type} (f : α → TreeJson) (xs : List α) :
    TreeJson.encodeList (xs.map f) = String.intercalate "," (xs.map (fun x => (f x).encode)) := by
  rw [encodeList_eq_intercalate]
  simp only [List.map_map]
  rfl

theorem encode_arr_map {α : Type} (f : α → TreeJson) (xs : List α) :
    TreeJson.encode (.arr (xs.map f)) = jsonArr (xs.map (fun x => (f x).encode)) := by
  dsimp [TreeJson.encode, jsonArr]
  rw [encodeList_map]

theorem toJson_arr_map {α : Type} (f : α → TreeJson) (xs : List α) :
    (TreeJson.arr (xs.map f)).toJson = Lean.Json.arr (xs.map (fun x => (f x).toJson)).toArray := by
  dsimp [TreeJson.toJson]
  rw [toJsonList_map]

theorem validList_map {α : Type} (f : α → TreeJson) (xs : List α)
    (h : ∀ x ∈ xs, TreeJson.Valid (f x)) :
    TreeJson.ValidList (xs.map f) := by
  induction xs with
  | nil => trivial
  | cons x xs ih =>
    dsimp [List.map, TreeJson.ValidList]
    refine ⟨h x (List.Mem.head xs), ih (fun y hy => h y (List.Mem.tail x hy))⟩

theorem valid_arr_map {α : Type} (f : α → TreeJson) (xs : List α)
    (h_len : xs.length ≤ 4096)
    (h : ∀ x ∈ xs, TreeJson.Valid (f x)) :
    TreeJson.Valid (TreeJson.arr (xs.map f)) := by
  dsimp [TreeJson.Valid]
  rw [List.length_map]
  exact ⟨h_len, validList_map f xs h⟩

theorem encode_arr_str (xs : List String) :
    TreeJson.encode (.arr (xs.map TreeJson.str)) = jsonArr (xs.map escapeJsonString) := by
  rw [encode_arr_map]
  have h_eq : (xs.map (fun s => (TreeJson.str s).encode)) = xs.map escapeJsonString := by
    simp only [List.map_inj_left]
    intro s _
    exact escapeTreeString_eq_escapeJsonString s
  rw [h_eq]

theorem toJson_arr_str (xs : List String) :
    (TreeJson.arr (xs.map TreeJson.str)).toJson = Lean.Json.arr (xs.map Lean.Json.str).toArray := by
  rw [toJson_arr_map]
  rfl

theorem valid_arr_str (xs : List String) (h_len : xs.length ≤ 4096) :
    TreeJson.Valid (TreeJson.arr (xs.map TreeJson.str)) := by
  apply valid_arr_map
  · exact h_len
  · intro _ _; trivial

/-- Explicit Nat-to-TreeJson mapping avoiding ambiguous List coercions. -/
def natToTreeJson (n : Nat) : TreeJson := TreeJson.num (Int.ofNat n)

theorem natToTreeJson_encode (n : Nat) : (natToTreeJson n).encode = toString n := rfl

theorem natToTreeJson_toJson (n : Nat) : (natToTreeJson n).toJson = Json.num (JsonNumber.fromNat n) := rfl

theorem natToTreeJson_valid (n : Nat) : TreeJson.Valid (natToTreeJson n) := trivial

/-- Packed value unit-and-value object representation in TreeJson. -/
def packedValueFullToTreeJson (v : PackedValueEnc) : TreeJson :=
  TreeJson.obj [("unit", unitToTreeJson v.unit), ("value", packedValueToTreeJson v)]

theorem packedValueFullToTreeJson_toJson (v : PackedValueEnc) :
    (packedValueFullToTreeJson v).toJson = packedValueFullToJson v := by
  dsimp [packedValueFullToTreeJson, packedValueFullToJson, TreeJson.toJson, TreeJson.toJsonObj]
  rw [unitToTreeJson_toJson, packedValueToTreeJson_toJson]

theorem packedValueFullToTreeJson_encode (v : PackedValueEnc) :
    (packedValueFullToTreeJson v).encode = encodePackedValue v := by
  dsimp [packedValueFullToTreeJson, encodePackedValue]
  rw [encode_obj_eq_jsonObj]
  dsimp [List.map]
  rw [unitToTreeJson_encode]
  cases h : v.unit with
  | bool =>
    dsimp [packedValueToTreeJson]
    rw [h]
    dsimp
    cases v.valBool <;> rfl
  | numeric nu =>
    dsimp [packedValueToTreeJson]
    rw [h]
    dsimp
    rw [ratToTreeJson_encode]
    rfl

theorem packedValueFullToTreeJson_valid (v : PackedValueEnc) :
    TreeJson.Valid (packedValueFullToTreeJson v) := by
  dsimp [packedValueFullToTreeJson, TreeJson.Valid, TreeJson.ValidObj]
  simp only [List.map_cons, List.map_nil]
  refine ⟨by decide, unitToTreeJson_valid v.unit, ?_, trivial⟩
  cases h : v.unit with
  | bool =>
    dsimp [packedValueToTreeJson]
    rw [h]
    dsimp
    cases v.valBool <;> trivial
  | numeric nu =>
    dsimp [packedValueToTreeJson]
    rw [h]
    dsimp
    exact ratToTreeJson_valid ⟨v.valRat.num, v.valRat.den⟩

theorem map_encode_str_pairs (entries : List (String × String)) :
    (entries.map (fun (k, v) => (k, TreeJson.str v))).map (fun (k, v) => (k, TreeJson.encode v)) =
    entries.map (fun (k, v) => (k, escapeJsonString v)) := by
  induction entries with
  | nil => rfl
  | cons kv rest ih =>
    rcases kv with ⟨k, v⟩
    dsimp [List.map]
    have h_esc : (TreeJson.str v).encode = escapeJsonString v := escapeTreeString_eq_escapeJsonString v
    rw [h_esc, ih]

def sourceMapToTreeJson (entries : List (String × String)) : TreeJson :=
  TreeJson.obj (entries.map (fun (k, v) => (k, TreeJson.str v)))

theorem toJsonObj_map_str (entries : List (String × String)) :
    TreeJson.toJsonObj (entries.map (fun (k, v) => (k, TreeJson.str v))) =
    entries.map (fun (k, v) => (k, Lean.Json.str v)) := by
  induction entries with
  | nil => rfl
  | cons kv rest ih =>
    rcases kv with ⟨k, v⟩
    dsimp [List.map, TreeJson.toJsonObj, TreeJson.toJson]
    rw [ih]

theorem sourceMapToTreeJson_toJson (entries : List (String × String)) :
    (sourceMapToTreeJson entries).toJson = Lean.Json.mkObj (entries.map (fun (k, v) => (k, Lean.Json.str v))) := by
  dsimp [sourceMapToTreeJson, TreeJson.toJson]
  rw [toJsonObj_map_str]

theorem sourceMapToTreeJson_encode (entries : List (String × String)) (h_sm : SourceMapSorted entries) :
    (sourceMapToTreeJson entries).encode = encodeSourceMap entries := by
  dsimp [sourceMapToTreeJson, encodeSourceMap]
  rw [h_sm]
  dsimp
  rw [encode_obj_eq_jsonObj]
  rw [map_encode_str_pairs]

def stateCellToTreeJson (c : StateCellEnc) : TreeJson :=
  TreeJson.obj [
    ("domain", domainToTreeJson c.domain),
    ("party", partyToTreeJson c.party),
    ("asset", assetToTreeJson c.asset),
    ("amount", ratToTreeJson c.amount)
  ]

theorem stateCellToTreeJson_toJson (c : StateCellEnc) :
    (stateCellToTreeJson c).toJson = stateCellToJson c := by
  dsimp [stateCellToTreeJson, stateCellToJson, TreeJson.toJson, TreeJson.toJsonObj]
  rw [domainToTreeJson_toJson, partyToTreeJson_toJson, assetToTreeJson_toJson, ratToTreeJson_toJson]

theorem stateCellToTreeJson_encode (c : StateCellEnc) :
    (stateCellToTreeJson c).encode = encodeStateCell c := by
  dsimp [stateCellToTreeJson, encodeStateCell]
  rw [encode_obj_eq_jsonObj]
  dsimp [List.map]
  rw [domainToTreeJson_encode, partyToTreeJson_encode, assetToTreeJson_encode, ratToTreeJson_encode]

theorem stateCellToTreeJson_valid (c : StateCellEnc) :
    TreeJson.Valid (stateCellToTreeJson c) := by
  dsimp [stateCellToTreeJson, TreeJson.Valid, TreeJson.ValidObj]
  simp only [List.map_cons, List.map_nil]
  refine ⟨by decide, domainToTreeJson_valid c.domain, partyToTreeJson_valid c.party,
          assetToTreeJson_valid c.asset, ratToTreeJson_valid c.amount, trivial⟩

def cellToTreeJson (c : CellEnc) : TreeJson :=
  TreeJson.obj [
    ("domain", domainToTreeJson c.domain),
    ("party", partyToTreeJson c.party),
    ("asset", assetToTreeJson c.asset)
  ]

theorem cellToTreeJson_toJson (c : CellEnc) :
    (cellToTreeJson c).toJson = cellToJson c := by
  dsimp [cellToTreeJson, cellToJson, TreeJson.toJson, TreeJson.toJsonObj]
  rw [domainToTreeJson_toJson, partyToTreeJson_toJson, assetToTreeJson_toJson]

theorem cellToTreeJson_encode (c : CellEnc) :
    (cellToTreeJson c).encode = encodeCell c := by
  dsimp [cellToTreeJson, encodeCell]
  rw [encode_obj_eq_jsonObj]
  dsimp [List.map]
  rw [domainToTreeJson_encode, partyToTreeJson_encode, assetToTreeJson_encode]

theorem cellToTreeJson_valid (c : CellEnc) :
    TreeJson.Valid (cellToTreeJson c) := by
  dsimp [cellToTreeJson, TreeJson.Valid, TreeJson.ValidObj]
  simp only [List.map_cons, List.map_nil]
  refine ⟨by decide, domainToTreeJson_valid c.domain, partyToTreeJson_valid c.party,
          assetToTreeJson_valid c.asset, trivial⟩

def rightToTreeJson : RightEnc → TreeJson
  | .invoke => TreeJson.obj [("tag", TreeJson.str "invoke")]
  | .debit c => TreeJson.obj [("tag", TreeJson.str "debit"), ("cell", cellToTreeJson c)]
  | .changeSupply d a =>
    TreeJson.obj [
      ("tag", TreeJson.str "changeSupply"),
      ("domain", domainToTreeJson d),
      ("asset", assetToTreeJson a)
    ]

theorem rightToTreeJson_toJson (r : RightEnc) :
    (rightToTreeJson r).toJson = rightToJson r := by
  cases r with
  | invoke => rfl
  | debit c =>
    dsimp [rightToTreeJson, rightToJson, TreeJson.toJson, TreeJson.toJsonObj]
    rw [cellToTreeJson_toJson]
  | changeSupply d a =>
    dsimp [rightToTreeJson, rightToJson, TreeJson.toJson, TreeJson.toJsonObj]
    rw [domainToTreeJson_toJson, assetToTreeJson_toJson]

theorem rightToTreeJson_encode (r : RightEnc) :
    (rightToTreeJson r).encode = encodeRight r := by
  cases r with
  | invoke => rfl
  | debit c =>
    dsimp [rightToTreeJson, encodeRight]
    rw [encode_obj_eq_jsonObj]
    dsimp [List.map]
    rw [cellToTreeJson_encode]
    rfl
  | changeSupply d a =>
    dsimp [rightToTreeJson, encodeRight]
    rw [encode_obj_eq_jsonObj]
    dsimp [List.map]
    rw [domainToTreeJson_encode, assetToTreeJson_encode]
    rfl

theorem rightToTreeJson_valid (r : RightEnc) :
    TreeJson.Valid (rightToTreeJson r) := by
  cases r with
  | invoke =>
    dsimp [rightToTreeJson, TreeJson.Valid, TreeJson.ValidObj]
    simp only [List.map_cons, List.map_nil]
    refine ⟨by decide, trivial, trivial⟩
  | debit c =>
    dsimp [rightToTreeJson, TreeJson.Valid, TreeJson.ValidObj]
    simp only [List.map_cons, List.map_nil]
    refine ⟨by decide, trivial, cellToTreeJson_valid c, trivial⟩
  | changeSupply d a =>
    dsimp [rightToTreeJson, TreeJson.Valid, TreeJson.ValidObj]
    simp only [List.map_cons, List.map_nil]
    refine ⟨by decide, trivial, domainToTreeJson_valid d, assetToTreeJson_valid a, trivial⟩

def grantToTreeJson (g : GrantEnc) : TreeJson :=
  TreeJson.obj [
    ("holder", partyToTreeJson g.holder),
    ("domain", domainToTreeJson g.domain),
    ("operation", natToTreeJson g.operation),
    ("right", rightToTreeJson g.right)
  ]

theorem grantToTreeJson_toJson (g : GrantEnc) :
    (grantToTreeJson g).toJson = grantToJson g := by
  dsimp [grantToTreeJson, grantToJson, TreeJson.toJson, TreeJson.toJsonObj]
  rw [partyToTreeJson_toJson, domainToTreeJson_toJson, rightToTreeJson_toJson]
  rfl

theorem grantToTreeJson_encode (g : GrantEnc) :
    (grantToTreeJson g).encode = encodeGrant g := by
  dsimp [grantToTreeJson, encodeGrant]
  rw [encode_obj_eq_jsonObj]
  dsimp [List.map]
  rw [partyToTreeJson_encode, domainToTreeJson_encode, rightToTreeJson_encode, natToTreeJson_encode]

theorem grantToTreeJson_valid (g : GrantEnc) :
    TreeJson.Valid (grantToTreeJson g) := by
  dsimp [grantToTreeJson, TreeJson.Valid, TreeJson.ValidObj]
  simp only [List.map_cons, List.map_nil]
  refine ⟨by decide, partyToTreeJson_valid g.holder, domainToTreeJson_valid g.domain,
          trivial, rightToTreeJson_valid g.right, trivial⟩

def capabilityToTreeJson (c : CapabilityEnc) : TreeJson :=
  TreeJson.obj [
    ("holder", partyToTreeJson c.holder),
    ("domain", domainToTreeJson c.domain),
    ("operation", natToTreeJson c.operation),
    ("right", rightToTreeJson c.right),
    ("live", TreeJson.bool c.live)
  ]

theorem capabilityToTreeJson_toJson (c : CapabilityEnc) :
    (capabilityToTreeJson c).toJson = capabilityToJson c := by
  dsimp [capabilityToTreeJson, capabilityToJson, TreeJson.toJson, TreeJson.toJsonObj]
  rw [partyToTreeJson_toJson, domainToTreeJson_toJson, rightToTreeJson_toJson]
  rfl

theorem capabilityToTreeJson_encode (c : CapabilityEnc) :
    (capabilityToTreeJson c).encode = encodeCapability c := by
  dsimp [capabilityToTreeJson, encodeCapability]
  rw [encode_obj_eq_jsonObj]
  dsimp [List.map]
  rw [partyToTreeJson_encode, domainToTreeJson_encode, rightToTreeJson_encode, natToTreeJson_encode]
  cases c.live <;> rfl

theorem capabilityToTreeJson_valid (c : CapabilityEnc) :
    TreeJson.Valid (capabilityToTreeJson c) := by
  dsimp [capabilityToTreeJson, TreeJson.Valid, TreeJson.ValidObj]
  simp only [List.map_cons, List.map_nil]
  refine ⟨by decide, partyToTreeJson_valid c.holder, domainToTreeJson_valid c.domain,
          trivial, rightToTreeJson_valid c.right, trivial, trivial⟩

def storeToTreeJson (s : StoreEnc) : TreeJson :=
  TreeJson.obj [("entries", TreeJson.arr (s.entries.map capabilityToTreeJson))]

theorem storeToTreeJson_toJson (s : StoreEnc) :
    (storeToTreeJson s).toJson = storeToJson s := by
  dsimp [storeToTreeJson, storeToJson, TreeJson.toJson, TreeJson.toJsonObj]
  rw [toJsonList_map]
  have h_map : (s.entries.map (fun x => (capabilityToTreeJson x).toJson)) = s.entries.map capabilityToJson := by
    simp only [List.map_inj_left]; intro c _; exact capabilityToTreeJson_toJson c
  rw [h_map]

theorem storeToTreeJson_encode (s : StoreEnc) :
    (storeToTreeJson s).encode = encodeStore s := by
  dsimp [storeToTreeJson, encodeStore]
  rw [encode_obj_eq_jsonObj]
  dsimp [List.map]
  rw [encode_arr_map]
  have h_map : (s.entries.map (fun x => (capabilityToTreeJson x).encode)) = s.entries.map encodeCapability := by
    simp only [List.map_inj_left]; intro c _; exact capabilityToTreeJson_encode c
  rw [h_map]

theorem storeToTreeJson_valid (s : StoreEnc) (h_len : s.entries.length ≤ 4096) :
    TreeJson.Valid (storeToTreeJson s) := by
  dsimp [storeToTreeJson, TreeJson.Valid, TreeJson.ValidObj]
  simp only [List.map_cons, List.map_nil]
  refine ⟨by decide, valid_arr_map capabilityToTreeJson s.entries h_len (fun c _ => capabilityToTreeJson_valid c), trivial⟩

def stateToTreeJson (s : StateEnc) : TreeJson :=
  TreeJson.obj [("cells", TreeJson.arr (s.cells.map stateCellToTreeJson))]

theorem stateToTreeJson_toJson (s : StateEnc) :
    (stateToTreeJson s).toJson = stateToJson s := by
  dsimp [stateToTreeJson, stateToJson, TreeJson.toJson, TreeJson.toJsonObj]
  rw [toJsonList_map]
  have h_map : (s.cells.map (fun x => (stateCellToTreeJson x).toJson)) = s.cells.map stateCellToJson := by
    simp only [List.map_inj_left]; intro c _; exact stateCellToTreeJson_toJson c
  rw [h_map]

theorem stateToTreeJson_encode (s : StateEnc) :
    (stateToTreeJson s).encode = encodeState s := by
  dsimp [stateToTreeJson, encodeState]
  rw [encode_obj_eq_jsonObj]
  dsimp [List.map]
  rw [encode_arr_map]
  have h_map : (s.cells.map (fun x => (stateCellToTreeJson x).encode)) = s.cells.map encodeStateCell := by
    simp only [List.map_inj_left]; intro c _; exact stateCellToTreeJson_encode c
  rw [h_map]

theorem stateToTreeJson_valid (s : StateEnc) (h_len : s.cells.length ≤ 4096) :
    TreeJson.Valid (stateToTreeJson s) := by
  dsimp [stateToTreeJson, TreeJson.Valid, TreeJson.ValidObj]
  simp only [List.map_cons, List.map_nil]
  refine ⟨by decide, valid_arr_map stateCellToTreeJson s.cells h_len (fun c _ => stateCellToTreeJson_valid c), trivial⟩

def contextToTreeJson (ctx : ContextEnc) : TreeJson :=
  TreeJson.obj [
    ("principal", partyToTreeJson ctx.principal),
    ("domain", domainToTreeJson ctx.domain)
  ]

theorem contextToTreeJson_toJson (ctx : ContextEnc) :
    (contextToTreeJson ctx).toJson = contextToJson ctx := by
  dsimp [contextToTreeJson, contextToJson, TreeJson.toJson, TreeJson.toJsonObj]
  rw [partyToTreeJson_toJson, domainToTreeJson_toJson]

theorem contextToTreeJson_encode (ctx : ContextEnc) :
    (contextToTreeJson ctx).encode = encodeContext ctx := by
  dsimp [contextToTreeJson, encodeContext]
  rw [encode_obj_eq_jsonObj]
  dsimp [List.map]
  rw [partyToTreeJson_encode, domainToTreeJson_encode]

theorem contextToTreeJson_valid (ctx : ContextEnc) :
    TreeJson.Valid (contextToTreeJson ctx) := by
  dsimp [contextToTreeJson, TreeJson.Valid, TreeJson.ValidObj]
  simp only [List.map_cons, List.map_nil]
  refine ⟨by decide, partyToTreeJson_valid ctx.principal, domainToTreeJson_valid ctx.domain, trivial⟩

def observationToTreeJson (o : ObservationEnc) : TreeJson :=
  TreeJson.obj [
    ("value", packedValueFullToTreeJson o.value),
    ("timestamp", natToTreeJson o.timestamp)
  ]

theorem observationToTreeJson_toJson (o : ObservationEnc) :
    (observationToTreeJson o).toJson = observationToJson o := by
  dsimp [observationToTreeJson, observationToJson, TreeJson.toJson, TreeJson.toJsonObj]
  rw [packedValueFullToTreeJson_toJson, natToTreeJson_toJson]

theorem observationToTreeJson_encode (o : ObservationEnc) :
    (observationToTreeJson o).encode = encodeObservation o := by
  dsimp [observationToTreeJson, encodeObservation]
  rw [encode_obj_eq_jsonObj]
  dsimp [List.map]
  rw [packedValueFullToTreeJson_encode, natToTreeJson_encode]


theorem observationToTreeJson_valid (o : ObservationEnc) :
    TreeJson.Valid (observationToTreeJson o) := by
  dsimp [observationToTreeJson, TreeJson.Valid, TreeJson.ValidObj]
  simp only [List.map_cons, List.map_nil]
  refine ⟨by decide, packedValueFullToTreeJson_valid o.value, trivial, trivial⟩

def environmentEntryToTreeJson (e : EnvironmentEntryEnc) : TreeJson :=
  TreeJson.obj [
    ("key", observationKeyToTreeJson e.key),
    ("observation", observationToTreeJson e.observation)
  ]

theorem environmentEntryToTreeJson_toJson (e : EnvironmentEntryEnc) :
    (environmentEntryToTreeJson e).toJson = environmentEntryToJson e := by
  dsimp [environmentEntryToTreeJson, environmentEntryToJson, TreeJson.toJson, TreeJson.toJsonObj]
  rw [observationKeyToTreeJson_toJson, observationToTreeJson_toJson]

theorem environmentEntryToTreeJson_encode (e : EnvironmentEntryEnc) :
    (environmentEntryToTreeJson e).encode = encodeEnvironmentEntry e := by
  dsimp [environmentEntryToTreeJson, encodeEnvironmentEntry]
  rw [encode_obj_eq_jsonObj]
  dsimp [List.map]
  rw [observationKeyToTreeJson_encode, observationToTreeJson_encode]

theorem environmentEntryToTreeJson_valid (e : EnvironmentEntryEnc) :
    TreeJson.Valid (environmentEntryToTreeJson e) := by
  dsimp [environmentEntryToTreeJson, TreeJson.Valid, TreeJson.ValidObj]
  simp only [List.map_cons, List.map_nil]
  refine ⟨by decide, observationKeyToTreeJson_valid e.key, observationToTreeJson_valid e.observation, trivial⟩

def environmentToTreeJson (env : EnvironmentEnc) : TreeJson :=
  TreeJson.obj [("entries", TreeJson.arr (env.entries.map environmentEntryToTreeJson))]

theorem environmentToTreeJson_toJson (env : EnvironmentEnc) :
    (environmentToTreeJson env).toJson = environmentToJson env := by
  dsimp [environmentToTreeJson, environmentToJson, TreeJson.toJson, TreeJson.toJsonObj]
  rw [toJsonList_map]
  have h_map : (env.entries.map (fun x => (environmentEntryToTreeJson x).toJson)) = env.entries.map environmentEntryToJson := by
    simp only [List.map_inj_left]; intro e _; exact environmentEntryToTreeJson_toJson e
  rw [h_map]

theorem environmentToTreeJson_encode (env : EnvironmentEnc) :
    (environmentToTreeJson env).encode = encodeEnvironment env := by
  dsimp [environmentToTreeJson, encodeEnvironment]
  rw [encode_obj_eq_jsonObj]
  dsimp [List.map]
  rw [encode_arr_map]
  have h_map : (env.entries.map (fun x => (environmentEntryToTreeJson x).encode)) = env.entries.map encodeEnvironmentEntry := by
    simp only [List.map_inj_left]; intro e _; exact environmentEntryToTreeJson_encode e
  rw [h_map]

theorem environmentToTreeJson_valid (env : EnvironmentEnc) (h_len : env.entries.length ≤ 4096) :
    TreeJson.Valid (environmentToTreeJson env) := by
  dsimp [environmentToTreeJson, TreeJson.Valid, TreeJson.ValidObj]
  simp only [List.map_cons, List.map_nil]
  refine ⟨by decide, valid_arr_map environmentEntryToTreeJson env.entries h_len (fun e _ => environmentEntryToTreeJson_valid e), trivial⟩

def requestToTreeJson (r : RequestEnc) : TreeJson :=
  TreeJson.obj [
    ("operation", natToTreeJson r.operation),
    ("parties", TreeJson.arr (r.parties.map partyToTreeJson)),
    ("arguments", TreeJson.arr (r.arguments.map packedValueFullToTreeJson)),
    ("capabilityIds", TreeJson.arr (r.capabilityIds.map natToTreeJson)),
    ("claimedActor", match r.claimedActor with | some a => partyToTreeJson a | none => TreeJson.null)
  ]

theorem requestToTreeJson_encode (r : RequestEnc) :
    (requestToTreeJson r).encode = encodeRequest r := by
  dsimp [requestToTreeJson, encodeRequest]
  rw [encode_obj_eq_jsonObj]
  dsimp [List.map]
  rw [encode_arr_map, encode_arr_map, encode_arr_map]
  have h_ps : (r.parties.map (fun x => (partyToTreeJson x).encode)) = r.parties.map encodeParty := by
    simp only [List.map_inj_left]; intro p _; exact partyToTreeJson_encode p
  have h_args : (r.arguments.map (fun x => (packedValueFullToTreeJson x).encode)) = r.arguments.map encodePackedValue := by
    simp only [List.map_inj_left]; intro v _; exact packedValueFullToTreeJson_encode v
  have h_caps : (r.capabilityIds.map (fun x => (natToTreeJson x).encode)) = r.capabilityIds.map toString := by
    simp only [List.map_inj_left]; intro x _; exact natToTreeJson_encode x
  rw [h_ps, h_args, h_caps, natToTreeJson_encode]
  cases r.claimedActor with
  | none => rfl
  | some a =>
    dsimp
    rw [partyToTreeJson_encode]

theorem decodeRequest_requestToTreeJson (r : RequestEnc) (h_can : RequestCanonical r) :
    decodeRequest (requestToTreeJson r).toJson = .ok r := by
  cases r with | mk op parties args caps actor =>
  dsimp [requestToTreeJson, TreeJson.toJson, TreeJson.toJsonObj]
  rw [toJsonList_map, toJsonList_map, toJsonList_map]
  have h_ps : (parties.map (fun x => (partyToTreeJson x).toJson)) = parties.map partyToJson := by
    simp only [List.map_inj_left]; intro p _; exact partyToTreeJson_toJson p
  have h_args : (args.map (fun x => (packedValueFullToTreeJson x).toJson)) = args.map packedValueFullToJson := by
    simp only [List.map_inj_left]; intro v _; exact packedValueFullToTreeJson_toJson v
  have h_caps : (caps.map (fun x => (natToTreeJson x).toJson)) = caps.map natToJson := by
    simp only [List.map_inj_left]; intro c _; exact natToTreeJson_toJson c
  rw [h_ps, h_args, h_caps, natToTreeJson_toJson]
  cases actor with
  | none =>
    simp only [TreeJson.toJson]
    have h_order : decodeRequest (Json.mkObj [
        ("operation", Json.num (JsonNumber.fromNat op)),
        ("parties", Json.arr (parties.map partyToJson).toArray),
        ("arguments", Json.arr (args.map packedValueFullToJson).toArray),
        ("capabilityIds", Json.arr (caps.map natToJson).toArray),
        ("claimedActor", Json.null)]) =
      decodeRequest (Json.mkObj [
        ("arguments", Json.arr (args.map packedValueFullToJson).toArray),
        ("capabilityIds", Json.arr (caps.map natToJson).toArray),
        ("claimedActor", Json.null),
        ("operation", Json.num (JsonNumber.fromNat op)),
        ("parties", Json.arr (parties.map partyToJson).toArray)]) := by rfl
    rw [h_order]
    have h_req : decodeRequest (requestToJson ⟨op, parties, args, caps, none⟩) = .ok ⟨op, parties, args, caps, none⟩ :=
      decodeRequest_requestToJson ⟨op, parties, args, caps, none⟩ h_can
    exact h_req
  | some a =>
    have h_a : (partyToTreeJson a).toJson = partyToJson a := partyToTreeJson_toJson a
    dsimp
    rw [h_a]
    have h_order : decodeRequest (Json.mkObj [
        ("operation", Json.num (JsonNumber.fromNat op)),
        ("parties", Json.arr (parties.map partyToJson).toArray),
        ("arguments", Json.arr (args.map packedValueFullToJson).toArray),
        ("capabilityIds", Json.arr (caps.map natToJson).toArray),
        ("claimedActor", partyToJson a)]) =
      decodeRequest (Json.mkObj [
        ("arguments", Json.arr (args.map packedValueFullToJson).toArray),
        ("capabilityIds", Json.arr (caps.map natToJson).toArray),
        ("claimedActor", partyToJson a),
        ("operation", Json.num (JsonNumber.fromNat op)),
        ("parties", Json.arr (parties.map partyToJson).toArray)]) := by rfl
    rw [h_order]
    have h_req : decodeRequest (requestToJson ⟨op, parties, args, caps, some a⟩) = .ok ⟨op, parties, args, caps, some a⟩ :=
      decodeRequest_requestToJson ⟨op, parties, args, caps, some a⟩ h_can
    exact h_req

theorem requestToTreeJson_valid (r : RequestEnc)
    (h_ps : r.parties.length ≤ 4096)
    (h_args : r.arguments.length ≤ 4096)
    (h_caps : r.capabilityIds.length ≤ 4096) :
    TreeJson.Valid (requestToTreeJson r) := by
  dsimp [requestToTreeJson, TreeJson.Valid, TreeJson.ValidObj]
  simp only [List.map_cons, List.map_nil]
  refine ⟨by decide, trivial,
          valid_arr_map partyToTreeJson r.parties h_ps (fun p _ => partyToTreeJson_valid p),
          valid_arr_map packedValueFullToTreeJson r.arguments h_args (fun v _ => packedValueFullToTreeJson_valid v),
          valid_arr_map natToTreeJson r.capabilityIds h_caps (fun _ _ => trivial),
          ?_, trivial⟩
  cases r.claimedActor with
  | none => trivial
  | some a => exact partyToTreeJson_valid a

def sourcePinToTreeJson (pin : SourcePinEnc) : TreeJson :=
  TreeJson.obj [
    ("git", TreeJson.str pin.git),
    ("lean_toolchain", TreeJson.str pin.lean_toolchain),
    ("mathlib_rev", TreeJson.str pin.mathlib_rev),
    ("checker_candidate", TreeJson.str pin.checker_candidate),
    ("compiler_record", match pin.compiler_record with | some r => TreeJson.str r | none => TreeJson.null),
    ("audit_record", match pin.audit_record with | some r => TreeJson.str r | none => TreeJson.null)
  ]

theorem sourcePinToTreeJson_toJson (pin : SourcePinEnc) :
    (sourcePinToTreeJson pin).toJson = sourcePinToJson pin := by
  dsimp [sourcePinToTreeJson, sourcePinToJson, TreeJson.toJson, TreeJson.toJsonObj]
  cases pin.compiler_record <;> cases pin.audit_record <;> rfl

theorem sourcePinToTreeJson_encode (pin : SourcePinEnc) :
    (sourcePinToTreeJson pin).encode = encodeSourcePin pin := by
  dsimp [sourcePinToTreeJson, encodeSourcePin]
  rw [encode_obj_eq_jsonObj]
  dsimp [List.map, TreeJson.encode]
  have h_git : escapeTreeString pin.git = escapeJsonString pin.git := escapeTreeString_eq_escapeJsonString pin.git
  have h_tc : escapeTreeString pin.lean_toolchain = escapeJsonString pin.lean_toolchain := escapeTreeString_eq_escapeJsonString pin.lean_toolchain
  have h_ml : escapeTreeString pin.mathlib_rev = escapeJsonString pin.mathlib_rev := escapeTreeString_eq_escapeJsonString pin.mathlib_rev
  have h_cc : escapeTreeString pin.checker_candidate = escapeJsonString pin.checker_candidate := escapeTreeString_eq_escapeJsonString pin.checker_candidate
  rw [h_git, h_tc, h_ml, h_cc]
  cases pin.compiler_record <;> cases pin.audit_record <;> dsimp [TreeJson.encode] <;> try rw [escapeTreeString_eq_escapeJsonString] <;> rfl

theorem sourcePinToTreeJson_valid (pin : SourcePinEnc) :
    TreeJson.Valid (sourcePinToTreeJson pin) := by
  dsimp [sourcePinToTreeJson, TreeJson.Valid, TreeJson.ValidObj]
  simp only [List.map_cons, List.map_nil]
  refine ⟨by decide, trivial, trivial, trivial, trivial, ?_, ?_, trivial⟩
  · cases pin.compiler_record <;> trivial
  · cases pin.audit_record <;> trivial

def typesEnumToTreeJson (t : TypesEnumEnc) : TreeJson :=
  TreeJson.obj [
    ("parties", TreeJson.arr (t.parties.map partyToTreeJson)),
    ("assets", TreeJson.arr (t.assets.map assetToTreeJson)),
    ("domains", TreeJson.arr (t.domains.map domainToTreeJson))
  ]

theorem typesEnumToTreeJson_toJson (t : TypesEnumEnc) :
    (typesEnumToTreeJson t).toJson = typesEnumToJson t := by
  dsimp [typesEnumToTreeJson, typesEnumToJson, TreeJson.toJson, TreeJson.toJsonObj]
  rw [toJsonList_map, toJsonList_map, toJsonList_map]
  have h_ps : (t.parties.map (fun x => (partyToTreeJson x).toJson)) = t.parties.map partyToJson := by
    simp only [List.map_inj_left]; intro p _; exact partyToTreeJson_toJson p
  have h_as : (t.assets.map (fun x => (assetToTreeJson x).toJson)) = t.assets.map assetToJson := by
    simp only [List.map_inj_left]; intro a _; exact assetToTreeJson_toJson a
  have h_ds : (t.domains.map (fun x => (domainToTreeJson x).toJson)) = t.domains.map domainToJson := by
    simp only [List.map_inj_left]; intro d _; exact domainToTreeJson_toJson d
  rw [h_ps, h_as, h_ds]

theorem typesEnumToTreeJson_encode (t : TypesEnumEnc) :
    (typesEnumToTreeJson t).encode = encodeTypesEnum t := by
  dsimp [typesEnumToTreeJson, encodeTypesEnum]
  rw [encode_obj_eq_jsonObj]
  dsimp [List.map]
  rw [encode_arr_map, encode_arr_map, encode_arr_map]
  have h_ps : (t.parties.map (fun x => (partyToTreeJson x).encode)) = t.parties.map encodeParty := by
    simp only [List.map_inj_left]; intro p _; exact partyToTreeJson_encode p
  have h_as : (t.assets.map (fun x => (assetToTreeJson x).encode)) = t.assets.map encodeAsset := by
    simp only [List.map_inj_left]; intro a _; exact assetToTreeJson_encode a
  have h_ds : (t.domains.map (fun x => (domainToTreeJson x).encode)) = t.domains.map encodeDomain := by
    simp only [List.map_inj_left]; intro d _; exact domainToTreeJson_encode d
  rw [h_ps, h_as, h_ds]

theorem typesEnumToTreeJson_valid (t : TypesEnumEnc)
    (h_ps : t.parties.length ≤ 4096)
    (h_as : t.assets.length ≤ 4096)
    (h_ds : t.domains.length ≤ 4096) :
    TreeJson.Valid (typesEnumToTreeJson t) := by
  dsimp [typesEnumToTreeJson, TreeJson.Valid, TreeJson.ValidObj]
  simp only [List.map_cons, List.map_nil]
  refine ⟨by decide,
          valid_arr_map partyToTreeJson t.parties h_ps (fun p _ => partyToTreeJson_valid p),
          valid_arr_map assetToTreeJson t.assets h_as (fun a _ => assetToTreeJson_valid a),
          valid_arr_map domainToTreeJson t.domains h_ds (fun d _ => domainToTreeJson_valid d),
          trivial⟩

def libraryRefToTreeJson (lib : LibraryRefEnc) : TreeJson :=
  match lib.moduleName with
  | some m => TreeJson.obj [("theorem", TreeJson.str lib.theoremName), ("module", TreeJson.str m)]
  | none => TreeJson.obj [("theorem", TreeJson.str lib.theoremName)]

theorem libraryRefToTreeJson_encode (lib : LibraryRefEnc) :
    (libraryRefToTreeJson lib).encode = encodeLibraryRef lib := by
  dsimp [libraryRefToTreeJson, encodeLibraryRef]
  cases h : lib.moduleName with
  | none =>
    rw [encode_obj_eq_jsonObj]
    dsimp [List.map, TreeJson.encode]
    rw [escapeTreeString_eq_escapeJsonString]
  | some m =>
    rw [encode_obj_eq_jsonObj]
    dsimp [List.map, TreeJson.encode]
    rw [escapeTreeString_eq_escapeJsonString, escapeTreeString_eq_escapeJsonString]

theorem libraryRefToTreeJson_valid (lib : LibraryRefEnc) :
    TreeJson.Valid (libraryRefToTreeJson lib) := by
  dsimp [libraryRefToTreeJson]
  cases lib.moduleName with
  | none =>
    dsimp [TreeJson.Valid, TreeJson.ValidObj]
    simp only [List.map_cons, List.map_nil]
    refine ⟨by decide, trivial, trivial⟩
  | some m =>
    dsimp [TreeJson.Valid, TreeJson.ValidObj]
    simp only [List.map_cons, List.map_nil]
    refine ⟨by decide, trivial, trivial, trivial⟩

def worldToTreeJson (w : WorldEnc) : TreeJson :=
  TreeJson.obj [("state", stateToTreeJson w.state), ("capabilities", storeToTreeJson w.capabilities)]

theorem worldToTreeJson_encode (w : WorldEnc) :
    (worldToTreeJson w).encode = encodeWorld w := by
  dsimp [worldToTreeJson, encodeWorld]
  rw [encode_obj_eq_jsonObj]
  dsimp [List.map]
  rw [stateToTreeJson_encode, storeToTreeJson_encode]

def boundaryToTreeJson (b : BoundaryEnc) : TreeJson :=
  TreeJson.obj [("ctx", contextToTreeJson b.ctx), ("env", environmentToTreeJson b.env), ("now", natToTreeJson b.now)]

theorem boundaryToTreeJson_encode (b : BoundaryEnc) :
    (boundaryToTreeJson b).encode = encodeBoundary b := by
  dsimp [boundaryToTreeJson, encodeBoundary]
  rw [encode_obj_eq_jsonObj]
  dsimp [List.map]
  rw [contextToTreeJson_encode, environmentToTreeJson_encode, natToTreeJson_encode]

def envelopeToTreeJson (env : EnvelopeEnc) (payload : TreeJson) : TreeJson :=
  TreeJson.obj [
    ("schema_version", natToTreeJson env.schema_version),
    ("mode", TreeJson.str env.mode),
    ("source_pin", sourcePinToTreeJson env.source_pin),
    ("audit_roots", TreeJson.arr (env.audit_roots.map TreeJson.str)),
    ("types", typesEnumToTreeJson env.types),
    ("assumptions", TreeJson.arr (env.assumptions.map TreeJson.str)),
    ("invariants", TreeJson.arr (env.invariants.map TreeJson.str)),
    ("libraries", TreeJson.arr (env.libraries.map libraryRefToTreeJson)),
    ("source_map", sourceMapToTreeJson env.source_map),
    ("payload", payload),
    ("claimed_judgments", TreeJson.arr (env.claimed_judgments.map TreeJson.str)),
    ("claimed_next_state", match env.claimed_next_state with | some w => worldToTreeJson w | none => TreeJson.null),
    ("require_library_discharge", TreeJson.bool env.require_library_discharge),
    ("require_invariant_discharge", TreeJson.bool env.require_invariant_discharge)
  ]

theorem envelopeToTreeJson_encode (env : EnvelopeEnc) (payload : TreeJson)
    (h_sm : SourceMapSorted env.source_map) :
    (envelopeToTreeJson env payload).encode = encodeEnvelope env payload.encode := by
  dsimp [envelopeToTreeJson, encodeEnvelope]
  rw [encode_obj_eq_jsonObj]
  dsimp [List.map]
  rw [encode_arr_str, encode_arr_str, encode_arr_str, encode_arr_str, encode_arr_map]
  have h_libs : (env.libraries.map (fun x => (libraryRefToTreeJson x).encode)) = env.libraries.map encodeLibraryRef := by
    simp only [List.map_inj_left]; intro lib _; exact libraryRefToTreeJson_encode lib
  rw [h_libs]
  rw [sourceMapToTreeJson_encode env.source_map h_sm]
  rw [sourcePinToTreeJson_encode, typesEnumToTreeJson_encode, natToTreeJson_encode]
  have h_mode : (TreeJson.str env.mode).encode = escapeJsonString env.mode := escapeTreeString_eq_escapeJsonString env.mode
  rw [h_mode]
  cases env.claimed_next_state with
  | none =>
    cases env.require_library_discharge <;> cases env.require_invariant_discharge <;> rfl
  | some w =>
    rw [worldToTreeJson_encode]
    cases env.require_library_discharge <;> cases env.require_invariant_discharge <;> rfl

def cellDeltaToTreeJson (d : CellDeltaEnc) : TreeJson :=
  TreeJson.obj [
    ("asset", assetToTreeJson d.asset),
    ("target", cellRefToTreeJson d.target),
    ("amount", exprToTreeJson d.amount)
  ]

theorem cellDeltaToTreeJson_encode (d : CellDeltaEnc) :
    (cellDeltaToTreeJson d).encode = encodeCellDelta d := by
  dsimp [cellDeltaToTreeJson, encodeCellDelta]
  rw [encode_obj_eq_jsonObj]
  dsimp [List.map]
  rw [assetToTreeJson_encode, cellRefToTreeJson_encode, exprToTreeJson_encode]

theorem cellDeltaToTreeJson_valid (d : CellDeltaEnc) :
    TreeJson.Valid (cellDeltaToTreeJson d) := by
  dsimp [cellDeltaToTreeJson, TreeJson.Valid, TreeJson.ValidObj]
  simp only [List.map_cons, List.map_nil]
  refine ⟨by decide, assetToTreeJson_valid d.asset, cellRefToTreeJson_valid d.target, exprToTreeJson_valid d.amount, trivial⟩

def supplyDeltaToTreeJson (d : SupplyDeltaEnc) : TreeJson :=
  TreeJson.obj [
    ("domain", domainToTreeJson d.domain),
    ("asset", assetToTreeJson d.asset),
    ("amount", exprToTreeJson d.amount)
  ]

theorem supplyDeltaToTreeJson_encode (d : SupplyDeltaEnc) :
    (supplyDeltaToTreeJson d).encode = encodeSupplyDelta d := by
  dsimp [supplyDeltaToTreeJson, encodeSupplyDelta]
  rw [encode_obj_eq_jsonObj]
  dsimp [List.map]
  rw [domainToTreeJson_encode, assetToTreeJson_encode, exprToTreeJson_encode]

theorem supplyDeltaToTreeJson_valid (d : SupplyDeltaEnc) :
    TreeJson.Valid (supplyDeltaToTreeJson d) := by
  dsimp [supplyDeltaToTreeJson, TreeJson.Valid, TreeJson.ValidObj]
  simp only [List.map_cons, List.map_nil]
  refine ⟨by decide, domainToTreeJson_valid d.domain, assetToTreeJson_valid d.asset, exprToTreeJson_valid d.amount, trivial⟩

def envReadToTreeJson : EnvReadEnc → TreeJson
  | .observation k => TreeJson.obj [("tag", TreeJson.str "observation"), ("key", observationKeyToTreeJson k)]
  | .currentTime => TreeJson.obj [("tag", TreeJson.str "currentTime")]

theorem envReadToTreeJson_encode (e : EnvReadEnc) :
    (envReadToTreeJson e).encode = encodeEnvRead e := by
  cases e with
  | observation k =>
    dsimp [envReadToTreeJson, encodeEnvRead]
    rw [encode_obj_eq_jsonObj]
    dsimp [List.map, TreeJson.encode]
    rw [observationKeyToTreeJson_encode]
    rfl
  | currentTime => rfl

theorem envReadToTreeJson_valid (e : EnvReadEnc) :
    TreeJson.Valid (envReadToTreeJson e) := by
  cases e with
  | observation k =>
    dsimp [envReadToTreeJson, TreeJson.Valid, TreeJson.ValidObj]
    simp only [List.map_cons, List.map_nil]
    refine ⟨by decide, trivial, observationKeyToTreeJson_valid k, trivial⟩
  | currentTime =>
    dsimp [envReadToTreeJson, TreeJson.Valid, TreeJson.ValidObj]
    simp only [List.map_cons, List.map_nil]
    refine ⟨by decide, trivial, trivial⟩

def templateToTreeJson (t : TemplateEnc) : TreeJson :=
  TreeJson.obj [
    ("signature", TreeJson.arr (t.signature.map unitToTreeJson)),
    ("domain", domainToTreeJson t.domain),
    ("partyArity", natToTreeJson t.partyArity),
    ("guard", exprToTreeJson t.guard),
    ("deltas", TreeJson.arr (t.deltas.map cellDeltaToTreeJson)),
    ("supplyDeltas", TreeJson.arr (t.supplyDeltas.map supplyDeltaToTreeJson)),
    ("stateReads", TreeJson.arr (t.stateReads.map packedCellRefToTreeJson)),
    ("envReads", TreeJson.arr (t.envReads.map envReadToTreeJson)),
    ("writes", TreeJson.arr (t.writes.map packedCellRefToTreeJson))
  ]

theorem templateToTreeJson_encode (t : TemplateEnc) :
    (templateToTreeJson t).encode = encodeTemplate t := by
  dsimp [templateToTreeJson, encodeTemplate]
  rw [encode_obj_eq_jsonObj]
  dsimp [List.map]
  rw [encode_arr_map, encode_arr_map, encode_arr_map, encode_arr_map, encode_arr_map, encode_arr_map]
  have h_sig : (t.signature.map (fun x => (unitToTreeJson x).encode)) = t.signature.map encodeUnit := by
    simp only [List.map_inj_left]; intro u _; exact unitToTreeJson_encode u
  have h_del : (t.deltas.map (fun x => (cellDeltaToTreeJson x).encode)) = t.deltas.map encodeCellDelta := by
    simp only [List.map_inj_left]; intro d _; exact cellDeltaToTreeJson_encode d
  have h_sdel : (t.supplyDeltas.map (fun x => (supplyDeltaToTreeJson x).encode)) = t.supplyDeltas.map encodeSupplyDelta := by
    simp only [List.map_inj_left]; intro sd _; exact supplyDeltaToTreeJson_encode sd
  have h_srd : (t.stateReads.map (fun x => (packedCellRefToTreeJson x).encode)) = t.stateReads.map encodePackedCellRef := by
    simp only [List.map_inj_left]; intro sr _; exact packedCellRefToTreeJson_encode sr
  have h_erd : (t.envReads.map (fun x => (envReadToTreeJson x).encode)) = t.envReads.map encodeEnvRead := by
    simp only [List.map_inj_left]; intro er _; exact envReadToTreeJson_encode er
  have h_wrt : (t.writes.map (fun x => (packedCellRefToTreeJson x).encode)) = t.writes.map encodePackedCellRef := by
    simp only [List.map_inj_left]; intro w _; exact packedCellRefToTreeJson_encode w
  rw [h_sig, h_del, h_sdel, h_srd, h_erd, h_wrt]
  rw [domainToTreeJson_encode, exprToTreeJson_encode, natToTreeJson_encode]

theorem templateToTreeJson_valid (t : TemplateEnc)
    (h_sig : t.signature.length ≤ 4096)
    (h_del : t.deltas.length ≤ 4096)
    (h_sdel : t.supplyDeltas.length ≤ 4096)
    (h_srd : t.stateReads.length ≤ 4096)
    (h_erd : t.envReads.length ≤ 4096)
    (h_wrt : t.writes.length ≤ 4096) :
    TreeJson.Valid (templateToTreeJson t) := by
  dsimp [templateToTreeJson, TreeJson.Valid, TreeJson.ValidObj]
  simp only [List.map_cons, List.map_nil]
  refine ⟨by decide,
          valid_arr_map unitToTreeJson t.signature h_sig (fun u _ => unitToTreeJson_valid u),
          domainToTreeJson_valid t.domain,
          trivial,
          exprToTreeJson_valid t.guard,
          valid_arr_map cellDeltaToTreeJson t.deltas h_del (fun d _ => cellDeltaToTreeJson_valid d),
          valid_arr_map supplyDeltaToTreeJson t.supplyDeltas h_sdel (fun sd _ => supplyDeltaToTreeJson_valid sd),
          valid_arr_map packedCellRefToTreeJson t.stateReads h_srd (fun sr _ => packedCellRefToTreeJson_valid sr),
          valid_arr_map envReadToTreeJson t.envReads h_erd (fun er _ => envReadToTreeJson_valid er),
          valid_arr_map packedCellRefToTreeJson t.writes h_wrt (fun w _ => packedCellRefToTreeJson_valid w),
          trivial⟩

def registryEntryToTreeJson (e : RegistryEntryEnc) : TreeJson :=
  TreeJson.obj [("id", natToTreeJson e.id), ("template", templateToTreeJson e.template)]

theorem registryEntryToTreeJson_encode (e : RegistryEntryEnc) :
    (registryEntryToTreeJson e).encode = encodeRegistryEntry e := by
  dsimp [registryEntryToTreeJson, encodeRegistryEntry]
  rw [encode_obj_eq_jsonObj]
  dsimp [List.map]
  rw [natToTreeJson_encode, templateToTreeJson_encode]

theorem registryEntryToTreeJson_valid (e : RegistryEntryEnc)
    (h_sig : e.template.signature.length ≤ 4096)
    (h_del : e.template.deltas.length ≤ 4096)
    (h_sdel : e.template.supplyDeltas.length ≤ 4096)
    (h_srd : e.template.stateReads.length ≤ 4096)
    (h_erd : e.template.envReads.length ≤ 4096)
    (h_wrt : e.template.writes.length ≤ 4096) :
    TreeJson.Valid (registryEntryToTreeJson e) := by
  dsimp [registryEntryToTreeJson, TreeJson.Valid, TreeJson.ValidObj]
  simp only [List.map_cons, List.map_nil]
  refine ⟨by decide, trivial, templateToTreeJson_valid e.template h_sig h_del h_sdel h_srd h_erd h_wrt, trivial⟩

def registryToTreeJson (r : RegistryEnc) : TreeJson :=
  TreeJson.obj [("entries", TreeJson.arr (r.entries.map registryEntryToTreeJson))]

theorem registryToTreeJson_encode (r : RegistryEnc) :
    (registryToTreeJson r).encode = encodeRegistry r := by
  dsimp [registryToTreeJson, encodeRegistry]
  rw [encode_obj_eq_jsonObj]
  dsimp [List.map]
  rw [encode_arr_map]
  have h_map : (r.entries.map (fun x => (registryEntryToTreeJson x).encode)) = r.entries.map encodeRegistryEntry := by
    simp only [List.map_inj_left]; intro e _; exact registryEntryToTreeJson_encode e
  rw [h_map]

def domainAdminToTreeJson (d : DomainAdminEnc) : TreeJson :=
  TreeJson.obj [("domain", domainToTreeJson d.domain), ("party", partyToTreeJson d.party)]

theorem domainAdminToTreeJson_encode (d : DomainAdminEnc) :
    (domainAdminToTreeJson d).encode = encodeDomainAdmin d := by
  dsimp [domainAdminToTreeJson, encodeDomainAdmin]
  rw [encode_obj_eq_jsonObj]
  dsimp [List.map]
  rw [domainToTreeJson_encode, partyToTreeJson_encode]

theorem domainAdminToTreeJson_valid (d : DomainAdminEnc) :
    TreeJson.Valid (domainAdminToTreeJson d) := by
  dsimp [domainAdminToTreeJson, TreeJson.Valid, TreeJson.ValidObj]
  simp only [List.map_cons, List.map_nil]
  refine ⟨by decide, domainToTreeJson_valid d.domain, partyToTreeJson_valid d.party, trivial⟩

def inputPortToTreeJson (p : InputPortEnc) : TreeJson :=
  TreeJson.obj [("id", natToTreeJson p.id), ("unit", unitToTreeJson p.unit)]

theorem inputPortToTreeJson_encode (p : InputPortEnc) :
    (inputPortToTreeJson p).encode = encodeInputPort p := by
  dsimp [inputPortToTreeJson, encodeInputPort]
  rw [encode_obj_eq_jsonObj]
  dsimp [List.map]
  rw [natToTreeJson_encode, unitToTreeJson_encode]

theorem inputPortToTreeJson_valid (p : InputPortEnc) :
    TreeJson.Valid (inputPortToTreeJson p) := by
  dsimp [inputPortToTreeJson, TreeJson.Valid, TreeJson.ValidObj]
  simp only [List.map_cons, List.map_nil]
  refine ⟨by decide, trivial, unitToTreeJson_valid p.unit, trivial⟩

def outputPortToTreeJson (p : OutputPortEnc) : TreeJson :=
  TreeJson.obj [("id", natToTreeJson p.id), ("cell", cellToTreeJson p.cell)]

theorem outputPortToTreeJson_encode (p : OutputPortEnc) :
    (outputPortToTreeJson p).encode = encodeOutputPort p := by
  dsimp [outputPortToTreeJson, encodeOutputPort]
  rw [encode_obj_eq_jsonObj]
  dsimp [List.map]
  rw [natToTreeJson_encode, cellToTreeJson_encode]

theorem outputPortToTreeJson_valid (p : OutputPortEnc) :
    TreeJson.Valid (outputPortToTreeJson p) := by
  dsimp [outputPortToTreeJson, TreeJson.Valid, TreeJson.ValidObj]
  simp only [List.map_cons, List.map_nil]
  refine ⟨by decide, trivial, cellToTreeJson_valid p.cell, trivial⟩

def resourcePortToTreeJson (p : ResourcePortEnc) : TreeJson :=
  TreeJson.obj [
    ("id", natToTreeJson p.id),
    ("cell", cellToTreeJson p.cell),
    ("writable", TreeJson.bool p.writable)
  ]

theorem resourcePortToTreeJson_encode (p : ResourcePortEnc) :
    (resourcePortToTreeJson p).encode = encodeResourcePort p := by
  dsimp [resourcePortToTreeJson, encodeResourcePort]
  rw [encode_obj_eq_jsonObj]
  dsimp [List.map]
  rw [natToTreeJson_encode, cellToTreeJson_encode]
  cases p.writable <;> rfl

theorem resourcePortToTreeJson_valid (p : ResourcePortEnc) :
    TreeJson.Valid (resourcePortToTreeJson p) := by
  dsimp [resourcePortToTreeJson, TreeJson.Valid, TreeJson.ValidObj]
  simp only [List.map_cons, List.map_nil]
  refine ⟨by decide, trivial, cellToTreeJson_valid p.cell, trivial, trivial⟩

def qualifiedPortToTreeJson (qp : QualifiedPortEnc) : TreeJson :=
  TreeJson.obj [("component", natToTreeJson qp.component), ("port", natToTreeJson qp.port)]

theorem qualifiedPortToTreeJson_encode (qp : QualifiedPortEnc) :
    (qualifiedPortToTreeJson qp).encode = encodeQualifiedPort qp := by
  dsimp [qualifiedPortToTreeJson, encodeQualifiedPort]
  rw [encode_obj_eq_jsonObj]
  dsimp [List.map]
  rw [natToTreeJson_encode, natToTreeJson_encode]

theorem qualifiedPortToTreeJson_valid (qp : QualifiedPortEnc) :
    TreeJson.Valid (qualifiedPortToTreeJson qp) := by
  dsimp [qualifiedPortToTreeJson, TreeJson.Valid, TreeJson.ValidObj]
  simp only [List.map_cons, List.map_nil]
  refine ⟨by decide, trivial, trivial, trivial⟩

def resourceImportToTreeJson (ri : ResourceImportEnc) : TreeJson :=
  TreeJson.obj [
    ("source", qualifiedPortToTreeJson ri.source),
    ("cell", cellToTreeJson ri.cell),
    ("writable", TreeJson.bool ri.writable)
  ]

theorem resourceImportToTreeJson_encode (ri : ResourceImportEnc) :
    (resourceImportToTreeJson ri).encode = encodeResourceImport ri := by
  dsimp [resourceImportToTreeJson, encodeResourceImport]
  rw [encode_obj_eq_jsonObj]
  dsimp [List.map]
  rw [qualifiedPortToTreeJson_encode, cellToTreeJson_encode]
  cases ri.writable <;> rfl

theorem resourceImportToTreeJson_valid (ri : ResourceImportEnc) :
    TreeJson.Valid (resourceImportToTreeJson ri) := by
  dsimp [resourceImportToTreeJson, TreeJson.Valid, TreeJson.ValidObj]
  simp only [List.map_cons, List.map_nil]
  refine ⟨by decide, qualifiedPortToTreeJson_valid ri.source, cellToTreeJson_valid ri.cell, trivial, trivial⟩

def operationInterfaceToTreeJson (op : OperationInterfaceEnc) : TreeJson :=
  TreeJson.obj [
    ("operation", natToTreeJson op.operation),
    ("inputs", TreeJson.arr (op.inputs.map inputPortToTreeJson)),
    ("outputs", TreeJson.arr (op.outputs.map outputPortToTreeJson))
  ]

theorem operationInterfaceToTreeJson_encode (op : OperationInterfaceEnc) :
    (operationInterfaceToTreeJson op).encode = encodeOperationInterface op := by
  dsimp [operationInterfaceToTreeJson, encodeOperationInterface]
  rw [encode_obj_eq_jsonObj]
  dsimp [List.map]
  rw [encode_arr_map, encode_arr_map]
  have h_ins : (op.inputs.map (fun x => (inputPortToTreeJson x).encode)) = op.inputs.map encodeInputPort := by
    simp only [List.map_inj_left]; intro x _; exact inputPortToTreeJson_encode x
  have h_outs : (op.outputs.map (fun x => (outputPortToTreeJson x).encode)) = op.outputs.map encodeOutputPort := by
    simp only [List.map_inj_left]; intro x _; exact outputPortToTreeJson_encode x
  rw [h_ins, h_outs, natToTreeJson_encode]

def componentToTreeJson (c : ComponentEnc) : TreeJson :=
  TreeJson.obj [
    ("id", natToTreeJson c.id),
    ("privateCells", TreeJson.arr (c.privateCells.map cellToTreeJson)),
    ("exports", TreeJson.arr (c.exports.map resourcePortToTreeJson)),
    ("imports", TreeJson.arr (c.imports.map resourceImportToTreeJson)),
    ("operations", TreeJson.arr (c.operations.map operationInterfaceToTreeJson))
  ]

theorem componentToTreeJson_encode (c : ComponentEnc) :
    (componentToTreeJson c).encode = encodeComponent c := by
  dsimp [componentToTreeJson, encodeComponent]
  rw [encode_obj_eq_jsonObj]
  dsimp [List.map]
  rw [encode_arr_map, encode_arr_map, encode_arr_map, encode_arr_map]
  have h_privs : (c.privateCells.map (fun x => (cellToTreeJson x).encode)) = c.privateCells.map encodeCell := by
    simp only [List.map_inj_left]; intro x _; exact cellToTreeJson_encode x
  have h_exps : (c.exports.map (fun x => (resourcePortToTreeJson x).encode)) = c.exports.map encodeResourcePort := by
    simp only [List.map_inj_left]; intro x _; exact resourcePortToTreeJson_encode x
  have h_imps : (c.imports.map (fun x => (resourceImportToTreeJson x).encode)) = c.imports.map encodeResourceImport := by
    simp only [List.map_inj_left]; intro x _; exact resourceImportToTreeJson_encode x
  have h_ops : (c.operations.map (fun x => (operationInterfaceToTreeJson x).encode)) = c.operations.map encodeOperationInterface := by
    simp only [List.map_inj_left]; intro x _; exact operationInterfaceToTreeJson_encode x
  rw [h_privs, h_exps, h_imps, h_ops, natToTreeJson_encode]

def configToTreeJson (c : ConfigEnc) : TreeJson :=
  TreeJson.obj [
    ("registry", registryToTreeJson c.registry),
    ("domainAdmin", TreeJson.arr (c.domainAdmin.map domainAdminToTreeJson)),
    ("catalog", TreeJson.arr (c.catalog.map componentToTreeJson))
  ]

theorem configToTreeJson_encode (c : ConfigEnc) :
    (configToTreeJson c).encode = encodeConfig c := by
  dsimp [configToTreeJson, encodeConfig]
  rw [encode_obj_eq_jsonObj]
  dsimp [List.map]
  rw [encode_arr_map, encode_arr_map]
  have h_adm : (c.domainAdmin.map (fun x => (domainAdminToTreeJson x).encode)) = c.domainAdmin.map encodeDomainAdmin := by
    simp only [List.map_inj_left]; intro x _; exact domainAdminToTreeJson_encode x
  have h_cat : (c.catalog.map (fun x => (componentToTreeJson x).encode)) = c.catalog.map encodeComponent := by
    simp only [List.map_inj_left]; intro x _; exact componentToTreeJson_encode x
  rw [h_adm, h_cat, registryToTreeJson_encode]

def inputSourceToTreeJson : InputSourceEnc → TreeJson
  | .literal v => TreeJson.obj [("tag", TreeJson.str "literal"), ("value", packedValueFullToTreeJson v)]
  | .priorOutput step port =>
    TreeJson.obj [
      ("tag", TreeJson.str "priorOutput"),
      ("step", natToTreeJson step),
      ("port", qualifiedPortToTreeJson port)
    ]

theorem inputSourceToTreeJson_encode (i : InputSourceEnc) :
    (inputSourceToTreeJson i).encode = encodeInputSource i := by
  cases i with
  | literal v =>
    dsimp [inputSourceToTreeJson, encodeInputSource]
    rw [encode_obj_eq_jsonObj]
    dsimp [List.map, TreeJson.encode]
    rw [packedValueFullToTreeJson_encode]
    rfl
  | priorOutput step port =>
    dsimp [inputSourceToTreeJson, encodeInputSource]
    rw [encode_obj_eq_jsonObj]
    dsimp [List.map, TreeJson.encode]
    rw [natToTreeJson_encode, qualifiedPortToTreeJson_encode]
    rfl

def invocationToTreeJson (inv : InvocationEnc) : TreeJson :=
  TreeJson.obj [
    ("component", natToTreeJson inv.component),
    ("operation", natToTreeJson inv.operation),
    ("parties", TreeJson.arr (inv.parties.map partyToTreeJson)),
    ("inputs", TreeJson.arr (inv.inputs.map inputSourceToTreeJson)),
    ("capabilityIds", TreeJson.arr (inv.capabilityIds.map natToTreeJson)),
    ("claimedActor", match inv.claimedActor with | some a => partyToTreeJson a | none => TreeJson.null)
  ]

theorem invocationToTreeJson_encode (inv : InvocationEnc) :
    (invocationToTreeJson inv).encode = encodeInvocation inv := by
  dsimp [invocationToTreeJson, encodeInvocation]
  rw [encode_obj_eq_jsonObj]
  dsimp [List.map]
  rw [encode_arr_map, encode_arr_map, encode_arr_map]
  have h_ps : (inv.parties.map (fun x => (partyToTreeJson x).encode)) = inv.parties.map encodeParty := by
    simp only [List.map_inj_left]; intro x _; exact partyToTreeJson_encode x
  have h_ins : (inv.inputs.map (fun x => (inputSourceToTreeJson x).encode)) = inv.inputs.map encodeInputSource := by
    simp only [List.map_inj_left]; intro x _; exact inputSourceToTreeJson_encode x
  have h_caps : (inv.capabilityIds.map (fun x => (natToTreeJson x).encode)) = inv.capabilityIds.map toString := by
    simp only [List.map_inj_left]; intro x _; exact natToTreeJson_encode x
  rw [h_ps, h_ins, h_caps, natToTreeJson_encode, natToTreeJson_encode]
  cases inv.claimedActor with
  | none => rfl
  | some a =>
    dsimp
    rw [partyToTreeJson_encode]

def stepToTreeJson : StepEnc → TreeJson
  | .invoke inv => TreeJson.obj [("tag", TreeJson.str "invoke"), ("invocation", invocationToTreeJson inv)]
  | .issue g => TreeJson.obj [("tag", TreeJson.str "issue"), ("grant", grantToTreeJson g)]
  | .revoke id => TreeJson.obj [("tag", TreeJson.str "revoke"), ("id", natToTreeJson id)]
  | .unsupported tag => TreeJson.obj [("tag", TreeJson.str tag)]

theorem stepToTreeJson_encode (s : StepEnc) (h_can : StepCanonical s) :
    (stepToTreeJson s).encode = encodeStep s := by
  cases s with
  | invoke inv =>
    dsimp [stepToTreeJson, encodeStep]
    rw [encode_obj_eq_jsonObj]
    dsimp [List.map, TreeJson.encode]
    rw [invocationToTreeJson_encode]
    rfl
  | issue g =>
    dsimp [stepToTreeJson, encodeStep]
    rw [encode_obj_eq_jsonObj]
    dsimp [List.map, TreeJson.encode]
    rw [grantToTreeJson_encode]
    rfl
  | revoke id =>
    dsimp [stepToTreeJson, encodeStep]
    rw [encode_obj_eq_jsonObj]
    dsimp [List.map, TreeJson.encode]
    rw [natToTreeJson_encode]
    rfl
  | unsupported tag =>
    cases h_can

def outputObservationToTreeJson (o : OutputObservationEnc) : TreeJson :=
  TreeJson.obj [
    ("step", natToTreeJson o.step),
    ("port", qualifiedPortToTreeJson o.port),
    ("value", packedValueFullToTreeJson o.value)
  ]

theorem outputObservationToTreeJson_encode (o : OutputObservationEnc) :
    (outputObservationToTreeJson o).encode = encodeOutputObservation o := by
  dsimp [outputObservationToTreeJson, encodeOutputObservation]
  rw [encode_obj_eq_jsonObj]
  dsimp [List.map]
  rw [natToTreeJson_encode, qualifiedPortToTreeJson_encode, packedValueFullToTreeJson_encode]

def typedExecutePayloadToTreeJson (p : TypedExecutePayloadEnc) : TreeJson :=
  TreeJson.obj [
    ("registry", registryToTreeJson p.registry),
    ("store", storeToTreeJson p.store),
    ("ctx", contextToTreeJson p.ctx),
    ("env", environmentToTreeJson p.env),
    ("now", natToTreeJson p.now),
    ("request", requestToTreeJson p.request),
    ("state", stateToTreeJson p.state)
  ]

theorem typedExecutePayloadToTreeJson_encode (p : TypedExecutePayloadEnc) :
    (typedExecutePayloadToTreeJson p).encode = encodeTypedExecutePayload p := by
  dsimp [typedExecutePayloadToTreeJson, encodeTypedExecutePayload]
  rw [encode_obj_eq_jsonObj]
  dsimp [List.map]
  rw [registryToTreeJson_encode, storeToTreeJson_encode, contextToTreeJson_encode,
      environmentToTreeJson_encode, natToTreeJson_encode, requestToTreeJson_encode,
      stateToTreeJson_encode]

def compositionStepPayloadToTreeJson (p : CompositionStepPayloadEnc) : TreeJson :=
  TreeJson.obj [
    ("config", configToTreeJson p.config),
    ("boundary", boundaryToTreeJson p.boundary),
    ("index", natToTreeJson p.index),
    ("history", TreeJson.arr (p.history.map outputObservationToTreeJson)),
    ("step", stepToTreeJson p.step),
    ("pre", worldToTreeJson p.pre)
  ]

theorem compositionStepPayloadToTreeJson_encode (p : CompositionStepPayloadEnc) (h_can : StepCanonical p.step) :
    (compositionStepPayloadToTreeJson p).encode = encodeCompositionStepPayload p := by
  dsimp [compositionStepPayloadToTreeJson, encodeCompositionStepPayload]
  rw [encode_obj_eq_jsonObj]
  dsimp [List.map]
  rw [configToTreeJson_encode, boundaryToTreeJson_encode, natToTreeJson_encode, encode_arr_map]
  have h_hist : (p.history.map (fun x => (outputObservationToTreeJson x).encode)) = p.history.map encodeOutputObservation := by
    simp only [List.map_inj_left]; intro x _; exact outputObservationToTreeJson_encode x
  rw [h_hist]
  rw [stepToTreeJson_encode p.step h_can, worldToTreeJson_encode]

def compositionRunPayloadToTreeJson (p : CompositionRunPayloadEnc) : TreeJson :=
  TreeJson.obj [
    ("config", configToTreeJson p.config),
    ("boundaries", TreeJson.arr (p.boundaries.map boundaryToTreeJson)),
    ("world", worldToTreeJson p.world),
    ("steps", TreeJson.arr (p.steps.map stepToTreeJson))
  ]

theorem compositionRunPayloadToTreeJson_encode (p : CompositionRunPayloadEnc) (h_can : ∀ s ∈ p.steps, StepCanonical s) :
    (compositionRunPayloadToTreeJson p).encode = encodeCompositionRunPayload p := by
  dsimp [compositionRunPayloadToTreeJson, encodeCompositionRunPayload]
  rw [encode_obj_eq_jsonObj]
  dsimp [List.map]
  rw [configToTreeJson_encode, encode_arr_map, worldToTreeJson_encode, encode_arr_map]
  have h_bs : (p.boundaries.map (fun x => (boundaryToTreeJson x).encode)) = p.boundaries.map encodeBoundary := by
    simp only [List.map_inj_left]; intro x _; exact boundaryToTreeJson_encode x
  have h_ss : (p.steps.map (fun x => (stepToTreeJson x).encode)) = p.steps.map encodeStep := by
    simp only [List.map_inj_left]; intro s hs; exact stepToTreeJson_encode s (h_can s hs)
  rw [h_bs, h_ss]

def moduleToTreeJson : DecodedIR → TreeJson
  | .execution (.typed env p) =>
    envelopeToTreeJson env (typedExecutePayloadToTreeJson p)
  | .execution (.step env p) =>
    envelopeToTreeJson env (compositionStepPayloadToTreeJson p)
  | .execution (.run env p) =>
    envelopeToTreeJson env (compositionRunPayloadToTreeJson p)
  | .audit _ => TreeJson.null
  | .codec _ => TreeJson.null

theorem moduleToTreeJson_encode (ir : DecodedIR) (h_adm : StructurallyAdmissibleIR ir) :
    (moduleToTreeJson ir).encode = encodeModuleString ir := by
  rcases h_adm with ⟨h_sup, h_can⟩
  dsimp [SupportedIR] at h_sup
  rcases h_sup with ⟨h_byte, h_depth, h_arr, h_ir_sup⟩
  cases ir with
  | execution ex =>
    cases ex with
    | typed env p =>
      dsimp [moduleToTreeJson, encodeModuleString]
      dsimp [CanonicalIR] at h_can
      rcases h_can with ⟨h_sm, _⟩
      rw [envelopeToTreeJson_encode env (typedExecutePayloadToTreeJson p) h_sm]
      rw [typedExecutePayloadToTreeJson_encode]
    | step env p =>
      dsimp [moduleToTreeJson, encodeModuleString]
      dsimp [CanonicalIR] at h_can
      rcases h_can with ⟨h_sm, _, _, h_step_can, _⟩
      rw [envelopeToTreeJson_encode env (compositionStepPayloadToTreeJson p) h_sm]
      rw [compositionStepPayloadToTreeJson_encode p h_step_can]
    | run env p =>
      dsimp [moduleToTreeJson, encodeModuleString]
      dsimp [CanonicalIR] at h_can
      rcases h_can with ⟨h_sm, _, _, h_steps_can, _⟩
      rw [envelopeToTreeJson_encode env (compositionRunPayloadToTreeJson p) h_sm]
      rw [compositionRunPayloadToTreeJson_encode p h_steps_can]
  | audit a =>
    dsimp [CanonicalIR] at h_can
  | codec doc =>
    dsimp [CanonicalIR] at h_can

theorem parseCanonicalJson_encodeModuleString_tree (ir : DecodedIR)


    (h_adm : StructurallyAdmissibleIR ir)
    (h_valid : TreeJson.Valid (moduleToTreeJson ir))
    (h_depth : TreeJson.depth (moduleToTreeJson ir) ≤ 64) :
    parseCanonicalJson (encodeModuleString ir) = .ok ((moduleToTreeJson ir).toJson) := by
  have h_enc := moduleToTreeJson_encode ir h_adm
  rw [← h_enc]
  exact parseCanonicalJson_tree (moduleToTreeJson ir) h_valid h_depth

theorem decodeBytes_encodeModule_of_valid_and_depth (ir : DecodedIR)
    (h_adm : StructurallyAdmissibleIR ir)
    (h_valid : TreeJson.Valid (moduleToTreeJson ir))
    (h_depth : TreeJson.depth (moduleToTreeJson ir) ≤ 64)
    (h_dec : decodeDecodedIR ((moduleToTreeJson ir).toJson) (encodeModuleString ir) = .ok ir)
    (h_lex : scanLexical (encodeModule ir) = .ok ()) :
    decodeBytes (encodeModule ir) = .ok ir := by
  have h_parse := parseCanonicalJson_encodeModuleString_tree ir h_adm h_valid h_depth
  apply decodeBytes_eq_of_steps (encodeModule ir) (encodeModuleString ir) ((moduleToTreeJson ir).toJson) ir
  · exact h_lex
  · exact string_fromUTF8_encodeModule ir
  · exact h_parse
  · exact h_dec
  · rfl

end DefiKernel.Certificates

