import DefiKernel.Certificates.Correspondence

namespace DefiKernel.Certificates

set_option linter.style.longLine false

open Lean

/-! # Universal Roundtrip Module for P19 Typed/Sequential Certificates
    Provides TreeJson structural representations, encoding/toJson lemmas,
    and parser roundtrip proofs for all accepted certificate forms. -/

theorem toJsonList_map {α : Type} (f : α → TreeJson) (xs : List α) :
    TreeJson.toJsonList (xs.map f) = xs.map (fun x => (f x).toJson) := by
  induction xs with
  | nil => rfl
  | cons x xs ih =>
    dsimp [List.map, TreeJson.toJsonList]
    rw [ih]

theorem encodeList_map {α : Type} (f : α → TreeJson) (xs : List α) :
    TreeJson.encodeList (xs.map f) = String.intercalate "," (xs.map (fun x => (f x).encode)) := by
  rw [encodeList_eq_intercalate]
  simp only [List.map_map]
  rfl

theorem encode_arr_map {α : Type} (f : α → TreeJson) (xs : List α) :
    TreeJson.encode (.arr (xs.map f)) = jsonArr (xs.map (fun x => (f x).encode)) := by
  dsimp [TreeJson.encode, jsonArr]
  rw [encodeList_map]

theorem toJson_arr_map {α : Type} (f : α → TreeJson) (xs : List α) :
    (TreeJson.arr (xs.map f)).toJson = Lean.Json.arr (xs.map (fun x => (f x).toJson)).toArray := by
  dsimp [TreeJson.toJson]
  rw [toJsonList_map]

theorem validList_map {α : Type} (f : α → TreeJson) (xs : List α)
    (h : ∀ x ∈ xs, TreeJson.Valid (f x)) :
    TreeJson.ValidList (xs.map f) := by
  induction xs with
  | nil => trivial
  | cons x xs ih =>
    dsimp [List.map, TreeJson.ValidList]
    refine ⟨h x (List.Mem.head xs), ih (fun y hy => h y (List.Mem.tail x hy))⟩

theorem valid_arr_map {α : Type} (f : α → TreeJson) (xs : List α)
    (h_len : xs.length ≤ 4096)
    (h : ∀ x ∈ xs, TreeJson.Valid (f x)) :
    TreeJson.Valid (TreeJson.arr (xs.map f)) := by
  dsimp [TreeJson.Valid]
  rw [List.length_map]
  exact ⟨h_len, validList_map f xs h⟩

theorem encode_arr_str (xs : List String) :
    TreeJson.encode (.arr (xs.map TreeJson.str)) = jsonArr (xs.map escapeJsonString) := by
  rw [encode_arr_map]
  have h_eq : (xs.map (fun s => (TreeJson.str s).encode)) = xs.map escapeJsonString := by
    simp only [List.map_inj_left]
    intro s _
    exact escapeTreeString_eq_escapeJsonString s
  rw [h_eq]

theorem toJson_arr_str (xs : List String) :
    (TreeJson.arr (xs.map TreeJson.str)).toJson = Lean.Json.arr (xs.map Lean.Json.str).toArray := by
  rw [toJson_arr_map]
  rfl

theorem valid_arr_str (xs : List String) (h_len : xs.length ≤ 4096) :
    TreeJson.Valid (TreeJson.arr (xs.map TreeJson.str)) := by
  apply valid_arr_map
  · exact h_len
  · intro _ _; trivial

/-- Explicit Nat-to-TreeJson mapping avoiding ambiguous List coercions. -/
def natToTreeJson (n : Nat) : TreeJson := TreeJson.num (Int.ofNat n)

theorem natToTreeJson_encode (n : Nat) : (natToTreeJson n).encode = toString n := rfl

theorem natToTreeJson_toJson (n : Nat) : (natToTreeJson n).toJson = Json.num (JsonNumber.fromNat n) := rfl

theorem natToTreeJson_valid (n : Nat) : TreeJson.Valid (natToTreeJson n) := trivial

/-- Packed value unit-and-value object representation in TreeJson. -/
def packedValueFullToTreeJson (v : PackedValueEnc) : TreeJson :=
  TreeJson.obj [("unit", unitToTreeJson v.unit), ("value", packedValueToTreeJson v)]

theorem packedValueFullToTreeJson_toJson (v : PackedValueEnc) :
    (packedValueFullToTreeJson v).toJson = packedValueFullToJson v := by
  dsimp [packedValueFullToTreeJson, packedValueFullToJson, TreeJson.toJson, TreeJson.toJsonObj]
  rw [unitToTreeJson_toJson, packedValueToTreeJson_toJson]

theorem packedValueFullToTreeJson_encode (v : PackedValueEnc) :
    (packedValueFullToTreeJson v).encode = encodePackedValue v := by
  dsimp [packedValueFullToTreeJson, encodePackedValue]
  rw [encode_obj_eq_jsonObj]
  dsimp [List.map]
  rw [unitToTreeJson_encode]
  cases h : v.unit with
  | bool =>
    dsimp [packedValueToTreeJson]
    rw [h]
    dsimp
    cases v.valBool <;> rfl
  | numeric nu =>
    dsimp [packedValueToTreeJson]
    rw [h]
    dsimp
    rw [ratToTreeJson_encode]
    rfl

theorem packedValueFullToTreeJson_valid (v : PackedValueEnc) :
    TreeJson.Valid (packedValueFullToTreeJson v) := by
  dsimp [packedValueFullToTreeJson, TreeJson.Valid, TreeJson.ValidObj]
  simp only [List.map_cons, List.map_nil]
  refine ⟨by decide, unitToTreeJson_valid v.unit, ?_, trivial⟩
  cases h : v.unit with
  | bool =>
    dsimp [packedValueToTreeJson]
    rw [h]
    dsimp
    cases v.valBool <;> trivial
  | numeric nu =>
    dsimp [packedValueToTreeJson]
    rw [h]
    dsimp
    exact ratToTreeJson_valid ⟨v.valRat.num, v.valRat.den⟩

theorem map_encode_str_pairs (entries : List (String × String)) :
    (entries.map (fun (k, v) => (k, TreeJson.str v))).map (fun (k, v) => (k, TreeJson.encode v)) =
    entries.map (fun (k, v) => (k, escapeJsonString v)) := by
  induction entries with
  | nil => rfl
  | cons kv rest ih =>
    rcases kv with ⟨k, v⟩
    dsimp [List.map]
    have h_esc : (TreeJson.str v).encode = escapeJsonString v := escapeTreeString_eq_escapeJsonString v
    rw [h_esc, ih]

def sourceMapToTreeJson (entries : List (String × String)) : TreeJson :=
  TreeJson.obj (entries.map (fun (k, v) => (k, TreeJson.str v)))

theorem toJsonObj_map_str (entries : List (String × String)) :
    TreeJson.toJsonObj (entries.map (fun (k, v) => (k, TreeJson.str v))) =
    entries.map (fun (k, v) => (k, Lean.Json.str v)) := by
  induction entries with
  | nil => rfl
  | cons kv rest ih =>
    rcases kv with ⟨k, v⟩
    dsimp [List.map, TreeJson.toJsonObj, TreeJson.toJson]
    rw [ih]

theorem sourceMapToTreeJson_toJson (entries : List (String × String)) :
    (sourceMapToTreeJson entries).toJson = Lean.Json.mkObj (entries.map (fun (k, v) => (k, Lean.Json.str v))) := by
  dsimp [sourceMapToTreeJson, TreeJson.toJson]
  rw [toJsonObj_map_str]

theorem sourceMapToTreeJson_encode (entries : List (String × String)) (h_sm : SourceMapSorted entries) :
    (sourceMapToTreeJson entries).encode = encodeSourceMap entries := by
  dsimp [sourceMapToTreeJson, encodeSourceMap]
  rw [h_sm]
  dsimp
  rw [encode_obj_eq_jsonObj]
  rw [map_encode_str_pairs]

def stateCellToTreeJson (c : StateCellEnc) : TreeJson :=
  TreeJson.obj [
    ("domain", domainToTreeJson c.domain),
    ("party", partyToTreeJson c.party),
    ("asset", assetToTreeJson c.asset),
    ("amount", ratToTreeJson c.amount)
  ]

theorem stateCellToTreeJson_toJson (c : StateCellEnc) :
    (stateCellToTreeJson c).toJson = stateCellToJson c := by
  dsimp [stateCellToTreeJson, stateCellToJson, TreeJson.toJson, TreeJson.toJsonObj]
  rw [domainToTreeJson_toJson, partyToTreeJson_toJson, assetToTreeJson_toJson, ratToTreeJson_toJson]

theorem stateCellToTreeJson_encode (c : StateCellEnc) :
    (stateCellToTreeJson c).encode = encodeStateCell c := by
  dsimp [stateCellToTreeJson, encodeStateCell]
  rw [encode_obj_eq_jsonObj]
  dsimp [List.map]
  rw [domainToTreeJson_encode, partyToTreeJson_encode, assetToTreeJson_encode, ratToTreeJson_encode]

theorem stateCellToTreeJson_valid (c : StateCellEnc) :
    TreeJson.Valid (stateCellToTreeJson c) := by
  dsimp [stateCellToTreeJson, TreeJson.Valid, TreeJson.ValidObj]
  simp only [List.map_cons, List.map_nil]
  refine ⟨by decide, domainToTreeJson_valid c.domain, partyToTreeJson_valid c.party,
          assetToTreeJson_valid c.asset, ratToTreeJson_valid c.amount, trivial⟩

def cellToTreeJson (c : CellEnc) : TreeJson :=
  TreeJson.obj [
    ("domain", domainToTreeJson c.domain),
    ("party", partyToTreeJson c.party),
    ("asset", assetToTreeJson c.asset)
  ]

theorem cellToTreeJson_toJson (c : CellEnc) :
    (cellToTreeJson c).toJson = cellToJson c := by
  dsimp [cellToTreeJson, cellToJson, TreeJson.toJson, TreeJson.toJsonObj]
  rw [domainToTreeJson_toJson, partyToTreeJson_toJson, assetToTreeJson_toJson]

theorem cellToTreeJson_encode (c : CellEnc) :
    (cellToTreeJson c).encode = encodeCell c := by
  dsimp [cellToTreeJson, encodeCell]
  rw [encode_obj_eq_jsonObj]
  dsimp [List.map]
  rw [domainToTreeJson_encode, partyToTreeJson_encode, assetToTreeJson_encode]

theorem cellToTreeJson_valid (c : CellEnc) :
    TreeJson.Valid (cellToTreeJson c) := by
  dsimp [cellToTreeJson, TreeJson.Valid, TreeJson.ValidObj]
  simp only [List.map_cons, List.map_nil]
  refine ⟨by decide, domainToTreeJson_valid c.domain, partyToTreeJson_valid c.party,
          assetToTreeJson_valid c.asset, trivial⟩

def rightToTreeJson : RightEnc → TreeJson
  | .invoke => TreeJson.obj [("tag", TreeJson.str "invoke")]
  | .debit c => TreeJson.obj [("tag", TreeJson.str "debit"), ("cell", cellToTreeJson c)]
  | .changeSupply d a =>
    TreeJson.obj [
      ("tag", TreeJson.str "changeSupply"),
      ("domain", domainToTreeJson d),
      ("asset", assetToTreeJson a)
    ]

theorem rightToTreeJson_toJson (r : RightEnc) :
    (rightToTreeJson r).toJson = rightToJson r := by
  cases r with
  | invoke => rfl
  | debit c =>
    dsimp [rightToTreeJson, rightToJson, TreeJson.toJson, TreeJson.toJsonObj]
    rw [cellToTreeJson_toJson]
  | changeSupply d a =>
    dsimp [rightToTreeJson, rightToJson, TreeJson.toJson, TreeJson.toJsonObj]
    rw [domainToTreeJson_toJson, assetToTreeJson_toJson]

theorem rightToTreeJson_encode (r : RightEnc) :
    (rightToTreeJson r).encode = encodeRight r := by
  cases r with
  | invoke => rfl
  | debit c =>
    dsimp [rightToTreeJson, encodeRight]
    rw [encode_obj_eq_jsonObj]
    dsimp [List.map]
    rw [cellToTreeJson_encode]
    rfl
  | changeSupply d a =>
    dsimp [rightToTreeJson, encodeRight]
    rw [encode_obj_eq_jsonObj]
    dsimp [List.map]
    rw [domainToTreeJson_encode, assetToTreeJson_encode]
    rfl

theorem rightToTreeJson_valid (r : RightEnc) :
    TreeJson.Valid (rightToTreeJson r) := by
  cases r with
  | invoke =>
    dsimp [rightToTreeJson, TreeJson.Valid, TreeJson.ValidObj]
    simp only [List.map_cons, List.map_nil]
    refine ⟨by decide, trivial, trivial⟩
  | debit c =>
    dsimp [rightToTreeJson, TreeJson.Valid, TreeJson.ValidObj]
    simp only [List.map_cons, List.map_nil]
    refine ⟨by decide, trivial, cellToTreeJson_valid c, trivial⟩
  | changeSupply d a =>
    dsimp [rightToTreeJson, TreeJson.Valid, TreeJson.ValidObj]
    simp only [List.map_cons, List.map_nil]
    refine ⟨by decide, trivial, domainToTreeJson_valid d, assetToTreeJson_valid a, trivial⟩

def grantToTreeJson (g : GrantEnc) : TreeJson :=
  TreeJson.obj [
    ("holder", partyToTreeJson g.holder),
    ("domain", domainToTreeJson g.domain),
    ("operation", natToTreeJson g.operation),
    ("right", rightToTreeJson g.right)
  ]

theorem grantToTreeJson_toJson (g : GrantEnc) :
    (grantToTreeJson g).toJson = grantToJson g := by
  dsimp [grantToTreeJson, grantToJson, TreeJson.toJson, TreeJson.toJsonObj]
  rw [partyToTreeJson_toJson, domainToTreeJson_toJson, rightToTreeJson_toJson]
  rfl

theorem grantToTreeJson_encode (g : GrantEnc) :
    (grantToTreeJson g).encode = encodeGrant g := by
  dsimp [grantToTreeJson, encodeGrant]
  rw [encode_obj_eq_jsonObj]
  dsimp [List.map]
  rw [partyToTreeJson_encode, domainToTreeJson_encode, rightToTreeJson_encode, natToTreeJson_encode]

theorem grantToTreeJson_valid (g : GrantEnc) :
    TreeJson.Valid (grantToTreeJson g) := by
  dsimp [grantToTreeJson, TreeJson.Valid, TreeJson.ValidObj]
  simp only [List.map_cons, List.map_nil]
  refine ⟨by decide, partyToTreeJson_valid g.holder, domainToTreeJson_valid g.domain,
          trivial, rightToTreeJson_valid g.right, trivial⟩

def capabilityToTreeJson (c : CapabilityEnc) : TreeJson :=
  TreeJson.obj [
    ("holder", partyToTreeJson c.holder),
    ("domain", domainToTreeJson c.domain),
    ("operation", natToTreeJson c.operation),
    ("right", rightToTreeJson c.right),
    ("live", TreeJson.bool c.live)
  ]

theorem capabilityToTreeJson_toJson (c : CapabilityEnc) :
    (capabilityToTreeJson c).toJson = capabilityToJson c := by
  dsimp [capabilityToTreeJson, capabilityToJson, TreeJson.toJson, TreeJson.toJsonObj]
  rw [partyToTreeJson_toJson, domainToTreeJson_toJson, rightToTreeJson_toJson]
  rfl

theorem capabilityToTreeJson_encode (c : CapabilityEnc) :
    (capabilityToTreeJson c).encode = encodeCapability c := by
  dsimp [capabilityToTreeJson, encodeCapability]
  rw [encode_obj_eq_jsonObj]
  dsimp [List.map]
  rw [partyToTreeJson_encode, domainToTreeJson_encode, rightToTreeJson_encode, natToTreeJson_encode]
  cases c.live <;> rfl

theorem capabilityToTreeJson_valid (c : CapabilityEnc) :
    TreeJson.Valid (capabilityToTreeJson c) := by
  dsimp [capabilityToTreeJson, TreeJson.Valid, TreeJson.ValidObj]
  simp only [List.map_cons, List.map_nil]
  refine ⟨by decide, partyToTreeJson_valid c.holder, domainToTreeJson_valid c.domain,
          trivial, rightToTreeJson_valid c.right, trivial, trivial⟩

def storeToTreeJson (s : StoreEnc) : TreeJson :=
  TreeJson.obj [("entries", TreeJson.arr (s.entries.map capabilityToTreeJson))]

theorem storeToTreeJson_toJson (s : StoreEnc) :
    (storeToTreeJson s).toJson = storeToJson s := by
  dsimp [storeToTreeJson, storeToJson, TreeJson.toJson, TreeJson.toJsonObj]
  rw [toJsonList_map]
  have h_map : (s.entries.map (fun x => (capabilityToTreeJson x).toJson)) = s.entries.map capabilityToJson := by
    simp only [List.map_inj_left]; intro c _; exact capabilityToTreeJson_toJson c
  rw [h_map]

theorem storeToTreeJson_encode (s : StoreEnc) :
    (storeToTreeJson s).encode = encodeStore s := by
  dsimp [storeToTreeJson, encodeStore]
  rw [encode_obj_eq_jsonObj]
  dsimp [List.map]
  rw [encode_arr_map]
  have h_map : (s.entries.map (fun x => (capabilityToTreeJson x).encode)) = s.entries.map encodeCapability := by
    simp only [List.map_inj_left]; intro c _; exact capabilityToTreeJson_encode c
  rw [h_map]

theorem storeToTreeJson_valid (s : StoreEnc) (h_len : s.entries.length ≤ 4096) :
    TreeJson.Valid (storeToTreeJson s) := by
  dsimp [storeToTreeJson, TreeJson.Valid, TreeJson.ValidObj]
  simp only [List.map_cons, List.map_nil]
  refine ⟨by decide, valid_arr_map capabilityToTreeJson s.entries h_len (fun c _ => capabilityToTreeJson_valid c), trivial⟩

def stateToTreeJson (s : StateEnc) : TreeJson :=
  TreeJson.obj [("cells", TreeJson.arr (s.cells.map stateCellToTreeJson))]

theorem stateToTreeJson_toJson (s : StateEnc) :
    (stateToTreeJson s).toJson = stateToJson s := by
  dsimp [stateToTreeJson, stateToJson, TreeJson.toJson, TreeJson.toJsonObj]
  rw [toJsonList_map]
  have h_map : (s.cells.map (fun x => (stateCellToTreeJson x).toJson)) = s.cells.map stateCellToJson := by
    simp only [List.map_inj_left]; intro c _; exact stateCellToTreeJson_toJson c
  rw [h_map]

theorem stateToTreeJson_encode (s : StateEnc) :
    (stateToTreeJson s).encode = encodeState s := by
  dsimp [stateToTreeJson, encodeState]
  rw [encode_obj_eq_jsonObj]
  dsimp [List.map]
  rw [encode_arr_map]
  have h_map : (s.cells.map (fun x => (stateCellToTreeJson x).encode)) = s.cells.map encodeStateCell := by
    simp only [List.map_inj_left]; intro c _; exact stateCellToTreeJson_encode c
  rw [h_map]

theorem stateToTreeJson_valid (s : StateEnc) (h_len : s.cells.length ≤ 4096) :
    TreeJson.Valid (stateToTreeJson s) := by
  dsimp [stateToTreeJson, TreeJson.Valid, TreeJson.ValidObj]
  simp only [List.map_cons, List.map_nil]
  refine ⟨by decide, valid_arr_map stateCellToTreeJson s.cells h_len (fun c _ => stateCellToTreeJson_valid c), trivial⟩

def contextToTreeJson (ctx : ContextEnc) : TreeJson :=
  TreeJson.obj [
    ("principal", partyToTreeJson ctx.principal),
    ("domain", domainToTreeJson ctx.domain)
  ]

theorem contextToTreeJson_toJson (ctx : ContextEnc) :
    (contextToTreeJson ctx).toJson = contextToJson ctx := by
  dsimp [contextToTreeJson, contextToJson, TreeJson.toJson, TreeJson.toJsonObj]
  rw [partyToTreeJson_toJson, domainToTreeJson_toJson]

theorem contextToTreeJson_encode (ctx : ContextEnc) :
    (contextToTreeJson ctx).encode = encodeContext ctx := by
  dsimp [contextToTreeJson, encodeContext]
  rw [encode_obj_eq_jsonObj]
  dsimp [List.map]
  rw [partyToTreeJson_encode, domainToTreeJson_encode]

theorem contextToTreeJson_valid (ctx : ContextEnc) :
    TreeJson.Valid (contextToTreeJson ctx) := by
  dsimp [contextToTreeJson, TreeJson.Valid, TreeJson.ValidObj]
  simp only [List.map_cons, List.map_nil]
  refine ⟨by decide, partyToTreeJson_valid ctx.principal, domainToTreeJson_valid ctx.domain, trivial⟩

def observationToTreeJson (o : ObservationEnc) : TreeJson :=
  TreeJson.obj [
    ("value", packedValueFullToTreeJson o.value),
    ("timestamp", natToTreeJson o.timestamp)
  ]

theorem observationToTreeJson_toJson (o : ObservationEnc) :
    (observationToTreeJson o).toJson = observationToJson o := by
  dsimp [observationToTreeJson, observationToJson, TreeJson.toJson, TreeJson.toJsonObj]
  rw [packedValueFullToTreeJson_toJson, natToTreeJson_toJson]

theorem observationToTreeJson_encode (o : ObservationEnc) :
    (observationToTreeJson o).encode = encodeObservation o := by
  dsimp [observationToTreeJson, encodeObservation]
  rw [encode_obj_eq_jsonObj]
  dsimp [List.map]
  rw [packedValueFullToTreeJson_encode, natToTreeJson_encode]


theorem observationToTreeJson_valid (o : ObservationEnc) :
    TreeJson.Valid (observationToTreeJson o) := by
  dsimp [observationToTreeJson, TreeJson.Valid, TreeJson.ValidObj]
  simp only [List.map_cons, List.map_nil]
  refine ⟨by decide, packedValueFullToTreeJson_valid o.value, trivial, trivial⟩

def environmentEntryToTreeJson (e : EnvironmentEntryEnc) : TreeJson :=
  TreeJson.obj [
    ("key", observationKeyToTreeJson e.key),
    ("observation", observationToTreeJson e.observation)
  ]

theorem environmentEntryToTreeJson_toJson (e : EnvironmentEntryEnc) :
    (environmentEntryToTreeJson e).toJson = environmentEntryToJson e := by
  dsimp [environmentEntryToTreeJson, environmentEntryToJson, TreeJson.toJson, TreeJson.toJsonObj]
  rw [observationKeyToTreeJson_toJson, observationToTreeJson_toJson]

theorem environmentEntryToTreeJson_encode (e : EnvironmentEntryEnc) :
    (environmentEntryToTreeJson e).encode = encodeEnvironmentEntry e := by
  dsimp [environmentEntryToTreeJson, encodeEnvironmentEntry]
  rw [encode_obj_eq_jsonObj]
  dsimp [List.map]
  rw [observationKeyToTreeJson_encode, observationToTreeJson_encode]

theorem environmentEntryToTreeJson_valid (e : EnvironmentEntryEnc) :
    TreeJson.Valid (environmentEntryToTreeJson e) := by
  dsimp [environmentEntryToTreeJson, TreeJson.Valid, TreeJson.ValidObj]
  simp only [List.map_cons, List.map_nil]
  refine ⟨by decide, observationKeyToTreeJson_valid e.key, observationToTreeJson_valid e.observation, trivial⟩

def environmentToTreeJson (env : EnvironmentEnc) : TreeJson :=
  TreeJson.obj [("entries", TreeJson.arr (env.entries.map environmentEntryToTreeJson))]

theorem environmentToTreeJson_toJson (env : EnvironmentEnc) :
    (environmentToTreeJson env).toJson = environmentToJson env := by
  dsimp [environmentToTreeJson, environmentToJson, TreeJson.toJson, TreeJson.toJsonObj]
  rw [toJsonList_map]
  have h_map : (env.entries.map (fun x => (environmentEntryToTreeJson x).toJson)) = env.entries.map environmentEntryToJson := by
    simp only [List.map_inj_left]; intro e _; exact environmentEntryToTreeJson_toJson e
  rw [h_map]

theorem environmentToTreeJson_encode (env : EnvironmentEnc) :
    (environmentToTreeJson env).encode = encodeEnvironment env := by
  dsimp [environmentToTreeJson, encodeEnvironment]
  rw [encode_obj_eq_jsonObj]
  dsimp [List.map]
  rw [encode_arr_map]
  have h_map : (env.entries.map (fun x => (environmentEntryToTreeJson x).encode)) = env.entries.map encodeEnvironmentEntry := by
    simp only [List.map_inj_left]; intro e _; exact environmentEntryToTreeJson_encode e
  rw [h_map]

theorem environmentToTreeJson_valid (env : EnvironmentEnc) (h_len : env.entries.length ≤ 4096) :
    TreeJson.Valid (environmentToTreeJson env) := by
  dsimp [environmentToTreeJson, TreeJson.Valid, TreeJson.ValidObj]
  simp only [List.map_cons, List.map_nil]
  refine ⟨by decide, valid_arr_map environmentEntryToTreeJson env.entries h_len (fun e _ => environmentEntryToTreeJson_valid e), trivial⟩

def requestToTreeJson (r : RequestEnc) : TreeJson :=
  TreeJson.obj [
    ("operation", natToTreeJson r.operation),
    ("parties", TreeJson.arr (r.parties.map partyToTreeJson)),
    ("arguments", TreeJson.arr (r.arguments.map packedValueFullToTreeJson)),
    ("capabilityIds", TreeJson.arr (r.capabilityIds.map natToTreeJson)),
    ("claimedActor", match r.claimedActor with | some a => partyToTreeJson a | none => TreeJson.null)
  ]

theorem requestToTreeJson_encode (r : RequestEnc) :
    (requestToTreeJson r).encode = encodeRequest r := by
  dsimp [requestToTreeJson, encodeRequest]
  rw [encode_obj_eq_jsonObj]
  dsimp [List.map]
  rw [encode_arr_map, encode_arr_map, encode_arr_map]
  have h_ps : (r.parties.map (fun x => (partyToTreeJson x).encode)) = r.parties.map encodeParty := by
    simp only [List.map_inj_left]; intro p _; exact partyToTreeJson_encode p
  have h_args : (r.arguments.map (fun x => (packedValueFullToTreeJson x).encode)) = r.arguments.map encodePackedValue := by
    simp only [List.map_inj_left]; intro v _; exact packedValueFullToTreeJson_encode v
  have h_caps : (r.capabilityIds.map (fun x => (natToTreeJson x).encode)) = r.capabilityIds.map toString := by
    simp only [List.map_inj_left]; intro x _; exact natToTreeJson_encode x
  rw [h_ps, h_args, h_caps, natToTreeJson_encode]
  cases r.claimedActor with
  | none => rfl
  | some a =>
    dsimp
    rw [partyToTreeJson_encode]

theorem decodeRequest_requestToTreeJson (r : RequestEnc) (h_can : RequestCanonical r) :
    decodeRequest (requestToTreeJson r).toJson = .ok r := by
  cases r with | mk op parties args caps actor =>
  dsimp [requestToTreeJson, TreeJson.toJson, TreeJson.toJsonObj]
  rw [toJsonList_map, toJsonList_map, toJsonList_map]
  have h_ps : (parties.map (fun x => (partyToTreeJson x).toJson)) = parties.map partyToJson := by
    simp only [List.map_inj_left]; intro p _; exact partyToTreeJson_toJson p
  have h_args : (args.map (fun x => (packedValueFullToTreeJson x).toJson)) = args.map packedValueFullToJson := by
    simp only [List.map_inj_left]; intro v _; exact packedValueFullToTreeJson_toJson v
  have h_caps : (caps.map (fun x => (natToTreeJson x).toJson)) = caps.map natToJson := by
    simp only [List.map_inj_left]; intro c _; exact natToTreeJson_toJson c
  rw [h_ps, h_args, h_caps, natToTreeJson_toJson]
  cases actor with
  | none =>
    simp only [TreeJson.toJson]
    have h_order : decodeRequest (Json.mkObj [
        ("operation", Json.num (JsonNumber.fromNat op)),
        ("parties", Json.arr (parties.map partyToJson).toArray),
        ("arguments", Json.arr (args.map packedValueFullToJson).toArray),
        ("capabilityIds", Json.arr (caps.map natToJson).toArray),
        ("claimedActor", Json.null)]) =
      decodeRequest (Json.mkObj [
        ("arguments", Json.arr (args.map packedValueFullToJson).toArray),
        ("capabilityIds", Json.arr (caps.map natToJson).toArray),
        ("claimedActor", Json.null),
        ("operation", Json.num (JsonNumber.fromNat op)),
        ("parties", Json.arr (parties.map partyToJson).toArray)]) := by rfl
    rw [h_order]
    have h_req : decodeRequest (requestToJson ⟨op, parties, args, caps, none⟩) = .ok ⟨op, parties, args, caps, none⟩ :=
      decodeRequest_requestToJson ⟨op, parties, args, caps, none⟩ h_can
    exact h_req
  | some a =>
    have h_a : (partyToTreeJson a).toJson = partyToJson a := partyToTreeJson_toJson a
    dsimp
    rw [h_a]
    have h_order : decodeRequest (Json.mkObj [
        ("operation", Json.num (JsonNumber.fromNat op)),
        ("parties", Json.arr (parties.map partyToJson).toArray),
        ("arguments", Json.arr (args.map packedValueFullToJson).toArray),
        ("capabilityIds", Json.arr (caps.map natToJson).toArray),
        ("claimedActor", partyToJson a)]) =
      decodeRequest (Json.mkObj [
        ("arguments", Json.arr (args.map packedValueFullToJson).toArray),
        ("capabilityIds", Json.arr (caps.map natToJson).toArray),
        ("claimedActor", partyToJson a),
        ("operation", Json.num (JsonNumber.fromNat op)),
        ("parties", Json.arr (parties.map partyToJson).toArray)]) := by rfl
    rw [h_order]
    have h_req : decodeRequest (requestToJson ⟨op, parties, args, caps, some a⟩) = .ok ⟨op, parties, args, caps, some a⟩ :=
      decodeRequest_requestToJson ⟨op, parties, args, caps, some a⟩ h_can
    exact h_req

theorem requestToTreeJson_valid (r : RequestEnc)
    (h_ps : r.parties.length ≤ 4096)
    (h_args : r.arguments.length ≤ 4096)
    (h_caps : r.capabilityIds.length ≤ 4096) :
    TreeJson.Valid (requestToTreeJson r) := by
  dsimp [requestToTreeJson, TreeJson.Valid, TreeJson.ValidObj]
  simp only [List.map_cons, List.map_nil]
  refine ⟨by decide, trivial,
          valid_arr_map partyToTreeJson r.parties h_ps (fun p _ => partyToTreeJson_valid p),
          valid_arr_map packedValueFullToTreeJson r.arguments h_args (fun v _ => packedValueFullToTreeJson_valid v),
          valid_arr_map natToTreeJson r.capabilityIds h_caps (fun _ _ => trivial),
          ?_, trivial⟩
  cases r.claimedActor with
  | none => trivial
  | some a => exact partyToTreeJson_valid a

def sourcePinToTreeJson (pin : SourcePinEnc) : TreeJson :=
  TreeJson.obj [
    ("git", TreeJson.str pin.git),
    ("lean_toolchain", TreeJson.str pin.lean_toolchain),
    ("mathlib_rev", TreeJson.str pin.mathlib_rev),
    ("checker_candidate", TreeJson.str pin.checker_candidate),
    ("compiler_record", match pin.compiler_record with | some r => TreeJson.str r | none => TreeJson.null),
    ("audit_record", match pin.audit_record with | some r => TreeJson.str r | none => TreeJson.null)
  ]

theorem sourcePinToTreeJson_toJson (pin : SourcePinEnc) :
    (sourcePinToTreeJson pin).toJson = sourcePinToJson pin := by
  dsimp [sourcePinToTreeJson, sourcePinToJson, TreeJson.toJson, TreeJson.toJsonObj]
  cases pin.compiler_record <;> cases pin.audit_record <;> rfl

theorem sourcePinToTreeJson_encode (pin : SourcePinEnc) :
    (sourcePinToTreeJson pin).encode = encodeSourcePin pin := by
  dsimp [sourcePinToTreeJson, encodeSourcePin]
  rw [encode_obj_eq_jsonObj]
  dsimp [List.map, TreeJson.encode]
  have h_git : escapeTreeString pin.git = escapeJsonString pin.git := escapeTreeString_eq_escapeJsonString pin.git
  have h_tc : escapeTreeString pin.lean_toolchain = escapeJsonString pin.lean_toolchain := escapeTreeString_eq_escapeJsonString pin.lean_toolchain
  have h_ml : escapeTreeString pin.mathlib_rev = escapeJsonString pin.mathlib_rev := escapeTreeString_eq_escapeJsonString pin.mathlib_rev
  have h_cc : escapeTreeString pin.checker_candidate = escapeJsonString pin.checker_candidate := escapeTreeString_eq_escapeJsonString pin.checker_candidate
  rw [h_git, h_tc, h_ml, h_cc]
  cases pin.compiler_record <;> cases pin.audit_record <;> dsimp [TreeJson.encode] <;> try rw [escapeTreeString_eq_escapeJsonString] <;> rfl

theorem sourcePinToTreeJson_valid (pin : SourcePinEnc) :
    TreeJson.Valid (sourcePinToTreeJson pin) := by
  dsimp [sourcePinToTreeJson, TreeJson.Valid, TreeJson.ValidObj]
  simp only [List.map_cons, List.map_nil]
  refine ⟨by decide, trivial, trivial, trivial, trivial, ?_, ?_, trivial⟩
  · cases pin.compiler_record <;> trivial
  · cases pin.audit_record <;> trivial

def typesEnumToTreeJson (t : TypesEnumEnc) : TreeJson :=
  TreeJson.obj [
    ("parties", TreeJson.arr (t.parties.map partyToTreeJson)),
    ("assets", TreeJson.arr (t.assets.map assetToTreeJson)),
    ("domains", TreeJson.arr (t.domains.map domainToTreeJson))
  ]

theorem typesEnumToTreeJson_toJson (t : TypesEnumEnc) :
    (typesEnumToTreeJson t).toJson = typesEnumToJson t := by
  dsimp [typesEnumToTreeJson, typesEnumToJson, TreeJson.toJson, TreeJson.toJsonObj]
  rw [toJsonList_map, toJsonList_map, toJsonList_map]
  have h_ps : (t.parties.map (fun x => (partyToTreeJson x).toJson)) = t.parties.map partyToJson := by
    simp only [List.map_inj_left]; intro p _; exact partyToTreeJson_toJson p
  have h_as : (t.assets.map (fun x => (assetToTreeJson x).toJson)) = t.assets.map assetToJson := by
    simp only [List.map_inj_left]; intro a _; exact assetToTreeJson_toJson a
  have h_ds : (t.domains.map (fun x => (domainToTreeJson x).toJson)) = t.domains.map domainToJson := by
    simp only [List.map_inj_left]; intro d _; exact domainToTreeJson_toJson d
  rw [h_ps, h_as, h_ds]

theorem typesEnumToTreeJson_encode (t : TypesEnumEnc) :
    (typesEnumToTreeJson t).encode = encodeTypesEnum t := by
  dsimp [typesEnumToTreeJson, encodeTypesEnum]
  rw [encode_obj_eq_jsonObj]
  dsimp [List.map]
  rw [encode_arr_map, encode_arr_map, encode_arr_map]
  have h_ps : (t.parties.map (fun x => (partyToTreeJson x).encode)) = t.parties.map encodeParty := by
    simp only [List.map_inj_left]; intro p _; exact partyToTreeJson_encode p
  have h_as : (t.assets.map (fun x => (assetToTreeJson x).encode)) = t.assets.map encodeAsset := by
    simp only [List.map_inj_left]; intro a _; exact assetToTreeJson_encode a
  have h_ds : (t.domains.map (fun x => (domainToTreeJson x).encode)) = t.domains.map encodeDomain := by
    simp only [List.map_inj_left]; intro d _; exact domainToTreeJson_encode d
  rw [h_ps, h_as, h_ds]

theorem typesEnumToTreeJson_valid (t : TypesEnumEnc)
    (h_ps : t.parties.length ≤ 4096)
    (h_as : t.assets.length ≤ 4096)
    (h_ds : t.domains.length ≤ 4096) :
    TreeJson.Valid (typesEnumToTreeJson t) := by
  dsimp [typesEnumToTreeJson, TreeJson.Valid, TreeJson.ValidObj]
  simp only [List.map_cons, List.map_nil]
  refine ⟨by decide,
          valid_arr_map partyToTreeJson t.parties h_ps (fun p _ => partyToTreeJson_valid p),
          valid_arr_map assetToTreeJson t.assets h_as (fun a _ => assetToTreeJson_valid a),
          valid_arr_map domainToTreeJson t.domains h_ds (fun d _ => domainToTreeJson_valid d),
          trivial⟩

def libraryRefToTreeJson (lib : LibraryRefEnc) : TreeJson :=
  match lib.moduleName with
  | some m => TreeJson.obj [("theorem", TreeJson.str lib.theoremName), ("module", TreeJson.str m)]
  | none => TreeJson.obj [("theorem", TreeJson.str lib.theoremName)]

theorem libraryRefToTreeJson_encode (lib : LibraryRefEnc) :
    (libraryRefToTreeJson lib).encode = encodeLibraryRef lib := by
  dsimp [libraryRefToTreeJson, encodeLibraryRef]
  cases h : lib.moduleName with
  | none =>
    rw [encode_obj_eq_jsonObj]
    dsimp [List.map, TreeJson.encode]
    rw [escapeTreeString_eq_escapeJsonString]
  | some m =>
    rw [encode_obj_eq_jsonObj]
    dsimp [List.map, TreeJson.encode]
    rw [escapeTreeString_eq_escapeJsonString, escapeTreeString_eq_escapeJsonString]

theorem libraryRefToTreeJson_valid (lib : LibraryRefEnc) :
    TreeJson.Valid (libraryRefToTreeJson lib) := by
  dsimp [libraryRefToTreeJson]
  cases lib.moduleName with
  | none =>
    dsimp [TreeJson.Valid, TreeJson.ValidObj]
    simp only [List.map_cons, List.map_nil]
    refine ⟨by decide, trivial, trivial⟩
  | some m =>
    dsimp [TreeJson.Valid, TreeJson.ValidObj]
    simp only [List.map_cons, List.map_nil]
    refine ⟨by decide, trivial, trivial, trivial⟩

def worldToTreeJson (w : WorldEnc) : TreeJson :=
  TreeJson.obj [("state", stateToTreeJson w.state), ("capabilities", storeToTreeJson w.capabilities)]

theorem worldToTreeJson_encode (w : WorldEnc) :
    (worldToTreeJson w).encode = encodeWorld w := by
  dsimp [worldToTreeJson, encodeWorld]
  rw [encode_obj_eq_jsonObj]
  dsimp [List.map]
  rw [stateToTreeJson_encode, storeToTreeJson_encode]

def boundaryToTreeJson (b : BoundaryEnc) : TreeJson :=
  TreeJson.obj [("ctx", contextToTreeJson b.ctx), ("env", environmentToTreeJson b.env), ("now", natToTreeJson b.now)]

theorem boundaryToTreeJson_encode (b : BoundaryEnc) :
    (boundaryToTreeJson b).encode = encodeBoundary b := by
  dsimp [boundaryToTreeJson, encodeBoundary]
  rw [encode_obj_eq_jsonObj]
  dsimp [List.map]
  rw [contextToTreeJson_encode, environmentToTreeJson_encode, natToTreeJson_encode]

def envelopeToTreeJson (env : EnvelopeEnc) (payload : TreeJson) : TreeJson :=
  TreeJson.obj [
    ("schema_version", natToTreeJson env.schema_version),
    ("mode", TreeJson.str env.mode),
    ("source_pin", sourcePinToTreeJson env.source_pin),
    ("audit_roots", TreeJson.arr (env.audit_roots.map TreeJson.str)),
    ("types", typesEnumToTreeJson env.types),
    ("assumptions", TreeJson.arr (env.assumptions.map TreeJson.str)),
    ("invariants", TreeJson.arr (env.invariants.map TreeJson.str)),
    ("libraries", TreeJson.arr (env.libraries.map libraryRefToTreeJson)),
    ("source_map", sourceMapToTreeJson env.source_map),
    ("payload", payload),
    ("claimed_judgments", TreeJson.arr (env.claimed_judgments.map TreeJson.str)),
    ("claimed_next_state", match env.claimed_next_state with | some w => worldToTreeJson w | none => TreeJson.null),
    ("require_library_discharge", TreeJson.bool env.require_library_discharge),
    ("require_invariant_discharge", TreeJson.bool env.require_invariant_discharge)
  ]

theorem envelopeToTreeJson_encode (env : EnvelopeEnc) (payload : TreeJson)
    (h_sm : SourceMapSorted env.source_map) :
    (envelopeToTreeJson env payload).encode = encodeEnvelope env payload.encode := by
  dsimp [envelopeToTreeJson, encodeEnvelope]
  rw [encode_obj_eq_jsonObj]
  dsimp [List.map]
  rw [encode_arr_str, encode_arr_str, encode_arr_str, encode_arr_str, encode_arr_map]
  have h_libs : (env.libraries.map (fun x => (libraryRefToTreeJson x).encode)) = env.libraries.map encodeLibraryRef := by
    simp only [List.map_inj_left]; intro lib _; exact libraryRefToTreeJson_encode lib
  rw [h_libs]
  rw [sourceMapToTreeJson_encode env.source_map h_sm]
  rw [sourcePinToTreeJson_encode, typesEnumToTreeJson_encode, natToTreeJson_encode]
  have h_mode : (TreeJson.str env.mode).encode = escapeJsonString env.mode := escapeTreeString_eq_escapeJsonString env.mode
  rw [h_mode]
  cases env.claimed_next_state with
  | none =>
    cases env.require_library_discharge <;> cases env.require_invariant_discharge <;> rfl
  | some w =>
    rw [worldToTreeJson_encode]
    cases env.require_library_discharge <;> cases env.require_invariant_discharge <;> rfl

def cellDeltaToTreeJson (d : CellDeltaEnc) : TreeJson :=
  TreeJson.obj [
    ("asset", assetToTreeJson d.asset),
    ("target", cellRefToTreeJson d.target),
    ("amount", exprToTreeJson d.amount)
  ]

theorem cellDeltaToTreeJson_encode (d : CellDeltaEnc) :
    (cellDeltaToTreeJson d).encode = encodeCellDelta d := by
  dsimp [cellDeltaToTreeJson, encodeCellDelta]
  rw [encode_obj_eq_jsonObj]
  dsimp [List.map]
  rw [assetToTreeJson_encode, cellRefToTreeJson_encode, exprToTreeJson_encode]

theorem cellDeltaToTreeJson_valid (d : CellDeltaEnc) :
    TreeJson.Valid (cellDeltaToTreeJson d) := by
  dsimp [cellDeltaToTreeJson, TreeJson.Valid, TreeJson.ValidObj]
  simp only [List.map_cons, List.map_nil]
  refine ⟨by decide, assetToTreeJson_valid d.asset, cellRefToTreeJson_valid d.target, exprToTreeJson_valid d.amount, trivial⟩

def supplyDeltaToTreeJson (d : SupplyDeltaEnc) : TreeJson :=
  TreeJson.obj [
    ("domain", domainToTreeJson d.domain),
    ("asset", assetToTreeJson d.asset),
    ("amount", exprToTreeJson d.amount)
  ]

theorem supplyDeltaToTreeJson_encode (d : SupplyDeltaEnc) :
    (supplyDeltaToTreeJson d).encode = encodeSupplyDelta d := by
  dsimp [supplyDeltaToTreeJson, encodeSupplyDelta]
  rw [encode_obj_eq_jsonObj]
  dsimp [List.map]
  rw [domainToTreeJson_encode, assetToTreeJson_encode, exprToTreeJson_encode]

theorem supplyDeltaToTreeJson_valid (d : SupplyDeltaEnc) :
    TreeJson.Valid (supplyDeltaToTreeJson d) := by
  dsimp [supplyDeltaToTreeJson, TreeJson.Valid, TreeJson.ValidObj]
  simp only [List.map_cons, List.map_nil]
  refine ⟨by decide, domainToTreeJson_valid d.domain, assetToTreeJson_valid d.asset, exprToTreeJson_valid d.amount, trivial⟩

def envReadToTreeJson : EnvReadEnc → TreeJson
  | .observation k => TreeJson.obj [("tag", TreeJson.str "observation"), ("key", observationKeyToTreeJson k)]
  | .currentTime => TreeJson.obj [("tag", TreeJson.str "currentTime")]

theorem envReadToTreeJson_encode (e : EnvReadEnc) :
    (envReadToTreeJson e).encode = encodeEnvRead e := by
  cases e with
  | observation k =>
    dsimp [envReadToTreeJson, encodeEnvRead]
    rw [encode_obj_eq_jsonObj]
    dsimp [List.map, TreeJson.encode]
    rw [observationKeyToTreeJson_encode]
    rfl
  | currentTime => rfl

theorem envReadToTreeJson_valid (e : EnvReadEnc) :
    TreeJson.Valid (envReadToTreeJson e) := by
  cases e with
  | observation k =>
    dsimp [envReadToTreeJson, TreeJson.Valid, TreeJson.ValidObj]
    simp only [List.map_cons, List.map_nil]
    refine ⟨by decide, trivial, observationKeyToTreeJson_valid k, trivial⟩
  | currentTime =>
    dsimp [envReadToTreeJson, TreeJson.Valid, TreeJson.ValidObj]
    simp only [List.map_cons, List.map_nil]
    refine ⟨by decide, trivial, trivial⟩

def templateToTreeJson (t : TemplateEnc) : TreeJson :=
  TreeJson.obj [
    ("signature", TreeJson.arr (t.signature.map unitToTreeJson)),
    ("domain", domainToTreeJson t.domain),
    ("partyArity", natToTreeJson t.partyArity),
    ("guard", exprToTreeJson t.guard),
    ("deltas", TreeJson.arr (t.deltas.map cellDeltaToTreeJson)),
    ("supplyDeltas", TreeJson.arr (t.supplyDeltas.map supplyDeltaToTreeJson)),
    ("stateReads", TreeJson.arr (t.stateReads.map packedCellRefToTreeJson)),
    ("envReads", TreeJson.arr (t.envReads.map envReadToTreeJson)),
    ("writes", TreeJson.arr (t.writes.map packedCellRefToTreeJson))
  ]

theorem templateToTreeJson_encode (t : TemplateEnc) :
    (templateToTreeJson t).encode = encodeTemplate t := by
  dsimp [templateToTreeJson, encodeTemplate]
  rw [encode_obj_eq_jsonObj]
  dsimp [List.map]
  rw [encode_arr_map, encode_arr_map, encode_arr_map, encode_arr_map, encode_arr_map, encode_arr_map]
  have h_sig : (t.signature.map (fun x => (unitToTreeJson x).encode)) = t.signature.map encodeUnit := by
    simp only [List.map_inj_left]; intro u _; exact unitToTreeJson_encode u
  have h_del : (t.deltas.map (fun x => (cellDeltaToTreeJson x).encode)) = t.deltas.map encodeCellDelta := by
    simp only [List.map_inj_left]; intro d _; exact cellDeltaToTreeJson_encode d
  have h_sdel : (t.supplyDeltas.map (fun x => (supplyDeltaToTreeJson x).encode)) = t.supplyDeltas.map encodeSupplyDelta := by
    simp only [List.map_inj_left]; intro sd _; exact supplyDeltaToTreeJson_encode sd
  have h_srd : (t.stateReads.map (fun x => (packedCellRefToTreeJson x).encode)) = t.stateReads.map encodePackedCellRef := by
    simp only [List.map_inj_left]; intro sr _; exact packedCellRefToTreeJson_encode sr
  have h_erd : (t.envReads.map (fun x => (envReadToTreeJson x).encode)) = t.envReads.map encodeEnvRead := by
    simp only [List.map_inj_left]; intro er _; exact envReadToTreeJson_encode er
  have h_wrt : (t.writes.map (fun x => (packedCellRefToTreeJson x).encode)) = t.writes.map encodePackedCellRef := by
    simp only [List.map_inj_left]; intro w _; exact packedCellRefToTreeJson_encode w
  rw [h_sig, h_del, h_sdel, h_srd, h_erd, h_wrt]
  rw [domainToTreeJson_encode, exprToTreeJson_encode, natToTreeJson_encode]

theorem templateToTreeJson_valid (t : TemplateEnc)
    (h_sig : t.signature.length ≤ 4096)
    (h_del : t.deltas.length ≤ 4096)
    (h_sdel : t.supplyDeltas.length ≤ 4096)
    (h_srd : t.stateReads.length ≤ 4096)
    (h_erd : t.envReads.length ≤ 4096)
    (h_wrt : t.writes.length ≤ 4096) :
    TreeJson.Valid (templateToTreeJson t) := by
  dsimp [templateToTreeJson, TreeJson.Valid, TreeJson.ValidObj]
  simp only [List.map_cons, List.map_nil]
  refine ⟨by decide,
          valid_arr_map unitToTreeJson t.signature h_sig (fun u _ => unitToTreeJson_valid u),
          domainToTreeJson_valid t.domain,
          trivial,
          exprToTreeJson_valid t.guard,
          valid_arr_map cellDeltaToTreeJson t.deltas h_del (fun d _ => cellDeltaToTreeJson_valid d),
          valid_arr_map supplyDeltaToTreeJson t.supplyDeltas h_sdel (fun sd _ => supplyDeltaToTreeJson_valid sd),
          valid_arr_map packedCellRefToTreeJson t.stateReads h_srd (fun sr _ => packedCellRefToTreeJson_valid sr),
          valid_arr_map envReadToTreeJson t.envReads h_erd (fun er _ => envReadToTreeJson_valid er),
          valid_arr_map packedCellRefToTreeJson t.writes h_wrt (fun w _ => packedCellRefToTreeJson_valid w),
          trivial⟩

def registryEntryToTreeJson (e : RegistryEntryEnc) : TreeJson :=
  TreeJson.obj [("id", natToTreeJson e.id), ("template", templateToTreeJson e.template)]

theorem registryEntryToTreeJson_encode (e : RegistryEntryEnc) :
    (registryEntryToTreeJson e).encode = encodeRegistryEntry e := by
  dsimp [registryEntryToTreeJson, encodeRegistryEntry]
  rw [encode_obj_eq_jsonObj]
  dsimp [List.map]
  rw [natToTreeJson_encode, templateToTreeJson_encode]

theorem registryEntryToTreeJson_valid (e : RegistryEntryEnc)
    (h_sig : e.template.signature.length ≤ 4096)
    (h_del : e.template.deltas.length ≤ 4096)
    (h_sdel : e.template.supplyDeltas.length ≤ 4096)
    (h_srd : e.template.stateReads.length ≤ 4096)
    (h_erd : e.template.envReads.length ≤ 4096)
    (h_wrt : e.template.writes.length ≤ 4096) :
    TreeJson.Valid (registryEntryToTreeJson e) := by
  dsimp [registryEntryToTreeJson, TreeJson.Valid, TreeJson.ValidObj]
  simp only [List.map_cons, List.map_nil]
  refine ⟨by decide, trivial, templateToTreeJson_valid e.template h_sig h_del h_sdel h_srd h_erd h_wrt, trivial⟩

def registryToTreeJson (r : RegistryEnc) : TreeJson :=
  TreeJson.obj [("entries", TreeJson.arr (r.entries.map registryEntryToTreeJson))]

theorem registryToTreeJson_encode (r : RegistryEnc) :
    (registryToTreeJson r).encode = encodeRegistry r := by
  dsimp [registryToTreeJson, encodeRegistry]
  rw [encode_obj_eq_jsonObj]
  dsimp [List.map]
  rw [encode_arr_map]
  have h_map : (r.entries.map (fun x => (registryEntryToTreeJson x).encode)) = r.entries.map encodeRegistryEntry := by
    simp only [List.map_inj_left]; intro e _; exact registryEntryToTreeJson_encode e
  rw [h_map]

def domainAdminToTreeJson (d : DomainAdminEnc) : TreeJson :=
  TreeJson.obj [("domain", domainToTreeJson d.domain), ("party", partyToTreeJson d.party)]

theorem domainAdminToTreeJson_encode (d : DomainAdminEnc) :
    (domainAdminToTreeJson d).encode = encodeDomainAdmin d := by
  dsimp [domainAdminToTreeJson, encodeDomainAdmin]
  rw [encode_obj_eq_jsonObj]
  dsimp [List.map]
  rw [domainToTreeJson_encode, partyToTreeJson_encode]

theorem domainAdminToTreeJson_valid (d : DomainAdminEnc) :
    TreeJson.Valid (domainAdminToTreeJson d) := by
  dsimp [domainAdminToTreeJson, TreeJson.Valid, TreeJson.ValidObj]
  simp only [List.map_cons, List.map_nil]
  refine ⟨by decide, domainToTreeJson_valid d.domain, partyToTreeJson_valid d.party, trivial⟩

def inputPortToTreeJson (p : InputPortEnc) : TreeJson :=
  TreeJson.obj [("id", natToTreeJson p.id), ("unit", unitToTreeJson p.unit)]

theorem inputPortToTreeJson_encode (p : InputPortEnc) :
    (inputPortToTreeJson p).encode = encodeInputPort p := by
  dsimp [inputPortToTreeJson, encodeInputPort]
  rw [encode_obj_eq_jsonObj]
  dsimp [List.map]
  rw [natToTreeJson_encode, unitToTreeJson_encode]

theorem inputPortToTreeJson_valid (p : InputPortEnc) :
    TreeJson.Valid (inputPortToTreeJson p) := by
  dsimp [inputPortToTreeJson, TreeJson.Valid, TreeJson.ValidObj]
  simp only [List.map_cons, List.map_nil]
  refine ⟨by decide, trivial, unitToTreeJson_valid p.unit, trivial⟩

def outputPortToTreeJson (p : OutputPortEnc) : TreeJson :=
  TreeJson.obj [("id", natToTreeJson p.id), ("cell", cellToTreeJson p.cell)]

theorem outputPortToTreeJson_encode (p : OutputPortEnc) :
    (outputPortToTreeJson p).encode = encodeOutputPort p := by
  dsimp [outputPortToTreeJson, encodeOutputPort]
  rw [encode_obj_eq_jsonObj]
  dsimp [List.map]
  rw [natToTreeJson_encode, cellToTreeJson_encode]

theorem outputPortToTreeJson_valid (p : OutputPortEnc) :
    TreeJson.Valid (outputPortToTreeJson p) := by
  dsimp [outputPortToTreeJson, TreeJson.Valid, TreeJson.ValidObj]
  simp only [List.map_cons, List.map_nil]
  refine ⟨by decide, trivial, cellToTreeJson_valid p.cell, trivial⟩

def resourcePortToTreeJson (p : ResourcePortEnc) : TreeJson :=
  TreeJson.obj [
    ("id", natToTreeJson p.id),
    ("cell", cellToTreeJson p.cell),
    ("writable", TreeJson.bool p.writable)
  ]

theorem resourcePortToTreeJson_encode (p : ResourcePortEnc) :
    (resourcePortToTreeJson p).encode = encodeResourcePort p := by
  dsimp [resourcePortToTreeJson, encodeResourcePort]
  rw [encode_obj_eq_jsonObj]
  dsimp [List.map]
  rw [natToTreeJson_encode, cellToTreeJson_encode]
  cases p.writable <;> rfl

theorem resourcePortToTreeJson_valid (p : ResourcePortEnc) :
    TreeJson.Valid (resourcePortToTreeJson p) := by
  dsimp [resourcePortToTreeJson, TreeJson.Valid, TreeJson.ValidObj]
  simp only [List.map_cons, List.map_nil]
  refine ⟨by decide, trivial, cellToTreeJson_valid p.cell, trivial, trivial⟩

def qualifiedPortToTreeJson (qp : QualifiedPortEnc) : TreeJson :=
  TreeJson.obj [("component", natToTreeJson qp.component), ("port", natToTreeJson qp.port)]

theorem qualifiedPortToTreeJson_encode (qp : QualifiedPortEnc) :
    (qualifiedPortToTreeJson qp).encode = encodeQualifiedPort qp := by
  dsimp [qualifiedPortToTreeJson, encodeQualifiedPort]
  rw [encode_obj_eq_jsonObj]
  dsimp [List.map]
  rw [natToTreeJson_encode, natToTreeJson_encode]

theorem qualifiedPortToTreeJson_valid (qp : QualifiedPortEnc) :
    TreeJson.Valid (qualifiedPortToTreeJson qp) := by
  dsimp [qualifiedPortToTreeJson, TreeJson.Valid, TreeJson.ValidObj]
  simp only [List.map_cons, List.map_nil]
  refine ⟨by decide, trivial, trivial, trivial⟩

def resourceImportToTreeJson (ri : ResourceImportEnc) : TreeJson :=
  TreeJson.obj [
    ("source", qualifiedPortToTreeJson ri.source),
    ("cell", cellToTreeJson ri.cell),
    ("writable", TreeJson.bool ri.writable)
  ]

theorem resourceImportToTreeJson_encode (ri : ResourceImportEnc) :
    (resourceImportToTreeJson ri).encode = encodeResourceImport ri := by
  dsimp [resourceImportToTreeJson, encodeResourceImport]
  rw [encode_obj_eq_jsonObj]
  dsimp [List.map]
  rw [qualifiedPortToTreeJson_encode, cellToTreeJson_encode]
  cases ri.writable <;> rfl

theorem resourceImportToTreeJson_valid (ri : ResourceImportEnc) :
    TreeJson.Valid (resourceImportToTreeJson ri) := by
  dsimp [resourceImportToTreeJson, TreeJson.Valid, TreeJson.ValidObj]
  simp only [List.map_cons, List.map_nil]
  refine ⟨by decide, qualifiedPortToTreeJson_valid ri.source, cellToTreeJson_valid ri.cell, trivial, trivial⟩

def operationInterfaceToTreeJson (op : OperationInterfaceEnc) : TreeJson :=
  TreeJson.obj [
    ("operation", natToTreeJson op.operation),
    ("inputs", TreeJson.arr (op.inputs.map inputPortToTreeJson)),
    ("outputs", TreeJson.arr (op.outputs.map outputPortToTreeJson))
  ]

theorem operationInterfaceToTreeJson_encode (op : OperationInterfaceEnc) :
    (operationInterfaceToTreeJson op).encode = encodeOperationInterface op := by
  dsimp [operationInterfaceToTreeJson, encodeOperationInterface]
  rw [encode_obj_eq_jsonObj]
  dsimp [List.map]
  rw [encode_arr_map, encode_arr_map]
  have h_ins : (op.inputs.map (fun x => (inputPortToTreeJson x).encode)) = op.inputs.map encodeInputPort := by
    simp only [List.map_inj_left]; intro x _; exact inputPortToTreeJson_encode x
  have h_outs : (op.outputs.map (fun x => (outputPortToTreeJson x).encode)) = op.outputs.map encodeOutputPort := by
    simp only [List.map_inj_left]; intro x _; exact outputPortToTreeJson_encode x
  rw [h_ins, h_outs, natToTreeJson_encode]

def componentToTreeJson (c : ComponentEnc) : TreeJson :=
  TreeJson.obj [
    ("id", natToTreeJson c.id),
    ("privateCells", TreeJson.arr (c.privateCells.map cellToTreeJson)),
    ("exports", TreeJson.arr (c.exports.map resourcePortToTreeJson)),
    ("imports", TreeJson.arr (c.imports.map resourceImportToTreeJson)),
    ("operations", TreeJson.arr (c.operations.map operationInterfaceToTreeJson))
  ]

theorem componentToTreeJson_encode (c : ComponentEnc) :
    (componentToTreeJson c).encode = encodeComponent c := by
  dsimp [componentToTreeJson, encodeComponent]
  rw [encode_obj_eq_jsonObj]
  dsimp [List.map]
  rw [encode_arr_map, encode_arr_map, encode_arr_map, encode_arr_map]
  have h_privs : (c.privateCells.map (fun x => (cellToTreeJson x).encode)) = c.privateCells.map encodeCell := by
    simp only [List.map_inj_left]; intro x _; exact cellToTreeJson_encode x
  have h_exps : (c.exports.map (fun x => (resourcePortToTreeJson x).encode)) = c.exports.map encodeResourcePort := by
    simp only [List.map_inj_left]; intro x _; exact resourcePortToTreeJson_encode x
  have h_imps : (c.imports.map (fun x => (resourceImportToTreeJson x).encode)) = c.imports.map encodeResourceImport := by
    simp only [List.map_inj_left]; intro x _; exact resourceImportToTreeJson_encode x
  have h_ops : (c.operations.map (fun x => (operationInterfaceToTreeJson x).encode)) = c.operations.map encodeOperationInterface := by
    simp only [List.map_inj_left]; intro x _; exact operationInterfaceToTreeJson_encode x
  rw [h_privs, h_exps, h_imps, h_ops, natToTreeJson_encode]

def configToTreeJson (c : ConfigEnc) : TreeJson :=
  TreeJson.obj [
    ("registry", registryToTreeJson c.registry),
    ("domainAdmin", TreeJson.arr (c.domainAdmin.map domainAdminToTreeJson)),
    ("catalog", TreeJson.arr (c.catalog.map componentToTreeJson))
  ]

theorem configToTreeJson_encode (c : ConfigEnc) :
    (configToTreeJson c).encode = encodeConfig c := by
  dsimp [configToTreeJson, encodeConfig]
  rw [encode_obj_eq_jsonObj]
  dsimp [List.map]
  rw [encode_arr_map, encode_arr_map]
  have h_adm : (c.domainAdmin.map (fun x => (domainAdminToTreeJson x).encode)) = c.domainAdmin.map encodeDomainAdmin := by
    simp only [List.map_inj_left]; intro x _; exact domainAdminToTreeJson_encode x
  have h_cat : (c.catalog.map (fun x => (componentToTreeJson x).encode)) = c.catalog.map encodeComponent := by
    simp only [List.map_inj_left]; intro x _; exact componentToTreeJson_encode x
  rw [h_adm, h_cat, registryToTreeJson_encode]

def inputSourceToTreeJson : InputSourceEnc → TreeJson
  | .literal v => TreeJson.obj [("tag", TreeJson.str "literal"), ("value", packedValueFullToTreeJson v)]
  | .priorOutput step port =>
    TreeJson.obj [
      ("tag", TreeJson.str "priorOutput"),
      ("step", natToTreeJson step),
      ("port", qualifiedPortToTreeJson port)
    ]

theorem inputSourceToTreeJson_encode (i : InputSourceEnc) :
    (inputSourceToTreeJson i).encode = encodeInputSource i := by
  cases i with
  | literal v =>
    dsimp [inputSourceToTreeJson, encodeInputSource]
    rw [encode_obj_eq_jsonObj]
    dsimp [List.map, TreeJson.encode]
    rw [packedValueFullToTreeJson_encode]
    rfl
  | priorOutput step port =>
    dsimp [inputSourceToTreeJson, encodeInputSource]
    rw [encode_obj_eq_jsonObj]
    dsimp [List.map, TreeJson.encode]
    rw [natToTreeJson_encode, qualifiedPortToTreeJson_encode]
    rfl

def invocationToTreeJson (inv : InvocationEnc) : TreeJson :=
  TreeJson.obj [
    ("component", natToTreeJson inv.component),
    ("operation", natToTreeJson inv.operation),
    ("parties", TreeJson.arr (inv.parties.map partyToTreeJson)),
    ("inputs", TreeJson.arr (inv.inputs.map inputSourceToTreeJson)),
    ("capabilityIds", TreeJson.arr (inv.capabilityIds.map natToTreeJson)),
    ("claimedActor", match inv.claimedActor with | some a => partyToTreeJson a | none => TreeJson.null)
  ]

theorem invocationToTreeJson_encode (inv : InvocationEnc) :
    (invocationToTreeJson inv).encode = encodeInvocation inv := by
  dsimp [invocationToTreeJson, encodeInvocation]
  rw [encode_obj_eq_jsonObj]
  dsimp [List.map]
  rw [encode_arr_map, encode_arr_map, encode_arr_map]
  have h_ps : (inv.parties.map (fun x => (partyToTreeJson x).encode)) = inv.parties.map encodeParty := by
    simp only [List.map_inj_left]; intro x _; exact partyToTreeJson_encode x
  have h_ins : (inv.inputs.map (fun x => (inputSourceToTreeJson x).encode)) = inv.inputs.map encodeInputSource := by
    simp only [List.map_inj_left]; intro x _; exact inputSourceToTreeJson_encode x
  have h_caps : (inv.capabilityIds.map (fun x => (natToTreeJson x).encode)) = inv.capabilityIds.map toString := by
    simp only [List.map_inj_left]; intro x _; exact natToTreeJson_encode x
  rw [h_ps, h_ins, h_caps, natToTreeJson_encode, natToTreeJson_encode]
  cases inv.claimedActor with
  | none => rfl
  | some a =>
    dsimp
    rw [partyToTreeJson_encode]

def stepToTreeJson : StepEnc → TreeJson
  | .invoke inv => TreeJson.obj [("tag", TreeJson.str "invoke"), ("invocation", invocationToTreeJson inv)]
  | .issue g => TreeJson.obj [("tag", TreeJson.str "issue"), ("grant", grantToTreeJson g)]
  | .revoke id => TreeJson.obj [("tag", TreeJson.str "revoke"), ("id", natToTreeJson id)]
  | .unsupported tag => TreeJson.obj [("tag", TreeJson.str tag)]

theorem stepToTreeJson_encode (s : StepEnc) (h_can : StepCanonical s) :
    (stepToTreeJson s).encode = encodeStep s := by
  cases s with
  | invoke inv =>
    dsimp [stepToTreeJson, encodeStep]
    rw [encode_obj_eq_jsonObj]
    dsimp [List.map, TreeJson.encode]
    rw [invocationToTreeJson_encode]
    rfl
  | issue g =>
    dsimp [stepToTreeJson, encodeStep]
    rw [encode_obj_eq_jsonObj]
    dsimp [List.map, TreeJson.encode]
    rw [grantToTreeJson_encode]
    rfl
  | revoke id =>
    dsimp [stepToTreeJson, encodeStep]
    rw [encode_obj_eq_jsonObj]
    dsimp [List.map, TreeJson.encode]
    rw [natToTreeJson_encode]
    rfl
  | unsupported tag =>
    cases h_can

def outputObservationToTreeJson (o : OutputObservationEnc) : TreeJson :=
  TreeJson.obj [
    ("step", natToTreeJson o.step),
    ("port", qualifiedPortToTreeJson o.port),
    ("value", packedValueFullToTreeJson o.value)
  ]

theorem outputObservationToTreeJson_encode (o : OutputObservationEnc) :
    (outputObservationToTreeJson o).encode = encodeOutputObservation o := by
  dsimp [outputObservationToTreeJson, encodeOutputObservation]
  rw [encode_obj_eq_jsonObj]
  dsimp [List.map]
  rw [natToTreeJson_encode, qualifiedPortToTreeJson_encode, packedValueFullToTreeJson_encode]

def typedExecutePayloadToTreeJson (p : TypedExecutePayloadEnc) : TreeJson :=
  TreeJson.obj [
    ("registry", registryToTreeJson p.registry),
    ("store", storeToTreeJson p.store),
    ("ctx", contextToTreeJson p.ctx),
    ("env", environmentToTreeJson p.env),
    ("now", natToTreeJson p.now),
    ("request", requestToTreeJson p.request),
    ("state", stateToTreeJson p.state)
  ]

theorem typedExecutePayloadToTreeJson_encode (p : TypedExecutePayloadEnc) :
    (typedExecutePayloadToTreeJson p).encode = encodeTypedExecutePayload p := by
  dsimp [typedExecutePayloadToTreeJson, encodeTypedExecutePayload]
  rw [encode_obj_eq_jsonObj]
  dsimp [List.map]
  rw [registryToTreeJson_encode, storeToTreeJson_encode, contextToTreeJson_encode,
      environmentToTreeJson_encode, natToTreeJson_encode, requestToTreeJson_encode,
      stateToTreeJson_encode]

def compositionStepPayloadToTreeJson (p : CompositionStepPayloadEnc) : TreeJson :=
  TreeJson.obj [
    ("config", configToTreeJson p.config),
    ("boundary", boundaryToTreeJson p.boundary),
    ("index", natToTreeJson p.index),
    ("history", TreeJson.arr (p.history.map outputObservationToTreeJson)),
    ("step", stepToTreeJson p.step),
    ("pre", worldToTreeJson p.pre)
  ]

theorem compositionStepPayloadToTreeJson_encode (p : CompositionStepPayloadEnc) (h_can : StepCanonical p.step) :
    (compositionStepPayloadToTreeJson p).encode = encodeCompositionStepPayload p := by
  dsimp [compositionStepPayloadToTreeJson, encodeCompositionStepPayload]
  rw [encode_obj_eq_jsonObj]
  dsimp [List.map]
  rw [configToTreeJson_encode, boundaryToTreeJson_encode, natToTreeJson_encode, encode_arr_map]
  have h_hist : (p.history.map (fun x => (outputObservationToTreeJson x).encode)) = p.history.map encodeOutputObservation := by
    simp only [List.map_inj_left]; intro x _; exact outputObservationToTreeJson_encode x
  rw [h_hist]
  rw [stepToTreeJson_encode p.step h_can, worldToTreeJson_encode]

def compositionRunPayloadToTreeJson (p : CompositionRunPayloadEnc) : TreeJson :=
  TreeJson.obj [
    ("config", configToTreeJson p.config),
    ("boundaries", TreeJson.arr (p.boundaries.map boundaryToTreeJson)),
    ("world", worldToTreeJson p.world),
    ("steps", TreeJson.arr (p.steps.map stepToTreeJson))
  ]

theorem compositionRunPayloadToTreeJson_encode (p : CompositionRunPayloadEnc) (h_can : ∀ s ∈ p.steps, StepCanonical s) :
    (compositionRunPayloadToTreeJson p).encode = encodeCompositionRunPayload p := by
  dsimp [compositionRunPayloadToTreeJson, encodeCompositionRunPayload]
  rw [encode_obj_eq_jsonObj]
  dsimp [List.map]
  rw [configToTreeJson_encode, encode_arr_map, worldToTreeJson_encode, encode_arr_map]
  have h_bs : (p.boundaries.map (fun x => (boundaryToTreeJson x).encode)) = p.boundaries.map encodeBoundary := by
    simp only [List.map_inj_left]; intro x _; exact boundaryToTreeJson_encode x
  have h_ss : (p.steps.map (fun x => (stepToTreeJson x).encode)) = p.steps.map encodeStep := by
    simp only [List.map_inj_left]; intro s hs; exact stepToTreeJson_encode s (h_can s hs)
  rw [h_bs, h_ss]

def moduleToTreeJson : DecodedIR → TreeJson
  | .execution (.typed env p) =>
    envelopeToTreeJson env (typedExecutePayloadToTreeJson p)
  | .execution (.step env p) =>
    envelopeToTreeJson env (compositionStepPayloadToTreeJson p)
  | .execution (.run env p) =>
    envelopeToTreeJson env (compositionRunPayloadToTreeJson p)
  | .audit _ => TreeJson.null
  | .codec _ => TreeJson.null

theorem moduleToTreeJson_encode (ir : DecodedIR) (h_adm : StructurallyAdmissibleIR ir) :
    (moduleToTreeJson ir).encode = encodeModuleString ir := by
  rcases h_adm with ⟨h_sup, h_can⟩
  dsimp [SupportedIR] at h_sup
  rcases h_sup with ⟨h_byte, h_depth, h_arr, h_ir_sup⟩
  cases ir with
  | execution ex =>
    cases ex with
    | typed env p =>
      dsimp [moduleToTreeJson, encodeModuleString]
      dsimp [CanonicalIR] at h_can
      rcases h_can with ⟨h_sm, _⟩
      rw [envelopeToTreeJson_encode env (typedExecutePayloadToTreeJson p) h_sm]
      rw [typedExecutePayloadToTreeJson_encode]
    | step env p =>
      dsimp [moduleToTreeJson, encodeModuleString]
      dsimp [CanonicalIR] at h_can
      rcases h_can with ⟨h_sm, _, _, h_step_can, _⟩
      rw [envelopeToTreeJson_encode env (compositionStepPayloadToTreeJson p) h_sm]
      rw [compositionStepPayloadToTreeJson_encode p h_step_can]
    | run env p =>
      dsimp [moduleToTreeJson, encodeModuleString]
      dsimp [CanonicalIR] at h_can
      rcases h_can with ⟨h_sm, _, _, h_steps_can, _⟩
      rw [envelopeToTreeJson_encode env (compositionRunPayloadToTreeJson p) h_sm]
      rw [compositionRunPayloadToTreeJson_encode p h_steps_can]
  | audit a =>
    dsimp [CanonicalIR] at h_can
  | codec doc =>
    dsimp [CanonicalIR] at h_can

theorem cellDeltaToTreeJson_toJson (d : CellDeltaEnc) :
    (cellDeltaToTreeJson d).toJson = cellDeltaToJson d := by
  dsimp [cellDeltaToTreeJson, cellDeltaToJson, TreeJson.toJson, TreeJson.toJsonObj]
  rw [assetToTreeJson_toJson, cellRefToTreeJson_toJson, exprToTreeJson_toJson]

theorem supplyDeltaToTreeJson_toJson (d : SupplyDeltaEnc) :
    (supplyDeltaToTreeJson d).toJson = supplyDeltaToJson d := by
  dsimp [supplyDeltaToTreeJson, supplyDeltaToJson, TreeJson.toJson, TreeJson.toJsonObj]
  rw [domainToTreeJson_toJson, assetToTreeJson_toJson, exprToTreeJson_toJson]

theorem envReadToTreeJson_toJson (e : EnvReadEnc) :
    (envReadToTreeJson e).toJson = envReadToJson e := by
  cases e with
  | observation k =>
    dsimp [envReadToTreeJson, envReadToJson, TreeJson.toJson, TreeJson.toJsonObj]
    rw [observationKeyToTreeJson_toJson]
  | currentTime =>
    rfl

theorem templateToTreeJson_toJson (t : TemplateEnc) :
    (templateToTreeJson t).toJson = templateToJson t := by
  dsimp [templateToTreeJson, templateToJson, TreeJson.toJson, TreeJson.toJsonObj]
  rw [toJsonList_map, toJsonList_map, toJsonList_map, toJsonList_map, toJsonList_map, toJsonList_map]
  have h_sig : (t.signature.map (fun x => (unitToTreeJson x).toJson)) = t.signature.map unitToJson := by
    simp only [List.map_inj_left]; intro u _; exact unitToTreeJson_toJson u
  have h_del : (t.deltas.map (fun x => (cellDeltaToTreeJson x).toJson)) = t.deltas.map cellDeltaToJson := by
    simp only [List.map_inj_left]; intro x _; exact cellDeltaToTreeJson_toJson x
  have h_sdel : (t.supplyDeltas.map (fun x => (supplyDeltaToTreeJson x).toJson)) = t.supplyDeltas.map supplyDeltaToJson := by
    simp only [List.map_inj_left]; intro x _; exact supplyDeltaToTreeJson_toJson x
  have h_srd : (t.stateReads.map (fun x => (packedCellRefToTreeJson x).toJson)) = t.stateReads.map packedCellRefToJson := by
    simp only [List.map_inj_left]; intro x _; exact packedCellRefToTreeJson_toJson x
  have h_erd : (t.envReads.map (fun x => (envReadToTreeJson x).toJson)) = t.envReads.map envReadToJson := by
    simp only [List.map_inj_left]; intro x _; exact envReadToTreeJson_toJson x
  have h_wrt : (t.writes.map (fun x => (packedCellRefToTreeJson x).toJson)) = t.writes.map packedCellRefToJson := by
    simp only [List.map_inj_left]; intro x _; exact packedCellRefToTreeJson_toJson x
  rw [h_sig, h_del, h_sdel, h_srd, h_erd, h_wrt]
  rw [domainToTreeJson_toJson, natToTreeJson_toJson, exprToTreeJson_toJson]

theorem registryEntryToTreeJson_toJson (e : RegistryEntryEnc) :
    (registryEntryToTreeJson e).toJson = registryEntryToJson e := by
  dsimp [registryEntryToTreeJson, registryEntryToJson, TreeJson.toJson, TreeJson.toJsonObj]
  rw [natToTreeJson_toJson, templateToTreeJson_toJson]

theorem registryToTreeJson_toJson (r : RegistryEnc) :
    (registryToTreeJson r).toJson = registryToJson r := by
  dsimp [registryToTreeJson, registryToJson, TreeJson.toJson, TreeJson.toJsonObj]
  rw [toJsonList_map]
  have h_map : (r.entries.map (fun x => (registryEntryToTreeJson x).toJson)) = r.entries.map registryEntryToJson := by
    simp only [List.map_inj_left]; intro e _; exact registryEntryToTreeJson_toJson e
  rw [h_map]

theorem decodeWorld_worldToTreeJson (w : WorldEnc)
    (h_st_valid : ∀ c ∈ w.state.cells, c.amount.den ≠ 0 ∧ Int.gcd c.amount.num.natAbs c.amount.den = 1 ∧ c.amount.num ≥ 0)
    (h_st_unique : (w.state.cells.map (fun c => (c.domain, c.party, c.asset))).eraseDups.length = w.state.cells.length) :
    decodeWorld (worldToTreeJson w).toJson = .ok w := by
  dsimp [worldToTreeJson, TreeJson.toJson, TreeJson.toJsonObj]
  rw [stateToTreeJson_toJson, storeToTreeJson_toJson]
  unfold decodeWorld
  dsimp [Json.mkObj]
  have h_dec : (do
      checkObjectKeys
          (Std.TreeMap.Raw.ofList [("state", stateToJson w.state), ("capabilities", storeToJson w.capabilities)]
              compare).toList
          ["state", "capabilities"]
      let sJ ←
        getField
            (Std.TreeMap.Raw.ofList [("state", stateToJson w.state), ("capabilities", storeToJson w.capabilities)]
                compare).toList
            "state"
      let state ← decodeState sJ
      let cJ ←
        getField
            (Std.TreeMap.Raw.ofList [("state", stateToJson w.state), ("capabilities", storeToJson w.capabilities)]
                compare).toList
            "capabilities"
      let caps ← decodeStore cJ
      Except.ok (⟨state, caps⟩ : WorldEnc)) = (do
      let state ← decodeState (stateToJson w.state)
      let caps ← decodeStore (storeToJson w.capabilities)
      Except.ok (⟨state, caps⟩ : WorldEnc)) := rfl
  rw [h_dec]
  have h_st := decodeState_stateToJson w.state h_st_valid h_st_unique
  have h_store := decodeStore_storeToJson w.capabilities
  rw [h_st, h_store]
  rfl

theorem decodeLibraryRef_libraryRefToTreeJson (lib : LibraryRefEnc) :
    decodeLibraryRef (libraryRefToTreeJson lib).toJson = .ok lib := by
  cases lib with | mk t m =>
  cases m with
  | none =>
    dsimp [libraryRefToTreeJson, TreeJson.toJson, TreeJson.toJsonObj, decodeLibraryRef, checkObjectKeys, getField, getField?]
    rfl
  | some m' =>
    dsimp [libraryRefToTreeJson, TreeJson.toJson, TreeJson.toJsonObj, decodeLibraryRef, checkObjectKeys, getField, getField?]
    rfl

theorem qualifiedPortToTreeJson_toJson (qp : QualifiedPortEnc) :
    (qualifiedPortToTreeJson qp).toJson = qualifiedPortToJson qp := by
  dsimp [qualifiedPortToTreeJson, qualifiedPortToJson, TreeJson.toJson, TreeJson.toJsonObj]
  rw [natToTreeJson_toJson, natToTreeJson_toJson]

theorem decodeOutputObservation_outputObservationToTreeJson (o : OutputObservationEnc)
    (h_can : PackedValueCanonical o.value) :
    decodeOutputObservation (outputObservationToTreeJson o).toJson = .ok o := by
  have h_def : decodeOutputObservation (outputObservationToTreeJson o).toJson = (do
      let port ← decodeQualifiedPort (qualifiedPortToTreeJson o.port).toJson
      let val ← decodePackedValue (packedValueFullToTreeJson o.value).toJson
      .ok ⟨o.step, port, val⟩) := rfl
  rw [h_def]
  have h_port := decodeQualifiedPort_qualifiedPortToJson o.port
  have h_val := decodePackedValue_canonical o.value h_can
  rw [qualifiedPortToTreeJson_toJson]
  rw [packedValueFullToTreeJson_toJson]
  rw [h_port, h_val]
  rfl

set_option maxHeartbeats 3000000 in
-- Definitional reduction of TreeMap key sorting for 7 typedExecute payload fields
theorem decodeTypedExecutePayload_typedExecutePayloadToTreeJson (p : TypedExecutePayloadEnc)
    (h_reg_can : RegistryCanonical p.registry)
    (h_env_can : EnvironmentCanonical p.env)
    (h_req_can : RequestCanonical p.request)
    (h_state_valid : ∀ c ∈ p.state.cells, c.amount.den ≠ 0 ∧ Int.gcd c.amount.num.natAbs c.amount.den = 1 ∧ c.amount.num ≥ 0)
    (h_state_unique : (p.state.cells.map (fun c => (c.domain, c.party, c.asset))).eraseDups.length = p.state.cells.length) :
    decodeTypedExecutePayload (typedExecutePayloadToTreeJson p).toJson = .ok p := by
  have h_def : decodeTypedExecutePayload (typedExecutePayloadToTreeJson p).toJson = (do
      let reg_dec ← decodeRegistry (registryToTreeJson p.registry).toJson
      let store_dec ← decodeStore (storeToTreeJson p.store).toJson
      let ctx_dec ← decodeContext (contextToTreeJson p.ctx).toJson
      let env_dec ← decodeEnvironment (environmentToTreeJson p.env).toJson
      let req_dec ← decodeRequest (requestToTreeJson p.request).toJson
      let st_dec ← decodeState (stateToTreeJson p.state).toJson
      .ok ⟨reg_dec, store_dec, ctx_dec, env_dec, p.now, req_dec, st_dec⟩) := rfl
  rw [h_def]
  rw [registryToTreeJson_toJson, storeToTreeJson_toJson, contextToTreeJson_toJson, environmentToTreeJson_toJson, stateToTreeJson_toJson]
  have h_reg := decodeRegistry_registryToJson p.registry h_reg_can
  have h_store := decodeStore_storeToJson p.store
  have h_ctx := decodeContext_contextToJson p.ctx
  have h_env := decodeEnvironment_environmentToJson p.env h_env_can
  have h_req := decodeRequest_requestToTreeJson p.request h_req_can
  have h_state := decodeState_stateToJson p.state h_state_valid h_state_unique
  rw [h_reg, h_store, h_ctx, h_env, h_req, h_state]
  rfl


theorem nodup_of_pairwise_lt_string : ∀ (xs : List String),
    xs.Pairwise (· < ·) → xs.Nodup
  | [], _ => List.nodup_nil
  | x :: xs, h => by
    cases h with
    | cons h_head h_tail =>
      refine List.nodup_cons.mpr ⟨?_, nodup_of_pairwise_lt_string xs h_tail⟩
      intro h_mem
      have h_lt := h_head x h_mem
      exact String.lt_irrefl x h_lt

theorem validObj_str_map (entries : List (String × String)) :
    TreeJson.ValidObj (entries.map (fun (k, v) => (k, TreeJson.str v))) := by
  induction entries with
  | nil => trivial
  | cons e es ih =>
    dsimp [List.map, TreeJson.ValidObj]
    exact ⟨trivial, ih⟩

theorem sourceMapToTreeJson_valid (entries : List (String × String))
    (h_sm : SourceMapSorted entries) :
    TreeJson.Valid (sourceMapToTreeJson entries) := by
  dsimp [sourceMapToTreeJson, TreeJson.Valid]
  have h_nd : ((entries.map (fun (k, v) => (k, TreeJson.str v))).map Prod.fst).Nodup := by
    have h_map_eq : (entries.map (fun (k, v) => (k, TreeJson.str v))).map Prod.fst = entries.map Prod.fst := by
      simp only [List.map_map, Function.comp_def]
    rw [h_map_eq]
    dsimp [SourceMapSorted] at h_sm
    have h_pw := pairwise_lt_of_isSortedStrictAscending (entries.map Prod.fst) h_sm
    exact nodup_of_pairwise_lt_string (entries.map Prod.fst) h_pw
  refine ⟨h_nd, validObj_str_map entries⟩

theorem registryToTreeJson_valid (r : RegistryEnc)
    (h_len : r.entries.length ≤ 4096)
    (h_tmpl : ∀ e ∈ r.entries, TemplateLengthBounds e.template) :
    TreeJson.Valid (registryToTreeJson r) := by
  dsimp [registryToTreeJson, TreeJson.Valid, TreeJson.ValidObj]
  simp only [List.map_cons, List.map_nil]
  refine ⟨by decide, valid_arr_map registryEntryToTreeJson r.entries h_len (fun e he => by
    have hb := h_tmpl e he
    rcases hb with ⟨h1, h2, h3, h4, h5, h6⟩
    exact registryEntryToTreeJson_valid e h1 h2 h3 h4 h5 h6), trivial⟩

theorem worldToTreeJson_valid (w : WorldEnc)
    (h_cells : w.state.cells.length ≤ 4096)
    (h_caps : w.capabilities.entries.length ≤ 4096) :
    TreeJson.Valid (worldToTreeJson w) := by
  dsimp [worldToTreeJson, TreeJson.Valid, TreeJson.ValidObj]
  simp only [List.map_cons, List.map_nil]
  refine ⟨by decide, stateToTreeJson_valid w.state h_cells, storeToTreeJson_valid w.capabilities h_caps, trivial⟩

theorem boundaryToTreeJson_valid (b : BoundaryEnc)
    (h_env : b.env.entries.length ≤ 4096) :
    TreeJson.Valid (boundaryToTreeJson b) := by
  dsimp [boundaryToTreeJson, TreeJson.Valid, TreeJson.ValidObj]
  simp only [List.map_cons, List.map_nil]
  refine ⟨by decide, contextToTreeJson_valid b.ctx, environmentToTreeJson_valid b.env h_env, trivial, trivial⟩

theorem operationInterfaceToTreeJson_valid (op : OperationInterfaceEnc)
    (h_in : op.inputs.length ≤ 4096)
    (h_out : op.outputs.length ≤ 4096) :
    TreeJson.Valid (operationInterfaceToTreeJson op) := by
  dsimp [operationInterfaceToTreeJson, TreeJson.Valid, TreeJson.ValidObj]
  simp only [List.map_cons, List.map_nil]
  refine ⟨by decide, trivial,
          valid_arr_map inputPortToTreeJson op.inputs h_in (fun p _ => inputPortToTreeJson_valid p),
          valid_arr_map outputPortToTreeJson op.outputs h_out (fun p _ => outputPortToTreeJson_valid p),
          trivial⟩

theorem componentToTreeJson_valid (c : ComponentEnc)
    (h_priv : c.privateCells.length ≤ 4096)
    (h_exp : c.exports.length ≤ 4096)
    (h_imp : c.imports.length ≤ 4096)
    (h_op : c.operations.length ≤ 4096)
    (h_op_in : ∀ op ∈ c.operations, op.inputs.length ≤ 4096)
    (h_op_out : ∀ op ∈ c.operations, op.outputs.length ≤ 4096) :
    TreeJson.Valid (componentToTreeJson c) := by
  dsimp [componentToTreeJson, TreeJson.Valid, TreeJson.ValidObj]
  simp only [List.map_cons, List.map_nil]
  refine ⟨by decide, trivial,
          valid_arr_map cellToTreeJson c.privateCells h_priv (fun cell _ => cellToTreeJson_valid cell),
          valid_arr_map resourcePortToTreeJson c.exports h_exp (fun p _ => resourcePortToTreeJson_valid p),
          valid_arr_map resourceImportToTreeJson c.imports h_imp (fun ri _ => resourceImportToTreeJson_valid ri),
          valid_arr_map operationInterfaceToTreeJson c.operations h_op (fun op hop => operationInterfaceToTreeJson_valid op (h_op_in op hop) (h_op_out op hop)),
          trivial⟩

theorem configToTreeJson_valid (c : ConfigEnc)
    (h_cfg : ConfigLengthBounds c) :
    TreeJson.Valid (configToTreeJson c) := by
  rcases h_cfg with ⟨h_reg, h_tmpl, h_da, h_cat, h_cat_bounds⟩
  dsimp [configToTreeJson, TreeJson.Valid, TreeJson.ValidObj]
  simp only [List.map_cons, List.map_nil]
  refine ⟨by decide, registryToTreeJson_valid c.registry h_reg h_tmpl,
          valid_arr_map domainAdminToTreeJson c.domainAdmin h_da (fun da _ => domainAdminToTreeJson_valid da),
          valid_arr_map componentToTreeJson c.catalog h_cat (fun comp hcomp => by
            have hb := h_cat_bounds comp hcomp
            rcases hb with ⟨h1, h2, h3, h4, h5⟩
            exact componentToTreeJson_valid comp h1 h2 h3 h4
              (fun op hop => (h5 op hop).1)
              (fun op hop => (h5 op hop).2)),
          trivial⟩

theorem inputSourceToTreeJson_valid (i : InputSourceEnc) :
    TreeJson.Valid (inputSourceToTreeJson i) := by
  cases i with
  | literal v =>
    dsimp [inputSourceToTreeJson, TreeJson.Valid, TreeJson.ValidObj]
    simp only [List.map_cons, List.map_nil]
    refine ⟨by decide, trivial, packedValueFullToTreeJson_valid v, trivial⟩
  | priorOutput step port =>
    dsimp [inputSourceToTreeJson, TreeJson.Valid, TreeJson.ValidObj]
    simp only [List.map_cons, List.map_nil]
    refine ⟨by decide, trivial, trivial, qualifiedPortToTreeJson_valid port, trivial⟩

theorem invocationToTreeJson_valid (inv : InvocationEnc)
    (h_ps : inv.parties.length ≤ 4096)
    (h_ins : inv.inputs.length ≤ 4096)
    (h_caps : inv.capabilityIds.length ≤ 4096) :
    TreeJson.Valid (invocationToTreeJson inv) := by
  dsimp [invocationToTreeJson, TreeJson.Valid, TreeJson.ValidObj]
  simp only [List.map_cons, List.map_nil]
  refine ⟨by decide, trivial, trivial,
          valid_arr_map partyToTreeJson inv.parties h_ps (fun p _ => partyToTreeJson_valid p),
          valid_arr_map inputSourceToTreeJson inv.inputs h_ins (fun i _ => inputSourceToTreeJson_valid i),
          valid_arr_map natToTreeJson inv.capabilityIds h_caps (fun n _ => natToTreeJson_valid n),
          by cases inv.claimedActor with | none => trivial | some a => exact partyToTreeJson_valid a,
          trivial⟩

theorem stepToTreeJson_valid (s : StepEnc)
    (h_bounds : StepLengthBounds s) :
    TreeJson.Valid (stepToTreeJson s) := by
  cases s with
  | invoke inv =>
    rcases h_bounds with ⟨h_ins, h_caps, h_ps⟩
    dsimp [stepToTreeJson, TreeJson.Valid, TreeJson.ValidObj]
    simp only [List.map_cons, List.map_nil]
    refine ⟨by decide, trivial, invocationToTreeJson_valid inv h_ps h_ins h_caps, trivial⟩
  | issue g =>
    dsimp [stepToTreeJson, TreeJson.Valid, TreeJson.ValidObj]
    simp only [List.map_cons, List.map_nil]
    refine ⟨by decide, trivial, grantToTreeJson_valid g, trivial⟩
  | revoke id =>
    dsimp [stepToTreeJson, TreeJson.Valid, TreeJson.ValidObj]
    simp only [List.map_cons, List.map_nil]
    refine ⟨by decide, trivial, trivial, trivial⟩
  | unsupported tag =>
    dsimp [stepToTreeJson, TreeJson.Valid, TreeJson.ValidObj]
    simp only [List.map_cons, List.map_nil]
    refine ⟨by decide, trivial, trivial⟩

theorem outputObservationToTreeJson_valid (o : OutputObservationEnc) :
    TreeJson.Valid (outputObservationToTreeJson o) := by
  dsimp [outputObservationToTreeJson, TreeJson.Valid, TreeJson.ValidObj]
  simp only [List.map_cons, List.map_nil]
  refine ⟨by decide, trivial, qualifiedPortToTreeJson_valid o.port, packedValueFullToTreeJson_valid o.value, trivial⟩

theorem typedExecutePayloadToTreeJson_valid (p : TypedExecutePayloadEnc)
    (h_b : TypedPayloadLengthBounds p) :
    TreeJson.Valid (typedExecutePayloadToTreeJson p) := by
  rcases h_b with ⟨h_cells, h_reg, h_tmpl, h_store, h_env, h_args, h_caps, h_ps⟩
  dsimp [typedExecutePayloadToTreeJson, TreeJson.Valid, TreeJson.ValidObj]
  simp only [List.map_cons, List.map_nil]
  refine ⟨by decide, registryToTreeJson_valid p.registry h_reg h_tmpl,
          storeToTreeJson_valid p.store h_store,
          contextToTreeJson_valid p.ctx,
          environmentToTreeJson_valid p.env h_env,
          trivial,
          requestToTreeJson_valid p.request h_ps h_args h_caps,
          stateToTreeJson_valid p.state (by omega),
          trivial⟩

theorem compositionStepPayloadToTreeJson_valid (p : CompositionStepPayloadEnc)
    (h_b : StepPayloadLengthBounds p) :
    TreeJson.Valid (compositionStepPayloadToTreeJson p) := by
  rcases h_b with ⟨h_cfg, h_cells, h_caps, h_env, h_hist, h_step⟩
  dsimp [compositionStepPayloadToTreeJson, TreeJson.Valid, TreeJson.ValidObj]
  simp only [List.map_cons, List.map_nil]
  refine ⟨by decide, configToTreeJson_valid p.config h_cfg,
          boundaryToTreeJson_valid p.boundary h_env,
          trivial,
          valid_arr_map outputObservationToTreeJson p.history h_hist (fun o _ => outputObservationToTreeJson_valid o),
          stepToTreeJson_valid p.step h_step,
          worldToTreeJson_valid p.pre (by omega) h_caps,
          trivial⟩

theorem compositionRunPayloadToTreeJson_valid (p : CompositionRunPayloadEnc)
    (h_b : RunPayloadLengthBounds p) :
    TreeJson.Valid (compositionRunPayloadToTreeJson p) := by
  rcases h_b with ⟨h_cfg, h_cells, h_caps, h_bnds, h_bnd_envs, h_steps, h_step_bounds⟩
  dsimp [compositionRunPayloadToTreeJson, TreeJson.Valid, TreeJson.ValidObj]
  simp only [List.map_cons, List.map_nil]
  refine ⟨by decide, configToTreeJson_valid p.config h_cfg,
          valid_arr_map boundaryToTreeJson p.boundaries h_bnds (fun b hb => boundaryToTreeJson_valid b (h_bnd_envs b hb)),
          worldToTreeJson_valid p.world (by omega) h_caps,
          valid_arr_map stepToTreeJson p.steps h_steps (fun s hs => stepToTreeJson_valid s (h_step_bounds s hs)),
          trivial⟩

theorem envelopeToTreeJson_valid (env : EnvelopeEnc) (payload : TreeJson)
    (h_env : EnvelopeLengthBounds env)
    (h_sm : SourceMapSorted env.source_map)
    (h_p : TreeJson.Valid payload) :
    TreeJson.Valid (envelopeToTreeJson env payload) := by
  rcases h_env with ⟨h_roots, h_asms, h_invs, h_libs, h_sm_len, h_cj, h_ps, h_as, h_ds, h_cns⟩
  dsimp [envelopeToTreeJson, TreeJson.Valid, TreeJson.ValidObj]
  simp only [List.map_cons, List.map_nil]
  refine ⟨by decide, trivial, trivial, sourcePinToTreeJson_valid env.source_pin,
          valid_arr_map TreeJson.str env.audit_roots h_roots (fun _ _ => trivial),
          typesEnumToTreeJson_valid env.types h_ps h_as h_ds,
          valid_arr_map TreeJson.str env.assumptions h_asms (fun _ _ => trivial),
          valid_arr_map TreeJson.str env.invariants h_invs (fun _ _ => trivial),
          valid_arr_map libraryRefToTreeJson env.libraries h_libs (fun l _ => libraryRefToTreeJson_valid l),
          sourceMapToTreeJson_valid env.source_map h_sm,
          h_p,
          valid_arr_map TreeJson.str env.claimed_judgments h_cj (fun _ _ => trivial),
          ?_,
          trivial, trivial, trivial⟩
  cases h_w : env.claimed_next_state with
  | none => trivial
  | some w =>
    have hc : ClaimedNextStateLengthBounds env.claimed_next_state = true := h_cns
    rw [h_w] at hc
    dsimp [ClaimedNextStateLengthBounds] at hc
    have hc_w : w.state.cells.length ≤ 4096 := by
      revert hc
      simp only [Bool.and_eq_true, beq_iff_eq, decide_eq_true_eq]
      intro ⟨h1, _⟩
      omega
    have hc_caps : w.capabilities.entries.length ≤ 4096 := by
      revert hc
      simp only [Bool.and_eq_true, beq_iff_eq, decide_eq_true_eq]
      intro ⟨_, h2⟩
      exact h2
    exact worldToTreeJson_valid w hc_w hc_caps

theorem moduleToTreeJson_valid (ir : DecodedIR) (h_adm : StructurallyAdmissibleIR ir) :
    TreeJson.Valid (moduleToTreeJson ir) := by
  rcases h_adm with ⟨h_sup, h_can⟩
  dsimp [SupportedIR] at h_sup
  rcases h_sup with ⟨h_byte, h_depth, h_arr, h_ir_sup⟩
  cases ir with
  | execution ex =>
    cases ex with
    | typed env p =>
      rcases h_ir_sup with ⟨h_ver, h_mode, h_types, h_cells, h_keys, h_pos, h_store, h_nodup, h_env, h_p⟩
      dsimp [CanonicalIR] at h_can
      rcases h_can with ⟨h_sm, _⟩
      dsimp [moduleToTreeJson]
      exact envelopeToTreeJson_valid env (typedExecutePayloadToTreeJson p) h_env h_sm (typedExecutePayloadToTreeJson_valid p h_p)
    | step env p =>
      rcases h_ir_sup with ⟨h_ver, h_mode, h_types, h_step_unsupp, h_cells, h_keys, h_pos, h_store, h_nodup, h_env, h_p⟩
      dsimp [CanonicalIR] at h_can
      rcases h_can with ⟨h_sm, _⟩
      dsimp [moduleToTreeJson]
      exact envelopeToTreeJson_valid env (compositionStepPayloadToTreeJson p) h_env h_sm (compositionStepPayloadToTreeJson_valid p h_p)
    | run env p =>
      rcases h_ir_sup with ⟨h_ver, h_mode, h_types, h_steps_unsupp, h_cells, h_keys, h_pos, h_store, h_nodup, h_env, h_p⟩
      dsimp [CanonicalIR] at h_can
      rcases h_can with ⟨h_sm, _⟩
      dsimp [moduleToTreeJson]
      exact envelopeToTreeJson_valid env (compositionRunPayloadToTreeJson p) h_env h_sm (compositionRunPayloadToTreeJson_valid p h_p)
  | audit a => contradiction
  | codec doc => contradiction

theorem parseCanonicalJson_encodeModuleString_tree (ir : DecodedIR)
    (h_adm : StructurallyAdmissibleIR ir)
    (h_valid : TreeJson.Valid (moduleToTreeJson ir))
    (h_depth : TreeJson.depth (moduleToTreeJson ir) ≤ 64) :
    parseCanonicalJson (encodeModuleString ir) = .ok ((moduleToTreeJson ir).toJson) := by
  have h_enc := moduleToTreeJson_encode ir h_adm
  rw [← h_enc]
  exact parseCanonicalJson_tree (moduleToTreeJson ir) h_valid h_depth

theorem parseCanonicalJson_encodeModuleString_tree_of_depth (ir : DecodedIR)
    (h_adm : StructurallyAdmissibleIR ir)
    (h_depth : TreeJson.depth (moduleToTreeJson ir) ≤ 64) :
    parseCanonicalJson (encodeModuleString ir) = .ok ((moduleToTreeJson ir).toJson) :=
  parseCanonicalJson_encodeModuleString_tree ir h_adm (moduleToTreeJson_valid ir h_adm) h_depth

theorem decodeBytes_encodeModule_of_valid_and_depth (ir : DecodedIR)
    (h_adm : StructurallyAdmissibleIR ir)
    (h_valid : TreeJson.Valid (moduleToTreeJson ir))
    (h_depth : TreeJson.depth (moduleToTreeJson ir) ≤ 64)
    (h_dec : decodeDecodedIR ((moduleToTreeJson ir).toJson) (encodeModuleString ir) = .ok ir)
    (h_lex : scanLexical (encodeModule ir) = .ok ()) :
    decodeBytes (encodeModule ir) = .ok ir := by
  have h_parse := parseCanonicalJson_encodeModuleString_tree ir h_adm h_valid h_depth
  apply decodeBytes_eq_of_steps (encodeModule ir) (encodeModuleString ir) ((moduleToTreeJson ir).toJson) ir
  · exact h_lex
  · exact string_fromUTF8_encodeModule ir
  · exact h_parse
  · exact h_dec
  · rfl

theorem decodeBytes_encodeModule_of_depth (ir : DecodedIR)
    (h_adm : StructurallyAdmissibleIR ir)
    (h_depth : TreeJson.depth (moduleToTreeJson ir) ≤ 64)
    (h_dec : decodeDecodedIR ((moduleToTreeJson ir).toJson) (encodeModuleString ir) = .ok ir)
    (h_lex : scanLexical (encodeModule ir) = .ok ()) :
    decodeBytes (encodeModule ir) = .ok ir :=
  decodeBytes_encodeModule_of_valid_and_depth ir h_adm (moduleToTreeJson_valid ir h_adm) h_depth h_dec h_lex

end DefiKernel.Certificates

