import Lean.Data.Json
import DefiKernel.Certificates.Correspondence

open Lean DefiKernel.Certificates

theorem test_typed_payload_tolist (p : TypedExecutePayloadEnc) :
  (match Json.mkObj [
    ("registry", registryToJson p.registry),
    ("store", storeToJson p.store),
    ("ctx", contextToJson p.ctx),
    ("env", environmentToJson p.env),
    ("now", Lean.Json.num p.now),
    ("request", requestToJson p.request),
    ("state", stateToJson p.state)
  ] with
   | Json.obj f => f.toList
   | _ => []) =
  (match typedExecutePayloadToJson p with
   | Json.obj f => f.toList
   | _ => []) := by
  rfl


theorem decodeTypedExecutePayload_ordered (p : TypedExecutePayloadEnc)
    (h_reg_can : RegistryCanonical p.registry)
    (h_env_can : EnvironmentCanonical p.env)
    (h_req_can : RequestCanonical p.request)
    (h_state_valid : ∀ c ∈ p.state.cells, c.amount.den ≠ 0 ∧ Int.gcd c.amount.num.natAbs c.amount.den = 1 ∧ c.amount.num ≥ 0)
    (h_state_unique : (p.state.cells.map (fun c => (c.domain, c.party, c.asset))).eraseDups.length = p.state.cells.length) :
    decodeTypedExecutePayload (Json.mkObj [
      ("registry", registryToJson p.registry),
      ("store", storeToJson p.store),
      ("ctx", contextToJson p.ctx),
      ("env", environmentToJson p.env),
      ("now", Lean.Json.num p.now),
      ("request", requestToJson p.request),
      ("state", stateToJson p.state)
    ]) = .ok p := by
  have h_dec := decodeTypedExecutePayload_typedExecutePayloadToJson p h_reg_can h_env_can h_req_can h_state_valid h_state_unique
  -- Notice decodeTypedExecutePayload matches on .obj fields and only uses fields.toList
  have h_eq : decodeTypedExecutePayload (Json.mkObj [
      ("registry", registryToJson p.registry),
      ("store", storeToJson p.store),
      ("ctx", contextToJson p.ctx),
      ("env", environmentToJson p.env),
      ("now", Lean.Json.num p.now),
      ("request", requestToJson p.request),
      ("state", stateToJson p.state)
    ]) = decodeTypedExecutePayload (typedExecutePayloadToJson p) := by rfl
  rw [h_eq]
  exact h_dec

