import Lean.Data.Json
import DefiKernel.Certificates.Correspondence

open Lean DefiKernel.Certificates

#eval (decodeBytes (encodeModule canonicalWitnessIR) == .ok canonicalWitnessIR)

#eval (decodeBytes (encodeModule collisionIR) == .ok collisionIR)
