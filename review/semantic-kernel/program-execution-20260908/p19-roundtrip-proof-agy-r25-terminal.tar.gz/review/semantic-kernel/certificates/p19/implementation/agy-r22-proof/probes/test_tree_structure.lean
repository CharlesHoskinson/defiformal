import Lean.Data.Json

open Lean

def j1 := Json.mkObj [("b", Json.num 2), ("a", Json.num 1)]
def j2 := Json.mkObj [("a", Json.num 1), ("b", Json.num 2)]

#eval (j1 == j2)
#eval match j1, j2 with
  | Json.obj t1, Json.obj t2 =>
    -- check if identical tree structure
    t1.inner.inner == t2.inner.inner
  | _, _ => false
