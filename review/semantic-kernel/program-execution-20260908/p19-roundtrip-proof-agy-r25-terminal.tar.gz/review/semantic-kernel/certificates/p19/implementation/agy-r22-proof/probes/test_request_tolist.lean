import Lean.Data.Json
import DefiKernel.Certificates.Correspondence

open Lean DefiKernel.Certificates

#check match (requestToJson ⟨0, [.alice], [], [], some .alice⟩) with
       | Json.obj f => f.toList
       | _ => []

