import Lean.Data.Json
import DefiKernel.Certificates.Correspondence

open Lean DefiKernel.Certificates

def getWitnessKeys : List String :=
  match canonicalWitnessIR with
  | .execution (.typed env p) =>
    match Json.mkObj (envelopeOrderedFields env (typedExecutePayloadToJson p)) with
    | Json.obj f => f.toList.map Prod.fst
    | _ => []
  | _ => []

#eval getWitnessKeys
