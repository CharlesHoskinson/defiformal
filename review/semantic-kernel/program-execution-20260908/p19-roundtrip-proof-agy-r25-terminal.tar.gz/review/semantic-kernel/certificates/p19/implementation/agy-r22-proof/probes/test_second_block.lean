import Lean.Data.Json
import DefiKernel.Certificates.Correspondence

open Lean DefiKernel.Certificates

theorem toJsonList_map {α : Type} (f : α → TreeJson) (xs : List α) :
    TreeJson.toJsonList (xs.map f) = xs.map (fun x => (f x).toJson) := by
  induction xs with
  | nil => rfl
  | cons x xs ih =>
    dsimp [List.map, TreeJson.toJsonList]
    rw [ih]

theorem encodeList_map {α : Type} (f : α → TreeJson) (xs : List α) :
    TreeJson.encodeList (xs.map f) = String.intercalate "," (xs.map (fun x => (f x).encode)) := by
  rw [encodeList_eq_intercalate]
  simp only [List.map_map]
  rfl

theorem encode_arr_map {α : Type} (f : α → TreeJson) (xs : List α) :
    TreeJson.encode (.arr (xs.map f)) = jsonArr (xs.map (fun x => (f x).encode)) := by
  dsimp [TreeJson.encode, jsonArr]
  rw [encodeList_map]

theorem toJson_arr_map {α : Type} (f : α → TreeJson) (xs : List α) :
    (TreeJson.arr (xs.map f)).toJson = Lean.Json.arr (xs.map (fun x => (f x).toJson)).toArray := by
  dsimp [TreeJson.toJson]
  rw [toJsonList_map]

theorem validList_map {α : Type} (f : α → TreeJson) (xs : List α)
    (h : ∀ x ∈ xs, TreeJson.Valid (f x)) :
    TreeJson.ValidList (xs.map f) := by
  induction xs with
  | nil => trivial
  | cons x xs ih =>
    dsimp [List.map, TreeJson.ValidList]
    refine ⟨h x (List.Mem.head xs), ih (fun y hy => h y (List.Mem.tail x hy))⟩

theorem valid_arr_map {α : Type} (f : α → TreeJson) (xs : List α)
    (h_len : xs.length ≤ 4096)
    (h : ∀ x ∈ xs, TreeJson.Valid (f x)) :
    TreeJson.Valid (TreeJson.arr (xs.map f)) := by
  dsimp [TreeJson.Valid]
  rw [List.length_map]
  exact ⟨h_len, validList_map f xs h⟩

/-- Production TreeJson representation for packed values with unit/value object wrapper. -/
def packedValueFullToTreeJson (v : PackedValueEnc) : TreeJson :=
  TreeJson.obj [("unit", unitToTreeJson v.unit), ("value", packedValueToTreeJson v)]

theorem packedValueFullToTreeJson_toJson (v : PackedValueEnc) :
    (packedValueFullToTreeJson v).toJson = packedValueFullToJson v := by
  dsimp [packedValueFullToTreeJson, packedValueFullToJson, TreeJson.toJson, TreeJson.toJsonObj]
  rw [unitToTreeJson_toJson, packedValueToTreeJson_toJson]

theorem packedValueFullToTreeJson_encode (v : PackedValueEnc) :
    (packedValueFullToTreeJson v).encode = encodePackedValue v := by
  dsimp [packedValueFullToTreeJson, encodePackedValue]
  rw [encode_obj_eq_jsonObj]
  dsimp [List.map]
  rw [unitToTreeJson_encode]
  cases h : v.unit with
  | bool =>
    dsimp [encodeUnit]
    dsimp [packedValueToTreeJson]
    rw [h]
    dsimp
    cases v.valBool <;> rfl
  | numeric nu =>
    dsimp [encodeUnit]
    dsimp [packedValueToTreeJson]
    rw [h]
    dsimp
    rw [ratToTreeJson_encode]

theorem packedValueFullToTreeJson_valid (v : PackedValueEnc) :
    TreeJson.Valid (packedValueFullToTreeJson v) := by
  dsimp [packedValueFullToTreeJson, TreeJson.Valid, TreeJson.ValidObj]
  simp only [List.map_cons, List.map_nil]
  refine ⟨by decide, unitToTreeJson_valid v.unit, ?_, trivial⟩
  cases h : v.unit with
  | bool =>
    dsimp [packedValueToTreeJson]
    rw [h]
    trivial
  | numeric nu =>
    dsimp [packedValueToTreeJson]
    rw [h]
    exact ratToTreeJson_valid ⟨v.valRat.num, v.valRat.den⟩

def stateCellToTreeJson (c : StateCellEnc) : TreeJson :=
  TreeJson.obj [
    ("domain", domainToTreeJson c.domain),
    ("party", partyToTreeJson c.party),
    ("asset", assetToTreeJson c.asset),
    ("amount", ratToTreeJson c.amount)
  ]

theorem stateCellToTreeJson_toJson (c : StateCellEnc) :
    (stateCellToTreeJson c).toJson = stateCellToJson c := by
  dsimp [stateCellToTreeJson, stateCellToJson, TreeJson.toJson, TreeJson.toJsonObj]
  rw [domainToTreeJson_toJson, partyToTreeJson_toJson, assetToTreeJson_toJson, ratToTreeJson_toJson]

theorem stateCellToTreeJson_encode (c : StateCellEnc) :
    (stateCellToTreeJson c).encode = encodeStateCell c := by
  dsimp [stateCellToTreeJson, encodeStateCell]
  rw [encode_obj_eq_jsonObj]
  dsimp [List.map]
  rw [domainToTreeJson_encode, partyToTreeJson_encode, assetToTreeJson_encode, ratToTreeJson_encode]

theorem stateCellToTreeJson_valid (c : StateCellEnc) :
    TreeJson.Valid (stateCellToTreeJson c) := by
  dsimp [stateCellToTreeJson, TreeJson.Valid, TreeJson.ValidObj]
  simp only [List.map_cons, List.map_nil]
  refine ⟨by decide, domainToTreeJson_valid c.domain, partyToTreeJson_valid c.party,
          assetToTreeJson_valid c.asset, ratToTreeJson_valid c.amount, trivial⟩

def cellToTreeJson (c : CellEnc) : TreeJson :=
  TreeJson.obj [
    ("domain", domainToTreeJson c.domain),
    ("party", partyToTreeJson c.party),
    ("asset", assetToTreeJson c.asset)
  ]

theorem cellToTreeJson_toJson (c : CellEnc) :
    (cellToTreeJson c).toJson = cellToJson c := by
  dsimp [cellToTreeJson, cellToJson, TreeJson.toJson, TreeJson.toJsonObj]
  rw [domainToTreeJson_toJson, partyToTreeJson_toJson, assetToTreeJson_toJson]

theorem cellToTreeJson_encode (c : CellEnc) :
    (cellToTreeJson c).encode = encodeCell c := by
  dsimp [cellToTreeJson, encodeCell]
  rw [encode_obj_eq_jsonObj]
  dsimp [List.map]
  rw [domainToTreeJson_encode, partyToTreeJson_encode, assetToTreeJson_encode]

theorem cellToTreeJson_valid (c : CellEnc) :
    TreeJson.Valid (cellToTreeJson c) := by
  dsimp [cellToTreeJson, TreeJson.Valid, TreeJson.ValidObj]
  simp only [List.map_cons, List.map_nil]
  refine ⟨by decide, domainToTreeJson_valid c.domain, partyToTreeJson_valid c.party,
          assetToTreeJson_valid c.asset, trivial⟩

def rightToTreeJson : RightEnc → TreeJson
  | .invoke => TreeJson.obj [("tag", TreeJson.str "invoke")]
  | .debit c => TreeJson.obj [("tag", TreeJson.str "debit"), ("cell", cellToTreeJson c)]
  | .changeSupply d a =>
    TreeJson.obj [
      ("tag", TreeJson.str "changeSupply"),
      ("domain", domainToTreeJson d),
      ("asset", assetToTreeJson a)
    ]

theorem rightToTreeJson_toJson (r : RightEnc) :
    (rightToTreeJson r).toJson = rightToJson r := by
  cases r with
  | invoke => rfl
  | debit c =>
    dsimp [rightToTreeJson, rightToJson, TreeJson.toJson, TreeJson.toJsonObj]
    rw [cellToTreeJson_toJson]
  | changeSupply d a =>
    dsimp [rightToTreeJson, rightToJson, TreeJson.toJson, TreeJson.toJsonObj]
    rw [domainToTreeJson_toJson, assetToTreeJson_toJson]

theorem rightToTreeJson_encode (r : RightEnc) :
    (rightToTreeJson r).encode = encodeRight r := by
  cases r with
  | invoke => rfl
  | debit c =>
    dsimp [rightToTreeJson, encodeRight]
    rw [encode_obj_eq_jsonObj]
    dsimp [List.map]
    rw [cellToTreeJson_encode]
    rfl
  | changeSupply d a =>
    dsimp [rightToTreeJson, encodeRight]
    rw [encode_obj_eq_jsonObj]
    dsimp [List.map]
    rw [domainToTreeJson_encode, assetToTreeJson_encode]
    rfl

theorem rightToTreeJson_valid (r : RightEnc) :
    TreeJson.Valid (rightToTreeJson r) := by
  cases r with
  | invoke =>
    dsimp [rightToTreeJson, TreeJson.Valid, TreeJson.ValidObj]
    simp only [List.map_cons, List.map_nil]
    refine ⟨by decide, trivial, trivial⟩
  | debit c =>
    dsimp [rightToTreeJson, TreeJson.Valid, TreeJson.ValidObj]
    simp only [List.map_cons, List.map_nil]
    refine ⟨by decide, trivial, cellToTreeJson_valid c, trivial⟩
  | changeSupply d a =>
    dsimp [rightToTreeJson, TreeJson.Valid, TreeJson.ValidObj]
    simp only [List.map_cons, List.map_nil]
    refine ⟨by decide, trivial, domainToTreeJson_valid d, assetToTreeJson_valid a, trivial⟩

def grantToTreeJson (g : GrantEnc) : TreeJson :=
  TreeJson.obj [
    ("holder", partyToTreeJson g.holder),
    ("domain", domainToTreeJson g.domain),
    ("operation", TreeJson.num g.operation),
    ("right", rightToTreeJson g.right)
  ]

theorem grantToTreeJson_toJson (g : GrantEnc) :
    (grantToTreeJson g).toJson = grantToJson g := by
  dsimp [grantToTreeJson, grantToJson, TreeJson.toJson, TreeJson.toJsonObj]
  rw [partyToTreeJson_toJson, domainToTreeJson_toJson, rightToTreeJson_toJson]

theorem grantToTreeJson_encode (g : GrantEnc) :
    (grantToTreeJson g).encode = encodeGrant g := by
  dsimp [grantToTreeJson, encodeGrant]
  rw [encode_obj_eq_jsonObj]
  dsimp [List.map]
  rw [partyToTreeJson_encode, domainToTreeJson_encode, rightToTreeJson_encode]

theorem grantToTreeJson_valid (g : GrantEnc) :
    TreeJson.Valid (grantToTreeJson g) := by
  dsimp [grantToTreeJson, TreeJson.Valid, TreeJson.ValidObj]
  simp only [List.map_cons, List.map_nil]
  refine ⟨by decide, partyToTreeJson_valid g.holder, domainToTreeJson_valid g.domain,
          trivial, rightToTreeJson_valid g.right, trivial⟩

def capabilityToTreeJson (c : CapabilityEnc) : TreeJson :=
  TreeJson.obj [
    ("holder", partyToTreeJson c.holder),
    ("domain", domainToTreeJson c.domain),
    ("operation", TreeJson.num c.operation),
    ("right", rightToTreeJson c.right),
    ("live", TreeJson.bool c.live)
  ]

theorem capabilityToTreeJson_toJson (c : CapabilityEnc) :
    (capabilityToTreeJson c).toJson = capabilityToJson c := by
  dsimp [capabilityToTreeJson, capabilityToJson, TreeJson.toJson, TreeJson.toJsonObj]
  rw [partyToTreeJson_toJson, domainToTreeJson_toJson, rightToTreeJson_toJson]

theorem capabilityToTreeJson_encode (c : CapabilityEnc) :
    (capabilityToTreeJson c).encode = encodeCapability c := by
  dsimp [capabilityToTreeJson, encodeCapability]
  rw [encode_obj_eq_jsonObj]
  dsimp [List.map]
  rw [partyToTreeJson_encode, domainToTreeJson_encode, rightToTreeJson_encode]
  cases c.live <;> rfl

theorem capabilityToTreeJson_valid (c : CapabilityEnc) :
    TreeJson.Valid (capabilityToTreeJson c) := by
  dsimp [capabilityToTreeJson, TreeJson.Valid, TreeJson.ValidObj]
  simp only [List.map_cons, List.map_nil]
  refine ⟨by decide, partyToTreeJson_valid c.holder, domainToTreeJson_valid c.domain,
          trivial, rightToTreeJson_valid c.right, trivial, trivial⟩

def storeToTreeJson (s : StoreEnc) : TreeJson :=
  TreeJson.obj [("entries", TreeJson.arr (s.entries.map capabilityToTreeJson))]

theorem storeToTreeJson_toJson (s : StoreEnc) :
    (storeToTreeJson s).toJson = storeToJson s := by
  dsimp [storeToTreeJson, storeToJson, TreeJson.toJson, TreeJson.toJsonObj]
  rw [toJson_arr_map]
  have h_map : (s.entries.map (fun x => (capabilityToTreeJson x).toJson)) = s.entries.map capabilityToJson := by
    simp only [List.map_inj_left]
    intro c _
    exact capabilityToTreeJson_toJson c
  rw [h_map]

theorem storeToTreeJson_encode (s : StoreEnc) :
    (storeToTreeJson s).encode = encodeStore s := by
  dsimp [storeToTreeJson, encodeStore]
  rw [encode_obj_eq_jsonObj]
  dsimp [List.map]
  rw [encode_arr_map]
  have h_map : (s.entries.map (fun x => (capabilityToTreeJson x).encode)) = s.entries.map encodeCapability := by
    simp only [List.map_inj_left]
    intro c _
    exact capabilityToTreeJson_encode c
  rw [h_map]

theorem storeToTreeJson_valid (s : StoreEnc) (h_len : s.entries.length ≤ 4096) :
    TreeJson.Valid (storeToTreeJson s) := by
  dsimp [storeToTreeJson, TreeJson.Valid, TreeJson.ValidObj]
  simp only [List.map_cons, List.map_nil]
  refine ⟨by decide, valid_arr_map capabilityToTreeJson s.entries h_len (fun c _ => capabilityToTreeJson_valid c), trivial⟩

def stateToTreeJson (s : StateEnc) : TreeJson :=
  TreeJson.obj [("cells", TreeJson.arr (s.cells.map stateCellToTreeJson))]

theorem stateToTreeJson_toJson (s : StateEnc) :
    (stateToTreeJson s).toJson = stateToJson s := by
  dsimp [stateToTreeJson, stateToJson, TreeJson.toJson, TreeJson.toJsonObj]
  rw [toJson_arr_map]
  have h_map : (s.cells.map (fun x => (stateCellToTreeJson x).toJson)) = s.cells.map stateCellToJson := by
    simp only [List.map_inj_left]
    intro c _
    exact stateCellToTreeJson_toJson c
  rw [h_map]

theorem stateToTreeJson_encode (s : StateEnc) :
    (stateToTreeJson s).encode = encodeState s := by
  dsimp [stateToTreeJson, encodeState]
  rw [encode_obj_eq_jsonObj]
  dsimp [List.map]
  rw [encode_arr_map]
  have h_map : (s.cells.map (fun x => (stateCellToTreeJson x).encode)) = s.cells.map encodeStateCell := by
    simp only [List.map_inj_left]
    intro c _
    exact stateCellToTreeJson_encode c
  rw [h_map]

theorem stateToTreeJson_valid (s : StateEnc) (h_len : s.cells.length ≤ 4096) :
    TreeJson.Valid (stateToTreeJson s) := by
  dsimp [stateToTreeJson, TreeJson.Valid, TreeJson.ValidObj]
  simp only [List.map_cons, List.map_nil]
  refine ⟨by decide, valid_arr_map stateCellToTreeJson s.cells h_len (fun c _ => stateCellToTreeJson_valid c), trivial⟩

def contextToTreeJson (ctx : ContextEnc) : TreeJson :=
  TreeJson.obj [
    ("principal", partyToTreeJson ctx.principal),
    ("domain", domainToTreeJson ctx.domain)
  ]

theorem contextToTreeJson_toJson (ctx : ContextEnc) :
    (contextToTreeJson ctx).toJson = contextToJson ctx := by
  dsimp [contextToTreeJson, contextToJson, TreeJson.toJson, TreeJson.toJsonObj]
  rw [partyToTreeJson_toJson, domainToTreeJson_toJson]

theorem contextToTreeJson_encode (ctx : ContextEnc) :
    (contextToTreeJson ctx).encode = encodeContext ctx := by
  dsimp [contextToTreeJson, encodeContext]
  rw [encode_obj_eq_jsonObj]
  dsimp [List.map]
  rw [partyToTreeJson_encode, domainToTreeJson_encode]

theorem contextToTreeJson_valid (ctx : ContextEnc) :
    TreeJson.Valid (contextToTreeJson ctx) := by
  dsimp [contextToTreeJson, TreeJson.Valid, TreeJson.ValidObj]
  simp only [List.map_cons, List.map_nil]
  refine ⟨by decide, partyToTreeJson_valid ctx.principal, domainToTreeJson_valid ctx.domain, trivial⟩

def observationToTreeJson (o : ObservationEnc) : TreeJson :=
  TreeJson.obj [
    ("value", packedValueFullToTreeJson o.value),
    ("timestamp", TreeJson.num o.timestamp)
  ]

theorem observationToTreeJson_toJson (o : ObservationEnc) :
    (observationToTreeJson o).toJson = observationToJson o := by
  dsimp [observationToTreeJson, observationToJson, TreeJson.toJson, TreeJson.toJsonObj]
  rw [packedValueFullToTreeJson_toJson]

theorem observationToTreeJson_encode (o : ObservationEnc) :
    (observationToTreeJson o).encode = encodeObservation o := by
  dsimp [observationToTreeJson, encodeObservation]
  rw [encode_obj_eq_jsonObj]
  dsimp [List.map]
  rw [packedValueFullToTreeJson_encode]
  rfl

theorem observationToTreeJson_valid (o : ObservationEnc) :
    TreeJson.Valid (observationToTreeJson o) := by
  dsimp [observationToTreeJson, TreeJson.Valid, TreeJson.ValidObj]
  simp only [List.map_cons, List.map_nil]
  refine ⟨by decide, packedValueFullToTreeJson_valid o.value, trivial, trivial⟩

def environmentEntryToTreeJson (e : EnvironmentEntryEnc) : TreeJson :=
  TreeJson.obj [
    ("key", observationKeyToTreeJson e.key),
    ("observation", observationToTreeJson e.observation)
  ]

theorem environmentEntryToTreeJson_toJson (e : EnvironmentEntryEnc) :
    (environmentEntryToTreeJson e).toJson = environmentEntryToJson e := by
  dsimp [environmentEntryToTreeJson, environmentEntryToJson, TreeJson.toJson, TreeJson.toJsonObj]
  rw [observationKeyToTreeJson_toJson, observationToTreeJson_toJson]

theorem environmentEntryToTreeJson_encode (e : EnvironmentEntryEnc) :
    (environmentEntryToTreeJson e).encode = encodeEnvironmentEntry e := by
  dsimp [environmentEntryToTreeJson, encodeEnvironmentEntry]
  rw [encode_obj_eq_jsonObj]
  dsimp [List.map]
  rw [observationKeyToTreeJson_encode, observationToTreeJson_encode]

theorem environmentEntryToTreeJson_valid (e : EnvironmentEntryEnc) :
    TreeJson.Valid (environmentEntryToTreeJson e) := by
  dsimp [environmentEntryToTreeJson, TreeJson.Valid, TreeJson.ValidObj]
  simp only [List.map_cons, List.map_nil]
  refine ⟨by decide, observationKeyToTreeJson_valid e.key, observationToTreeJson_valid e.observation, trivial⟩

def environmentToTreeJson (env : EnvironmentEnc) : TreeJson :=
  TreeJson.obj [("entries", TreeJson.arr (env.entries.map environmentEntryToTreeJson))]

theorem environmentToTreeJson_toJson (env : EnvironmentEnc) :
    (environmentToTreeJson env).toJson = environmentToJson env := by
  dsimp [environmentToTreeJson, environmentToJson, TreeJson.toJson, TreeJson.toJsonObj]
  rw [toJson_arr_map]
  have h_map : (env.entries.map (fun x => (environmentEntryToTreeJson x).toJson)) = env.entries.map environmentEntryToJson := by
    simp only [List.map_inj_left]
    intro e _
    exact environmentEntryToTreeJson_toJson e
  rw [h_map]

theorem environmentToTreeJson_encode (env : EnvironmentEnc) :
    (environmentToTreeJson env).encode = encodeEnvironment env := by
  dsimp [environmentToTreeJson, encodeEnvironment]
  rw [encode_obj_eq_jsonObj]
  dsimp [List.map]
  rw [encode_arr_map]
  have h_map : (env.entries.map (fun x => (environmentEntryToTreeJson x).encode)) = env.entries.map encodeEnvironmentEntry := by
    simp only [List.map_inj_left]
    intro e _
    exact environmentEntryToTreeJson_encode e
  rw [h_map]

theorem environmentToTreeJson_valid (env : EnvironmentEnc) (h_len : env.entries.length ≤ 4096) :
    TreeJson.Valid (environmentToTreeJson env) := by
  dsimp [environmentToTreeJson, TreeJson.Valid, TreeJson.ValidObj]
  simp only [List.map_cons, List.map_nil]
  refine ⟨by decide, valid_arr_map environmentEntryToTreeJson env.entries h_len (fun e _ => environmentEntryToTreeJson_valid e), trivial⟩

def requestToTreeJson (r : RequestEnc) : TreeJson :=
  TreeJson.obj [
    ("operation", TreeJson.num r.operation),
    ("parties", TreeJson.arr (r.parties.map partyToTreeJson)),
    ("arguments", TreeJson.arr (r.arguments.map packedValueFullToTreeJson)),
    ("capabilityIds", TreeJson.arr (r.capabilityIds.map TreeJson.num)),
    ("claimedActor", match r.claimedActor with | some a => partyToTreeJson a | none => TreeJson.null)
  ]

theorem requestToTreeJson_toJson (r : RequestEnc) :
    (requestToTreeJson r).toJson = requestToJson r := by
  dsimp [requestToTreeJson, requestToJson, TreeJson.toJson, TreeJson.toJsonObj]
  rw [toJson_arr_map, toJson_arr_map, toJson_arr_map]
  have h_ps : (r.parties.map (fun x => (partyToTreeJson x).toJson)) = r.parties.map partyToJson := by
    simp only [List.map_inj_left]
    intro p _
    exact partyToTreeJson_toJson p
  have h_args : (r.arguments.map (fun x => (packedValueFullToTreeJson x).toJson)) = r.arguments.map packedValueFullToJson := by
    simp only [List.map_inj_left]
    intro v _
    exact packedValueFullToTreeJson_toJson v
  rw [h_ps, h_args]
  cases r.claimedActor with
  | none => rfl
  | some a =>
    dsimp
    rw [partyToTreeJson_toJson]

theorem requestToTreeJson_encode (r : RequestEnc) :
    (requestToTreeJson r).encode = encodeRequest r := by
  dsimp [requestToTreeJson, encodeRequest]
  rw [encode_obj_eq_jsonObj]
  dsimp [List.map]
  rw [encode_arr_map, encode_arr_map, encode_arr_map]
  have h_ps : (r.parties.map (fun x => (partyToTreeJson x).encode)) = r.parties.map encodeParty := by
    simp only [List.map_inj_left]
    intro p _
    exact partyToTreeJson_encode p
  have h_args : (r.arguments.map (fun x => (packedValueFullToTreeJson x).encode)) = r.arguments.map encodePackedValue := by
    simp only [List.map_inj_left]
    intro v _
    exact packedValueFullToTreeJson_encode v
  rw [h_ps, h_args]
  cases r.claimedActor with
  | none => rfl
  | some a =>
    dsimp
    rw [partyToTreeJson_encode]
    rfl

theorem requestToTreeJson_valid (r : RequestEnc)
    (h_ps : r.parties.length ≤ 4096)
    (h_args : r.arguments.length ≤ 4096)
    (h_caps : r.capabilityIds.length ≤ 4096) :
    TreeJson.Valid (requestToTreeJson r) := by
  dsimp [requestToTreeJson, TreeJson.Valid, TreeJson.ValidObj]
  simp only [List.map_cons, List.map_nil]
  refine ⟨by decide, trivial,
          valid_arr_map partyToTreeJson r.parties h_ps (fun p _ => partyToTreeJson_valid p),
          valid_arr_map packedValueFullToTreeJson r.arguments h_args (fun v _ => packedValueFullToTreeJson_valid v),
          valid_arr_map TreeJson.num r.capabilityIds h_caps (fun _ _ => trivial),
          ?_, trivial⟩
  cases r.claimedActor with
  | none => trivial
  | some a => exact partyToTreeJson_valid a

def sourcePinToTreeJson (pin : SourcePinEnc) : TreeJson :=
  TreeJson.obj [
    ("git", TreeJson.str pin.git),
    ("lean_toolchain", TreeJson.str pin.lean_toolchain),
    ("mathlib_rev", TreeJson.str pin.mathlib_rev),
    ("checker_candidate", TreeJson.str pin.checker_candidate),
    ("compiler_record", match pin.compiler_record with | some r => TreeJson.str r | none => TreeJson.null),
    ("audit_record", match pin.audit_record with | some r => TreeJson.str r | none => TreeJson.null)
  ]

theorem sourcePinToTreeJson_toJson (pin : SourcePinEnc) :
    (sourcePinToTreeJson pin).toJson = sourcePinToJson pin := by
  dsimp [sourcePinToTreeJson, sourcePinToJson, TreeJson.toJson, TreeJson.toJsonObj]
  cases pin.compiler_record <;> cases pin.audit_record <;> rfl

theorem sourcePinToTreeJson_encode (pin : SourcePinEnc) :
    (sourcePinToTreeJson pin).encode = encodeSourcePin pin := by
  dsimp [sourcePinToTreeJson, encodeSourcePin]
  rw [encode_obj_eq_jsonObj]
  dsimp [List.map]
  have h_git : (TreeJson.str pin.git).encode = escapeJsonString pin.git := escapeTreeString_eq_escapeJsonString pin.git
  have h_tc : (TreeJson.str pin.lean_toolchain).encode = escapeJsonString pin.lean_toolchain := escapeTreeString_eq_escapeJsonString pin.lean_toolchain
  have h_ml : (TreeJson.str pin.mathlib_rev).encode = escapeJsonString pin.mathlib_rev := escapeTreeString_eq_escapeJsonString pin.mathlib_rev
  have h_cc : (TreeJson.str pin.checker_candidate).encode = escapeJsonString pin.checker_candidate := escapeTreeString_eq_escapeJsonString pin.checker_candidate
  rw [h_git, h_tc, h_ml, h_cc]
  cases pin.compiler_record <;> cases pin.audit_record <;> dsimp [escapeTreeString_eq_escapeJsonString] <;> rfl

theorem sourcePinToTreeJson_valid (pin : SourcePinEnc) :
    TreeJson.Valid (sourcePinToTreeJson pin) := by
  dsimp [sourcePinToTreeJson, TreeJson.Valid, TreeJson.ValidObj]
  simp only [List.map_cons, List.map_nil]
  refine ⟨by decide, trivial, trivial, trivial, trivial, ?_, ?_, trivial⟩
  · cases pin.compiler_record <;> trivial
  · cases pin.audit_record <;> trivial

def typesEnumToTreeJson (t : TypesEnumEnc) : TreeJson :=
  TreeJson.obj [
    ("parties", TreeJson.arr (t.parties.map partyToTreeJson)),
    ("assets", TreeJson.arr (t.assets.map assetToTreeJson)),
    ("domains", TreeJson.arr (t.domains.map domainToTreeJson))
  ]

theorem typesEnumToTreeJson_toJson (t : TypesEnumEnc) :
    (typesEnumToTreeJson t).toJson = typesEnumToJson t := by
  dsimp [typesEnumToTreeJson, typesEnumToJson, TreeJson.toJson, TreeJson.toJsonObj]
  rw [toJson_arr_map, toJson_arr_map, toJson_arr_map]
  have h_ps : (t.parties.map (fun x => (partyToTreeJson x).toJson)) = t.parties.map partyToJson := by
    simp only [List.map_inj_left]
    intro p _
    exact partyToTreeJson_toJson p
  have h_as : (t.assets.map (fun x => (assetToTreeJson x).toJson)) = t.assets.map assetToJson := by
    simp only [List.map_inj_left]
    intro a _
    exact assetToTreeJson_toJson a
  have h_ds : (t.domains.map (fun x => (domainToTreeJson x).toJson)) = t.domains.map domainToJson := by
    simp only [List.map_inj_left]
    intro d _
    exact domainToTreeJson_toJson d
  rw [h_ps, h_as, h_ds]

theorem typesEnumToTreeJson_encode (t : TypesEnumEnc) :
    (typesEnumToTreeJson t).encode = encodeTypesEnum t := by
  dsimp [typesEnumToTreeJson, encodeTypesEnum]
  rw [encode_obj_eq_jsonObj]
  dsimp [List.map]
  rw [encode_arr_map, encode_arr_map, encode_arr_map]
  have h_ps : (t.parties.map (fun x => (partyToTreeJson x).encode)) = t.parties.map encodeParty := by
    simp only [List.map_inj_left]
    intro p _
    exact partyToTreeJson_encode p
  have h_as : (t.assets.map (fun x => (assetToTreeJson x).encode)) = t.assets.map encodeAsset := by
    simp only [List.map_inj_left]
    intro a _
    exact assetToTreeJson_encode a
  have h_ds : (t.domains.map (fun x => (domainToTreeJson x).encode)) = t.domains.map encodeDomain := by
    simp only [List.map_inj_left]
    intro d _
    exact domainToTreeJson_encode d
  rw [h_ps, h_as, h_ds]

theorem typesEnumToTreeJson_valid (t : TypesEnumEnc)
    (h_ps : t.parties.length ≤ 4096)
    (h_as : t.assets.length ≤ 4096)
    (h_ds : t.domains.length ≤ 4096) :
    TreeJson.Valid (typesEnumToTreeJson t) := by
  dsimp [typesEnumToTreeJson, TreeJson.Valid, TreeJson.ValidObj]
  simp only [List.map_cons, List.map_nil]
  refine ⟨by decide,
          valid_arr_map partyToTreeJson t.parties h_ps (fun p _ => partyToTreeJson_valid p),
          valid_arr_map assetToTreeJson t.assets h_as (fun a _ => assetToTreeJson_valid a),
          valid_arr_map domainToTreeJson t.domains h_ds (fun d _ => domainToTreeJson_valid d),
          trivial⟩

def libraryRefToTreeJson (lib : LibraryRefEnc) : TreeJson :=
  match lib.moduleName with
  | some m => TreeJson.obj [("theorem", TreeJson.str lib.theoremName), ("module", TreeJson.str m)]
  | none => TreeJson.obj [("theorem", TreeJson.str lib.theoremName)]

theorem libraryRefToTreeJson_toJson (lib : LibraryRefEnc) :
    (libraryRefToTreeJson lib).toJson = libraryRefToJson lib := by
  cases lib.moduleName with
  | none => rfl
  | some m => rfl

theorem libraryRefToTreeJson_encode (lib : LibraryRefEnc) :
    (libraryRefToTreeJson lib).encode = encodeLibraryRef lib := by
  dsimp [libraryRefToTreeJson, encodeLibraryRef]
  cases lib.moduleName with
  | none =>
    rw [encode_obj_eq_jsonObj]
    dsimp [List.map]
    rw [escapeTreeString_eq_escapeJsonString]
  | some m =>
    rw [encode_obj_eq_jsonObj]
    dsimp [List.map]
    rw [escapeTreeString_eq_escapeJsonString, escapeTreeString_eq_escapeJsonString]

theorem libraryRefToTreeJson_valid (lib : LibraryRefEnc) :
    TreeJson.Valid (libraryRefToTreeJson lib) := by
  dsimp [libraryRefToTreeJson]
  cases lib.moduleName with
  | none =>
    dsimp [TreeJson.Valid, TreeJson.ValidObj]
    simp only [List.map_cons, List.map_nil]
    refine ⟨by decide, trivial, trivial⟩
  | some m =>
    dsimp [TreeJson.Valid, TreeJson.ValidObj]
    simp only [List.map_cons, List.map_nil]
    refine ⟨by decide, trivial, trivial, trivial⟩
