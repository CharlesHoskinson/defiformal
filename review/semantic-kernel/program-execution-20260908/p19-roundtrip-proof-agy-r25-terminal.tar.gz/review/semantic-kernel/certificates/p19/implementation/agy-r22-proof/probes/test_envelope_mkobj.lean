import Lean.Data.Json
import DefiKernel.Certificates.Correspondence

open Lean DefiKernel.Certificates

theorem test_ordered_eq_sorted (env : EnvelopeEnc) (payloadJ : Lean.Json) :
  Lean.Json.mkObj (envelopeOrderedFields env payloadJ) = Lean.Json.mkObj (envelopeSortedFields env payloadJ) := by
  sorry
