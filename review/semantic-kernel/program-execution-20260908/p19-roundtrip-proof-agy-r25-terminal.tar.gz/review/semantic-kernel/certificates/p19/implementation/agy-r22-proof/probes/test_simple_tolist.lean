import Lean.Data.Json

open Lean

theorem test_simple_tolist (v1 v2 : Json) :
  (match Json.mkObj [("b", v2), ("a", v1)] with
   | Json.obj f => f.toList
   | _ => []) = [("a", v1), ("b", v2)] := by
  rfl
