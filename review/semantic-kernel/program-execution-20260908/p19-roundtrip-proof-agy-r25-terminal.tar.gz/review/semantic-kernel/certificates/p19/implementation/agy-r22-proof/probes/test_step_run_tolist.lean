import Lean.Data.Json
import DefiKernel.Certificates.Correspondence

open Lean DefiKernel.Certificates

theorem test_step_payload_tolist (p : CompositionStepPayloadEnc) :
  (match Json.mkObj [
    ("config", configToJson p.config),
    ("boundary", boundaryToJson p.boundary),
    ("index", Lean.Json.num p.index),
    ("history", Lean.Json.arr (p.history.map outputObservationToJson).toArray),
    ("step", stepToJson p.step),
    ("pre", worldToJson p.pre)
  ] with
   | Json.obj f => f.toList
   | _ => []) =
  (match compositionStepPayloadToJson p with
   | Json.obj f => f.toList
   | _ => []) := by
  rfl

theorem test_run_payload_tolist (p : CompositionRunPayloadEnc) :
  (match Json.mkObj [
    ("config", configToJson p.config),
    ("boundaries", Lean.Json.arr (p.boundaries.map boundaryToJson).toArray),
    ("world", worldToJson p.world),
    ("steps", Lean.Json.arr (p.steps.map stepToJson).toArray)
  ] with
   | Json.obj f => f.toList
   | _ => []) =
  (match compositionRunPayloadToJson p with
   | Json.obj f => f.toList
   | _ => []) := by
  rfl

