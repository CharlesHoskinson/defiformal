import Lean.Data.Json
import DefiKernel.Certificates.Correspondence

open Lean DefiKernel.Certificates

theorem test_tolist_eq (env : EnvelopeEnc) (payloadJ : Lean.Json) :
  (match Json.mkObj (envelopeOrderedFields env payloadJ) with
   | Json.obj f => f.toList
   | _ => []) = envelopeSortedFields env payloadJ := by
  sorry
