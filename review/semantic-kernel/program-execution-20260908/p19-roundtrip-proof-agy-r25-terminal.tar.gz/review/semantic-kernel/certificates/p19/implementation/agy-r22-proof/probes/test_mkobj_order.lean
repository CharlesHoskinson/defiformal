import Lean.Data.Json
import DefiKernel.Certificates.Correspondence

open Lean DefiKernel.Certificates

theorem mkObj_test :
  Json.mkObj [("b", Json.num 2), ("a", Json.num 1)] = Json.mkObj [("a", Json.num 1), ("b", Json.num 2)] := by
  rfl
