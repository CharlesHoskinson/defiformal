import Lean.Data.Json
import DefiKernel.Certificates.Correspondence

open Lean DefiKernel.Certificates

/-! ### General Array TreeJson Helpers -/

theorem toJsonList_map {α : Type} (f : α → TreeJson) (xs : List α) :
    TreeJson.toJsonList (xs.map f) = xs.map (fun x => (f x).toJson) := by
  induction xs with
  | nil => rfl
  | cons x xs ih =>
    dsimp [List.map, TreeJson.toJsonList]
    rw [ih]

theorem encodeList_map {α : Type} (f : α → TreeJson) (xs : List α) :
    TreeJson.encodeList (xs.map f) = String.intercalate "," (xs.map (fun x => (f x).encode)) := by
  rw [encodeList_eq_intercalate]
  simp only [List.map_map]
  rfl

theorem encode_arr_map {α : Type} (f : α → TreeJson) (xs : List α) :
    TreeJson.encode (.arr (xs.map f)) = jsonArr (xs.map (fun x => (f x).encode)) := by
  dsimp [TreeJson.encode, jsonArr]
  rw [encodeList_map]

theorem toJson_arr_map {α : Type} (f : α → TreeJson) (xs : List α) :
    (TreeJson.arr (xs.map f)).toJson = Lean.Json.arr (xs.map (fun x => (f x).toJson)).toArray := by
  dsimp [TreeJson.toJson]
  rw [toJsonList_map]

theorem validList_map {α : Type} (f : α → TreeJson) (xs : List α)
    (h : ∀ x ∈ xs, TreeJson.Valid (f x)) :
    TreeJson.ValidList (xs.map f) := by
  induction xs with
  | nil => trivial
  | cons x xs ih =>
    dsimp [List.map, TreeJson.ValidList]
    refine ⟨h x (List.Mem.head xs), ih (fun y hy => h y (List.Mem.tail x hy))⟩

theorem valid_arr_map {α : Type} (f : α → TreeJson) (xs : List α)
    (h_len : xs.length ≤ 4096)
    (h : ∀ x ∈ xs, TreeJson.Valid (f x)) :
    TreeJson.Valid (TreeJson.arr (xs.map f)) := by
  dsimp [TreeJson.Valid]
  rw [List.length_map]
  exact ⟨h_len, validList_map f xs h⟩

theorem encode_arr_str (xs : List String) :
    TreeJson.encode (.arr (xs.map TreeJson.str)) = jsonArr (xs.map escapeJsonString) := by
  rw [encode_arr_map]
  have h_eq : (xs.map (fun s => (TreeJson.str s).encode)) = xs.map escapeJsonString := by
    simp only [List.map_inj_left]
    intro s _
    exact escapeTreeString_eq_escapeJsonString s
  rw [h_eq]

theorem toJson_arr_str (xs : List String) :
    (TreeJson.arr (xs.map TreeJson.str)).toJson = Lean.Json.arr (xs.map Lean.Json.str).toArray := by
  rw [toJson_arr_map]
  rfl

theorem valid_arr_str (xs : List String) (h_len : xs.length ≤ 4096) :
    TreeJson.Valid (TreeJson.arr (xs.map TreeJson.str)) := by
  apply valid_arr_map
  · exact h_len
  · intro _ _; trivial

/-! ### Packed Value Full Representation -/

/-- Production TreeJson representation for packed values with unit/value object wrapper. -/
def packedValueFullToTreeJson (v : PackedValueEnc) : TreeJson :=
  TreeJson.obj [("unit", unitToTreeJson v.unit), ("value", packedValueToTreeJson v)]

theorem packedValueFullToTreeJson_toJson (v : PackedValueEnc) :
    (packedValueFullToTreeJson v).toJson = packedValueFullToJson v := by
  dsimp [packedValueFullToTreeJson, packedValueFullToJson, TreeJson.toJson, TreeJson.toJsonObj]
  rw [unitToTreeJson_toJson, packedValueToTreeJson_toJson]

theorem packedValueFullToTreeJson_encode (v : PackedValueEnc) :
    (packedValueFullToTreeJson v).encode = encodePackedValue v := by
  dsimp [packedValueFullToTreeJson, encodePackedValue]
  rw [encode_obj_eq_jsonObj]
  dsimp [List.map]
  rw [unitToTreeJson_encode]
  cases h : v.unit with
  | bool =>
    dsimp [encodeUnit]
    dsimp [packedValueToTreeJson]
    rw [h]
    dsimp
    cases v.valBool <;> rfl
  | numeric nu =>
    dsimp [encodeUnit]
    dsimp [packedValueToTreeJson]
    rw [h]
    dsimp
    rw [ratToTreeJson_encode]

theorem packedValueFullToTreeJson_valid (v : PackedValueEnc) :
    TreeJson.Valid (packedValueFullToTreeJson v) := by
  dsimp [packedValueFullToTreeJson, TreeJson.Valid, TreeJson.ValidObj]
  simp only [List.map_cons, List.map_nil]
  refine ⟨by decide, unitToTreeJson_valid v.unit, ?_, trivial⟩
  cases h : v.unit with
  | bool =>
    dsimp [packedValueToTreeJson]
    rw [h]
    trivial
  | numeric nu =>
    dsimp [packedValueToTreeJson]
    rw [h]
    exact ratToTreeJson_valid ⟨v.valRat.num, v.valRat.den⟩

/-! ### Source Map TreeJson Representation -/

theorem map_encode_str_pairs (entries : List (String × String)) :
    (entries.map (fun (k, v) => (k, TreeJson.str v))).map (fun (k, v) => (k, TreeJson.encode v)) =
    entries.map (fun (k, v) => (k, escapeJsonString v)) := by
  induction entries with
  | nil => rfl
  | cons kv rest ih =>
    rcases kv with ⟨k, v⟩
    dsimp [List.map]
    have h_esc : (TreeJson.str v).encode = escapeJsonString v := escapeTreeString_eq_escapeJsonString v
    rw [h_esc, ih]

def sourceMapToTreeJson (entries : List (String × String)) : TreeJson :=
  TreeJson.obj (entries.map (fun (k, v) => (k, TreeJson.str v)))

theorem toJsonObj_map_str (entries : List (String × String)) :
    TreeJson.toJsonObj (entries.map (fun (k, v) => (k, TreeJson.str v))) =
    entries.map (fun (k, v) => (k, Lean.Json.str v)) := by
  induction entries with
  | nil => rfl
  | cons kv rest ih =>
    rcases kv with ⟨k, v⟩
    dsimp [List.map, TreeJson.toJsonObj, TreeJson.toJson]
    rw [ih]

theorem sourceMapToTreeJson_toJson (entries : List (String × String)) :
    (sourceMapToTreeJson entries).toJson = Lean.Json.mkObj (entries.map (fun (k, v) => (k, Lean.Json.str v))) := by
  dsimp [sourceMapToTreeJson, TreeJson.toJson]
  rw [toJsonObj_map_str]

theorem sourceMapToTreeJson_encode (entries : List (String × String)) (h_sm : SourceMapSorted entries) :
    (sourceMapToTreeJson entries).encode = encodeSourceMap entries := by
  dsimp [sourceMapToTreeJson, encodeSourceMap]
  rw [h_sm]
  dsimp
  rw [encode_obj_eq_jsonObj]
  rw [map_encode_str_pairs]

/-! ### Envelope Ordered Fields to Sorted Fields Equivalence -/

theorem envelope_mkObj_toList (env : EnvelopeEnc) (payloadJ : Lean.Json) :
    (match Lean.Json.mkObj (envelopeOrderedFields env payloadJ) with
     | Lean.Json.obj f => f.toList
     | _ => []) = envelopeSortedFields env payloadJ := by
  rfl
