import Lean.Data.Json
import DefiKernel.Certificates.Correspondence

open Lean DefiKernel.Certificates

theorem decodeDecodedIR_mkObj_ordered_eq (env : EnvelopeEnc) (payloadJ : Lean.Json) (raw : String) :
    decodeDecodedIR (Lean.Json.mkObj (envelopeOrderedFields env payloadJ)) raw =
    decodeDecodedIR (envelopeToJson env payloadJ) raw := by
  rfl
