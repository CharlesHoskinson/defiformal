import Lean.Data.Json
import DefiKernel.Certificates.Correspondence

open Lean DefiKernel.Certificates

def sourceMapToTreeJson (entries : List (String × String)) : TreeJson :=
  TreeJson.obj (entries.map (fun (k, v) => (k, TreeJson.str v)))

theorem toJsonObj_map_str (entries : List (String × String)) :
    TreeJson.toJsonObj (entries.map (fun (k, v) => (k, TreeJson.str v))) =
    entries.map (fun (k, v) => (k, Lean.Json.str v)) := by
  induction entries with
  | nil => rfl
  | cons kv rest ih =>
    rcases kv with ⟨k, v⟩
    dsimp [List.map, TreeJson.toJsonObj, TreeJson.toJson]
    rw [ih]

theorem sourceMapToTreeJson_toJson (entries : List (String × String)) :
    (sourceMapToTreeJson entries).toJson = Lean.Json.mkObj (entries.map (fun (k, v) => (k, Lean.Json.str v))) := by
  dsimp [sourceMapToTreeJson, TreeJson.toJson]
  rw [toJsonObj_map_str]

theorem sourceMapToTreeJson_encode (entries : List (String × String)) :
    (sourceMapToTreeJson entries).encode = encodeSourceMap entries := by
  dsimp [sourceMapToTreeJson, encodeSourceMap]
  rw [encode_obj_eq_jsonObj]
  have h_eq : (List.map (fun (k, v) => (k, TreeJson.str v)) entries).map (fun (k, v) => (k, TreeJson.encode v)) =
      entries.map (fun (k, v) => (k, escapeJsonString v)) := by
    induction entries with
    | nil => rfl
    | cons kv rest ih =>
      rcases kv with ⟨k, v⟩
      dsimp [List.map]
      rw [escapeTreeString_eq_escapeJsonString]
      rw [ih]
  rw [h_eq]

theorem sourceMapToTreeJson_valid (entries : List (String × String))
    (h_nodup : (entries.map Prod.fst).Nodup) :
    TreeJson.Valid (sourceMapToTreeJson entries) := by
  dsimp [sourceMapToTreeJson, TreeJson.Valid]
  have h_keys : ((entries.map (fun (k, v) => (k, TreeJson.str v))).map Prod.fst) = entries.map Prod.fst := by
    simp only [List.map_map, Prod.fst]
  refine ⟨by rw [h_keys]; exact h_nodup, ?_⟩
  induction entries with
  | nil => trivial
  | cons kv rest ih =>
    rcases kv with ⟨k, v⟩
    dsimp [List.map, TreeJson.ValidObj]
    exact ⟨trivial, ih⟩
