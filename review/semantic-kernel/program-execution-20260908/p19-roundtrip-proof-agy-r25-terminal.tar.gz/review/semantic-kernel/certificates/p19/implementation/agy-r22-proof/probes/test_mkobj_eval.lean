import Lean.Data.Json

open Lean

#eval (Json.mkObj [("b", Json.num 2), ("a", Json.num 1)] == Json.mkObj [("a", Json.num 1), ("b", Json.num 2)])
#eval Json.mkObj [("b", Json.num 2), ("a", Json.num 1)]
#eval Json.mkObj [("a", Json.num 1), ("b", Json.num 2)]
