import Lean.Data.Json
import DefiKernel.Certificates.Correspondence

open Lean DefiKernel.Certificates

def packedValueFullToTreeJson (v : PackedValueEnc) : TreeJson :=
  TreeJson.obj [("unit", unitToTreeJson v.unit), ("value", packedValueToTreeJson v)]

theorem packedValueFullToTreeJson_toJson (v : PackedValueEnc) :
    (packedValueFullToTreeJson v).toJson = packedValueFullToJson v := by
  dsimp [packedValueFullToTreeJson, packedValueFullToJson, TreeJson.toJson, TreeJson.toJsonObj]
  rw [unitToTreeJson_toJson, packedValueToTreeJson_toJson]

theorem packedValueFullToTreeJson_encode (v : PackedValueEnc) :
    (packedValueFullToTreeJson v).encode = encodePackedValue v := by
  dsimp [packedValueFullToTreeJson, encodePackedValue]
  rw [encode_obj_eq_jsonObj]
  dsimp [List.map]
  cases h : v.unit with
  | bool =>
    dsimp [unitToTreeJson, encode_obj_eq_jsonObj, List.map, TreeJson.encode, escapeTreeString]
    dsimp [packedValueToTreeJson]
    cases v.valBool <;> rfl
  | numeric nu =>
    dsimp [unitToTreeJson]
    rw [numericUnitToTreeJson_encode nu]
    dsimp [packedValueToTreeJson]
    rw [ratToTreeJson_encode]
    rfl
