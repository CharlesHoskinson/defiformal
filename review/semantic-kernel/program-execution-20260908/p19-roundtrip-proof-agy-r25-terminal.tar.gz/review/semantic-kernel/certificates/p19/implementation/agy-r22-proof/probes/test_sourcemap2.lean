import Lean.Data.Json
import DefiKernel.Certificates.Correspondence

open Lean DefiKernel.Certificates

def sourceMapToTreeJson (entries : List (String × String)) : TreeJson :=
  TreeJson.obj (entries.map (fun (k, v) => (k, TreeJson.str v)))

theorem sourceMapToTreeJson_encode (entries : List (String × String)) (h_sm : SourceMapSorted entries) :
    (sourceMapToTreeJson entries).encode = encodeSourceMap entries := by
  dsimp [sourceMapToTreeJson, encodeSourceMap]
  rw [h_sm]
  dsimp
  rw [encode_obj_eq_jsonObj]
  have h_eq : (List.map (fun (k, v) => (k, TreeJson.str v)) entries).map (fun (k, v) => (k, TreeJson.encode v)) =
      entries.map (fun (k, v) => (k, escapeJsonString v)) := by
    induction entries with
    | nil => rfl
    | cons kv rest ih =>
      rcases kv with ⟨k, v⟩
      dsimp [List.map]
      have h_esc : (TreeJson.str v).encode = escapeJsonString v := escapeTreeString_eq_escapeJsonString v
      rw [h_esc, ih]
  rw [h_eq]
