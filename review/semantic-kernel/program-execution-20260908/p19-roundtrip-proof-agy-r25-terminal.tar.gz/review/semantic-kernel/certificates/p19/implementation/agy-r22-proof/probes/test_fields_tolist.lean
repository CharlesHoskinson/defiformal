import Lean.Data.Json

open Lean

def l1 : List (String × Json) := [("b", Json.num 2), ("a", Json.num 1)]
def l2 : List (String × Json) := [("a", Json.num 1), ("b", Json.num 2)]

#eval match Json.mkObj l1 with | .obj f => f.toList | _ => []
#eval match Json.mkObj l2 with | .obj f => f.toList | _ => []
#eval ((match Json.mkObj l1 with | .obj f => f.toList | _ => []) == (match Json.mkObj l2 with | .obj f => f.toList | _ => []))
