import Lean.Data.Json
import DefiKernel.Certificates.Correspondence

open Lean DefiKernel.Certificates

def checkListEq : Bool :=
  match canonicalWitnessIR with
  | .execution (.typed env p) =>
    match Json.mkObj (envelopeOrderedFields env (typedExecutePayloadToJson p)) with
    | Json.obj f =>
      let l1 := f.toList
      let l2 := envelopeSortedFields env (typedExecutePayloadToJson p)
      l1.map Prod.fst == l2.map Prod.fst
    | _ => false
  | _ => false

#eval checkListEq
