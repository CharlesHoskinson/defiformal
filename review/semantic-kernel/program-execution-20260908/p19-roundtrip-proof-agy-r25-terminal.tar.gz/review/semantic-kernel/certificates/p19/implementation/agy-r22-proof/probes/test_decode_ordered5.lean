import Lean.Data.Json
import DefiKernel.Certificates.Correspondence

open Lean DefiKernel.Certificates

set_option maxHeartbeats 1000000 in
theorem decodeDecodedIR_mkObj_ordered (env : EnvelopeEnc) (payloadJ : Lean.Json) (raw : String) :
    decodeDecodedIR (Json.mkObj (envelopeOrderedFields env payloadJ)) raw =
    (do
      let env_dec ← decodeEnvelope (envelopeSortedFields env payloadJ)
      let payloadJ_dec ← getField (envelopeSortedFields env payloadJ) "payload"
      match env_dec.mode with
      | "typed-execute" =>
        let payload_dec ← decodeTypedExecutePayload payloadJ_dec
        Except.ok (DecodedIR.execution (.typed env_dec payload_dec))
      | "composition-step" =>
        let payload_dec ← decodeCompositionStepPayload payloadJ_dec
        Except.ok (DecodedIR.execution (.step env_dec payload_dec))
      | "composition-run" =>
        let payload_dec ← decodeCompositionRunPayload payloadJ_dec
        Except.ok (DecodedIR.execution (.run env_dec payload_dec))
      | "codec" => Except.ok (DecodedIR.codec ⟨some env_dec, raw⟩)
      | "audit" =>
        let payload_dec ← decodeAuditPayload env_dec payloadJ_dec true
        Except.ok (DecodedIR.audit payload_dec)
      | s => Except.error (.unknownIdentifier s)) := by
  rfl

theorem decodeDecodedIR_mkObj_ordered_eq (env : EnvelopeEnc) (payloadJ : Lean.Json) (raw : String) :
    decodeDecodedIR (Json.mkObj (envelopeOrderedFields env payloadJ)) raw =
    decodeDecodedIR (envelopeToJson env payloadJ) raw := by
  rw [decodeDecodedIR_mkObj_ordered]
  rw [decodeDecodedIR_envelopeToJson_eq]
  rfl

