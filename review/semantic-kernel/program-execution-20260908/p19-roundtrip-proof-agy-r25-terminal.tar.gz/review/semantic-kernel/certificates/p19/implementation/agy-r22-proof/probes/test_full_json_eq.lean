import Lean.Data.Json
import DefiKernel.Certificates.Correspondence

open Lean DefiKernel.Certificates

def checkFullEq : Bool :=
  match canonicalWitnessIR with
  | .execution (.typed env p) =>
    let j1 := Json.mkObj (envelopeOrderedFields env (typedExecutePayloadToJson p))
    let j2 := Json.mkObj (envelopeSortedFields env (typedExecutePayloadToJson p))
    j1 == j2
  | _ => false

#eval checkFullEq
