import Lean.Data.Json

open Lean

def j1 := Json.mkObj [("b", Json.num 2), ("a", Json.num 1)]
def j2 := Json.mkObj [("a", Json.num 1), ("b", Json.num 2)]

#check (rfl : j1 = j2)
