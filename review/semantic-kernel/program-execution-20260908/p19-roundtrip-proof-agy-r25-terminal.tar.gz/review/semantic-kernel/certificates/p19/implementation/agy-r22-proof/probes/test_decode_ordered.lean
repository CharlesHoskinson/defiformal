import Lean.Data.Json
import DefiKernel.Certificates.Correspondence

open Lean DefiKernel.Certificates

#eval match canonicalWitnessIR with
  | .execution (.typed env p) =>
    let j_ordered := Json.mkObj (envelopeOrderedFields env (typedExecutePayloadToJson p))
    let dec := decodeDecodedIR j_ordered "raw"
    match dec with
    | .ok ir => (ir == canonicalWitnessIR)
    | .error e => false
  | _ => false
