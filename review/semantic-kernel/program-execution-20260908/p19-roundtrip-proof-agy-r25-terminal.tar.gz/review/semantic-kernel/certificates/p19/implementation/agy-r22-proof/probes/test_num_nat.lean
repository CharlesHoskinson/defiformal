import Lean.Data.Json
import DefiKernel.Certificates.CanonicalJson

open Lean DefiKernel.Certificates

theorem numToTreeJson_encode_nat (n : Nat) :
    (TreeJson.num (n : Int)).encode = toString n := by
  rfl

theorem numToTreeJson_toJson_nat (n : Nat) :
    (TreeJson.num (n : Int)).toJson = Lean.Json.num n := by
  rfl

