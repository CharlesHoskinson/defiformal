import Lean.Data.Json
import DefiKernel.Certificates.Correspondence

open Lean DefiKernel.Certificates

theorem toJsonList_map {α : Type} (f : α → TreeJson) (xs : List α) :
    TreeJson.toJsonList (xs.map f) = xs.map (fun x => (f x).toJson) := by
  induction xs with
  | nil => rfl
  | cons x xs ih =>
    dsimp [List.map, TreeJson.toJsonList]
    rw [ih]

def typesEnumToTreeJson (t : TypesEnumEnc) : TreeJson :=
  TreeJson.obj [
    ("parties", TreeJson.arr (t.parties.map partyToTreeJson)),
    ("assets", TreeJson.arr (t.assets.map assetToTreeJson)),
    ("domains", TreeJson.arr (t.domains.map domainToTreeJson))
  ]

theorem typesEnumToTreeJson_toJson (t : TypesEnumEnc) :
    (typesEnumToTreeJson t).toJson = typesEnumToJson t := by
  dsimp [typesEnumToTreeJson, typesEnumToJson, TreeJson.toJson, TreeJson.toJsonObj]
  rw [toJsonList_map, toJsonList_map, toJsonList_map]
  have h_ps : (t.parties.map (fun x => (partyToTreeJson x).toJson)) = t.parties.map partyToJson := by
    simp only [List.map_inj_left]
    intro p _
    exact partyToTreeJson_toJson p
  have h_as : (t.assets.map (fun x => (assetToTreeJson x).toJson)) = t.assets.map assetToJson := by
    simp only [List.map_inj_left]
    intro a _
    exact assetToTreeJson_toJson a
  have h_ds : (t.domains.map (fun x => (domainToTreeJson x).toJson)) = t.domains.map domainToJson := by
    simp only [List.map_inj_left]
    intro d _
    exact domainToTreeJson_toJson d
  rw [h_ps, h_as, h_ds]
