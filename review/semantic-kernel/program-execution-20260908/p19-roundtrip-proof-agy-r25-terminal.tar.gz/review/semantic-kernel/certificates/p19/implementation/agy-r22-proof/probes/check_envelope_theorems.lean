import Lean.Data.Json
import DefiKernel.Certificates.Correspondence

open Lean DefiKernel.Certificates

#check decodeEnvelope_orderedFields
#check decodeEnvelope_sortedFields
