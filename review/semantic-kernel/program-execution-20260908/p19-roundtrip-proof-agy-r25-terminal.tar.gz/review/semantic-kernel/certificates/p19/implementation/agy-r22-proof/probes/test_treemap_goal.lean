import Lean.Data.Json

open Lean

def l1 (v1 v2 : Json) : List (String × Json) := [("b", v2), ("a", v1)]
def l2 (v1 v2 : Json) : List (String × Json) := [("a", v1), ("b", v2)]

theorem test_eq (v1 v2 : Json) : Json.mkObj (l1 v1 v2) = Json.mkObj (l2 v1 v2) := by
  dsimp [Json.mkObj, l1, l2, Std.TreeMap.Raw.ofList, Std.DTreeMap.Raw.Const.ofList, Std.DTreeMap.Raw.ofList]
