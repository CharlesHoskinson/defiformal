import DefiKernel.Certificates.Correspondence
open DefiKernel.Certificates

def withSourceMapKey (key : String) : DecodedIR :=
  match canonicalWitnessIR with
  | .execution (.typed env payload) =>
    .execution (.typed { env with source_map := [(key, "pin")] } payload)
  | ir => ir

def main : IO Unit := do
  let test_keys := [
    "plain",
    "a\"b",
    "a\\b",
    "a/b",
    "key with spaces",
    "control\u0000key",
    "newline\nkey",
    "tab\tkey",
    "unicode_λ_key",
    "emoji_🚀_key",
    "nested:colon=equal,comma"
  ]
  for k in test_keys do
    let ir := withSourceMapKey k
    let raw := encodeModule ir
    match decodeBytes raw with
    | .ok dec_ir =>
      if dec_ir == ir then
        IO.println s!"[PASS] key: {k.quote}"
      else
        IO.println s!"[FAIL - mismatch] key: {k.quote}"
    | .error e =>
      IO.println s!"[FAIL - decode error] key: {k.quote} error: {encodeDecodeFailure e}"

#eval! main
