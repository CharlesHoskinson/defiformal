import DefiKernel.Certificates.Schema
import DefiKernel.Certificates.Decode
import DefiKernel.Certificates.Correspondence

open DefiKernel.Certificates

def partyToJson (p : Party) : Lean.Json :=
  Lean.Json.str (match p with | .alice => "alice" | .bob => "bob" | .vault => "vault" | .pool => "pool")

def assetToJson (a : Asset) : Lean.Json :=
  Lean.Json.str (match a with | .usd => "usd" | .share => "share" | .collateral => "collateral" | .debt => "debt")

def domainToJson (d : Domain) : Lean.Json :=
  Lean.Json.str (match d with | .main => "main" | .other => "other")

def cellToJson (c : CellEnc) : Lean.Json :=
  Lean.Json.mkObj [("domain", domainToJson c.domain), ("party", partyToJson c.party), ("asset", assetToJson c.asset)]

theorem decodeParty_partyToJson (p : Party) : decodeParty (partyToJson p) = .ok p := by
  cases p <;> rfl

theorem decodeAsset_assetToJson (a : Asset) : decodeAsset (assetToJson a) = .ok a := by
  cases a <;> rfl

theorem decodeDomain_domainToJson (d : Domain) : decodeDomain (domainToJson d) = .ok d := by
  cases d <;> rfl

theorem decodeCell_cellToJson (c : CellEnc) : decodeCell (cellToJson c) = .ok c := by
  cases c with | mk d p a =>
  cases d <;> cases p <;> cases a <;> rfl

def rightToJson : RightEnc → Lean.Json
  | .invoke => Lean.Json.mkObj [("tag", Lean.Json.str "invoke")]
  | .debit c => Lean.Json.mkObj [("tag", Lean.Json.str "debit"), ("cell", cellToJson c)]
  | .changeSupply d a => Lean.Json.mkObj [("tag", Lean.Json.str "changeSupply"), ("domain", domainToJson d), ("asset", assetToJson a)]

theorem decodeRight_rightToJson (r : RightEnc) : decodeRight (rightToJson r) = .ok r := by
  cases r with
  | invoke => rfl
  | debit c =>
    have h_c := decodeCell_cellToJson c
    have h_def : decodeRight (rightToJson (.debit c)) = (do
        let c_dec ← decodeCell (cellToJson c)
        .ok (.debit c_dec)) := rfl
    rw [h_def, h_c]
    rfl
  | changeSupply d a =>
    cases d <;> cases a <;> rfl

def grantToJson (g : GrantEnc) : Lean.Json :=
  Lean.Json.mkObj [
    ("holder", partyToJson g.holder),
    ("domain", domainToJson g.domain),
    ("operation", Lean.Json.num g.operation),
    ("right", rightToJson g.right)
  ]

theorem decodeGrant_grantToJson (g : GrantEnc) : decodeGrant (grantToJson g) = .ok g := by
  cases g with | mk h d op r =>
  have h_r := decodeRight_rightToJson r
  cases h with
  | alice =>
    cases d with
    | main =>
      have h_def : decodeGrant (grantToJson ⟨.alice, .main, op, r⟩) = (do
          let r_dec ← decodeRight (rightToJson r)
          .ok ⟨.alice, .main, op, r_dec⟩) := rfl
      rw [h_def, h_r]
      rfl
    | other =>
      have h_def : decodeGrant (grantToJson ⟨.alice, .other, op, r⟩) = (do
          let r_dec ← decodeRight (rightToJson r)
          .ok ⟨.alice, .other, op, r_dec⟩) := rfl
      rw [h_def, h_r]
      rfl
  | bob =>
    cases d with
    | main =>
      have h_def : decodeGrant (grantToJson ⟨.bob, .main, op, r⟩) = (do
          let r_dec ← decodeRight (rightToJson r)
          .ok ⟨.bob, .main, op, r_dec⟩) := rfl
      rw [h_def, h_r]
      rfl
    | other =>
      have h_def : decodeGrant (grantToJson ⟨.bob, .other, op, r⟩) = (do
          let r_dec ← decodeRight (rightToJson r)
          .ok ⟨.bob, .other, op, r_dec⟩) := rfl
      rw [h_def, h_r]
      rfl
  | vault =>
    cases d with
    | main =>
      have h_def : decodeGrant (grantToJson ⟨.vault, .main, op, r⟩) = (do
          let r_dec ← decodeRight (rightToJson r)
          .ok ⟨.vault, .main, op, r_dec⟩) := rfl
      rw [h_def, h_r]
      rfl
    | other =>
      have h_def : decodeGrant (grantToJson ⟨.vault, .other, op, r⟩) = (do
          let r_dec ← decodeRight (rightToJson r)
          .ok ⟨.vault, .other, op, r_dec⟩) := rfl
      rw [h_def, h_r]
      rfl
  | pool =>
    cases d with
    | main =>
      have h_def : decodeGrant (grantToJson ⟨.pool, .main, op, r⟩) = (do
          let r_dec ← decodeRight (rightToJson r)
          .ok ⟨.pool, .main, op, r_dec⟩) := rfl
      rw [h_def, h_r]
      rfl
    | other =>
      have h_def : decodeGrant (grantToJson ⟨.pool, .other, op, r⟩) = (do
          let r_dec ← decodeRight (rightToJson r)
          .ok ⟨.pool, .other, op, r_dec⟩) := rfl
      rw [h_def, h_r]
      rfl

#print axioms decodeGrant_grantToJson
