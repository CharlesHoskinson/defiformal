import DefiKernel.Certificates.Schema
import DefiKernel.Certificates.Decode
import DefiKernel.Certificates.Encode
import DefiKernel.Certificates.CanonicalJson

namespace DefiKernel.Certificates

/-- Bounded array lengths for envelope collections matching production parser limits. -/
def EnvelopeLengthBounds (env : EnvelopeEnc) : Prop :=
  env.audit_roots.length ≤ 4096 ∧
  env.assumptions.length ≤ 4096 ∧
  env.invariants.length ≤ 4096 ∧
  env.libraries.length ≤ 4096 ∧
  env.source_map.length ≤ 4096 ∧
  env.claimed_judgments.length ≤ 4096 ∧
  env.types.parties.length ≤ 4096 ∧
  env.types.assets.length ≤ 4096 ∧
  env.types.domains.length ≤ 4096

/-- Serialized byte bound: the serialized document byte length does not exceed 1 MiB (1048576 bytes). -/
def SerializedByteBound (ir : DecodedIR) : Prop :=
  (encodeModule ir).size ≤ 1048576

/-- Expression AST depth calculation. -/
def exprDepth : ExprEnc → Nat
  | .lit _ => 1
  | .arg _ _ => 1
  | .balance _ => 1
  | .observe _ => 1
  | .timestamp _ => 1
  | .now => 1
  | .unary _ x => exprDepth x + 1
  | .binary _ x y => Nat.max (exprDepth x) (exprDepth y) + 1
  | .ite c t e => Nat.max (exprDepth c) (Nat.max (exprDepth t) (exprDepth e)) + 1

/-- Expression depth bound: expression depth does not exceed 55 (ensuring whole-document JSON depth ≤ 64). -/
def ExprDepthBounded (e : ExprEnc) : Prop :=
  exprDepth e ≤ 55

/-- Template depth bound: all guard expressions satisfy ExprDepthBounded. -/
def TemplateDepthBounded (t : TemplateEnc) : Prop :=
  ∀ g ∈ t.guard, ExprDepthBounded g

/-- Bounded array lengths for template collections matching parser limits. -/
def TemplateLengthBounds (t : TemplateEnc) : Prop :=
  t.guard.length ≤ 4096 ∧
  t.deltas.length ≤ 4096 ∧
  t.supplyDeltas.length ≤ 4096 ∧
  t.stateReads.length ≤ 4096 ∧
  t.envReads.length ≤ 4096 ∧
  t.writes.length ≤ 4096

/-- Bounded array lengths for typed execute payload matching production parser limits. -/
def TypedPayloadLengthBounds (p : TypedExecutePayloadEnc) : Prop :=
  p.state.cells.length = 32 ∧
  p.registry.entries.length ≤ 4096 ∧
  (∀ e ∈ p.registry.entries, TemplateLengthBounds e.template) ∧
  p.store.entries.length ≤ 4096 ∧
  p.env.entries.length ≤ 4096 ∧
  p.request.arguments.length ≤ 4096 ∧
  p.request.capabilityIds.length ≤ 4096 ∧
  p.request.parties.length ≤ 4096

/-- Bounded array lengths for composition step payload matching production parser limits. -/
def StepPayloadLengthBounds (p : CompositionStepPayloadEnc) : Prop :=
  p.config.registry.entries.length ≤ 4096 ∧
  (∀ e ∈ p.config.registry.entries, TemplateLengthBounds e.template) ∧
  p.pre.state.cells.length = 32 ∧
  p.pre.capabilities.entries.length ≤ 4096 ∧
  p.boundary.env.entries.length ≤ 4096 ∧
  p.history.length ≤ 4096 ∧
  (match p.step with
   | .transfer t => t.deltas.length ≤ 4096 ∧ t.supplyDeltas.length ≤ 4096
   | .invocation inv => inv.inputs.length ≤ 4096
   | _ => True)

/-- Bounded array lengths for composition run payload matching production parser limits. -/
def RunPayloadLengthBounds (p : CompositionRunPayloadEnc) : Prop :=
  p.config.registry.entries.length ≤ 4096 ∧
  (∀ e ∈ p.config.registry.entries, TemplateLengthBounds e.template) ∧
  p.world.state.cells.length = 32 ∧
  p.world.capabilities.entries.length ≤ 4096 ∧
  p.boundaries.length ≤ 4096 ∧
  (∀ b ∈ p.boundaries, b.env.entries.length ≤ 4096) ∧
  p.steps.length ≤ 4096 ∧
  (∀ s ∈ p.steps, match s with
   | .step (.transfer t) => t.deltas.length ≤ 4096 ∧ t.supplyDeltas.length ≤ 4096
   | .step (.invocation inv) => inv.inputs.length ≤ 4096
   | _ => True)

/-- Depth bounds for typed execute payload. -/
def TypedPayloadDepthBounds (p : TypedExecutePayloadEnc) : Prop :=
  ∀ e ∈ p.registry.entries, TemplateDepthBounded e.template

/-- Depth bounds for composition step payload. -/
def StepPayloadDepthBounds (p : CompositionStepPayloadEnc) : Prop :=
  ∀ e ∈ p.config.registry.entries, TemplateDepthBounded e.template

/-- Depth bounds for composition run payload. -/
def RunPayloadDepthBounds (p : CompositionRunPayloadEnc) : Prop :=
  ∀ e ∈ p.config.registry.entries, TemplateDepthBounded e.template

def standard32CellKeys : List (Domain × Party × Asset) :=
  let parties : List Party := [.alice, .bob, .vault, .pool]
  let assets : List Asset := [.usd, .share, .collateral, .debt]
  let domains : List Domain := [.main, .other]
  domains.flatMap fun d ↦
    parties.flatMap fun p ↦
      assets.map fun a ↦ (d, p, a)

def StandardTypesEnum (types : TypesEnc) : Prop :=
  types.parties = [.alice, .bob, .vault, .pool] ∧
  types.assets = [.usd, .share, .collateral, .debt] ∧
  types.domains = [.main, .other]

def StoreCanonical (store : StoreEnc) : Prop :=
  (store.entries.map (·.id)).Nodup

def RequestCanonical (_ : RequestEnc) : Prop := True
def EnvironmentCanonical (_ : EnvironmentEnc) : Prop := True
def ClaimedNextStateCanonical (_ : Option StateEnc) : Prop := True
def TemplateCanonical (_ : TemplateEnc) : Prop := True

def isSortedStrictAscending (keys : List String) : Bool :=
  match keys with
  | [] => true
  | [_] => true
  | x :: y :: rest =>
    if x < y then isSortedStrictAscending (y :: rest) else false

def SourceMapSorted (sourceMap : List (String × String)) : Prop :=
  isSortedStrictAscending (sourceMap.map (·.1)) = true

def SupportedIR (ir : DecodedIR) : Prop :=
  SerializedByteBound ir ∧
  match ir with
  | .execution (.typed env payload) =>
    env.schema_version = 1 ∧
    env.mode = "typed-execute" ∧
    StandardTypesEnum env.types ∧
    payload.state.cells.length = 32 ∧
    payload.state.cells.map (fun c ↦ (c.domain, c.party, c.asset)) = standard32CellKeys ∧
    payload.state.cells.all (fun c ↦ c.amount.den > 0 ∧ c.amount.num ≥ 0) = true ∧
    StoreCanonical payload.store ∧
    (payload.registry.entries.map (·.id)).Nodup ∧
    EnvelopeLengthBounds env ∧
    TypedPayloadLengthBounds payload ∧
    TypedPayloadDepthBounds payload
  | .execution (.step env payload) =>
    env.schema_version = 1 ∧
    env.mode = "composition-step" ∧
    StandardTypesEnum env.types ∧
    (match payload.step with | .unsupported _ => False | _ => True) ∧
    payload.pre.state.cells.length = 32 ∧
    payload.pre.state.cells.map (fun c ↦ (c.domain, c.party, c.asset)) = standard32CellKeys ∧
    payload.pre.state.cells.all (fun c ↦ c.amount.den > 0 ∧ c.amount.num ≥ 0) = true ∧
    StoreCanonical payload.pre.capabilities ∧
    (payload.config.registry.entries.map (·.id)).Nodup ∧
    EnvelopeLengthBounds env ∧
    StepPayloadLengthBounds payload ∧
    StepPayloadDepthBounds payload
  | .execution (.run env payload) =>
    env.schema_version = 1 ∧
    env.mode = "composition-run" ∧
    StandardTypesEnum env.types ∧
    payload.steps.all (fun s ↦ match s with | .unsupported _ => false | _ => true) = true ∧
    payload.world.state.cells.length = 32 ∧
    payload.world.state.cells.map (fun c ↦ (c.domain, c.party, c.asset)) = standard32CellKeys ∧
    payload.world.state.cells.all (fun c ↦ c.amount.den > 0 ∧ c.amount.num ≥ 0) = true ∧
    StoreCanonical payload.world.capabilities ∧
    (payload.config.registry.entries.map (·.id)).Nodup ∧
    EnvelopeLengthBounds env ∧
    RunPayloadLengthBounds payload ∧
    RunPayloadDepthBounds payload
  | .audit _ => False
  | .codec _ => False

def CanonicalIR (ir : DecodedIR) : Prop :=
  match ir with
  | .execution (.typed env payload) =>
    SourceMapSorted env.source_map ∧
    ClaimedNextStateCanonical env.claimed_next_state ∧
    payload.state.cells.all (fun c ↦ Int.gcd c.amount.num.natAbs c.amount.den = 1) = true ∧
    (∀ e ∈ payload.registry.entries, TemplateCanonical e.template) ∧
    RequestCanonical payload.request ∧
    EnvironmentCanonical payload.env
  | .execution (.step env payload) =>
    SourceMapSorted env.source_map ∧
    ClaimedNextStateCanonical env.claimed_next_state ∧
    payload.pre.state.cells.all (fun c ↦ Int.gcd c.amount.num.natAbs c.amount.den = 1) = true ∧
    (∀ e ∈ payload.config.registry.entries, TemplateCanonical e.template) ∧
    EnvironmentCanonical payload.boundary.env
  | .execution (.run env payload) =>
    SourceMapSorted env.source_map ∧
    ClaimedNextStateCanonical env.claimed_next_state ∧
    payload.world.state.cells.all (fun c ↦ Int.gcd c.amount.num.natAbs c.amount.den = 1) = true ∧
    (∀ e ∈ payload.config.registry.entries, TemplateCanonical e.template) ∧
    (∀ b ∈ payload.boundaries, EnvironmentCanonical b.env)
  | .audit _ => False
  | .codec _ => False

def StructurallyAdmissibleIR (ir : DecodedIR) : Prop :=
  SupportedIR ir ∧ CanonicalIR ir

def standard32Cells : List StateCellEnc :=
  let parties : List Party := [.alice, .bob, .vault, .pool]
  let assets : List Asset := [.usd, .share, .collateral, .debt]
  let domains : List Domain := [.main, .other]
  domains.flatMap fun d ↦
    parties.flatMap fun p ↦
      assets.map fun a ↦
        ⟨d, p, a, ⟨0, 1⟩⟩

def canonicalWitnessIR : DecodedIR :=
  .execution (.typed
    ⟨1, "typed-execute", ⟨"a12b7cac05a818cc8d35c2ca440b7170a2807e92", "leanprover/lean4:v4.33.0-rc2",
      "51e6992efd06126df61a496bebf8f49482a4e129", "", none, none⟩,
      ["DefiKernel.Certificates", "DefiKernel.Typed", "DefiKernel.Composition"],
      ⟨[.alice, .bob, .vault, .pool], [.usd, .share, .collateral, .debt], [.main, .other]⟩,
      ["environment-authenticity"], [], [], [], [], none, false, false⟩
    ⟨⟨[]⟩, ⟨[]⟩, ⟨.alice, .main⟩, ⟨[]⟩, 100, ⟨0, [.alice], [], [], some .alice⟩, ⟨standard32Cells⟩⟩)

set_option maxRecDepth 100000 in
theorem structurallyAdmissible_nonempty : StructurallyAdmissibleIR canonicalWitnessIR := by
  dsimp [StructurallyAdmissibleIR, SupportedIR, CanonicalIR, canonicalWitnessIR, StandardTypesEnum,
         SourceMapSorted, ClaimedNextStateCanonical, standard32Cells, standard32CellKeys,
         isSortedStrictAscending, StoreCanonical, RequestCanonical, EnvironmentCanonical,
         EnvelopeLengthBounds, TypedPayloadLengthBounds,
         TypedPayloadDepthBounds, TemplateLengthBounds, TemplateDepthBounded, SerializedByteBound]
  refine ⟨⟨by decide, ⟨rfl, rfl, ⟨rfl, rfl, rfl⟩, rfl, rfl, by decide, List.nodup_nil, List.nodup_nil, by decide, ?_, ?_⟩⟩, ?_⟩
  · refine ⟨rfl, by decide, ?_, by decide, by decide, by decide, by decide, by decide⟩
    intro _ h; contradiction
  · intro _ h; contradiction
  · refine ⟨rfl, trivial, by decide, ?_, trivial, trivial⟩
    intro _ h; contradiction

#print axioms structurallyAdmissible_nonempty

end DefiKernel.Certificates
