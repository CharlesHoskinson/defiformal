import DefiKernel.Certificates.Correspondence
open DefiKernel.Certificates

set_option maxRecDepth 1000000 in
theorem test_size : (encodeModule canonicalWitnessIR).size ≤ 1048576 := by
  decide

#print axioms test_size
