import DefiKernel.Certificates.Schema
import DefiKernel.Certificates.Decode
import DefiKernel.Certificates.Correspondence

open DefiKernel.Certificates

def partyToJson (p : Party) : Lean.Json :=
  Lean.Json.str (match p with | .alice => "alice" | .bob => "bob" | .vault => "vault" | .pool => "pool")

def assetToJson (a : Asset) : Lean.Json :=
  Lean.Json.str (match a with | .usd => "usd" | .share => "share" | .collateral => "collateral" | .debt => "debt")

def domainToJson (d : Domain) : Lean.Json :=
  Lean.Json.str (match d with | .main => "main" | .other => "other")

def numericUnitToJson : NumericUnitEnc → Lean.Json
  | .scalar => Lean.Json.mkObj [("tag", Lean.Json.str "scalar")]
  | .amount a => Lean.Json.mkObj [("tag", Lean.Json.str "amount"), ("asset", assetToJson a)]
  | .price b q => Lean.Json.mkObj [("tag", Lean.Json.str "price"), ("base", assetToJson b), ("quote", assetToJson q)]

def unitToJson : UnitEnc → Lean.Json
  | .bool => Lean.Json.mkObj [("tag", Lean.Json.str "bool")]
  | .numeric nu => numericUnitToJson nu

def ratToJson (r : RatEnc) : Lean.Json :=
  Lean.Json.mkObj [("num", Lean.Json.num r.num), ("den", Lean.Json.num r.den)]

def unaryOpToJson : UnaryOpEnc → Lean.Json
  | .not => Lean.Json.mkObj [("tag", Lean.Json.str "not")]
  | .neg nu => Lean.Json.mkObj [("tag", Lean.Json.str "neg"), ("numeric", numericUnitToJson nu)]

def binaryOpToJson : BinaryOpEnc → Lean.Json
  | .add nu => Lean.Json.mkObj [("tag", Lean.Json.str "add"), ("numeric", numericUnitToJson nu)]
  | .sub nu => Lean.Json.mkObj [("tag", Lean.Json.str "sub"), ("numeric", numericUnitToJson nu)]
  | .scale nu => Lean.Json.mkObj [("tag", Lean.Json.str "scale"), ("numeric", numericUnitToJson nu)]
  | .divide nu => Lean.Json.mkObj [("tag", Lean.Json.str "divide"), ("numeric", numericUnitToJson nu)]
  | .ratio nu => Lean.Json.mkObj [("tag", Lean.Json.str "ratio"), ("numeric", numericUnitToJson nu)]
  | .convert b q => Lean.Json.mkObj [("tag", Lean.Json.str "convert"), ("base", assetToJson b), ("quote", assetToJson q)]
  | .unconvert b q => Lean.Json.mkObj [("tag", Lean.Json.str "unconvert"), ("base", assetToJson b), ("quote", assetToJson q)]
  | .and => Lean.Json.mkObj [("tag", Lean.Json.str "and")]
  | .or => Lean.Json.mkObj [("tag", Lean.Json.str "or")]
  | .eq u => Lean.Json.mkObj [("tag", Lean.Json.str "eq"), ("unit", unitToJson u)]
  | .lt nu => Lean.Json.mkObj [("tag", Lean.Json.str "lt"), ("numeric", numericUnitToJson nu)]
  | .le nu => Lean.Json.mkObj [("tag", Lean.Json.str "le"), ("numeric", numericUnitToJson nu)]

def packedValueToJson (v : PackedValueEnc) : Lean.Json :=
  match v.unit with
  | .bool => Lean.Json.bool v.valBool
  | .numeric _ => ratToJson ⟨v.valRat.num, v.valRat.den⟩

def partyRefToJson : PartyRefEnc → Lean.Json
  | .caller => Lean.Json.mkObj [("tag", Lean.Json.str "caller")]
  | .argument idx => Lean.Json.mkObj [("tag", Lean.Json.str "argument"), ("index", Lean.Json.num idx)]
  | .literal p => Lean.Json.mkObj [("tag", Lean.Json.str "literal"), ("party", partyToJson p)]

def cellRefToJson (c : CellRefEnc) : Lean.Json :=
  Lean.Json.mkObj [("domain", domainToJson c.domain), ("owner", partyRefToJson c.owner)]

def packedCellRefToJson (c : PackedCellRefEnc) : Lean.Json :=
  Lean.Json.mkObj [("asset", assetToJson c.asset), ("cell", cellRefToJson c.cell)]

def observationKeyToJson (k : ObservationKeyEnc) : Lean.Json :=
  Lean.Json.mkObj [("domain", domainToJson k.domain), ("id", Lean.Json.num k.id)]

def observationRefToJson (r : ObservationRefEnc) : Lean.Json :=
  Lean.Json.mkObj [("key", observationKeyToJson r.key), ("unit", unitToJson r.unit)]

def exprToJson : ExprEnc → Lean.Json
  | .lit v => Lean.Json.mkObj [("tag", Lean.Json.str "lit"), ("unit", unitToJson v.unit), ("value", packedValueToJson v)]
  | .arg idx u => Lean.Json.mkObj [("tag", Lean.Json.str "arg"), ("index", Lean.Json.num idx), ("unit", unitToJson u)]
  | .balance c => Lean.Json.mkObj [("tag", Lean.Json.str "balance"), ("cell", packedCellRefToJson c)]
  | .observe r => Lean.Json.mkObj [("tag", Lean.Json.str "observe"), ("ref", observationRefToJson r)]
  | .timestamp k => Lean.Json.mkObj [("tag", Lean.Json.str "timestamp"), ("key", observationKeyToJson k)]
  | .now => Lean.Json.mkObj [("tag", Lean.Json.str "now")]
  | .unary op x => Lean.Json.mkObj [("tag", Lean.Json.str "unary"), ("op", unaryOpToJson op), ("x", exprToJson x)]
  | .binary op x y => Lean.Json.mkObj [("tag", Lean.Json.str "binary"), ("op", binaryOpToJson op), ("x", exprToJson x), ("y", exprToJson y)]
  | .ite c y n => Lean.Json.mkObj [("tag", Lean.Json.str "ite"), ("condition", exprToJson c), ("yes", exprToJson y), ("no", exprToJson n)]

theorem decodeUnaryOp_unaryOpToJson (op : UnaryOpEnc) : decodeUnaryOp (unaryOpToJson op) = .ok op := by
  cases op with
  | not => rfl
  | neg nu =>
    cases nu with
    | scalar => rfl
    | amount a => cases a <;> rfl
    | price b q => cases b <;> cases q <;> rfl

theorem decodeBinaryOp_binaryOpToJson (op : BinaryOpEnc) : decodeBinaryOp (binaryOpToJson op) = .ok op := by
  cases op with
  | add nu => cases nu with | scalar => rfl | amount a => cases a <;> rfl | price b q => cases b <;> cases q <;> rfl
  | sub nu => cases nu with | scalar => rfl | amount a => cases a <;> rfl | price b q => cases b <;> cases q <;> rfl
  | scale nu => cases nu with | scalar => rfl | amount a => cases a <;> rfl | price b q => cases b <;> cases q <;> rfl
  | divide nu => cases nu with | scalar => rfl | amount a => cases a <;> rfl | price b q => cases b <;> cases q <;> rfl
  | ratio nu => cases nu with | scalar => rfl | amount a => cases a <;> rfl | price b q => cases b <;> cases q <;> rfl
  | convert b q => cases b <;> cases q <;> rfl
  | unconvert b q => cases b <;> cases q <;> rfl
  | and => rfl
  | or => rfl
  | eq u =>
    cases u with
    | bool => rfl
    | numeric nu => cases nu with | scalar => rfl | amount a => cases a <;> rfl | price b q => cases b <;> cases q <;> rfl
  | lt nu => cases nu with | scalar => rfl | amount a => cases a <;> rfl | price b q => cases b <;> cases q <;> rfl
  | le nu => cases nu with | scalar => rfl | amount a => cases a <;> rfl | price b q => cases b <;> cases q <;> rfl

theorem decodeExprFuel_unary_step (fuel : Nat) (op : UnaryOpEnc) (x : ExprEnc)
    (h_x : decodeExprFuel fuel (exprToJson x) = .ok x) :
    decodeExprFuel (fuel + 1) (exprToJson (.unary op x)) = .ok (.unary op x) := by
  have h_def : decodeExprFuel (fuel + 1) (exprToJson (.unary op x)) = (do
      let op_dec ← decodeUnaryOp (unaryOpToJson op)
      let x_dec ← decodeExprFuel fuel (exprToJson x)
      .ok (.unary op_dec x_dec)) := rfl
  have h_op := decodeUnaryOp_unaryOpToJson op
  rw [h_def, h_op, h_x]
  rfl

theorem decodeExprFuel_binary_step (fuel : Nat) (op : BinaryOpEnc) (x y : ExprEnc)
    (h_x : decodeExprFuel fuel (exprToJson x) = .ok x)
    (h_y : decodeExprFuel fuel (exprToJson y) = .ok y) :
    decodeExprFuel (fuel + 1) (exprToJson (.binary op x y)) = .ok (.binary op x y) := by
  have h_def : decodeExprFuel (fuel + 1) (exprToJson (.binary op x y)) = (do
      let op_dec ← decodeBinaryOp (binaryOpToJson op)
      let x_dec ← decodeExprFuel fuel (exprToJson x)
      let y_dec ← decodeExprFuel fuel (exprToJson y)
      .ok (.binary op_dec x_dec y_dec)) := rfl
  have h_op := decodeBinaryOp_binaryOpToJson op
  rw [h_def, h_op, h_x, h_y]
  rfl

theorem decodeExprFuel_ite_step (fuel : Nat) (c y n : ExprEnc)
    (h_c : decodeExprFuel fuel (exprToJson c) = .ok c)
    (h_y : decodeExprFuel fuel (exprToJson y) = .ok y)
    (h_n : decodeExprFuel fuel (exprToJson n) = .ok n) :
    decodeExprFuel (fuel + 1) (exprToJson (.ite c y n)) = .ok (.ite c y n) := by
  have h_def : decodeExprFuel (fuel + 1) (exprToJson (.ite c y n)) = (do
      let c_dec ← decodeExprFuel fuel (exprToJson c)
      let y_dec ← decodeExprFuel fuel (exprToJson y)
      let n_dec ← decodeExprFuel fuel (exprToJson n)
      .ok (.ite c_dec y_dec n_dec)) := rfl
  rw [h_def, h_c, h_y, h_n]
  rfl
