import DefiKernel.Certificates.Schema
import DefiKernel.Certificates.Decode
import DefiKernel.Certificates.Correspondence

open DefiKernel.Certificates

def partyToJson (p : Party) : Lean.Json :=
  Lean.Json.str (match p with | .alice => "alice" | .bob => "bob" | .vault => "vault" | .pool => "pool")

def assetToJson (a : Asset) : Lean.Json :=
  Lean.Json.str (match a with | .usd => "usd" | .share => "share" | .collateral => "collateral" | .debt => "debt")

def domainToJson (d : Domain) : Lean.Json :=
  Lean.Json.str (match d with | .main => "main" | .other => "other")

def ratToJson (r : RatEnc) : Lean.Json :=
  Lean.Json.mkObj [("num", Lean.Json.num r.num), ("den", Lean.Json.num r.den)]

def stateCellToJson (c : StateCellEnc) : Lean.Json :=
  Lean.Json.mkObj [
    ("domain", domainToJson c.domain),
    ("party", partyToJson c.party),
    ("asset", assetToJson c.asset),
    ("amount", ratToJson c.amount)
  ]

theorem test_def (amt : RatEnc) :
    decodeStateCell (stateCellToJson (StateCellEnc.mk .main .alice .usd amt)) =
    (decodeRat (ratToJson amt) >>= fun amount =>
      if amount.num < 0 then Except.error DecodeFailure.stateNonneg
      else Except.ok ⟨.main, .alice, .usd, amount⟩) := rfl

theorem test_eval (amt : RatEnc)
    (h_den : amt.den ≠ 0) (h_gcd : Int.gcd amt.num.natAbs amt.den = 1) (h_nonneg : amt.num ≥ 0) :
    decodeStateCell (stateCellToJson (StateCellEnc.mk .main .alice .usd amt)) = .ok (StateCellEnc.mk .main .alice .usd amt) := by
  have h_amt : decodeRat (ratToJson amt) = .ok amt := decodeRat_mkObj amt.num amt.den h_den h_gcd
  rw [test_def, h_amt]
  change (if amt.num < 0 then Except.error DecodeFailure.stateNonneg else Except.ok (StateCellEnc.mk .main .alice .usd amt)) = Except.ok (StateCellEnc.mk .main .alice .usd amt)
  have h_not_neg : ¬ (amt.num < 0) := by omega
  rw [if_neg h_not_neg]

#print axioms test_eval
