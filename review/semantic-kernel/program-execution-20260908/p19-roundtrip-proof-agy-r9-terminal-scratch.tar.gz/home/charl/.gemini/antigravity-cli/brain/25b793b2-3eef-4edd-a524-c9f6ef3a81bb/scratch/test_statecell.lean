import DefiKernel.Certificates.Schema
import DefiKernel.Certificates.Decode
import DefiKernel.Certificates.Correspondence

open DefiKernel.Certificates

def partyToJson (p : Party) : Lean.Json :=
  Lean.Json.str (match p with | .alice => "alice" | .bob => "bob" | .vault => "vault" | .pool => "pool")

def assetToJson (a : Asset) : Lean.Json :=
  Lean.Json.str (match a with | .usd => "usd" | .share => "share" | .collateral => "collateral" | .debt => "debt")

def domainToJson (d : Domain) : Lean.Json :=
  Lean.Json.str (match d with | .main => "main" | .other => "other")

def ratToJson (r : RatEnc) : Lean.Json :=
  Lean.Json.mkObj [("num", Lean.Json.num r.num), ("den", Lean.Json.num r.den)]

def stateCellToJson (c : StateCellEnc) : Lean.Json :=
  Lean.Json.mkObj [
    ("domain", domainToJson c.domain),
    ("party", partyToJson c.party),
    ("asset", assetToJson c.asset),
    ("amount", ratToJson c.amount)
  ]

theorem decodeStateCell_stateCellToJson (c : StateCellEnc)
    (h_nonneg : c.amount.num ≥ 0) (h_den : c.amount.den ≠ 0)
    (h_gcd : Int.gcd c.amount.num.natAbs c.amount.den = 1) :
    decodeStateCell (stateCellToJson c) = .ok c := by
  cases c with | mk d p a amt =>
  have h_amt : decodeRat (ratToJson amt) = .ok amt := decodeRat_mkObj amt.num amt.den h_den h_gcd
  cases d <;> cases p <;> cases a <;> (
    have h_def : decodeStateCell (stateCellToJson ⟨_, _, _, amt⟩) = (do
        let r ← decodeRat (ratToJson amt)
        if r.num < 0 then throw .stateNonneg
        .ok ⟨_, _, _, r⟩) := rfl
    rw [h_def, h_amt]
    dsimp
    have h_not_neg : ¬ (amt.num < 0) := by omega
    simp [h_not_neg]
  )

#print axioms decodeStateCell_stateCellToJson
