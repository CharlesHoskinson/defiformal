import DefiKernel.Certificates.Schema
import DefiKernel.Certificates.Decode
import DefiKernel.Certificates.Correspondence

open DefiKernel.Certificates

def unitToJson : UnitEnc → Lean.Json
  | .bool => Lean.Json.mkObj [("tag", Lean.Json.str "bool")]
  | .numeric .scalar => Lean.Json.mkObj [("tag", Lean.Json.str "scalar")]
  | .numeric (.amount .usd) => Lean.Json.mkObj [("tag", Lean.Json.str "amount"), ("asset", Lean.Json.str "usd")]
  | .numeric (.amount .share) => Lean.Json.mkObj [("tag", Lean.Json.str "amount"), ("asset", Lean.Json.str "share")]
  | .numeric (.amount .collateral) => Lean.Json.mkObj [("tag", Lean.Json.str "amount"), ("asset", Lean.Json.str "collateral")]
  | .numeric (.amount .debt) => Lean.Json.mkObj [("tag", Lean.Json.str "amount"), ("asset", Lean.Json.str "debt")]
  | .numeric (.price b q) => Lean.Json.mkObj [("tag", Lean.Json.str "price"), ("base", Lean.Json.str "usd"), ("quote", Lean.Json.str "usd")]

def exprToJson : ExprEnc → Lean.Json
  | .arg idx u => Lean.Json.mkObj [("tag", Lean.Json.str "arg"), ("index", Lean.Json.num idx), ("unit", unitToJson u)]
  | _ => Lean.Json.null

theorem decodeExprFuel_arg_def (fuel : Nat) (idx : Nat) (u : UnitEnc) :
    decodeExprFuel (fuel + 1) (exprToJson (.arg idx u)) = (do
      let u_dec ← decodeUnit (unitToJson u)
      .ok (.arg idx u_dec)) := rfl

