import DefiKernel.Certificates.Correspondence

open DefiKernel.Certificates

set_option maxRecDepth 100000 in
theorem test_nonempty_size : (encodeModule canonicalWitnessIR).size ≤ 1048576 := by decide

#eval (encodeModule canonicalWitnessIR).size
