import DefiKernel.Certificates.Correspondence
import Lean.Data.Json.Parser
open DefiKernel.Certificates

def withSourceMapKey (key : String) : DecodedIR :=
  match canonicalWitnessIR with
  | .execution (.typed env payload) =>
    .execution (.typed { env with source_map := [(key, "pin")] } payload)
  | ir => ir

def main : IO Unit := do
  let raw := encodeModule (withSourceMapKey "a\"b")
  IO.println s!"Encoded bytes length: {raw.size}"
  match decodeBytes raw with
  | .ok _ => IO.println "decodeBytes: OK!"
  | .error e => IO.println s!"decodeBytes error: {encodeDecodeFailure e}"

#eval! main
