import DefiKernel.Certificates.Schema
import DefiKernel.Certificates.Decode
import DefiKernel.Certificates.Correspondence

open DefiKernel.Certificates

def partyToJson (p : Party) : Lean.Json :=
  Lean.Json.str (match p with | .alice => "alice" | .bob => "bob" | .vault => "vault" | .pool => "pool")

def assetToJson (a : Asset) : Lean.Json :=
  Lean.Json.str (match a with | .usd => "usd" | .share => "share" | .collateral => "collateral" | .debt => "debt")

def domainToJson (d : Domain) : Lean.Json :=
  Lean.Json.str (match d with | .main => "main" | .other => "other")

def partyRefToJson : PartyRefEnc → Lean.Json
  | .caller => Lean.Json.mkObj [("tag", Lean.Json.str "caller")]
  | .argument idx => Lean.Json.mkObj [("tag", Lean.Json.str "argument"), ("index", Lean.Json.num idx)]
  | .literal p => Lean.Json.mkObj [("tag", Lean.Json.str "literal"), ("party", partyToJson p)]

def cellRefToJson (c : CellRefEnc) : Lean.Json :=
  Lean.Json.mkObj [("domain", domainToJson c.domain), ("owner", partyRefToJson c.owner)]

def packedCellRefToJson (c : PackedCellRefEnc) : Lean.Json :=
  Lean.Json.mkObj [("asset", assetToJson c.asset), ("cell", cellRefToJson c.cell)]

def observationKeyToJson (k : ObservationKeyEnc) : Lean.Json :=
  Lean.Json.mkObj [("domain", domainToJson k.domain), ("id", Lean.Json.num k.id)]

def numericUnitToJson : NumericUnitEnc → Lean.Json
  | .scalar => Lean.Json.mkObj [("tag", Lean.Json.str "scalar")]
  | .amount a => Lean.Json.mkObj [("tag", Lean.Json.str "amount"), ("asset", assetToJson a)]
  | .price b q => Lean.Json.mkObj [("tag", Lean.Json.str "price"), ("base", assetToJson b), ("quote", assetToJson q)]

def unitToJson : UnitEnc → Lean.Json
  | .bool => Lean.Json.mkObj [("tag", Lean.Json.str "bool")]
  | .numeric nu => numericUnitToJson nu

def observationRefToJson (r : ObservationRefEnc) : Lean.Json :=
  Lean.Json.mkObj [("key", observationKeyToJson r.key), ("unit", unitToJson r.unit)]

def ratToJson (r : RatEnc) : Lean.Json :=
  Lean.Json.mkObj [("num", Lean.Json.num r.num), ("den", Lean.Json.num r.den)]

def packedValueToJson (v : PackedValueEnc) : Lean.Json :=
  match v.unit with
  | .bool => Lean.Json.bool v.valBool
  | .numeric _ => ratToJson ⟨v.valRat.num, v.valRat.den⟩

def exprToJson : ExprEnc → Lean.Json
  | .lit v => Lean.Json.mkObj [("tag", Lean.Json.str "lit"), ("unit", unitToJson v.unit), ("value", packedValueToJson v)]
  | .arg idx u => Lean.Json.mkObj [("tag", Lean.Json.str "arg"), ("index", Lean.Json.num idx), ("unit", unitToJson u)]
  | .balance c => Lean.Json.mkObj [("tag", Lean.Json.str "balance"), ("cell", packedCellRefToJson c)]
  | .observe r => Lean.Json.mkObj [("tag", Lean.Json.str "observe"), ("ref", observationRefToJson r)]
  | .timestamp k => Lean.Json.mkObj [("tag", Lean.Json.str "timestamp"), ("key", observationKeyToJson k)]
  | .now => Lean.Json.mkObj [("tag", Lean.Json.str "now")]
  | .unary op x => Lean.Json.mkObj [("tag", Lean.Json.str "unary"), ("op", Lean.Json.null), ("x", exprToJson x)]
  | .binary op x y => Lean.Json.mkObj [("tag", Lean.Json.str "binary"), ("op", Lean.Json.null), ("x", exprToJson x), ("y", exprToJson y)]
  | .ite c y n => Lean.Json.mkObj [("tag", Lean.Json.str "ite"), ("condition", exprToJson c), ("yes", exprToJson y), ("no", exprToJson n)]

theorem decodePartyRef_partyRefToJson (p : PartyRefEnc) : decodePartyRef (partyRefToJson p) = .ok p := by
  cases p with
  | caller => rfl
  | argument idx => rfl
  | literal p => cases p <;> rfl

theorem decodeCellRef_cellRefToJson (c : CellRefEnc) : decodeCellRef (cellRefToJson c) = .ok c := by
  cases c with | mk d o =>
  have h_o := decodePartyRef_partyRefToJson o
  cases d with
  | main =>
    dsimp [cellRefToJson, decodeCellRef, domainToJson, Lean.Json.mkObj, getField, checkObjectKeys, bind, Except.bind]
    rw [h_o]
    rfl
  | other =>
    dsimp [cellRefToJson, decodeCellRef, domainToJson, Lean.Json.mkObj, getField, checkObjectKeys, bind, Except.bind]
    rw [h_o]
    rfl

theorem decodePackedCellRef_packedCellRefToJson (c : PackedCellRefEnc) : decodePackedCellRef (packedCellRefToJson c) = .ok c := by
  cases c with | mk a cell =>
  have h_cell := decodeCellRef_cellRefToJson cell
  cases a with
  | usd =>
    dsimp [packedCellRefToJson, decodePackedCellRef, assetToJson, Lean.Json.mkObj, getField, checkObjectKeys, bind, Except.bind]
    rw [h_cell]
    rfl
  | share =>
    dsimp [packedCellRefToJson, decodePackedCellRef, assetToJson, Lean.Json.mkObj, getField, checkObjectKeys, bind, Except.bind]
    rw [h_cell]
    rfl
  | collateral =>
    dsimp [packedCellRefToJson, decodePackedCellRef, assetToJson, Lean.Json.mkObj, getField, checkObjectKeys, bind, Except.bind]
    rw [h_cell]
    rfl
  | debt =>
    dsimp [packedCellRefToJson, decodePackedCellRef, assetToJson, Lean.Json.mkObj, getField, checkObjectKeys, bind, Except.bind]
    rw [h_cell]
    rfl

theorem decodeObservationKey_observationKeyToJson (k : ObservationKeyEnc) : decodeObservationKey (observationKeyToJson k) = .ok k := by
  cases k with | mk d id =>
  cases d with
  | main => rfl
  | other => rfl

theorem decodeNumericUnit_numericUnitToJson (nu : NumericUnitEnc) : decodeNumericUnit (numericUnitToJson nu) = .ok nu := by
  cases nu with
  | scalar => rfl
  | amount a => cases a <;> rfl
  | price b q => cases b <;> cases q <;> rfl

theorem decodeUnit_unitToJson (u : UnitEnc) : decodeUnit (unitToJson u) = .ok u := by
  cases u with
  | bool => rfl
  | numeric nu => exact decodeNumericUnit_numericUnitToJson nu

theorem decodeObservationRef_observationRefToJson (r : ObservationRefEnc) : decodeObservationRef (observationRefToJson r) = .ok r := by
  cases r with | mk k u =>
  have h_k := decodeObservationKey_observationKeyToJson k
  have h_u := decodeUnit_unitToJson u
  dsimp [observationRefToJson, decodeObservationRef, Lean.Json.mkObj, getField, checkObjectKeys, bind, Except.bind]
  rw [h_k, h_u]
  rfl

theorem decodeExprFuel_now (fuel : Nat) : decodeExprFuel (fuel + 1) (exprToJson .now) = .ok .now := rfl

theorem decodeExprFuel_timestamp (fuel : Nat) (k : ObservationKeyEnc) :
    decodeExprFuel (fuel + 1) (exprToJson (.timestamp k)) = .ok (.timestamp k) := by
  have h_k := decodeObservationKey_observationKeyToJson k
  dsimp [exprToJson, decodeExprFuel, Lean.Json.mkObj, getField, checkObjectKeys, bind, Except.bind]
  rw [h_k]
  rfl

theorem decodeExprFuel_observe (fuel : Nat) (r : ObservationRefEnc) :
    decodeExprFuel (fuel + 1) (exprToJson (.observe r)) = .ok (.observe r) := by
  have h_r := decodeObservationRef_observationRefToJson r
  dsimp [exprToJson, decodeExprFuel, Lean.Json.mkObj, getField, checkObjectKeys, bind, Except.bind]
  rw [h_r]
  rfl

theorem decodeExprFuel_balance (fuel : Nat) (c : PackedCellRefEnc) :
    decodeExprFuel (fuel + 1) (exprToJson (.balance c)) = .ok (.balance c) := by
  have h_c := decodePackedCellRef_packedCellRefToJson c
  dsimp [exprToJson, decodeExprFuel, Lean.Json.mkObj, getField, checkObjectKeys, bind, Except.bind]
  rw [h_c]
  rfl

theorem decodeExprFuel_arg (fuel : Nat) (idx : Nat) (u : UnitEnc) :
    decodeExprFuel (fuel + 1) (exprToJson (.arg idx u)) = .ok (.arg idx u) := by
  have h_u := decodeUnit_unitToJson u
  dsimp [exprToJson, decodeExprFuel, Lean.Json.mkObj, getField, checkObjectKeys, bind, Except.bind]
  rw [h_u]
  rfl

