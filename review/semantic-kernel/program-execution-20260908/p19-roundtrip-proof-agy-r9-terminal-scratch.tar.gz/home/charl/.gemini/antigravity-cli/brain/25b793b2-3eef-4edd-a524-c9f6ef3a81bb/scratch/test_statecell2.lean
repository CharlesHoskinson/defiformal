import DefiKernel.Certificates.Schema
import DefiKernel.Certificates.Decode
import DefiKernel.Certificates.Correspondence

open DefiKernel.Certificates

def partyToJson (p : Party) : Lean.Json :=
  Lean.Json.str (match p with | .alice => "alice" | .bob => "bob" | .vault => "vault" | .pool => "pool")

def assetToJson (a : Asset) : Lean.Json :=
  Lean.Json.str (match a with | .usd => "usd" | .share => "share" | .collateral => "collateral" | .debt => "debt")

def domainToJson (d : Domain) : Lean.Json :=
  Lean.Json.str (match d with | .main => "main" | .other => "other")

def ratToJson (r : RatEnc) : Lean.Json :=
  Lean.Json.mkObj [("num", Lean.Json.num r.num), ("den", Lean.Json.num r.den)]

def stateCellToJson (c : StateCellEnc) : Lean.Json :=
  Lean.Json.mkObj [
    ("domain", domainToJson c.domain),
    ("party", partyToJson c.party),
    ("asset", assetToJson c.asset),
    ("amount", ratToJson c.amount)
  ]

theorem decodeStateCell_stateCellToJson (d : Domain) (p : Party) (a : Asset) (amt : RatEnc)
    (h_den : amt.den ≠ 0) (h_gcd : Int.gcd amt.num.natAbs amt.den = 1) (h_nonneg : amt.num ≥ 0) :
    decodeStateCell (stateCellToJson ⟨d, p, a, amt⟩) = .ok ⟨d, p, a, amt⟩ := by
  have h_amt : decodeRat (ratToJson amt) = .ok amt := decodeRat_mkObj amt.num amt.den h_den h_gcd
  cases d with
  | main =>
    cases p with
    | alice =>
      cases a with
      | usd =>
        have h_def : decodeStateCell (stateCellToJson ⟨.main, .alice, .usd, amt⟩) = (do
            let r ← decodeRat (ratToJson amt)
            if r.num < 0 then throw .stateNonneg
            .ok ⟨.main, .alice, .usd, r⟩) := rfl
        rw [h_def, h_amt]; dsimp [bind, Except.bind]
        dsimp
        have h_not_neg : ¬ (amt.num < 0) := by omega
        rw [if_neg h_not_neg]; rfl
      | share =>
        have h_def : decodeStateCell (stateCellToJson ⟨.main, .alice, .share, amt⟩) = (do
            let r ← decodeRat (ratToJson amt)
            if r.num < 0 then throw .stateNonneg
            .ok ⟨.main, .alice, .share, r⟩) := rfl
        rw [h_def, h_amt]; dsimp [bind, Except.bind]
        dsimp
        have h_not_neg : ¬ (amt.num < 0) := by omega
        rw [if_neg h_not_neg]; rfl
      | collateral =>
        have h_def : decodeStateCell (stateCellToJson ⟨.main, .alice, .collateral, amt⟩) = (do
            let r ← decodeRat (ratToJson amt)
            if r.num < 0 then throw .stateNonneg
            .ok ⟨.main, .alice, .collateral, r⟩) := rfl
        rw [h_def, h_amt]; dsimp [bind, Except.bind]
        dsimp
        have h_not_neg : ¬ (amt.num < 0) := by omega
        rw [if_neg h_not_neg]; rfl
      | debt =>
        have h_def : decodeStateCell (stateCellToJson ⟨.main, .alice, .debt, amt⟩) = (do
            let r ← decodeRat (ratToJson amt)
            if r.num < 0 then throw .stateNonneg
            .ok ⟨.main, .alice, .debt, r⟩) := rfl
        rw [h_def, h_amt]; dsimp [bind, Except.bind]
        dsimp
        have h_not_neg : ¬ (amt.num < 0) := by omega
        rw [if_neg h_not_neg]; rfl
    | bob => sorry
    | vault => sorry
    | pool => sorry
  | other => sorry
