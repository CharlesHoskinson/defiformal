import DefiKernel.Certificates.Correspondence
open DefiKernel.Certificates

#eval (encodeModule canonicalWitnessIR).size
theorem test_size : (encodeModule canonicalWitnessIR).size ≤ 1048576 := by decide
