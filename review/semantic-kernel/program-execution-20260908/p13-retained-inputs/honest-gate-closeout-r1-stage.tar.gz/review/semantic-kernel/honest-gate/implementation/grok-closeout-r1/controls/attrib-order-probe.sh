#!/usr/bin/env bash
# Bounded proof: the 3d (i) want() lock sources attrib/fns.sh before 3e creates it.
set -uo pipefail
FX=/tmp/honest-gate-attrib-order-proof
rm -rf "$FX"
mkdir -p "$FX"
cat > "$FX/w_rc.sh" <<'SNIP'
declare -A HOUT HRC
HOUT[pairs]="pairs: 1830"; HRC[pairs]=7
fail=0; blkd=0
. "$FX/attrib/fns.sh"
want "died but printed the needle" 'pairs: 1830' pairs
SNIP
# The inner script sees FX from its own environment, not the outer FX unless exported.
# Match the harness: it interpolates $FX into the heredoc because SNIP is unquoted
# in the original? Original uses <<SNIP (unquoted) so $FX expands at write time.
# Recreate that:
cat > "$FX/w_rc.sh" <<SNIP
declare -A HOUT HRC
HOUT[pairs]="pairs: 1830"; HRC[pairs]=7
fail=0; blkd=0
. "$FX/attrib/fns.sh"
want "died but printed the needle" 'pairs: 1830' pairs
SNIP
wout=$(bash "$FX/w_rc.sh" 2>&1); wrc=$?
printf 'WOUT_BEGIN\n%s\nWOUT_END\n' "$wout"
printf 'W_RC=%s\n' "$wrc"
if printf '%s' "$wout" | grep -qF -- "  ok   died but printed"; then
  echo RESULT=would_MISSED_want_not
else
  echo RESULT=would_CAUGHT_want_not
fi
if printf '%s' "$wout" | grep -qF -- "No such file or directory"; then
  echo MISSING_FNS=yes
else
  echo MISSING_FNS=no
fi
if printf '%s' "$wout" | grep -qE 'want: command not found|want: not found'; then
  echo WANT_NOT_DEFINED=yes
else
  echo WANT_NOT_DEFINED=no
fi
# Does the inner script mention FAIL from actual want()?
if printf '%s' "$wout" | grep -qF -- "  FAIL died but printed"; then
  echo ACTUAL_WANT_RAN=yes
else
  echo ACTUAL_WANT_RAN=no
fi
