# Honest-gate-failure closeout r1 — native Grok 4.6

**Role.** Native Grok 4.6 author. Independent GPT-6 checker pending. No Foreman.
**Scope.** Isolated reproduction and evidence closeout of the *existing* `honest-gate-failure` reporting/vacuity/incomplete-input contract.
**Not claimed.** Package archive, roadmap checkbox closure, M4/Claims/new financial facts, scientific paper acceptance, or untouched-holdout credit.

Worktree `/home/charl/defiformal-wt-honest-gate-grok-gpt6-20260908` on `work/honest-gate-grok-gpt6-20260908` at HEAD `a12b7cac05a818cc8d35c2ca440b7170a2807e92`. Never the primary tree.

Residual GPT-6 readiness (unchanged bytes):
- review SHA-256 `6def219a8f6cbbe5f17b4a4a30a2bd362324c5bfc2c807e017429b47df08b2a5`
- inputs SHA-256 `02a28baa0c510a1b7ebe95dce766d1ee910b56e041cc98bd2d100ff16a84b637`

37 historically checked tasks, 7 requirements and 18 scenarios do **not** by themselves prove fresh acceptance. This directory is the current executed candidate for independent adjudication.

## What was executed

Before any harness run: exact read/write closure, Git SHA and file hashes, chmod-000 actually unreadable for uid 1000 (`PermissionError`), `/tmp/negtest-reporting` absent, no parallel honest-gate owner of that scratch, no excluded assessment/holdout payloads read. `algebra/blind-test-set.json` was identity-hashed only (`7287caf83da22d4d10dfd3dfc7fc2f76fd980001306b21ef6f1d13959e76ac1b`, 26552 bytes) and was not used as a fixture.

Pre-existing worktree dirt (residual recovery copies and a live `WORKSTATE.json`) was reversibly quarantined so the harness dirty-check could mean what it historically meant. `/tmp/negtest-reporting` did not exist, so it was not deleted as unknown state.

Pinned runtimes for r2: bash `/usr/bin/bash` 5.3.9, node v24.18.1, python3.14.4, pdfTeX 3.141592653-2.6-1.40.28, BibTeX 0.99d, pdfinfo/pdftotext 26.01.0, git 2.53.0. argv `[/usr/bin/bash, …/formal/v3/negtest-reporting.sh]`, cwd the isolated worktree, `DEFIFORMAL_ROOT` and `GEN_IR` unset.

### Attempt 1 — unrepaired harness (failed baseline, preserved)

| Field | Value |
|---|---|
| Start | 2026-09-08T09:41:16.411219251Z |
| End | 2026-09-08T09:42:30.623136539Z |
| Exit | 1 |
| Result | **206 caught, 1 missed** |
| Harness SHA-256 | `ae7f955b22dc2a545b5dbf92e43e51a928fc41e1bc0e780ba387a14e87d6149e` (HEAD) |

The single miss was `M review/semantic-kernel/program-loop-20260908/WORKSTATE.json`. That file is orchestration state. Concurrent root `cat > …/briefs/honest-gate-closeout-r1.md` was observed during the run. Every reporting/vacuity polarity below was already CAUGHT. Independent snapshots of GATE-3.3 JSON, merged/domain graphs, twelve `SECTION-BRIEF.md` files and `paper/atlas.bbl` were byte-identical after the run (readback of the snapshots themselves also matched). `/tmp/negtest-reporting` was absent after the EXIT trap.

A bounded extra probe proved one **vacuous** harness lock: section 3d (i) sourced `$FX/attrib/fns.sh` before section 3e created it. Actual output: `want: command not found`; `ACTUAL_WANT_RAN=no`; `want_not` still CAUGHT because the ok needle was absent. That is the assertion-trap class this package exists to catch. Attempt 1 is retained as the failed baseline.

### Repair (minimal, in-scope)

Moved the `want()` rc=0 probe to after `attrib/fns.sh` is lifted. Added `want_has` for `FAIL died but printed` and `want_not` for missing-file / command-not-found collapse.

- Before SHA-256 `ae7f955b22dc2a545b5dbf92e43e51a928fc41e1bc0e780ba387a14e87d6149e`
- After SHA-256 `36c7c7b03fdb9f68d51f277ee6daa621f9a6d599b573babe7ccc1037be4e98b9`
- Diff: `repair/negtest-reporting.sh.diff` (26 insertions, 11 deletions)
- Not edited: `totalgate.mjs`, `paper/build.sh`, `gate.sh`, `loop2gate.sh`, `validate.mjs`, sigma scripts, OpenSpec package, `GATE-REGISTER.md`, AFTER logs, paper, expansion, IR

### Attempt r2 — repaired harness

| Field | Value |
|---|---|
| Start | 2026-09-08T09:48:30.887504086Z |
| End | 2026-09-08T09:49:44.466901739Z |
| Exit | 1 |
| Result | **209 caught, 1 missed** |
| Harness SHA-256 | `36c7c7b03fdb9f68d51f277ee6daa621f9a6d599b573babe7ccc1037be4e98b9` |

The single miss is the candidate itself: `M formal/v3/negtest-reporting.sh`. Section 5 still uses full `git status --porcelain -uall`; it was not weakened to ignore the repair. Independent tracked-restore hashes remain equal. The new live locks all CAUGHT:

- `want() rc=0 lock did not collapse to a missing lift`
- `want() rc=0 lock did not collapse to command-not-found`
- `want(): a dead harness is not ok on a stray needle`
- `want(): a dead harness with a stray needle is FAIL`

Do not copy the historical “207 caught / 0 missed” count. Attempt 1 had 207 assertions with 1 environmental miss. r2 has 210 assertions with 1 miss that is the candidate repair path.

## Polarities actually observed (r2)

| Control | Exit / result | Meaning |
|---|---|---|
| totalgate real corpus | 0, CAUGHT | nonempty pass |
| totalgate `$1{,}259$`→`$1{,}260$` | 1, CAUGHT | evaluated disagreement |
| totalgate chmod 000 expansion | 3, CAUGHT | blocked; EACCES; not a disagreement |
| totalgate empty expansion | 3, CAUGHT | vacuity blocked |
| build.sh blocked fixture | 3, CAUGHT | `were NOT checked`; diagnosis surfaced |
| build.sh violated fixture | 1, CAUGHT | `a headline total disagrees` |
| build.sh real tree | 0, CAUGHT | `OK  atlas.pdf` |
| gate.sh orphan / empty look-alike | 3, CAUGHT | no `FAIL 61 of 72` |
| validate.mjs empty dir | 3, CAUGHT | later unblock demonstrated; not restored as blocked |
| gate33 real IR | 0, CAUGHT | JSON restored to snapshot |
| gate33 empty IR | 3, CAUGHT | no PASS artefact |
| verify_final empty | 3, CAUGHT | |
| verify_final real | 0; `spec files: 60 (denominator)`; `X21-armed pairs (60-app basis): 159 of 1770` | |

Eight historical sibling shells still `cd /root/defiformal || exit 9`. Fresh exits: all eight = 9. Left untouched. tasks.md said twelve; this tree has eight such scripts; AFTER recorded eight.

Private PDFs from the existing build: atlas **40** pages / 464367 bytes; supplement **120** pages / 539165 bytes. AFTER recorded 39 atlas pages. This is a measurement, not a scientific-paper claim.

`smoke.sh` still ends by running this harness. That nested step was not re-run. Separate smoke CLI steps: selftest 22/22 exit 0; validate fixtures exit 0; malformed validate exit 1; empty validate exit 3; construct prints `REJECTED` on stderr (smoke.sh captures 2>&1); emit-tex produces `begin{measurement}`.

## 7 requirements / 18 scenarios

Exact mapping: `scenario-disposition.json`. 16 observed on current logs/source, 1 preserved historical exception (sibling exit 9), 1 register-recorded CANNOT FAIL bound (not expanded). 37 historical task boxes retained in `task-disposition.json`; they are not a new current completion and this package is not archived.

## Register limits, unchanged

- Aggregates do not detect a sum-preserving identity swap.
- `EXPECT_CATEGORIES = 12` and `EXPECT_SPEC_FILES = 60` remain hardcoded.
- Source-text matching is not arbitrary TeX macros, conditionals, or PDF meaning.
- The keyword tag-subset invariant is constructed to hold.
- No new adversarial manuscript / macro-generated figure / PDF-comparison design.
- No new financial correctness from a gate pass.
- `loop2gate.sh` still records BLOCKED citations because no citation checker exists; that is not converted into a pass.

Historical Grok/Fable register reviews, AFTER 43-caught, and commit `041865749cf39439cf3f006b14ec55c3f6dce8f0` 207-caught remain historical identities. They are not this closeout’s executed result.

## What GPT-6 should adjudicate

Frozen candidate:

1. HEAD `a12b7ca` plus the single source edit `formal/v3/negtest-reporting.sh` (hashes above).
2. This evidence directory (self-excluding manifest).
3. Attempt 1 baseline and r2 rerun, both with full stdout and exit 1.
4. Independent restore hashes for tracked JSON/graphs/briefs/`atlas.bbl`.

Do not treat 37 checkboxes, 7/18 inventory counts, or historical 43/207 figures as fresh acceptance. Root freeze / independent GPT-6 review is required before any publication, archive, or delivery. No commit or push was made in this closeout.
