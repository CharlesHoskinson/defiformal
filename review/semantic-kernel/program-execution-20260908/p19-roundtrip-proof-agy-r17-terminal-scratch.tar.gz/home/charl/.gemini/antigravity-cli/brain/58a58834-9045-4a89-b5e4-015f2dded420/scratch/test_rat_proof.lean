import DefiKernel.Certificates.Correspondence
import DefiKernel.Certificates.CanonicalJson

open DefiKernel.Certificates

set_option linter.unusedTactic false
set_option linter.unreachableTactic false

theorem encodeRat_chars (r : RatEnc) :
    (encodeRat r).toList =
      ['{', '"', 'n', 'u', 'm', '"', ':'] ++
      (toString r.num).toList ++
      [',', '"', 'd', 'e', 'n', '"', ':'] ++
      (toString r.den).toList ++
      ['}'] := by
  dsimp [encodeRat, jsonObj, escapeJsonString, escapeChars, escapeChar]
  rfl
