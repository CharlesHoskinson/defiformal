import json
import re
import subprocess
import os

lean_dir = "/home/charl/defiformal-wt-p19-certificates-grok-opus-20260909/lean"
canonical_json_path = os.path.join(lean_dir, "DefiKernel/Certificates/CanonicalJson.lean")
correspondence_path = os.path.join(lean_dir, "DefiKernel/Certificates/Correspondence.lean")

# Extract theorem names and statement lines
def extract_theorems(filepath, mod_name):
    theorems = []
    with open(filepath, 'r') as f:
        lines = f.readlines()
    
    i = 0
    while i < len(lines):
        line = lines[i]
        m = re.match(r'^(?:set_option\s+.*in\s+)?(?:(?:private|scoped|protected)\s+)?(?:theorem|lemma)\s+([A-Za-z0-9_\.\?\']+)\s*(.*)', line.strip())
        if m:
            name = m.group(1)
            stmt_part = m.group(2)
            # Accumulate statement lines until ":=" or "by"
            stmt_lines = [stmt_part]
            while not (":=" in stmt_lines[-1] or " by" in stmt_lines[-1] or stmt_lines[-1].endswith("by")) and i + 1 < len(lines):
                i += 1
                stmt_lines.append(lines[i].strip())
            full_stmt = " ".join(stmt_lines)
            # Clean up trailing := or by
            full_stmt = re.sub(r'\s*:=\s*.*$', '', full_stmt)
            full_stmt = re.sub(r'\s+by\s*.*$', '', full_stmt)
            theorems.append((name, f"DefiKernel.Certificates.{name}", os.path.relpath(filepath, os.path.dirname(lean_dir)), full_stmt))
        i += 1
    return theorems

cj_theorems = extract_theorems(canonical_json_path, "CanonicalJson")
corr_theorems = extract_theorems(correspondence_path, "Correspondence")

all_theorems = cj_theorems + corr_theorems
print(f"Total extracted theorems: {len(all_theorems)}")

# Generate Lean file with #print axioms for all theorems
probe_lean_path = "/home/charl/.gemini/antigravity-cli/brain/58a58834-9045-4a89-b5e4-015f2dded420/scratch/probe_all_axioms.lean"
with open(probe_lean_path, 'w') as f:
    f.write("import DefiKernel.Certificates.CanonicalJson\n")
    f.write("import DefiKernel.Certificates.Correspondence\n\n")
    for _, full_name, _, _ in all_theorems:
        f.write(f"#print axioms {full_name}\n")

# Run lake env lean probe_lean_path
print("Running lake env lean probe_all_axioms.lean...")
res = subprocess.run(["lake", "env", "lean", probe_lean_path], cwd=lean_dir, capture_output=True, text=True)
if res.returncode != 0:
    print(f"Error running probe: {res.stderr}")
    exit(1)

# Parse output
lines = res.stdout.strip().split("\n")
print(f"Output lines: {len(lines)}")

# Each output is either:
# 'DefiKernel.Certificates.foo' depends on axioms: [propext, Quot.sound]
# or:
# 'DefiKernel.Certificates.foo' does not depend on any axioms
# or multi-line if axioms list is wrapped.

probe_output = res.stdout
print("Probe output sample:")
print("\n".join(lines[:10]))
