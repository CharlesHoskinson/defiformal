import re
import subprocess
import json
import hashlib
import os

lean_dir = "/home/charl/defiformal-wt-p19-certificates-grok-opus-20260909/lean"
canonical_json_path = os.path.join(lean_dir, "DefiKernel/Certificates/CanonicalJson.lean")
correspondence_path = os.path.join(lean_dir, "DefiKernel/Certificates/Correspondence.lean")

# Extract theorems from file
theorem_pattern = re.compile(r'^(?:(?:private|scoped|protected)\s+)?(?:theorem|lemma)\s+([A-Za-z0-9_\.\?\']+)', re.MULTILINE)

with open(canonical_json_path, 'r') as f:
    cj_content = f.read()
cj_theorems = theorem_pattern.findall(cj_content)

with open(correspondence_path, 'r') as f:
    corr_content = f.read()
corr_theorems = theorem_pattern.findall(corr_content)

print(f"CanonicalJson theorems found: {len(cj_theorems)}")
print(f"Correspondence theorems found: {len(corr_theorems)}")
print(f"Total: {len(cj_theorems) + len(corr_theorems)}")
