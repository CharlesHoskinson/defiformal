import DefiKernel.Certificates.Correspondence

open DefiKernel.Certificates

theorem c1 : "{\"num\":".toList = ['{', '\"', 'n', 'u', 'm', '\"', ':'] := rfl
theorem c2 : ",\"den\":".toList = [',', '\"', 'd', 'e', 'n', '\"', ':'] := rfl
theorem c3 : "}".toList = ['}'] := rfl

theorem intercalate_two (s t u : String) :
    s.intercalate [t, u] = t ++ s ++ u := by
  rw [String.intercalate_cons_cons, String.intercalate_singleton]

theorem jsonObj_two (k1 v1 k2 v2 : String) :
    jsonObj [(k1, v1), (k2, v2)] =
    "{" ++ escapeJsonString k1 ++ ":" ++ v1 ++ "," ++ escapeJsonString k2 ++ ":" ++ v2 ++ "}" := by
  dsimp [jsonObj]
  simp only [List.map_cons, List.map_nil]
  rw [intercalate_two]
  simp [String.append_assoc]

theorem escapeJsonString_num : escapeJsonString "num" = "\"num\"" := rfl
theorem escapeJsonString_den : escapeJsonString "den" = "\"den\"" := rfl

theorem encodeRat_eq (r : RatEnc) :
    encodeRat r = "{\"num\":" ++ toString r.num ++ ",\"den\":" ++ toString r.den ++ "}" := by
  unfold encodeRat
  rw [jsonObj_two, escapeJsonString_num, escapeJsonString_den]
  simp [String.append_assoc]

theorem encodeRat_chars (r : RatEnc) :
    (encodeRat r).toList =
    ['{', '"', 'n', 'u', 'm', '"', ':'] ++
      ((toString r.num).toList ++
        ([',', '"', 'd', 'e', 'n', '"', ':'] ++
          ((toString r.den).toList ++ ['}']))) := by
  rw [encodeRat_eq]
  simp only [String.toList_append, c1, c2, c3, List.append_assoc]

theorem tokenizeFuel_num_colon (fuel : Nat) (rest : List Char) :
    tokenizeFuel (fuel + 2) ('"' :: 'n' :: 'u' :: 'm' :: '"' :: ':' :: rest) =
      (tokenizeFuel fuel rest).map (fun toks => JsonToken.str "num" :: JsonToken.colon :: toks) := by
  rw [tokenizeFuel]
  dsimp [bind, Except.bind]
  have h_lex : lexString [] ('n' :: 'u' :: 'm' :: '"' :: ':' :: rest) = .ok ("num", ':' :: rest) := rfl
  rw [h_lex]
  dsimp [bind, Except.bind]
  rw [tokenizeFuel_colon]
  cases tokenizeFuel fuel rest <;> rfl

theorem tokenizeFuel_den_colon (fuel : Nat) (rest : List Char) :
    tokenizeFuel (fuel + 2) ('"' :: 'd' :: 'e' :: 'n' :: '"' :: ':' :: rest) =
      (tokenizeFuel fuel rest).map (fun toks => JsonToken.str "den" :: JsonToken.colon :: toks) := by
  rw [tokenizeFuel]
  dsimp [bind, Except.bind]
  have h_lex : lexString [] ('d' :: 'e' :: 'n' :: '"' :: ':' :: rest) = .ok ("den", ':' :: rest) := rfl
  rw [h_lex]
  dsimp [bind, Except.bind]
  rw [tokenizeFuel_colon]
  cases tokenizeFuel fuel rest <;> rfl

theorem tokenizeFuel_encodeRat_chars (r : RatEnc) (f : Nat) :
    tokenizeFuel (f + 10)
      (['{', '"', 'n', 'u', 'm', '"', ':'] ++
        ((toString r.num).toList ++
          ([',', '"', 'd', 'e', 'n', '"', ':'] ++
            ((toString r.den).toList ++ ['}'])))) =
    .ok [
      JsonToken.lbrace,
      JsonToken.str "num", JsonToken.colon, JsonToken.num ⟨r.num, 0⟩,
      JsonToken.comma,
      JsonToken.str "den", JsonToken.colon, JsonToken.num ⟨(r.den : Int), 0⟩,
      JsonToken.rbrace
    ] := by
  change tokenizeFuel (f + 9 + 1) ('{' :: ('"' :: 'n' :: 'u' :: 'm' :: '"' :: ':' :: ((toString r.num).toList ++ (',' :: ('"' :: 'd' :: 'e' :: 'n' :: '"' :: ':' :: ((toString r.den).toList ++ ['}'])))))) = _
  rw [tokenizeFuel_lbrace]
  rw [tokenizeFuel_num_colon]
  rw [tokenizeFuel_int (f + 6) r.num (',' :: ('"' :: 'd' :: 'e' :: 'n' :: '"' :: ':' :: ((toString r.den).toList ++ ['}']))) rfl]
  rw [tokenizeFuel_comma]
  rw [tokenizeFuel_den_colon]
  rw [tokenizeFuel_nat (f + 2) r.den ['}'] rfl]
  rw [tokenizeFuel_rbrace]
  rfl

theorem tokenize_encodeRat (r : RatEnc) :
    tokenize (encodeRat r) =
    .ok [
      JsonToken.lbrace,
      JsonToken.str "num", JsonToken.colon, JsonToken.num ⟨r.num, 0⟩,
      JsonToken.comma,
      JsonToken.str "den", JsonToken.colon, JsonToken.num ⟨(r.den : Int), 0⟩,
      JsonToken.rbrace
    ] := by
  unfold tokenize
  rw [encodeRat_chars]
  have h_len_ge : (['{', '"', 'n', 'u', 'm', '"', ':'] ++
      ((toString r.num).toList ++
        ([',', '"', 'd', 'e', 'n', '"', ':'] ++
          ((toString r.den).toList ++ ['}']) : List Char))).length + 1 ≥ 10 := by
    simp only [List.length_append, List.length_cons, List.length_nil]
    omega
  let L := (['{', '"', 'n', 'u', 'm', '"', ':'] ++
      ((toString r.num).toList ++
        ([',', '"', 'd', 'e', 'n', '"', ':'] ++
          ((toString r.den).toList ++ ['}']) : List Char))).length + 1
  have h_dest : ∃ k, L = k + 10 := by
    rcases Nat.le.dest h_len_ge with ⟨k, hk⟩
    exact ⟨k, by omega⟩
  rcases h_dest with ⟨k, hk⟩
  change tokenizeFuel L _ = _
  rw [hk]
  exact tokenizeFuel_encodeRat_chars r k

theorem parseCanonicalJson_encodeRat_universal (r : RatEnc) :
    parseCanonicalJson (encodeRat r) = .ok (ratToJson r) := by
  unfold parseCanonicalJson
  rw [tokenize_encodeRat]
  dsimp [bind, Except.bind]
  rfl

theorem rat_end_to_end_universal (r : RatEnc)
    (h_den : r.den ≠ 0) (h_gcd : Int.gcd r.num.natAbs r.den = 1) :
    (do
      let j ← parseCanonicalJson (encodeRat r)
      decodeRat j) = .ok r := by
  rw [parseCanonicalJson_encodeRat_universal]
  dsimp [bind, Except.bind]
  exact decodeRat_ratToJson r h_den h_gcd
