import DefiKernel.Certificates.Correspondence
import DefiKernel.Certificates.CanonicalJson

open DefiKernel.Certificates

set_option linter.unusedTactic false
set_option linter.unreachableTactic false

theorem tokenizeFuel_rat (fuel : Nat) (r : RatEnc) (rest : List Char)
    (h_end : match rest with | [] => True | c :: _ => c.isDigit = false) :
    tokenizeFuel (fuel + 10) ((encodeRat r).toList ++ rest) =
      (do
        let toks ← tokenizeFuel fuel rest
        .ok ([
          JsonToken.lbrace,
          JsonToken.str "num", JsonToken.colon, JsonToken.num ⟨r.num, 0⟩,
          JsonToken.comma,
          JsonToken.str "den", JsonToken.colon, JsonToken.num ⟨(r.den : Int), 0⟩,
          JsonToken.rbrace
        ] ++ toks)) := by
  sorry

