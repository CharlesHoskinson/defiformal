import DefiKernel.Certificates.CanonicalJson

open DefiKernel.Certificates

set_option linter.unusedTactic false
set_option linter.unreachableTactic false

theorem lexDigits_step_eq (c : Char) (acc : Nat) (rest : List Char) :
    lexDigits acc (c :: rest) =
      if c.isDigit then lexDigits (acc * 10 + (c.toNat - '0'.toNat)) rest
      else (acc, c :: rest) := by
  rfl

theorem lexDigits_of_all_digits (l : List Char) (hl : ∀ c ∈ l, c.isDigit = true)
    (acc : Nat) (rest : List Char) (h_end : match rest with | [] => True | c :: _ => c.isDigit = false) :
    lexDigits acc (l ++ rest) = (Nat.ofDigitChars 10 l acc, rest) := by
  induction l generalizing acc with
  | nil =>
    simp only [List.nil_append, Nat.ofDigitChars_nil]
    cases rest with
    | nil => rfl
    | cons c cs =>
      rw [lexDigits_step_eq]
      dsimp at h_end
      rw [h_end]
      rfl
  | cons c cs ih =>
    simp only [List.cons_append, Nat.ofDigitChars_cons]
    have hc := hl c (by simp)
    have hcs : ∀ c' ∈ cs, c'.isDigit = true := fun c' hc' => hl c' (by simp [hc'])
    rw [lexDigits_step_eq]
    rw [hc]
    dsimp
    have h_comm : acc * 10 = 10 * acc := Nat.mul_comm _ _
    rw [h_comm]
    exact ih hcs (10 * acc + (c.toNat - '0'.toNat))

theorem lexDigits_head_tl (c : Char) (tl : List Char) (n : Nat)
    (h_eq : Nat.toDigits 10 n = c :: tl) (rest : List Char)
    (h_end : match rest with | [] => True | c :: _ => c.isDigit = false) :
    c.isDigit = true ∧
    lexDigits (c.toNat - '0'.toNat) (tl ++ rest) = (n, rest) := by
  have hl : ∀ x ∈ Nat.toDigits 10 n, x.isDigit = true := by
    intro x hx
    exact Nat.isDigit_of_mem_toDigits (by decide) (by decide) hx
  have hc : c.isDigit = true := by
    have : c ∈ Nat.toDigits 10 n := by simp [h_eq]
    exact hl c this
  have htl : ∀ x ∈ tl, x.isDigit = true := by
    intro x hx
    have : x ∈ Nat.toDigits 10 n := by simp [h_eq, hx]
    exact hl x this
  refine ⟨hc, ?_⟩
  rw [lexDigits_of_all_digits tl htl (c.toNat - '0'.toNat) rest h_end]
  have h_cons : Nat.ofDigitChars 10 (c :: tl) 0 = Nat.ofDigitChars 10 tl (10 * 0 + (c.toNat - '0'.toNat)) := rfl
  simp only [Nat.mul_zero, Nat.zero_add] at h_cons
  rw [← h_cons, ← h_eq]
  rw [Nat.ofDigitChars_ten_toDigits]

theorem toDigits_nonempty (n : Nat) : ∃ c tl, Nat.toDigits 10 n = c :: tl := by
  cases h : Nat.toDigits 10 n with
  | nil =>
    have h_len : 0 < (Nat.toDigits 10 n).length := Nat.length_toDigits_pos
    rw [h] at h_len
    contradiction
  | cons c tl =>
    exact ⟨c, tl, rfl⟩

theorem tokenizeFuel_digit_step (fuel : Nat) (c : Char) (tl : List Char) (rest : List Char)
    (hc : c.isDigit = true)
    (n : Nat)
    (h_lex : lexDigits (c.toNat - '0'.toNat) (tl ++ rest) = (n, rest)) :
    tokenizeFuel (fuel + 1) (c :: (tl ++ rest)) =
      (do
        let toks ← tokenizeFuel fuel rest
        .ok (JsonToken.num ⟨(n : Int), 0⟩ :: toks)) := by
  rw [tokenizeFuel]
  split
  · rw [h_lex]
  · rename_i h_not
    have hc_cond : (decide (c ≥ '0') && decide (c ≤ '9')) = true := hc
    contradiction
  all_goals
    try (intro h1; subst h1; revert hc; decide)
    try (intro _ h1 _; subst h1; revert hc; decide)
    try (intro _ h1; subst h1; revert hc; decide)
    try (intro _ _ h1 _; subst h1; revert hc; decide)

theorem tokenizeFuel_nat (fuel : Nat) (n : Nat) (rest : List Char)
    (h_end : match rest with | [] => True | c :: _ => c.isDigit = false) :
    tokenizeFuel (fuel + 1) ((toString n).toList ++ rest) =
      (do
        let toks ← tokenizeFuel fuel rest
        .ok (JsonToken.num ⟨(n : Int), 0⟩ :: toks)) := by
  have h_repr : (toString n).toList = Nat.toDigits 10 n := by
    change (Nat.repr n).toList = Nat.toDigits 10 n
    exact Nat.toList_repr
  rw [h_repr]
  rcases toDigits_nonempty n with ⟨c, tl, h_digits⟩
  rw [h_digits]
  have ⟨hc, h_lex⟩ := lexDigits_head_tl c tl n h_digits rest h_end
  simp only [List.cons_append]
  exact tokenizeFuel_digit_step fuel c tl rest hc n h_lex

theorem tokenizeFuel_int (fuel : Nat) (i : Int) (rest : List Char)
    (h_end : match rest with | [] => True | c :: _ => c.isDigit = false) :
    tokenizeFuel (fuel + 1) ((toString i).toList ++ rest) =
      (do
        let toks ← tokenizeFuel fuel rest
        .ok (JsonToken.num ⟨i, 0⟩ :: toks)) := by
  cases i with
  | ofNat n =>
    exact tokenizeFuel_nat fuel n rest h_end
  | negSucc n =>
    have h_repr : (toString (Int.negSucc n)).toList = '-' :: (Nat.repr (n + 1)).toList := by
      change ("-" ++ Nat.repr (n + 1)).toList = '-' :: (Nat.repr (n + 1)).toList
      rw [String.toList_append]
      rfl
    rw [h_repr]
    have h_nat_repr : (Nat.repr (n + 1)).toList = Nat.toDigits 10 (n + 1) := Nat.toList_repr
    rw [h_nat_repr]
    rcases toDigits_nonempty (n + 1) with ⟨c, tl, h_digits⟩
    rw [h_digits]
    have ⟨hc, h_lex⟩ := lexDigits_head_tl c tl (n + 1) h_digits rest h_end
    simp only [List.cons_append]
    rw [tokenizeFuel]
    have hc_cond : (decide (c ≥ '0') && decide (c ≤ '9')) = true := hc
    rw [hc_cond]
    dsimp
    have h_lex' : lexDigits (c.toNat - 48) (tl ++ rest) = (n + 1, rest) := h_lex
    rw [h_lex']
    have : (-↑(n + 1) : Int) = Int.negSucc n := rfl
    rw [this]


theorem parseTokens_rat (r : RatEnc) :
    parseTokens [
      JsonToken.lbrace,
      JsonToken.str "num", JsonToken.colon, JsonToken.num ⟨r.num, 0⟩,
      JsonToken.comma,
      JsonToken.str "den", JsonToken.colon, JsonToken.num ⟨(r.den : Int), 0⟩,
      JsonToken.rbrace
    ] = .ok (Lean.Json.mkObj [("num", Lean.Json.num r.num), ("den", Lean.Json.num (r.den : Int))]) := by
  rfl

