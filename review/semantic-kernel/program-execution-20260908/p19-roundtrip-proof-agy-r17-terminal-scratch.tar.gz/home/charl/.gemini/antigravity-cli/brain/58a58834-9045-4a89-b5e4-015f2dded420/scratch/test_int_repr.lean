import Lean

theorem int_negSucc_toList (n : Nat) :
    (toString (Int.negSucc n)).toList = '-' :: (Nat.repr (n + 1)).toList := by
  change ("-" ++ Nat.repr (n + 1)).toList = '-' :: (Nat.repr (n + 1)).toList
  rw [String.toList_append]
  rfl
