import DefiKernel.Certificates.Correspondence

open Lean DefiKernel.Certificates

set_option maxHeartbeats 3000000

def envelopeDeclFields (env : EnvelopeEnc) (payloadJson : Lean.Json) : List (String × Lean.Json) := [
  ("schema_version", Lean.Json.num env.schema_version),
  ("mode", Lean.Json.str env.mode),
  ("source_pin", sourcePinToJson env.source_pin),
  ("audit_roots", Lean.Json.arr (env.audit_roots.map Lean.Json.str).toArray),
  ("types", typesEnumToJson env.types),
  ("assumptions", Lean.Json.arr (env.assumptions.map Lean.Json.str).toArray),
  ("invariants", Lean.Json.arr (env.invariants.map Lean.Json.str).toArray),
  ("libraries", Lean.Json.arr (env.libraries.map libraryRefToJson).toArray),
  ("source_map", Lean.Json.mkObj (env.source_map.map (fun (k, v) => (k, Lean.Json.str v)))),
  ("payload", payloadJson),
  ("claimed_judgments", Lean.Json.arr (env.claimed_judgments.map Lean.Json.str).toArray),
  ("claimed_next_state", match env.claimed_next_state with | none => Lean.Json.null | some w => worldToJson w),
  ("require_library_discharge", Lean.Json.bool env.require_library_discharge),
  ("require_invariant_discharge", Lean.Json.bool env.require_invariant_discharge)
]

def envelopeToJsonNew (env : EnvelopeEnc) (payloadJson : Lean.Json) : Lean.Json :=
  Lean.Json.mkObj (envelopeDeclFields env payloadJson)

theorem decodeDecodedIR_envelopeToJsonNew_eq (env : EnvelopeEnc) (payloadJ : Lean.Json) (raw : String) :
    decodeDecodedIR (envelopeToJsonNew env payloadJ) raw = (do
      let env_dec ← decodeEnvelope (envelopeSortedFields env payloadJ)
      let payloadJ_dec ← getField (envelopeSortedFields env payloadJ) "payload"
      match env_dec.mode with
      | "typed-execute" =>
        let payload_dec ← decodeTypedExecutePayload payloadJ_dec
        Except.ok (DecodedIR.execution (.typed env_dec payload_dec))
      | "composition-step" =>
        let payload_dec ← decodeCompositionStepPayload payloadJ_dec
        Except.ok (DecodedIR.execution (.step env_dec payload_dec))
      | "composition-run" =>
        let payload_dec ← decodeCompositionRunPayload payloadJ_dec
        Except.ok (DecodedIR.execution (.run env_dec payload_dec))
      | "codec" => Except.ok (DecodedIR.codec ⟨some env_dec, raw⟩)
      | "audit" =>
        let payload_dec ← decodeAuditPayload env_dec payloadJ_dec true
        Except.ok (DecodedIR.audit payload_dec)
      | s => Except.error (.unknownIdentifier s)) := by
  rfl
