import DefiKernel.Certificates.Encode

open DefiKernel.Certificates

theorem escapeJsonString_num : (escapeJsonString "num").toList = ['"', 'n', 'u', 'm', '"'] := rfl
theorem escapeJsonString_den : (escapeJsonString "den").toList = ['"', 'd', 'e', 'n', '"'] := rfl

