import json
import os
import hashlib
from datetime import datetime, timezone

root_dir = "/home/charl/defiformal-wt-p19-certificates-grok-opus-20260909"
r17_dir = os.path.join(root_dir, "review/semantic-kernel/certificates/p19/implementation/agy-r17-proof")

files_to_hash = [
    "lean/DefiKernel/Certificates/Schema.lean",
    "lean/DefiKernel/Certificates/Decode.lean",
    "lean/DefiKernel/Certificates/Encode.lean",
    "lean/DefiKernel/Certificates/CanonicalJson.lean",
    "lean/DefiKernel/Certificates/Check.lean",
    "lean/DefiKernel/Certificates/Observation.lean",
    "lean/DefiKernel/Certificates/Correspondence.lean",
    "lean/DefiKernel/Certificates/Soundness.lean",
    "lean/DefiKernel/Certificates/Verify.lean",
    "lean/DefiKernel/Certificates/Audit.lean",
    "lean/DefiKernel/Certificates/Tests.lean",
    "scripts/test_certificate_fixture_runner.py"
]

sources_map = {}
for rel_path in files_to_hash:
    abs_path = os.path.join(root_dir, rel_path)
    with open(abs_path, 'rb') as f:
        data = f.read()
    sha = hashlib.sha256(data).hexdigest()
    lines_count = len(data.split(b'\n'))
    sources_map[rel_path] = {
        "sha256": sha,
        "bytes": len(data),
        "lines": lines_count
    }

manifest_data = {
    "schema": "defiformal-p19-source-manifest/v2",
    "timestamp_utc": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
    "git_head": "38de83c58e3f9315bf400807591d538d7565152e",
    "lean_version": "Lean (version 4.33.0-rc2, x86_64-unknown-linux-gnu, commit d8b18978322de05a8f3dba51ef03cf5461676c17, Release)",
    "lean_executable": "/home/charl/.elan/toolchains/leanprover--lean4---v4.33.0-rc2/bin/lean",
    "cwd": "/home/charl/defiformal-wt-p19-certificates-grok-opus-20260909/lean",
    "sources": sources_map
}

with open(os.path.join(r17_dir, "source-manifest.json"), 'w') as f:
    json.dump(manifest_data, f, indent=2)

print("Saved source-manifest.json.")
