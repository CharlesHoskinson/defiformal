import DefiKernel.Certificates.Correspondence

open Lean DefiKernel.Certificates

set_option maxHeartbeats 3000000

-- Test 1: typed payload
def typedPayloadDecl (p : TypedExecutePayloadEnc) : List (String × Lean.Json) := [
  ("registry", registryToJson p.registry),
  ("store", storeToJson p.store),
  ("ctx", contextToJson p.ctx),
  ("env", environmentToJson p.env),
  ("now", Lean.Json.num p.now),
  ("request", requestToJson p.request),
  ("state", stateToJson p.state)
]

theorem test_typed_payload_toList (p : TypedExecutePayloadEnc) :
    (match Json.mkObj (typedPayloadDecl p) with | .obj kvs => kvs.toList | _ => []) =
    (match typedExecutePayloadToJson p with | .obj kvs => kvs.toList | _ => []) := by
  rfl


def stepPayloadDecl (p : CompositionStepPayloadEnc) : List (String × Lean.Json) := [
  ("config", configToJson p.config),
  ("boundary", boundaryToJson p.boundary),
  ("index", Lean.Json.num p.index),
  ("history", Lean.Json.arr (p.history.map outputObservationToJson).toArray),
  ("step", stepToJson p.step),
  ("pre", worldToJson p.pre)
]

theorem test_step_payload_toList (p : CompositionStepPayloadEnc) :
    (match Json.mkObj (stepPayloadDecl p) with | .obj kvs => kvs.toList | _ => []) =
    (match compositionStepPayloadToJson p with | .obj kvs => kvs.toList | _ => []) := by
  rfl

def runPayloadDecl (p : CompositionRunPayloadEnc) : List (String × Lean.Json) := [
  ("config", configToJson p.config),
  ("boundaries", Lean.Json.arr (p.boundaries.map boundaryToJson).toArray),
  ("world", worldToJson p.world),
  ("steps", Lean.Json.arr (p.steps.map stepToJson).toArray)
]

theorem test_run_payload_toList (p : CompositionRunPayloadEnc) :
    (match Json.mkObj (runPayloadDecl p) with | .obj kvs => kvs.toList | _ => []) =
    (match compositionRunPayloadToJson p with | .obj kvs => kvs.toList | _ => []) := by
  rfl

