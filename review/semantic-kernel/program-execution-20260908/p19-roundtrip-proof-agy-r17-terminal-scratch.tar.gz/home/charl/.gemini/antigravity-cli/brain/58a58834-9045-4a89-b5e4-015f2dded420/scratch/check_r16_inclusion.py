import json
import re
import os

r16_theorems_json = "/home/charl/defiformal-wt-p19-certificates-grok-opus-20260909/review/semantic-kernel/certificates/p19/implementation/agy-r16-proof/theorems.json"
with open(r16_theorems_json, 'r') as f:
    r16_data = json.load(f)

r16_names = set(t["name"] for t in r16_data["theorems"])
print(f"R16 names count: {len(r16_names)}")

lean_dir = "/home/charl/defiformal-wt-p19-certificates-grok-opus-20260909/lean"
canonical_json_path = os.path.join(lean_dir, "DefiKernel/Certificates/CanonicalJson.lean")
correspondence_path = os.path.join(lean_dir, "DefiKernel/Certificates/Correspondence.lean")

theorem_pattern = re.compile(r'^(?:(?:private|scoped|protected)\s+)?(?:theorem|lemma)\s+([A-Za-z0-9_\.\?\']+)', re.MULTILINE)

with open(canonical_json_path, 'r') as f:
    cj_theorems = set(theorem_pattern.findall(f.read()))

with open(correspondence_path, 'r') as f:
    corr_theorems = set(theorem_pattern.findall(f.read()))

# Names with module prefix
r17_full_names = set()
for t in cj_theorems:
    r17_full_names.add(f"DefiKernel.Certificates.{t}")
for t in corr_theorems:
    r17_full_names.add(f"DefiKernel.Certificates.{t}")

missing = r16_names - r17_full_names
print(f"Missing R16 names: {len(missing)}")
if missing:
    print(f"Missing: {missing}")
else:
    print("ALL 269 R16 NAMES ARE FULLY PRESERVED!")

new_names = r17_full_names - r16_names
print(f"New names in R17: {len(new_names)}")
for n in sorted(new_names):
    print(f"  + {n}")
