import DefiKernel.Certificates.Correspondence
import DefiKernel.Certificates.CanonicalJson

open DefiKernel.Certificates

#check encodeRat
#check ratToJson
