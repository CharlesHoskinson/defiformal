import Lean.Data.Json
open Lean

set_option maxHeartbeats 3000000

def declOrder (n : Nat) : List (String × Json) := [
  ("schema_version", n),
  ("mode", "typed"),
  ("source_pin", "pin"),
  ("audit_roots", Json.arr #[]),
  ("types", Json.arr #[]),
  ("assumptions", Json.arr #[]),
  ("invariants", Json.arr #[]),
  ("libraries", Json.arr #[]),
  ("source_map", Json.mkObj []),
  ("payload", "p"),
  ("claimed_judgments", Json.arr #[]),
  ("claimed_next_state", Json.null),
  ("require_library_discharge", false),
  ("require_invariant_discharge", false)
]

def sortedOrder (n : Nat) : List (String × Json) := [
  ("assumptions", Json.arr #[]),
  ("audit_roots", Json.arr #[]),
  ("claimed_judgments", Json.arr #[]),
  ("claimed_next_state", Json.null),
  ("invariants", Json.arr #[]),
  ("libraries", Json.arr #[]),
  ("mode", "typed"),
  ("payload", "p"),
  ("require_invariant_discharge", false),
  ("require_library_discharge", false),
  ("schema_version", n),
  ("source_map", Json.mkObj []),
  ("source_pin", "pin"),
  ("types", Json.arr #[])
]

theorem test_eq (n : Nat) : Json.mkObj (declOrder n) = Json.mkObj (sortedOrder n) := by
  rfl
