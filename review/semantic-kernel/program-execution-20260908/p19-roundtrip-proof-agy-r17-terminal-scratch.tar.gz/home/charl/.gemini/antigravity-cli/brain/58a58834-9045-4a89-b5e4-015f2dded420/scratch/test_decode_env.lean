import DefiKernel.Certificates.Decode
import DefiKernel.Certificates.Correspondence

open Lean DefiKernel.Certificates

def envDeclFields (env : EnvelopeEnc) (payloadJ : Lean.Json) : List (String × Lean.Json) := [
  ("schema_version", Lean.Json.num env.schema_version),
  ("mode", Lean.Json.str env.mode),
  ("source_pin", sourcePinToJson env.source_pin),
  ("audit_roots", Lean.Json.arr (env.audit_roots.map Lean.Json.str).toArray),
  ("types", typesEnumToJson env.types),
  ("assumptions", Lean.Json.arr (env.assumptions.map Lean.Json.str).toArray),
  ("invariants", Lean.Json.arr (env.invariants.map Lean.Json.str).toArray),
  ("libraries", Lean.Json.arr (env.libraries.map libraryRefToJson).toArray),
  ("source_map", Lean.Json.mkObj (env.source_map.map (fun (k, v) => (k, Lean.Json.str v)))),
  ("payload", payloadJ),
  ("claimed_judgments", Lean.Json.arr (env.claimed_judgments.map Lean.Json.str).toArray),
  ("claimed_next_state", match env.claimed_next_state with | none => Lean.Json.null | some w => worldToJson w),
  ("require_library_discharge", Lean.Json.bool env.require_library_discharge),
  ("require_invariant_discharge", Lean.Json.bool env.require_invariant_discharge)
]

def envelopeToJsonDecl (env : EnvelopeEnc) (payloadJ : Lean.Json) : Lean.Json :=
  Lean.Json.mkObj (envDeclFields env payloadJ)

#eval (match envelopeToJsonDecl default default with
  | .obj kvs => kvs.toList.map Prod.fst
  | _ => [])
