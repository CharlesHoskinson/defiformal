import DefiKernel.Certificates.Correspondence
import DefiKernel.Certificates.CanonicalJson

open DefiKernel.Certificates

set_option linter.unusedTactic false
set_option linter.unreachableTactic false

theorem tokenizeFuel_colon (fuel : Nat) (rest : List Char) :
    tokenizeFuel (fuel + 1) (':' :: rest) =
      (do
        let toks ← tokenizeFuel fuel rest
        .ok (JsonToken.colon :: toks)) := rfl

theorem tokenizeFuel_comma (fuel : Nat) (rest : List Char) :
    tokenizeFuel (fuel + 1) (',' :: rest) =
      (do
        let toks ← tokenizeFuel fuel rest
        .ok (JsonToken.comma :: toks)) := rfl

theorem tokenizeFuel_lbrace (fuel : Nat) (rest : List Char) :
    tokenizeFuel (fuel + 1) ('{' :: rest) =
      (do
        let toks ← tokenizeFuel fuel rest
        .ok (JsonToken.lbrace :: toks)) := rfl

theorem tokenizeFuel_rbrace (fuel : Nat) (rest : List Char) :
    tokenizeFuel (fuel + 1) ('}' :: rest) =
      (do
        let toks ← tokenizeFuel fuel rest
        .ok (JsonToken.rbrace :: toks)) := rfl

