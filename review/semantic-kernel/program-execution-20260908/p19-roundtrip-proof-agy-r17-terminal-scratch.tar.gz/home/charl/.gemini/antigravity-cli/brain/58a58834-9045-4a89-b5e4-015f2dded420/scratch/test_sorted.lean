import Lean.Data.Json
open Lean

def sortedPairs : List (String × Json) := [
  ("a", 1),
  ("b", 2),
  ("c", 3)
]

theorem test_sorted : (match Json.mkObj sortedPairs with | .obj kvs => kvs.toList | _ => []) = sortedPairs := by
  rfl
