import json
import re
import subprocess
import os
import hashlib
from datetime import datetime, timezone

lean_dir = "/home/charl/defiformal-wt-p19-certificates-grok-opus-20260909/lean"
root_dir = "/home/charl/defiformal-wt-p19-certificates-grok-opus-20260909"
r17_dir = os.path.join(root_dir, "review/semantic-kernel/certificates/p19/implementation/agy-r17-proof")
os.makedirs(r17_dir, exist_ok=True)

canonical_json_path = os.path.join(lean_dir, "DefiKernel/Certificates/CanonicalJson.lean")
correspondence_path = os.path.join(lean_dir, "DefiKernel/Certificates/Correspondence.lean")

def extract_theorems(filepath):
    theorems = []
    with open(filepath, 'r') as f:
        lines = f.readlines()
    
    i = 0
    while i < len(lines):
        line = lines[i]
        m = re.match(r'^(?:set_option\s+.*in\s+)?(?:(?:private|scoped|protected)\s+)?(?:theorem|lemma)\s+([A-Za-z0-9_\.\?\']+)\s*(.*)', line.strip())
        if m:
            name = m.group(1)
            stmt_part = m.group(2)
            stmt_lines = [stmt_part]
            while not (":=" in stmt_lines[-1] or " by" in stmt_lines[-1] or stmt_lines[-1].endswith("by")) and i + 1 < len(lines):
                i += 1
                stmt_lines.append(lines[i].strip())
            full_stmt = " ".join(stmt_lines)
            full_stmt = re.sub(r'\s*:=\s*.*$', '', full_stmt)
            full_stmt = re.sub(r'\s+by\s*.*$', '', full_stmt)
            # Normalize whitespace
            full_stmt = re.sub(r'\s+', ' ', full_stmt).strip()
            theorems.append((name, f"DefiKernel.Certificates.{name}", os.path.relpath(filepath, root_dir), full_stmt))
        i += 1
    return theorems

cj_theorems = extract_theorems(canonical_json_path)
corr_theorems = extract_theorems(correspondence_path)

all_theorems = cj_theorems + corr_theorems

# Run axiom probe
probe_lean_path = "/home/charl/.gemini/antigravity-cli/brain/58a58834-9045-4a89-b5e4-015f2dded420/scratch/probe_all_axioms.lean"
with open(probe_lean_path, 'w') as f:
    f.write("import DefiKernel.Certificates.CanonicalJson\n")
    f.write("import DefiKernel.Certificates.Correspondence\n\n")
    for _, full_name, _, _ in all_theorems:
        f.write(f"#print axioms {full_name}\n")

res = subprocess.run(["lake", "env", "lean", probe_lean_path], cwd=lean_dir, capture_output=True, text=True)
if res.returncode != 0:
    print(f"Error: {res.stderr}")
    exit(1)

# Parse output mapping full_name -> list of axioms
# The output can span multiple lines for a single theorem
raw_probe_output = res.stdout
pattern = re.compile(r"'([A-Za-z0-9_\.\?']+)'\s+(?:depends on axioms:\s*\[(.*?)\]|does not depend on any axioms)", re.DOTALL)

# Clean up raw output: join lines between brackets
probe_lines = raw_probe_output.split("\n")
normalized_probe_entries = []
curr_entry = ""
for line in probe_lines:
    if line.startswith("'DefiKernel."):
        if curr_entry:
            normalized_probe_entries.append(curr_entry)
        curr_entry = line
    else:
        if curr_entry:
            curr_entry += " " + line.strip()
if curr_entry:
    normalized_probe_entries.append(curr_entry)

axiom_map = {}
for entry in normalized_probe_entries:
    m = re.match(r"'([A-Za-z0-9_\.\?']+)'\s+(.*)", entry)
    if m:
        tname = m.group(1)
        rest = m.group(2)
        if "does not depend on any axioms" in rest:
            axiom_map[tname] = []
        elif "depends on axioms:" in rest:
            bracket_m = re.search(r'\[(.*?)\]', rest)
            if bracket_m:
                ax_str = bracket_m.group(1).strip()
                if ax_str:
                    axs = [x.strip() for x in ax_str.split(",") if x.strip()]
                    axiom_map[tname] = axs
                else:
                    axiom_map[tname] = []
            else:
                axiom_map[tname] = []

print(f"Parsed axioms for {len(axiom_map)} declarations.")

standard_axioms = {"propext", "Classical.choice", "Quot.sound"}
theorems_list = []
zero_axiom_count = 0
standard_axiom_count = 0
forbidden_axiom_count = 0

for short_name, full_name, rel_path, stmt in all_theorems:
    axs = axiom_map.get(full_name, None)
    if axs is None:
        print(f"WARNING: No axioms found for {full_name}")
        axs = []
    
    non_std = [a for a in axs if a not in standard_axioms]
    if len(axs) == 0:
        zero_axiom_count += 1
    elif len(non_std) == 0:
        standard_axiom_count += 1
    else:
        forbidden_axiom_count += 1
        print(f"FORBIDDEN AXIOMS in {full_name}: {non_std}")
    
    theorems_list.append({
        "name": full_name,
        "file": rel_path,
        "statement": stmt,
        "axioms": axs,
        "standard_only": (len(non_std) == 0)
    })

print(f"Total: {len(theorems_list)}")
print(f"CanonicalJson count: {len(cj_theorems)}")
print(f"Correspondence count: {len(corr_theorems)}")
print(f"Zero axioms: {zero_axiom_count}")
print(f"Standard axioms only: {standard_axiom_count}")
print(f"Forbidden axioms: {forbidden_axiom_count}")

# 1. theorems.json
theorems_json_data = {
    "schema": "defiformal-p19-theorems/v3",
    "theorems_count": len(theorems_list),
    "canonical_json_theorems_count": len(cj_theorems),
    "correspondence_theorems_count": len(corr_theorems),
    "standard_axioms_only": (forbidden_axiom_count == 0),
    "forbidden_axioms_count": forbidden_axiom_count,
    "modules": [
        "DefiKernel.Certificates.Correspondence",
        "DefiKernel.Certificates.CanonicalJson"
    ],
    "theorems": theorems_list
}

with open(os.path.join(r17_dir, "theorems.json"), 'w') as f:
    json.dump(theorems_json_data, f, indent=2)

# 2. compiler-axiom-audit.log
# First section: Exact probe for each named theorem
# Second section: Verify.lean transitive compiler audit
verify_res = subprocess.run(["lake", "env", "lean", "DefiKernel/Certificates/Verify.lean"], cwd=lean_dir, capture_output=True, text=True)

with open(os.path.join(r17_dir, "compiler-axiom-audit.log"), 'w') as f:
    f.write(f"=== NAMED DECLARATIONS AXIOM PROBE ({len(theorems_list)} THEOREMS) ===\n")
    for full_name in [t["name"] for t in theorems_list]:
        axs = axiom_map.get(full_name, [])
        if len(axs) == 0:
            f.write(f"'{full_name}' does not depend on any axioms\n")
        else:
            f.write(f"'{full_name}' depends on axioms: [{', '.join(axs)}]\n")
    f.write("\n=== TRANSITIVE SCOPE COMPILER AUDIT (Verify.lean) ===\n")
    f.write(verify_res.stdout)

print("Saved theorems.json and compiler-axiom-audit.log.")
