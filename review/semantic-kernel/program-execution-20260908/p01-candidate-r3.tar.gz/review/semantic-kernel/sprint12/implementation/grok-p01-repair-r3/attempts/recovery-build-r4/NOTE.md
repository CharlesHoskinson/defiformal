exit 0, seconds 2.715
