import DefiKernel.Certificates.Decode
import DefiKernel.Certificates.Correspondence

namespace DefiKernel.Certificates

open Lean

def jsonDepthFuel (fuel : Nat) (j : Lean.Json) : Nat :=
  match fuel with
  | 0 => 0
  | fuel + 1 =>
    match j with
    | .arr elems =>
      1 + elems.foldl (fun acc elem => Nat.max acc (jsonDepthFuel fuel elem)) 0
    | .obj kvs =>
      1 + kvs.foldl (fun acc _ val => Nat.max acc (jsonDepthFuel fuel val)) 0
    | _ => 1

def jsonDepth (j : Lean.Json) : Nat :=
  jsonDepthFuel 100 j

def jsonMaxArrayLengthFuel (fuel : Nat) (j : Lean.Json) : Nat :=
  match fuel with
  | 0 => 0
  | fuel + 1 =>
    match j with
    | .arr elems =>
      Nat.max elems.size (elems.foldl (fun acc elem => Nat.max acc (jsonMaxArrayLengthFuel fuel elem)) 0)
    | .obj kvs =>
      kvs.foldl (fun acc _ val => Nat.max acc (jsonMaxArrayLengthFuel fuel val)) 0
    | _ => 0

def jsonMaxArrayLength (j : Lean.Json) : Nat :=
  jsonMaxArrayLengthFuel 100 j

def libraryRefToJson (lr : LibraryRefEnc) : Lean.Json :=
  match lr.moduleName with
  | none => Lean.Json.str lr.theoremName
  | some m => Lean.Json.mkObj [("theorem", Lean.Json.str lr.theoremName), ("module", Lean.Json.str m)]

def stateToJson (s : StateEnc) : Lean.Json :=
  Lean.Json.mkObj [("cells", Lean.Json.arr (s.cells.map stateCellToJson).toArray)]

def requestToJson (r : RequestEnc) : Lean.Json :=
  Lean.Json.mkObj [
    ("operation", Lean.Json.num r.operation),
    ("parties", Lean.Json.arr (r.parties.map partyToJson).toArray),
    ("arguments", Lean.Json.arr (r.arguments.map packedValueFullToJson).toArray),
    ("capabilityIds", Lean.Json.arr (r.capabilityIds.map (Lean.Json.num ·)).toArray),
    ("claimedActor", match r.claimedActor with | none => Lean.Json.null | some p => partyToJson p)
  ]

def typedExecutePayloadToJson (p : TypedExecutePayloadEnc) : Lean.Json :=
  Lean.Json.mkObj [
    ("registry", registryToJson p.registry),
    ("store", storeToJson p.store),
    ("ctx", contextToJson p.ctx),
    ("env", environmentToJson p.env),
    ("now", Lean.Json.num p.now),
    ("request", requestToJson p.request),
    ("state", stateToJson p.state)
  ]

def operationInterfaceToJson (op : OperationInterfaceEnc) : Lean.Json :=
  Lean.Json.mkObj [
    ("operation", Lean.Json.num op.operation),
    ("inputs", Lean.Json.arr (op.inputs.map inputPortToJson).toArray),
    ("outputs", Lean.Json.arr (op.outputs.map outputPortToJson).toArray)
  ]

def componentToJson (c : ComponentEnc) : Lean.Json :=
  Lean.Json.mkObj [
    ("id", Lean.Json.num c.id),
    ("privateCells", Lean.Json.arr (c.privateCells.map cellToJson).toArray),
    ("exports", Lean.Json.arr (c.exports.map resourcePortToJson).toArray),
    ("imports", Lean.Json.arr (c.imports.map resourceImportToJson).toArray),
    ("operations", Lean.Json.arr (c.operations.map operationInterfaceToJson).toArray)
  ]

def configToJson (cfg : ConfigEnc) : Lean.Json :=
  Lean.Json.mkObj [
    ("registry", registryToJson cfg.registry),
    ("domainAdmin", Lean.Json.arr (cfg.domainAdmin.map domainAdminToJson).toArray),
    ("catalog", Lean.Json.arr (cfg.catalog.map componentToJson).toArray)
  ]

def worldToJson (w : WorldEnc) : Lean.Json :=
  Lean.Json.mkObj [
    ("state", stateToJson w.state),
    ("capabilities", storeToJson w.capabilities)
  ]

def boundaryToJson (b : BoundaryEnc) : Lean.Json :=
  Lean.Json.mkObj [
    ("ctx", contextToJson b.ctx),
    ("env", environmentToJson b.env),
    ("now", Lean.Json.num b.now)
  ]

def inputSourceToJson : InputSourceEnc → Lean.Json
  | .literal v =>
    Lean.Json.mkObj [
      ("tag", Lean.Json.str "literal"),
      ("value", packedValueFullToJson v)
    ]
  | .priorOutput step port =>
    Lean.Json.mkObj [
      ("tag", Lean.Json.str "priorOutput"),
      ("step", Lean.Json.num step),
      ("port", qualifiedPortToJson port)
    ]

def invocationToJson (inv : InvocationEnc) : Lean.Json :=
  Lean.Json.mkObj [
    ("component", Lean.Json.num inv.component),
    ("operation", Lean.Json.num inv.operation),
    ("parties", Lean.Json.arr (inv.parties.map partyToJson).toArray),
    ("inputs", Lean.Json.arr (inv.inputs.map inputSourceToJson).toArray),
    ("capabilityIds", Lean.Json.arr (inv.capabilityIds.map (Lean.Json.num ·)).toArray),
    ("claimedActor", match inv.claimedActor with | none => Lean.Json.null | some p => partyToJson p)
  ]

def stepToJson : StepEnc → Lean.Json
  | .invoke inv =>
    Lean.Json.mkObj [
      ("tag", Lean.Json.str "invoke"),
      ("invocation", invocationToJson inv)
    ]
  | .issue grant =>
    Lean.Json.mkObj [
      ("tag", Lean.Json.str "issue"),
      ("grant", grantToJson grant)
    ]
  | .revoke id =>
    Lean.Json.mkObj [
      ("tag", Lean.Json.str "revoke"),
      ("id", Lean.Json.num id)
    ]
  | .unsupported s =>
    Lean.Json.mkObj [
      ("tag", Lean.Json.str s)
    ]

def outputObservationToJson (o : OutputObservationEnc) : Lean.Json :=
  Lean.Json.mkObj [
    ("step", Lean.Json.num o.step),
    ("port", qualifiedPortToJson o.port),
    ("value", packedValueFullToJson o.value)
  ]

def compositionStepPayloadToJson (p : CompositionStepPayloadEnc) : Lean.Json :=
  Lean.Json.mkObj [
    ("config", configToJson p.config),
    ("boundary", boundaryToJson p.boundary),
    ("index", Lean.Json.num p.index),
    ("history", Lean.Json.arr (p.history.map outputObservationToJson).toArray),
    ("step", stepToJson p.step),
    ("pre", worldToJson p.pre)
  ]

def compositionRunPayloadToJson (p : CompositionRunPayloadEnc) : Lean.Json :=
  Lean.Json.mkObj [
    ("config", configToJson p.config),
    ("boundaries", Lean.Json.arr (p.boundaries.map boundaryToJson).toArray),
    ("world", worldToJson p.world),
    ("steps", Lean.Json.arr (p.steps.map stepToJson).toArray)
  ]

def envelopeToJson (env : EnvelopeEnc) (payloadJson : Lean.Json) : Lean.Json :=
  Lean.Json.mkObj [
    ("schema_version", Lean.Json.num env.schema_version),
    ("mode", Lean.Json.str env.mode),
    ("source_pin", sourcePinToJson env.source_pin),
    ("audit_roots", Lean.Json.arr (env.audit_roots.map Lean.Json.str).toArray),
    ("types", typesEnumToJson env.types),
    ("assumptions", Lean.Json.arr (env.assumptions.map Lean.Json.str).toArray),
    ("invariants", Lean.Json.arr (env.invariants.map Lean.Json.str).toArray),
    ("libraries", Lean.Json.arr (env.libraries.map libraryRefToJson).toArray),
    ("source_map", Lean.Json.mkObj (env.source_map.map (fun (k, v) => (k, Lean.Json.str v)))),
    ("payload", payloadJson),
    ("claimed_judgments", Lean.Json.arr (env.claimed_judgments.map Lean.Json.str).toArray),
    ("claimed_next_state", match env.claimed_next_state with | none => Lean.Json.null | some w => worldToJson w),
    ("require_library_discharge", Lean.Json.bool env.require_library_discharge),
    ("require_invariant_discharge", Lean.Json.bool env.require_invariant_discharge)
  ]

def decodedIRToJson : DecodedIR → Lean.Json
  | .execution (.typed env p) =>
    envelopeToJson env (typedExecutePayloadToJson p)
  | .execution (.step env p) =>
    envelopeToJson env (compositionStepPayloadToJson p)
  | .execution (.run env p) =>
    envelopeToJson env (compositionRunPayloadToJson p)
  | .audit _ => Lean.Json.null
  | .codec _ => Lean.Json.null

#eval jsonDepth (decodedIRToJson canonicalWitnessIR)
#eval jsonMaxArrayLength (decodedIRToJson canonicalWitnessIR)

set_option maxRecDepth 500000 in
theorem test_depth : jsonDepth (decodedIRToJson canonicalWitnessIR) ≤ 64 := by decide

set_option maxRecDepth 500000 in
theorem test_array : jsonMaxArrayLength (decodedIRToJson canonicalWitnessIR) ≤ 4096 := by decide

end DefiKernel.Certificates

theorem decodeState_stateToJson (s : StateEnc)
    (h_valid : ∀ c ∈ s.cells, c.amount.den ≠ 0 ∧ Int.gcd c.amount.num.natAbs c.amount.den = 1 ∧ c.amount.num ≥ 0)
    (h_nodup : (s.cells.map (fun c => (c.domain, c.party, c.asset))).Nodup) :
    decodeState (stateToJson s) = .ok s := by
  cases s with | mk cells =>
  have h_cells : (cells.map stateCellToJson).mapM decodeStateCell = .ok cells := by
    apply list_mapM_decode_ok
    intro c hc
    have hc_valid := h_valid c hc
    exact decodeStateCell_stateCellToJson c hc_valid.1 hc_valid.2.1 hc_valid.2.2
  have h_def : decodeState (stateToJson ⟨cells⟩) = (do
      let arr ← Except.ok (cells.map stateCellToJson).toArray
      let c_dec ← arr.toList.mapM decodeStateCell
      let keys := c_dec.map (fun c => (c.domain, c.party, c.asset))
      if keys.length != keys.eraseDups.length then throw (.uniqueness "stateCell")
      .ok ⟨c_dec⟩) := rfl
  rw [h_def]
  change (do
      let c_dec ← (cells.map stateCellToJson).mapM decodeStateCell
      let keys := c_dec.map (fun c => (c.domain, c.party, c.asset))
      if keys.length != keys.eraseDups.length then throw (.uniqueness "stateCell")
      Except.ok (StateEnc.mk c_dec)) =
    (Except.ok (StateEnc.mk cells) : Except DecodeFailure StateEnc)
  rw [h_cells]
  dsimp [bind, Except.bind]
  have h_dup : (cells.map (fun c => (c.domain, c.party, c.asset))).eraseDups = cells.map (fun c => (c.domain, c.party, c.asset)) :=
    List.eraseDups_eq_of_nodup h_nodup
  rw [h_dup]
  have h_b : ((cells.map (fun c => (c.domain, c.party, c.asset))).length != (cells.map (fun c => (c.domain, c.party, c.asset))).length) = false := by
    rw [bne_iff_ne, Ne, not_not]
  rw [h_b]
  rfl
