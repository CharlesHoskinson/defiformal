import re

with open("/home/charl/.gemini/antigravity-cli/brain/907c4a2c-9039-4e68-b600-efe098d4d4af/scratch/Correspondence.lean.bak", "r") as f:
    text = f.read()

# Add maxHeartbeats at top of file
if "set_option maxHeartbeats" not in text[:300]:
    text = text.replace("set_option linter.style.longLine false\n", "set_option linter.style.longLine false\nset_option maxHeartbeats 4000000\nset_option linter.style.maxHeartbeats false\n")

# Extract all 40 *ToJson definitions from text
pattern = re.compile(r"(def [a-zA-Z0-9_]*ToJson[\s\S]*?)(?=\n(?:def |theorem |end |/--))")
defs_to_move = pattern.findall(text)
assert len(defs_to_move) == 40, f"Expected 40 defs, got {len(defs_to_move)}"

new_serializers = '''
def libraryRefToJson (lr : LibraryRefEnc) : Lean.Json :=
  match lr.moduleName with
  | none => Lean.Json.str lr.theoremName
  | some m => Lean.Json.mkObj [("module", Lean.Json.str m), ("theorem", Lean.Json.str lr.theoremName)]

def natToJson (n : Nat) : Lean.Json := Lean.Json.num n

def stateToJson (s : StateEnc) : Lean.Json :=
  Lean.Json.mkObj [("cells", Lean.Json.arr (s.cells.map stateCellToJson).toArray)]

def requestToJson (r : RequestEnc) : Lean.Json :=
  Lean.Json.mkObj [
    ("arguments", Lean.Json.arr (r.arguments.map packedValueFullToJson).toArray),
    ("capabilityIds", Lean.Json.arr (r.capabilityIds.map natToJson).toArray),
    ("claimedActor", match r.claimedActor with | none => Lean.Json.null | some p => partyToJson p),
    ("operation", Lean.Json.num r.operation),
    ("parties", Lean.Json.arr (r.parties.map partyToJson).toArray)
  ]

def typedExecutePayloadToJson (p : TypedExecutePayloadEnc) : Lean.Json :=
  Lean.Json.mkObj [
    ("ctx", contextToJson p.ctx),
    ("env", environmentToJson p.env),
    ("now", Lean.Json.num p.now),
    ("registry", registryToJson p.registry),
    ("request", requestToJson p.request),
    ("state", stateToJson p.state),
    ("store", storeToJson p.store)
  ]

def operationInterfaceToJson (op : OperationInterfaceEnc) : Lean.Json :=
  Lean.Json.mkObj [
    ("inputs", Lean.Json.arr (op.inputs.map inputPortToJson).toArray),
    ("operation", Lean.Json.num op.operation),
    ("outputs", Lean.Json.arr (op.outputs.map outputPortToJson).toArray)
  ]

def componentToJson (c : ComponentEnc) : Lean.Json :=
  Lean.Json.mkObj [
    ("exports", Lean.Json.arr (c.exports.map resourcePortToJson).toArray),
    ("id", Lean.Json.num c.id),
    ("imports", Lean.Json.arr (c.imports.map resourceImportToJson).toArray),
    ("operations", Lean.Json.arr (c.operations.map operationInterfaceToJson).toArray),
    ("privateCells", Lean.Json.arr (c.privateCells.map cellToJson).toArray)
  ]

def configToJson (cfg : ConfigEnc) : Lean.Json :=
  Lean.Json.mkObj [
    ("catalog", Lean.Json.arr (cfg.catalog.map componentToJson).toArray),
    ("domainAdmin", Lean.Json.arr (cfg.domainAdmin.map domainAdminToJson).toArray),
    ("registry", registryToJson cfg.registry)
  ]

def worldToJson (w : WorldEnc) : Lean.Json :=
  Lean.Json.mkObj [
    ("capabilities", storeToJson w.capabilities),
    ("state", stateToJson w.state)
  ]

def boundaryToJson (b : BoundaryEnc) : Lean.Json :=
  Lean.Json.mkObj [
    ("ctx", contextToJson b.ctx),
    ("env", environmentToJson b.env),
    ("now", Lean.Json.num b.now)
  ]

def inputSourceToJson : InputSourceEnc → Lean.Json
  | .literal v =>
    Lean.Json.mkObj [
      ("tag", Lean.Json.str "literal"),
      ("value", packedValueFullToJson v)
    ]
  | .priorOutput step port =>
    Lean.Json.mkObj [
      ("port", qualifiedPortToJson port),
      ("step", Lean.Json.num step),
      ("tag", Lean.Json.str "priorOutput")
    ]

def invocationToJson (inv : InvocationEnc) : Lean.Json :=
  Lean.Json.mkObj [
    ("capabilityIds", Lean.Json.arr (inv.capabilityIds.map natToJson).toArray),
    ("claimedActor", match inv.claimedActor with | none => Lean.Json.null | some p => partyToJson p),
    ("component", Lean.Json.num inv.component),
    ("inputs", Lean.Json.arr (inv.inputs.map inputSourceToJson).toArray),
    ("operation", Lean.Json.num inv.operation),
    ("parties", Lean.Json.arr (inv.parties.map partyToJson).toArray)
  ]

def stepToJson : StepEnc → Lean.Json
  | .invoke inv =>
    Lean.Json.mkObj [
      ("invocation", invocationToJson inv),
      ("tag", Lean.Json.str "invoke")
    ]
  | .issue grant =>
    Lean.Json.mkObj [
      ("grant", grantToJson grant),
      ("tag", Lean.Json.str "issue")
    ]
  | .revoke id =>
    Lean.Json.mkObj [
      ("id", Lean.Json.num id),
      ("tag", Lean.Json.str "revoke")
    ]
  | .unsupported s =>
    Lean.Json.mkObj [
      ("tag", Lean.Json.str s)
    ]

def outputObservationToJson (o : OutputObservationEnc) : Lean.Json :=
  Lean.Json.mkObj [
    ("port", qualifiedPortToJson o.port),
    ("step", Lean.Json.num o.step),
    ("value", packedValueFullToJson o.value)
  ]

def compositionStepPayloadToJson (p : CompositionStepPayloadEnc) : Lean.Json :=
  Lean.Json.mkObj [
    ("boundary", boundaryToJson p.boundary),
    ("config", configToJson p.config),
    ("history", Lean.Json.arr (p.history.map outputObservationToJson).toArray),
    ("index", Lean.Json.num p.index),
    ("pre", worldToJson p.pre),
    ("step", stepToJson p.step)
  ]

def compositionRunPayloadToJson (p : CompositionRunPayloadEnc) : Lean.Json :=
  Lean.Json.mkObj [
    ("boundaries", Lean.Json.arr (p.boundaries.map boundaryToJson).toArray),
    ("config", configToJson p.config),
    ("steps", Lean.Json.arr (p.steps.map stepToJson).toArray),
    ("world", worldToJson p.world)
  ]

def envelopeToJson (env : EnvelopeEnc) (payloadJson : Lean.Json) : Lean.Json :=
  Lean.Json.mkObj [
    ("assumptions", Lean.Json.arr (env.assumptions.map Lean.Json.str).toArray),
    ("audit_roots", Lean.Json.arr (env.audit_roots.map Lean.Json.str).toArray),
    ("claimed_judgments", Lean.Json.arr (env.claimed_judgments.map Lean.Json.str).toArray),
    ("claimed_next_state", match env.claimed_next_state with | none => Lean.Json.null | some w => worldToJson w),
    ("invariants", Lean.Json.arr (env.invariants.map Lean.Json.str).toArray),
    ("libraries", Lean.Json.arr (env.libraries.map libraryRefToJson).toArray),
    ("mode", Lean.Json.str env.mode),
    ("payload", payloadJson),
    ("require_invariant_discharge", Lean.Json.bool env.require_invariant_discharge),
    ("require_library_discharge", Lean.Json.bool env.require_library_discharge),
    ("schema_version", Lean.Json.num env.schema_version),
    ("source_map", Lean.Json.mkObj (env.source_map.map (fun (k, v) => (k, Lean.Json.str v)))),
    ("source_pin", sourcePinToJson env.source_pin),
    ("types", typesEnumToJson env.types)
  ]

def decodedIRToJson : DecodedIR → Lean.Json
  | .execution (.typed env p) =>
    envelopeToJson env (typedExecutePayloadToJson p)
  | .execution (.step env p) =>
    envelopeToJson env (compositionStepPayloadToJson p)
  | .execution (.run env p) =>
    envelopeToJson env (compositionRunPayloadToJson p)
  | .audit _ => Lean.Json.null
  | .codec _ => Lean.Json.null

/-- Fuel-bounded calculation of whole-document JSON nesting depth. -/
def jsonDepthFuel (fuel : Nat) (j : Lean.Json) : Nat :=
  match fuel with
  | 0 => 0
  | fuel + 1 =>
    match j with
    | .arr elems =>
      1 + elems.foldl (fun acc elem => Nat.max acc (jsonDepthFuel fuel elem)) 0
    | .obj kvs =>
      1 + kvs.foldl (fun acc _ val => Nat.max acc (jsonDepthFuel fuel val)) 0
    | _ => 1

/-- Whole-document JSON nesting depth. -/
def jsonDepth (j : Lean.Json) : Nat :=
  jsonDepthFuel 100 j

/-- Fuel-bounded calculation of whole-document maximum JSON array length. -/
def jsonMaxArrayLengthFuel (fuel : Nat) (j : Lean.Json) : Nat :=
  match fuel with
  | 0 => 0
  | fuel + 1 =>
    match j with
    | .arr elems =>
      Nat.max elems.size (elems.foldl (fun acc elem => Nat.max acc (jsonMaxArrayLengthFuel fuel elem)) 0)
    | .obj kvs =>
      kvs.foldl (fun acc _ val => Nat.max acc (jsonMaxArrayLengthFuel fuel val)) 0
    | _ => 0

/-- Whole-document maximum JSON array length. -/
def jsonMaxArrayLength (j : Lean.Json) : Nat :=
  jsonMaxArrayLengthFuel 100 j

/-- Whole-document JSON depth bounded by 64 (parser maximum depth limit). -/
def WholeDocumentDepthBounded (ir : DecodedIR) : Prop :=
  jsonDepth (decodedIRToJson ir) ≤ 64

/-- Whole-document JSON array lengths bounded by 4096 (parser maximum array length limit). -/
def WholeDocumentArrayBounded (ir : DecodedIR) : Prop :=
  jsonMaxArrayLength (decodedIRToJson ir) ≤ 4096
'''

serializers_block = "/-! ### Declarative JSON Serializers and Whole-Document Structural Metrics -/\n\n" + "\n\n".join(defs_to_move) + new_serializers

# Find the section to replace: from "def exprDepth" up to "def TypedPayloadLengthBounds"
start_pat = "/-- Expression AST depth calculation. -/\ndef exprDepth : ExprEnc → Nat"
end_pat = "/-- Bounded array lengths for typed execute payload matching production parser limits. -/\ndef TypedPayloadLengthBounds"

idx_start = text.find(start_pat)
idx_end = text.find(end_pat)
assert idx_start != -1 and idx_end != -1, "Could not find start/end of depth section"

part1 = text[:idx_start]
part2 = text[idx_end:]

# Now in part2, remove the three depth bounds before SupportedIR:
# TypedPayloadDepthBounds, StepPayloadDepthBounds, RunPayloadDepthBounds
depth_bounds_old = '''/-- Depth bounds for typed execute payload. -/
def TypedPayloadDepthBounds (p : TypedExecutePayloadEnc) : Prop :=
  ∀ e ∈ p.registry.entries, TemplateDepthBounded e.template

/-- Depth bounds for composition step payload. -/
def StepPayloadDepthBounds (p : CompositionStepPayloadEnc) : Prop :=
  ∀ e ∈ p.config.registry.entries, TemplateDepthBounded e.template

/-- Depth bounds for composition run payload. -/
def RunPayloadDepthBounds (p : CompositionRunPayloadEnc) : Prop :=
  ∀ e ∈ p.config.registry.entries, TemplateDepthBounded e.template

'''

assert depth_bounds_old in part2, "Could not find depth_bounds_old in part2"
part2 = part2.replace(depth_bounds_old, "")

# In part2, replace SupportedIR definition
supported_old = '''def SupportedIR (ir : DecodedIR) : Prop :=
  SerializedByteBound ir ∧
  match ir with
  | .execution (.typed env payload) =>
    env.schema_version = 1 ∧
    env.mode = "typed-execute" ∧
    StandardTypesEnum env.types ∧
    payload.state.cells.length = 32 ∧
    payload.state.cells.map (fun c ↦ (c.domain, c.party, c.asset)) = standard32CellKeys ∧
    payload.state.cells.all (fun c ↦ c.amount.den > 0 ∧ c.amount.num ≥ 0) = true ∧
    StoreCanonical payload.store ∧
    (payload.registry.entries.map (·.id)).Nodup ∧
    EnvelopeLengthBounds env ∧
    TypedPayloadLengthBounds payload ∧
    TypedPayloadDepthBounds payload
  | .execution (.step env payload) =>
    env.schema_version = 1 ∧
    env.mode = "composition-step" ∧
    StandardTypesEnum env.types ∧
    (match payload.step with | .unsupported _ => False | _ => True) ∧
    payload.pre.state.cells.length = 32 ∧
    payload.pre.state.cells.map (fun c ↦ (c.domain, c.party, c.asset)) = standard32CellKeys ∧
    payload.pre.state.cells.all (fun c ↦ c.amount.den > 0 ∧ c.amount.num ≥ 0) = true ∧
    StoreCanonical payload.pre.capabilities ∧
    (payload.config.registry.entries.map (·.id)).Nodup ∧
    EnvelopeLengthBounds env ∧
    StepPayloadLengthBounds payload ∧
    StepPayloadDepthBounds payload
  | .execution (.run env payload) =>
    env.schema_version = 1 ∧
    env.mode = "composition-run" ∧
    StandardTypesEnum env.types ∧
    payload.steps.all (fun s ↦ match s with | .unsupported _ => false | _ => true) = true ∧
    payload.world.state.cells.length = 32 ∧
    payload.world.state.cells.map (fun c ↦ (c.domain, c.party, c.asset)) = standard32CellKeys ∧
    payload.world.state.cells.all (fun c ↦ c.amount.den > 0 ∧ c.amount.num ≥ 0) = true ∧
    StoreCanonical payload.world.capabilities ∧
    (payload.config.registry.entries.map (·.id)).Nodup ∧
    EnvelopeLengthBounds env ∧
    RunPayloadLengthBounds payload ∧
    RunPayloadDepthBounds payload
  | .audit _ => False
  | .codec _ => False'''

supported_new = '''def SupportedIR (ir : DecodedIR) : Prop :=
  SerializedByteBound ir ∧
  WholeDocumentDepthBounded ir ∧
  WholeDocumentArrayBounded ir ∧
  match ir with
  | .execution (.typed env payload) =>
    env.schema_version = 1 ∧
    env.mode = "typed-execute" ∧
    StandardTypesEnum env.types ∧
    payload.state.cells.length = 32 ∧
    payload.state.cells.map (fun c ↦ (c.domain, c.party, c.asset)) = standard32CellKeys ∧
    payload.state.cells.all (fun c ↦ c.amount.den > 0 ∧ c.amount.num ≥ 0) = true ∧
    StoreCanonical payload.store ∧
    (payload.registry.entries.map (·.id)).Nodup ∧
    EnvelopeLengthBounds env ∧
    TypedPayloadLengthBounds payload
  | .execution (.step env payload) =>
    env.schema_version = 1 ∧
    env.mode = "composition-step" ∧
    StandardTypesEnum env.types ∧
    (match payload.step with | .unsupported _ => False | _ => True) ∧
    payload.pre.state.cells.length = 32 ∧
    payload.pre.state.cells.map (fun c ↦ (c.domain, c.party, c.asset)) = standard32CellKeys ∧
    payload.pre.state.cells.all (fun c ↦ c.amount.den > 0 ∧ c.amount.num ≥ 0) = true ∧
    StoreCanonical payload.pre.capabilities ∧
    (payload.config.registry.entries.map (·.id)).Nodup ∧
    EnvelopeLengthBounds env ∧
    StepPayloadLengthBounds payload
  | .execution (.run env payload) =>
    env.schema_version = 1 ∧
    env.mode = "composition-run" ∧
    StandardTypesEnum env.types ∧
    payload.steps.all (fun s ↦ match s with | .unsupported _ => false | _ => true) = true ∧
    payload.world.state.cells.length = 32 ∧
    payload.world.state.cells.map (fun c ↦ (c.domain, c.party, c.asset)) = standard32CellKeys ∧
    payload.world.state.cells.all (fun c ↦ c.amount.den > 0 ∧ c.amount.num ≥ 0) = true ∧
    StoreCanonical payload.world.capabilities ∧
    (payload.config.registry.entries.map (·.id)).Nodup ∧
    EnvelopeLengthBounds env ∧
    RunPayloadLengthBounds payload
  | .audit _ => False
  | .codec _ => False'''

assert supported_old in part2, "Could not find supported_old"
part2 = part2.replace(supported_old, supported_new)

# In part2, replace structurallyAdmissible_nonempty
nonempty_old = '''set_option maxRecDepth 100000 in
/-- Theorem: StructurallyAdmissibleIR is nonempty. -/
theorem structurallyAdmissible_nonempty : StructurallyAdmissibleIR canonicalWitnessIR := by
  dsimp [StructurallyAdmissibleIR, SupportedIR, CanonicalIR, canonicalWitnessIR, StandardTypesEnum,
         SourceMapSorted, ClaimedNextStateCanonical, standard32Cells, standard32CellKeys,
         isSortedStrictAscending, StoreCanonical, RequestCanonical, EnvironmentCanonical,
         WorldCanonical, StateCellsMatchStandard32, EnvelopeLengthBounds, TypedPayloadLengthBounds,
         TypedPayloadDepthBounds, TemplateLengthBounds, TemplateDepthBounded, SerializedByteBound]
  refine ⟨⟨by decide, ⟨rfl, rfl, ⟨rfl, rfl, rfl⟩, rfl, rfl, by decide, List.nodup_nil, List.nodup_nil, by decide, ?_, ?_⟩⟩, ?_⟩
  · refine ⟨rfl, by decide, ?_, by decide, by decide, by decide, by decide, by decide⟩
    intro _ h; contradiction
  · intro _ h; contradiction
  · refine ⟨rfl, trivial, by decide, ?_, ?_, ?_⟩
    · intro _ h; contradiction
    · intro _ h; contradiction'''

nonempty_new = '''set_option maxRecDepth 500000 in
/-- Theorem: StructurallyAdmissibleIR is nonempty. -/
theorem structurallyAdmissible_nonempty : StructurallyAdmissibleIR canonicalWitnessIR := by
  dsimp [StructurallyAdmissibleIR, SupportedIR, CanonicalIR, canonicalWitnessIR, StandardTypesEnum,
         SourceMapSorted, ClaimedNextStateCanonical, standard32Cells, standard32CellKeys,
         isSortedStrictAscending, StoreCanonical, RequestCanonical, EnvironmentCanonical,
         WorldCanonical, StateCellsMatchStandard32, EnvelopeLengthBounds, TypedPayloadLengthBounds,
         TemplateLengthBounds, SerializedByteBound, WholeDocumentDepthBounded, WholeDocumentArrayBounded]
  refine ⟨⟨by decide, by decide, by decide, ⟨rfl, rfl, ⟨rfl, rfl, rfl⟩, rfl, rfl, by decide, List.nodup_nil, List.nodup_nil, by decide, ?_⟩⟩, ?_⟩
  · refine ⟨rfl, by decide, ?_, by decide, by decide, by decide, by decide, by decide⟩
    intro _ h; contradiction
  · refine ⟨rfl, trivial, by decide, ?_, ?_, ?_⟩
    · intro _ h; contradiction
    · intro _ h; contradiction'''

assert nonempty_old in part2, "Could not find nonempty_old"
part2 = part2.replace(nonempty_old, nonempty_new)

# Remove the 40 definitions from part2 (they were moved to serializers_block)
for d in defs_to_move:
    assert d in part2, f"Could not find def in part2:\n{d[:40]}..."
    part2 = part2.replace(d, "", 1)

# Theorems to append before `end DefiKernel.Certificates`
theorems_block = '''
theorem decodeLibraryRef_libraryRefToJson (lr : LibraryRefEnc) :
    decodeLibraryRef (libraryRefToJson lr) = .ok lr := by
  cases lr with | mk thm m =>
  cases m with
  | none => rfl
  | some m' => rfl

theorem decodeNat_natToJson (n : Nat) :
    (match (natToJson n) with | .num m => (Except.ok m.mantissa.toNat : Except DecodeFailure Nat) | _ => Except.error (.jsonType "capabilityId")) = Except.ok n := rfl

theorem decodeNatList_map_num (caps : List Nat) :
    (caps.map natToJson).mapM (fun (x : Lean.Json) => match x with | .num n => (Except.ok n.mantissa.toNat : Except DecodeFailure Nat) | _ => Except.error (.jsonType "capabilityId")) = Except.ok caps := by
  apply list_mapM_decode_ok
  intro n _
  exact decodeNat_natToJson n

theorem decodeState_stateToJson (s : StateEnc)
    (h_valid : ∀ c ∈ s.cells, c.amount.den ≠ 0 ∧ Int.gcd c.amount.num.natAbs c.amount.den = 1 ∧ c.amount.num ≥ 0)
    (h_unique : (s.cells.map (fun c => (c.domain, c.party, c.asset))).eraseDups.length = s.cells.length) :
    decodeState (stateToJson s) = .ok s := by
  cases s with | mk cells =>
  have h_cells : (cells.map stateCellToJson).mapM decodeStateCell = .ok cells := by
    apply list_mapM_decode_ok
    intro c hc
    have hc_valid := h_valid c hc
    exact decodeStateCell_stateCellToJson c hc_valid.1 hc_valid.2.1 hc_valid.2.2
  have h_def : decodeState (stateToJson ⟨cells⟩) = (do
      let arr ← Except.ok (cells.map stateCellToJson).toArray
      let c_dec ← arr.toList.mapM decodeStateCell
      let keys := c_dec.map (fun c => (c.domain, c.party, c.asset))
      if keys.length != keys.eraseDups.length then throw (.uniqueness "stateCell")
      .ok ⟨c_dec⟩) := rfl
  rw [h_def]
  change (do
      let c_dec ← (cells.map stateCellToJson).mapM decodeStateCell
      let keys := c_dec.map (fun c => (c.domain, c.party, c.asset))
      if keys.length != keys.eraseDups.length then throw (.uniqueness "stateCell")
      Except.ok (StateEnc.mk c_dec)) =
    (Except.ok (StateEnc.mk cells) : Except DecodeFailure StateEnc)
  rw [h_cells]
  dsimp [bind, Except.bind]
  have h_len : (cells.map (fun c => (c.domain, c.party, c.asset))).length = cells.length := List.length_map ..
  dsimp at h_unique
  have h_cond : ((cells.map (fun c => (c.domain, c.party, c.asset))).length !=
      (cells.map (fun c => (c.domain, c.party, c.asset))).eraseDups.length) = false := by
    rw [h_len, h_unique]
    simp
  rw [h_cond]
  rfl

theorem decodeRequest_requestToJson (r : RequestEnc) (h_can : RequestCanonical r) :
    decodeRequest (requestToJson r) = .ok r := by
  cases r with | mk op parties args caps actor =>
  have h_parties : (parties.map partyToJson).mapM decodeParty = .ok parties := by
    apply list_mapM_decode_ok; intro p _; exact decodeParty_partyToJson p
  have h_args : (args.map packedValueFullToJson).mapM decodePackedValue = .ok args := by
    apply list_mapM_decode_ok; intro a ha; exact decodePackedValue_canonical a (h_can a ha)
  have h_caps : (caps.map natToJson).mapM (fun (x : Lean.Json) => match x with | .num n => (Except.ok n.mantissa.toNat : Except DecodeFailure Nat) | _ => Except.error (.jsonType "capabilityId")) = Except.ok caps :=
    decodeNatList_map_num caps
  cases actor with
  | none =>
    have h_def : decodeRequest (requestToJson ⟨op, parties, args, caps, none⟩) = (do
        let p_dec ← (parties.map partyToJson).mapM decodeParty
        let a_dec ← (args.map packedValueFullToJson).mapM decodePackedValue
        let c_dec ← (caps.map natToJson).mapM (fun (x : Lean.Json) => match x with | .num n => (Except.ok n.mantissa.toNat : Except DecodeFailure Nat) | _ => Except.error (.jsonType "capabilityId"))
        .ok ⟨op, p_dec, a_dec, c_dec, none⟩) := rfl
    rw [h_def, h_parties, h_args, h_caps]
    rfl
  | some p =>
    have hp := decodeParty_partyToJson p
    have h_def : decodeRequest (requestToJson ⟨op, parties, args, caps, some p⟩) = (do
        let p_dec ← (parties.map partyToJson).mapM decodeParty
        let a_dec ← (args.map packedValueFullToJson).mapM decodePackedValue
        let c_dec ← (caps.map natToJson).mapM (fun (x : Lean.Json) => match x with | .num n => (Except.ok n.mantissa.toNat : Except DecodeFailure Nat) | _ => Except.error (.jsonType "capabilityId"))
        let ca_dec ← (decodeParty (partyToJson p)).map some
        .ok ⟨op, p_dec, a_dec, c_dec, ca_dec⟩) := rfl
    rw [h_def, h_parties, h_args, h_caps, hp]
    rfl

theorem decodeOperationInterface_operationInterfaceToJson (op : OperationInterfaceEnc) :
    decodeOperationInterface (operationInterfaceToJson op) = .ok op := by
  cases op with | mk op_num inputs outputs =>
  have h_in : (inputs.map inputPortToJson).mapM decodeInputPort = .ok inputs := by
    apply list_mapM_decode_ok; intro p _; exact decodeInputPort_inputPortToJson p
  have h_out : (outputs.map outputPortToJson).mapM decodeOutputPort = .ok outputs := by
    apply list_mapM_decode_ok; intro p _; exact decodeOutputPort_outputPortToJson p
  have h_def : decodeOperationInterface (operationInterfaceToJson ⟨op_num, inputs, outputs⟩) = (do
      let in_dec ← (inputs.map inputPortToJson).mapM decodeInputPort
      let out_dec ← (outputs.map outputPortToJson).mapM decodeOutputPort
      .ok ⟨op_num, in_dec, out_dec⟩) := rfl
  rw [h_def, h_in, h_out]
  rfl

theorem decodeComponent_componentToJson (c : ComponentEnc) :
    decodeComponent (componentToJson c) = .ok c := by
  cases c with | mk id priv exp imp ops =>
  have h_priv : (priv.map cellToJson).mapM decodeCell = .ok priv := by
    apply list_mapM_decode_ok; intro x _; exact decodeCell_cellToJson x
  have h_exp : (exp.map resourcePortToJson).mapM decodeResourcePort = .ok exp := by
    apply list_mapM_decode_ok; intro x _; exact decodeResourcePort_resourcePortToJson x
  have h_imp : (imp.map resourceImportToJson).mapM decodeResourceImport = .ok imp := by
    apply list_mapM_decode_ok; intro x _; exact decodeResourceImport_resourceImportToJson x
  have h_ops : (ops.map operationInterfaceToJson).mapM decodeOperationInterface = .ok ops := by
    apply list_mapM_decode_ok; intro x _; exact decodeOperationInterface_operationInterfaceToJson x
  have h_def : decodeComponent (componentToJson ⟨id, priv, exp, imp, ops⟩) = (do
      let priv_dec ← (priv.map cellToJson).mapM decodeCell
      let exp_dec ← (exp.map resourcePortToJson).mapM decodeResourcePort
      let imp_dec ← (imp.map resourceImportToJson).mapM decodeResourceImport
      let ops_dec ← (ops.map operationInterfaceToJson).mapM decodeOperationInterface
      .ok ⟨id, priv_dec, exp_dec, imp_dec, ops_dec⟩) := rfl
  rw [h_def, h_priv, h_exp, h_imp, h_ops]
  rfl

theorem decodeConfig_configToJson (cfg : ConfigEnc)
    (h_reg_can : RegistryCanonical cfg.registry) :
    decodeConfig (configToJson cfg) = .ok cfg := by
  cases cfg with | mk reg da cat =>
  have h_reg := decodeRegistry_registryToJson reg h_reg_can
  have h_da : (da.map domainAdminToJson).mapM decodeDomainAdmin = .ok da := by
    apply list_mapM_decode_ok; intro x _; exact decodeDomainAdmin_domainAdminToJson x
  have h_cat : (cat.map componentToJson).mapM decodeComponent = .ok cat := by
    apply list_mapM_decode_ok; intro x _; exact decodeComponent_componentToJson x
  have h_def : decodeConfig (configToJson ⟨reg, da, cat⟩) = (do
      let reg_dec ← decodeRegistry (registryToJson reg)
      let da_dec ← (da.map domainAdminToJson).mapM decodeDomainAdmin
      let cat_dec ← (cat.map componentToJson).mapM decodeComponent
      .ok ⟨reg_dec, da_dec, cat_dec⟩) := rfl
  rw [h_def, h_reg, h_da, h_cat]
  rfl

theorem decodeWorld_worldToJson (w : WorldEnc)
    (h_state_valid : ∀ c ∈ w.state.cells, c.amount.den ≠ 0 ∧ Int.gcd c.amount.num.natAbs c.amount.den = 1 ∧ c.amount.num ≥ 0)
    (h_state_unique : (w.state.cells.map (fun c => (c.domain, c.party, c.asset))).eraseDups.length = w.state.cells.length) :
    decodeWorld (worldToJson w) = .ok w := by
  cases w with | mk st caps =>
  have h_st := decodeState_stateToJson st h_state_valid h_state_unique
  have h_caps := decodeStore_storeToJson caps
  have h_def : decodeWorld (worldToJson ⟨st, caps⟩) = (do
      let st_dec ← decodeState (stateToJson st)
      let caps_dec ← decodeStore (storeToJson caps)
      .ok ⟨st_dec, caps_dec⟩) := rfl
  rw [h_def, h_st, h_caps]
  rfl

theorem decodeBoundary_boundaryToJson (b : BoundaryEnc) (h_can : BoundaryCanonical b) :
    decodeBoundary (boundaryToJson b) = .ok b := by
  cases b with | mk ctx env now =>
  have h_ctx := decodeContext_contextToJson ctx
  have h_env := decodeEnvironment_environmentToJson env h_can
  have h_def : decodeBoundary (boundaryToJson ⟨ctx, env, now⟩) = (do
      let ctx_dec ← decodeContext (contextToJson ctx)
      let env_dec ← decodeEnvironment (environmentToJson env)
      .ok ⟨ctx_dec, env_dec, now⟩) := rfl
  rw [h_def, h_ctx, h_env]
  rfl

theorem decodeInputSource_inputSourceToJson (s : InputSourceEnc) (h_can : InputSourceCanonical s) :
    decodeInputSource (inputSourceToJson s) = .ok s := by
  cases s with
  | literal v =>
    have hv := decodePackedValue_canonical v h_can
    have h_def : decodeInputSource (inputSourceToJson (.literal v)) = (do
        let v_dec ← decodePackedValue (packedValueFullToJson v)
        .ok (.literal v_dec)) := rfl
    rw [h_def, hv]
    rfl
  | priorOutput step port =>
    cases port with | mk c p => rfl

theorem decodeInvocation_invocationToJson (inv : InvocationEnc) (h_can : InvocationCanonical inv) :
    decodeInvocation (invocationToJson inv) = .ok inv := by
  cases inv with | mk comp op parties inputs caps actor =>
  have h_parties : (parties.map partyToJson).mapM decodeParty = .ok parties := by
    apply list_mapM_decode_ok; intro p _; exact decodeParty_partyToJson p
  have h_inputs : (inputs.map inputSourceToJson).mapM decodeInputSource = .ok inputs := by
    apply list_mapM_decode_ok; intro i hi; exact decodeInputSource_inputSourceToJson i (h_can i hi)
  have h_caps : (caps.map natToJson).mapM (fun (x : Lean.Json) => match x with | .num n => (Except.ok n.mantissa.toNat : Except DecodeFailure Nat) | _ => Except.error (.jsonType "capabilityId")) = Except.ok caps :=
    decodeNatList_map_num caps
  cases actor with
  | none =>
    have h_def : decodeInvocation (invocationToJson ⟨comp, op, parties, inputs, caps, none⟩) = (do
        let p_dec ← (parties.map partyToJson).mapM decodeParty
        let in_dec ← (inputs.map inputSourceToJson).mapM decodeInputSource
        let c_dec ← (caps.map natToJson).mapM (fun (x : Lean.Json) => match x with | .num n => (Except.ok n.mantissa.toNat : Except DecodeFailure Nat) | _ => Except.error (.jsonType "capabilityId"))
        .ok ⟨comp, op, p_dec, in_dec, c_dec, none⟩) := rfl
    rw [h_def, h_parties, h_inputs, h_caps]
    rfl
  | some p =>
    have hp := decodeParty_partyToJson p
    have h_def : decodeInvocation (invocationToJson ⟨comp, op, parties, inputs, caps, some p⟩) = (do
        let p_dec ← (parties.map partyToJson).mapM decodeParty
        let in_dec ← (inputs.map inputSourceToJson).mapM decodeInputSource
        let c_dec ← (caps.map natToJson).mapM (fun (x : Lean.Json) => match x with | .num n => (Except.ok n.mantissa.toNat : Except DecodeFailure Nat) | _ => Except.error (.jsonType "capabilityId"))
        let ca_dec ← (decodeParty (partyToJson p)).map some
        .ok ⟨comp, op, p_dec, in_dec, c_dec, ca_dec⟩) := rfl
    rw [h_def, h_parties, h_inputs, h_caps, hp]
    rfl

set_option maxHeartbeats 1000000 in
theorem decodeStep_stepToJson (s : StepEnc) (h_can : StepCanonical s) :
    decodeStep (stepToJson s) = .ok s := by
  cases s with
  | invoke inv =>
    have h_inv := decodeInvocation_invocationToJson inv h_can
    have h_def : decodeStep (stepToJson (.invoke inv)) = (do
        let inv_dec ← decodeInvocation (invocationToJson inv)
        .ok (.invoke inv_dec)) := rfl
    rw [h_def, h_inv]
    rfl
  | issue grant =>
    have h_g := decodeGrant_grantToJson grant
    have h_def : decodeStep (stepToJson (.issue grant)) = (do
        let g_dec ← decodeGrant (grantToJson grant)
        .ok (.issue g_dec)) := rfl
    rw [h_def, h_g]
    rfl
  | revoke id =>
    rfl
  | unsupported _ =>
    contradiction

theorem decodeOutputObservation_outputObservationToJson (o : OutputObservationEnc) (h_can : PackedValueCanonical o.value) :
    decodeOutputObservation (outputObservationToJson o) = .ok o := by
  cases o with | mk step port val =>
  have h_val := decodePackedValue_canonical val h_can
  cases port with | mk c p =>
  have h_def : decodeOutputObservation (outputObservationToJson ⟨step, ⟨c, p⟩, val⟩) = (do
      let v_dec ← decodePackedValue (packedValueFullToJson val)
      .ok ⟨step, ⟨c, p⟩, v_dec⟩) := rfl
  rw [h_def, h_val]
  rfl

theorem decodeTypedExecutePayload_typedExecutePayloadToJson (p : TypedExecutePayloadEnc)
    (h_reg_can : RegistryCanonical p.registry)
    (h_env_can : EnvironmentCanonical p.env)
    (h_req_can : RequestCanonical p.request)
    (h_state_valid : ∀ c ∈ p.state.cells, c.amount.den ≠ 0 ∧ Int.gcd c.amount.num.natAbs c.amount.den = 1 ∧ c.amount.num ≥ 0)
    (h_state_unique : (p.state.cells.map (fun c => (c.domain, c.party, c.asset))).eraseDups.length = p.state.cells.length) :
    decodeTypedExecutePayload (typedExecutePayloadToJson p) = .ok p := by
  cases p with | mk reg store ctx env now req st =>
  have h_reg := decodeRegistry_registryToJson reg h_reg_can
  have h_store := decodeStore_storeToJson store
  have h_ctx := decodeContext_contextToJson ctx
  have h_env := decodeEnvironment_environmentToJson env h_env_can
  have h_req := decodeRequest_requestToJson req h_req_can
  have h_st := decodeState_stateToJson st h_state_valid h_state_unique
  have h_def : decodeTypedExecutePayload (typedExecutePayloadToJson ⟨reg, store, ctx, env, now, req, st⟩) = (do
      let reg_dec ← decodeRegistry (registryToJson reg)
      let store_dec ← decodeStore (storeToJson store)
      let ctx_dec ← decodeContext (contextToJson ctx)
      let env_dec ← decodeEnvironment (environmentToJson env)
      let req_dec ← decodeRequest (requestToJson req)
      let st_dec ← decodeState (stateToJson st)
      .ok ⟨reg_dec, store_dec, ctx_dec, env_dec, now, req_dec, st_dec⟩) := rfl
  rw [h_def, h_reg, h_store, h_ctx, h_env, h_req, h_st]
  rfl

theorem decodeCompositionStepPayload_compositionStepPayloadToJson (p : CompositionStepPayloadEnc)
    (h_cfg_can : RegistryCanonical p.config.registry)
    (h_bnd_can : BoundaryCanonical p.boundary)
    (h_hist_can : HistoryCanonical p.history)
    (h_step_can : StepCanonical p.step)
    (h_pre_valid : ∀ c ∈ p.pre.state.cells, c.amount.den ≠ 0 ∧ Int.gcd c.amount.num.natAbs c.amount.den = 1 ∧ c.amount.num ≥ 0)
    (h_pre_unique : (p.pre.state.cells.map (fun c => (c.domain, c.party, c.asset))).eraseDups.length = p.pre.state.cells.length) :
    decodeCompositionStepPayload (compositionStepPayloadToJson p) = .ok p := by
  cases p with | mk cfg bnd idx hist step pre =>
  have h_cfg := decodeConfig_configToJson cfg h_cfg_can
  have h_bnd := decodeBoundary_boundaryToJson bnd h_bnd_can
  have h_hist : (hist.map outputObservationToJson).mapM decodeOutputObservation = .ok hist := by
    apply list_mapM_decode_ok; intro o ho; exact decodeOutputObservation_outputObservationToJson o (h_hist_can o ho)
  have h_step := decodeStep_stepToJson step h_step_can
  have h_pre := decodeWorld_worldToJson pre h_pre_valid h_pre_unique
  have h_def : decodeCompositionStepPayload (compositionStepPayloadToJson ⟨cfg, bnd, idx, hist, step, pre⟩) = (do
      let cfg_dec ← decodeConfig (configToJson cfg)
      let bnd_dec ← decodeBoundary (boundaryToJson bnd)
      let hist_dec ← (hist.map outputObservationToJson).mapM decodeOutputObservation
      let step_dec ← decodeStep (stepToJson step)
      let pre_dec ← decodeWorld (worldToJson pre)
      .ok ⟨cfg_dec, bnd_dec, idx, hist_dec, step_dec, pre_dec⟩) := rfl
  rw [h_def, h_cfg, h_bnd, h_hist, h_step, h_pre]
  rfl

theorem decodeCompositionRunPayload_compositionRunPayloadToJson (p : CompositionRunPayloadEnc)
    (h_cfg_can : RegistryCanonical p.config.registry)
    (h_bnds_can : ∀ b ∈ p.boundaries, BoundaryCanonical b)
    (h_steps_can : ∀ s ∈ p.steps, StepCanonical s)
    (h_w_valid : ∀ c ∈ p.world.state.cells, c.amount.den ≠ 0 ∧ Int.gcd c.amount.num.natAbs c.amount.den = 1 ∧ c.amount.num ≥ 0)
    (h_w_unique : (p.world.state.cells.map (fun c => (c.domain, c.party, c.asset))).eraseDups.length = p.world.state.cells.length) :
    decodeCompositionRunPayload (compositionRunPayloadToJson p) = .ok p := by
  cases p with | mk cfg bnds world steps =>
  have h_cfg := decodeConfig_configToJson cfg h_cfg_can
  have h_bnds : (bnds.map boundaryToJson).mapM decodeBoundary = .ok bnds := by
    apply list_mapM_decode_ok; intro b hb; exact decodeBoundary_boundaryToJson b (h_bnds_can b hb)
  have h_world := decodeWorld_worldToJson world h_w_valid h_w_unique
  have h_steps : (steps.map stepToJson).mapM decodeStep = .ok steps := by
    apply list_mapM_decode_ok; intro s hs; exact decodeStep_stepToJson s (h_steps_can s hs)
  have h_def : decodeCompositionRunPayload (compositionRunPayloadToJson ⟨cfg, bnds, world, steps⟩) = (do
      let cfg_dec ← decodeConfig (configToJson cfg)
      let bnds_dec ← (bnds.map boundaryToJson).mapM decodeBoundary
      let world_dec ← decodeWorld (worldToJson world)
      let steps_dec ← (steps.map stepToJson).mapM decodeStep
      .ok ⟨cfg_dec, bnds_dec, world_dec, steps_dec⟩) := rfl
  rw [h_def, h_cfg, h_bnds, h_world, h_steps]
  rfl
'''

end_marker = "end DefiKernel.Certificates"
idx_last_end = part2.rfind(end_marker)
assert idx_last_end != -1, "Could not find end DefiKernel.Certificates"

final_text = part1 + serializers_block + "\n\n" + part2[:idx_last_end] + theorems_block + "\n\n" + end_marker + "\n"

with open("lean/DefiKernel/Certificates/Correspondence.lean", "w") as f:
    f.write(final_text)

print("Candidate Correspondence.lean built successfully!")
