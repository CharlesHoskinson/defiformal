import DefiKernel.Certificates.Correspondence
import DefiKernel.Certificates.Decode

namespace DefiKernel.Certificates

open Lean

def libraryRefToJson (lr : LibraryRefEnc) : Lean.Json :=
  match lr.moduleName with
  | none => Lean.Json.str lr.theoremName
  | some m => Lean.Json.mkObj [("theorem", Lean.Json.str lr.theoremName), ("module", Lean.Json.str m)]

def stateToJson (s : StateEnc) : Lean.Json :=
  Lean.Json.mkObj [("cells", Lean.Json.arr (s.cells.map stateCellToJson).toArray)]

def requestToJson (r : RequestEnc) : Lean.Json :=
  Lean.Json.mkObj [
    ("operation", Lean.Json.num r.operation),
    ("parties", Lean.Json.arr (r.parties.map partyToJson).toArray),
    ("arguments", Lean.Json.arr (r.arguments.map packedValueFullToJson).toArray),
    ("capabilityIds", Lean.Json.arr (r.capabilityIds.map (Lean.Json.num ·)).toArray),
    ("claimedActor", match r.claimedActor with | none => Lean.Json.null | some p => partyToJson p)
  ]

def typedExecutePayloadToJson (p : TypedExecutePayloadEnc) : Lean.Json :=
  Lean.Json.mkObj [
    ("registry", registryToJson p.registry),
    ("store", storeToJson p.store),
    ("ctx", contextToJson p.ctx),
    ("env", environmentToJson p.env),
    ("now", Lean.Json.num p.now),
    ("request", requestToJson p.request),
    ("state", stateToJson p.state)
  ]

def operationInterfaceToJson (op : OperationInterfaceEnc) : Lean.Json :=
  Lean.Json.mkObj [
    ("operation", Lean.Json.num op.operation),
    ("inputs", Lean.Json.arr (op.inputs.map inputPortToJson).toArray),
    ("outputs", Lean.Json.arr (op.outputs.map outputPortToJson).toArray)
  ]

def componentToJson (c : ComponentEnc) : Lean.Json :=
  Lean.Json.mkObj [
    ("id", Lean.Json.num c.id),
    ("privateCells", Lean.Json.arr (c.privateCells.map cellToJson).toArray),
    ("exports", Lean.Json.arr (c.exports.map resourcePortToJson).toArray),
    ("imports", Lean.Json.arr (c.imports.map resourceImportToJson).toArray),
    ("operations", Lean.Json.arr (c.operations.map operationInterfaceToJson).toArray)
  ]

def configToJson (cfg : ConfigEnc) : Lean.Json :=
  Lean.Json.mkObj [
    ("registry", registryToJson cfg.registry),
    ("domainAdmin", Lean.Json.arr (cfg.domainAdmin.map domainAdminToJson).toArray),
    ("catalog", Lean.Json.arr (cfg.catalog.map componentToJson).toArray)
  ]

def worldToJson (w : WorldEnc) : Lean.Json :=
  Lean.Json.mkObj [
    ("state", stateToJson w.state),
    ("capabilities", storeToJson w.capabilities)
  ]

def boundaryToJson (b : BoundaryEnc) : Lean.Json :=
  Lean.Json.mkObj [
    ("ctx", contextToJson b.ctx),
    ("env", environmentToJson b.env),
    ("now", Lean.Json.num b.now)
  ]

def inputSourceToJson : InputSourceEnc → Lean.Json
  | .literal v =>
    Lean.Json.mkObj [
      ("tag", Lean.Json.str "literal"),
      ("value", packedValueFullToJson v)
    ]
  | .priorOutput step port =>
    Lean.Json.mkObj [
      ("tag", Lean.Json.str "priorOutput"),
      ("step", Lean.Json.num step),
      ("port", qualifiedPortToJson port)
    ]

def invocationToJson (inv : InvocationEnc) : Lean.Json :=
  Lean.Json.mkObj [
    ("component", Lean.Json.num inv.component),
    ("operation", Lean.Json.num inv.operation),
    ("parties", Lean.Json.arr (inv.parties.map partyToJson).toArray),
    ("inputs", Lean.Json.arr (inv.inputs.map inputSourceToJson).toArray),
    ("capabilityIds", Lean.Json.arr (inv.capabilityIds.map (Lean.Json.num ·)).toArray),
    ("claimedActor", match inv.claimedActor with | none => Lean.Json.null | some p => partyToJson p)
  ]

def stepToJson : StepEnc → Lean.Json
  | .invoke inv =>
    Lean.Json.mkObj [
      ("tag", Lean.Json.str "invoke"),
      ("invocation", invocationToJson inv)
    ]
  | .issue grant =>
    Lean.Json.mkObj [
      ("tag", Lean.Json.str "issue"),
      ("grant", grantToJson grant)
    ]
  | .revoke id =>
    Lean.Json.mkObj [
      ("tag", Lean.Json.str "revoke"),
      ("id", Lean.Json.num id)
    ]
  | .unsupported s =>
    Lean.Json.mkObj [
      ("tag", Lean.Json.str s)
    ]

def outputObservationToJson (o : OutputObservationEnc) : Lean.Json :=
  Lean.Json.mkObj [
    ("step", Lean.Json.num o.step),
    ("port", qualifiedPortToJson o.port),
    ("value", packedValueFullToJson o.value)
  ]

def compositionStepPayloadToJson (p : CompositionStepPayloadEnc) : Lean.Json :=
  Lean.Json.mkObj [
    ("config", configToJson p.config),
    ("boundary", boundaryToJson p.boundary),
    ("index", Lean.Json.num p.index),
    ("history", Lean.Json.arr (p.history.map outputObservationToJson).toArray),
    ("step", stepToJson p.step),
    ("pre", worldToJson p.pre)
  ]

def compositionRunPayloadToJson (p : CompositionRunPayloadEnc) : Lean.Json :=
  Lean.Json.mkObj [
    ("config", configToJson p.config),
    ("boundaries", Lean.Json.arr (p.boundaries.map boundaryToJson).toArray),
    ("world", worldToJson p.world),
    ("steps", Lean.Json.arr (p.steps.map stepToJson).toArray)
  ]

theorem decodeLibraryRef_libraryRefToJson (lr : LibraryRefEnc) :
    decodeLibraryRef (libraryRefToJson lr) = .ok lr := by
  cases lr with | mk thm m =>
  cases m with
  | none => rfl
  | some m' => rfl

theorem decodeState_stateToJson (s : StateEnc)
    (h_valid : ∀ c ∈ s.cells, c.amount.den ≠ 0 ∧ Int.gcd c.amount.num.natAbs c.amount.den = 1 ∧ c.amount.num ≥ 0)
    (h_nodup : (s.cells.map (fun c => (c.domain, c.party, c.asset))).Nodup) :
    decodeState (stateToJson s) = .ok s := by
  cases s with | mk cells =>
  have h_cells : (cells.map stateCellToJson).mapM decodeStateCell = .ok cells := by
    apply list_mapM_decode_ok
    intro c hc
    have hc_valid := h_valid c hc
    exact decodeStateCell_stateCellToJson c hc_valid.1 hc_valid.2.1 hc_valid.2.2
  have h_def : decodeState (stateToJson ⟨cells⟩) = (do
      let arr ← Except.ok (cells.map stateCellToJson).toArray
      let c_dec ← arr.toList.mapM decodeStateCell
      let keys := c_dec.map (fun c => (c.domain, c.party, c.asset))
      if keys.length != keys.eraseDups.length then throw (.uniqueness "stateCell")
      .ok ⟨c_dec⟩) := rfl
  rw [h_def]
  change (do
      let c_dec ← (cells.map stateCellToJson).mapM decodeStateCell
      let keys := c_dec.map (fun c => (c.domain, c.party, c.asset))
      if keys.length != keys.eraseDups.length then throw (.uniqueness "stateCell")
      Except.ok (StateEnc.mk c_dec)) =
    (Except.ok (StateEnc.mk cells) : Except DecodeFailure StateEnc)
  rw [h_cells]
  dsimp [bind, Except.bind]
  have h_dup : (cells.map (fun c => (c.domain, c.party, c.asset))).eraseDups = cells.map (fun c => (c.domain, c.party, c.asset)) :=
    List.eraseDups_eq_of_nodup h_nodup
  rw [h_dup]
  have h_b : ((cells.map (fun c => (c.domain, c.party, c.asset))).length != (cells.map (fun c => (c.domain, c.party, c.asset))).length) = false := by
    rw [bne_iff_ne, Ne, not_not]
  rw [h_b]
  rfl

theorem decodeRequest_requestToJson (r : RequestEnc) (h_can : RequestCanonical r) :
    decodeRequest (requestToJson r) = .ok r := by
  cases r with | mk op parties args caps actor =>
  have h_parties : (parties.map partyToJson).mapM decodeParty = .ok parties := by
    apply list_mapM_decode_ok; intro p _; exact decodeParty_partyToJson p
  have h_args : (args.map packedValueFullToJson).mapM decodePackedValue = .ok args := by
    apply list_mapM_decode_ok; intro a ha; exact decodePackedValue_canonical a (h_can a ha)
  have h_caps : (caps.map (Lean.Json.num ·)).mapM (fun x => match x with | .num n => .ok n.mantissa.toNat | _ => .error (.jsonType "capabilityId")) = .ok caps := by
    induction caps with
    | nil => rfl
    | cons c cs ih =>
      dsimp [List.map, List.mapM]
      rw [ih]
      rfl
  have h_def : decodeRequest (requestToJson ⟨op, parties, args, caps, actor⟩) = (do
      let p_dec ← (parties.map partyToJson).mapM decodeParty
      let a_dec ← (args.map packedValueFullToJson).mapM decodePackedValue
      let c_dec ← (caps.map (Lean.Json.num ·)).mapM (fun x => match x with | .num n => .ok n.mantissa.toNat | _ => .error (.jsonType "capabilityId"))
      let ca_dec ← match actor with
        | none => .ok none
        | some p => (decodeParty (partyToJson p)).map some
      .ok ⟨op, p_dec, a_dec, c_dec, ca_dec⟩) := rfl
  rw [h_def, h_parties, h_args, h_caps]
  dsimp [bind, Except.bind]
  cases actor with
  | none => rfl
  | some p =>
    have hp := decodeParty_partyToJson p
    rw [hp]
    rfl

theorem decodeOperationInterface_operationInterfaceToJson (op : OperationInterfaceEnc) :
    decodeOperationInterface (operationInterfaceToJson op) = .ok op := by
  cases op with | mk op_num inputs outputs =>
  have h_in : (inputs.map inputPortToJson).mapM decodeInputPort = .ok inputs := by
    apply list_mapM_decode_ok; intro p _; exact decodeInputPort_inputPortToJson p
  have h_out : (outputs.map outputPortToJson).mapM decodeOutputPort = .ok outputs := by
    apply list_mapM_decode_ok; intro p _; exact decodeOutputPort_outputPortToJson p
  have h_def : decodeOperationInterface (operationInterfaceToJson ⟨op_num, inputs, outputs⟩) = (do
      let in_dec ← (inputs.map inputPortToJson).mapM decodeInputPort
      let out_dec ← (outputs.map outputPortToJson).mapM decodeOutputPort
      .ok ⟨op_num, in_dec, out_dec⟩) := rfl
  rw [h_def, h_in, h_out]
  rfl

theorem decodeComponent_componentToJson (c : ComponentEnc) :
    decodeComponent (componentToJson c) = .ok c := by
  cases c with | mk id priv exp imp ops =>
  have h_priv : (priv.map cellToJson).mapM decodeCell = .ok priv := by
    apply list_mapM_decode_ok; intro x _; exact decodeCell_cellToJson x
  have h_exp : (exp.map resourcePortToJson).mapM decodeResourcePort = .ok exp := by
    apply list_mapM_decode_ok; intro x _; exact decodeResourcePort_resourcePortToJson x
  have h_imp : (imp.map resourceImportToJson).mapM decodeResourceImport = .ok imp := by
    apply list_mapM_decode_ok; intro x _; exact decodeResourceImport_resourceImportToJson x
  have h_ops : (ops.map operationInterfaceToJson).mapM decodeOperationInterface = .ok ops := by
    apply list_mapM_decode_ok; intro x _; exact decodeOperationInterface_operationInterfaceToJson x
  have h_def : decodeComponent (componentToJson ⟨id, priv, exp, imp, ops⟩) = (do
      let priv_dec ← (priv.map cellToJson).mapM decodeCell
      let exp_dec ← (exp.map resourcePortToJson).mapM decodeResourcePort
      let imp_dec ← (imp.map resourceImportToJson).mapM decodeResourceImport
      let ops_dec ← (ops.map operationInterfaceToJson).mapM decodeOperationInterface
      .ok ⟨id, priv_dec, exp_dec, imp_dec, ops_dec⟩) := rfl
  rw [h_def, h_priv, h_exp, h_imp, h_ops]
  rfl

theorem decodeConfig_configToJson (cfg : ConfigEnc)
    (h_reg_nodup : (cfg.registry.entries.map (·.id)).Nodup)
    (h_reg_can : ∀ e ∈ cfg.registry.entries, TemplateCanonical e.template) :
    decodeConfig (configToJson cfg) = .ok cfg := by
  cases cfg with | mk reg da cat =>
  have h_reg := decodeRegistry_registryToJson reg h_reg_nodup h_reg_can
  have h_da : (da.map domainAdminToJson).mapM decodeDomainAdmin = .ok da := by
    apply list_mapM_decode_ok; intro x _; exact decodeDomainAdmin_domainAdminToJson x
  have h_cat : (cat.map componentToJson).mapM decodeComponent = .ok cat := by
    apply list_mapM_decode_ok; intro x _; exact decodeComponent_componentToJson x
  have h_def : decodeConfig (configToJson ⟨reg, da, cat⟩) = (do
      let reg_dec ← decodeRegistry (registryToJson reg)
      let da_dec ← (da.map domainAdminToJson).mapM decodeDomainAdmin
      let cat_dec ← (cat.map componentToJson).mapM decodeComponent
      .ok ⟨reg_dec, da_dec, cat_dec⟩) := rfl
  rw [h_def, h_reg, h_da, h_cat]
  rfl

theorem decodeWorld_worldToJson (w : WorldEnc)
    (h_state_valid : ∀ c ∈ w.state.cells, c.amount.den ≠ 0 ∧ Int.gcd c.amount.num.natAbs c.amount.den = 1 ∧ c.amount.num ≥ 0)
    (h_state_nodup : (w.state.cells.map (fun c => (c.domain, c.party, c.asset))).Nodup)
    (h_store_can : StoreCanonical w.capabilities) :
    decodeWorld (worldToJson w) = .ok w := by
  cases w with | mk st caps =>
  have h_st := decodeState_stateToJson st h_state_valid h_state_nodup
  have h_caps := decodeStore_storeToJson caps h_store_can
  have h_def : decodeWorld (worldToJson ⟨st, caps⟩) = (do
      let st_dec ← decodeState (stateToJson st)
      let caps_dec ← decodeStore (storeToJson caps)
      .ok ⟨st_dec, caps_dec⟩) := rfl
  rw [h_def, h_st, h_caps]
  rfl

theorem decodeBoundary_boundaryToJson (b : BoundaryEnc) (h_can : BoundaryCanonical b) :
    decodeBoundary (boundaryToJson b) = .ok b := by
  cases b with | mk ctx env now =>
  have h_ctx := decodeContext_contextToJson ctx
  have h_env := decodeEnvironment_environmentToJson env h_can
  have h_def : decodeBoundary (boundaryToJson ⟨ctx, env, now⟩) = (do
      let ctx_dec ← decodeContext (contextToJson ctx)
      let env_dec ← decodeEnvironment (environmentToJson env)
      .ok ⟨ctx_dec, env_dec, now⟩) := rfl
  rw [h_def, h_ctx, h_env]
  rfl

theorem decodeInputSource_inputSourceToJson (s : InputSourceEnc) (h_can : InputSourceCanonical s) :
    decodeInputSource (inputSourceToJson s) = .ok s := by
  cases s with
  | literal v =>
    have hv := decodePackedValue_canonical v h_can
    have h_def : decodeInputSource (inputSourceToJson (.literal v)) = (do
        let v_dec ← decodePackedValue (packedValueFullToJson v)
        .ok (.literal v_dec)) := rfl
    rw [h_def, hv]
    rfl
  | priorOutput step port =>
    cases port with | mk c p => rfl

theorem decodeInvocation_invocationToJson (inv : InvocationEnc) (h_can : InvocationCanonical inv) :
    decodeInvocation (invocationToJson inv) = .ok inv := by
  cases inv with | mk comp op parties inputs caps actor =>
  have h_parties : (parties.map partyToJson).mapM decodeParty = .ok parties := by
    apply list_mapM_decode_ok; intro p _; exact decodeParty_partyToJson p
  have h_inputs : (inputs.map inputSourceToJson).mapM decodeInputSource = .ok inputs := by
    apply list_mapM_decode_ok; intro i hi; exact decodeInputSource_inputSourceToJson i (h_can i hi)
  have h_caps : (caps.map (Lean.Json.num ·)).mapM (fun x => match x with | .num n => .ok n.mantissa.toNat | _ => .error (.jsonType "capabilityId")) = .ok caps := by
    induction caps with
    | nil => rfl
    | cons c cs ih =>
      dsimp [List.map, List.mapM]
      rw [ih]
      rfl
  have h_def : decodeInvocation (invocationToJson ⟨comp, op, parties, inputs, caps, actor⟩) = (do
      let p_dec ← (parties.map partyToJson).mapM decodeParty
      let in_dec ← (inputs.map inputSourceToJson).mapM decodeInputSource
      let c_dec ← (caps.map (Lean.Json.num ·)).mapM (fun x => match x with | .num n => .ok n.mantissa.toNat | _ => .error (.jsonType "capabilityId"))
      let ca_dec ← match actor with
        | none => .ok none
        | some p => (decodeParty (partyToJson p)).map some
      .ok ⟨comp, op, p_dec, in_dec, c_dec, ca_dec⟩) := rfl
  rw [h_def, h_parties, h_inputs, h_caps]
  dsimp [bind, Except.bind]
  cases actor with
  | none => rfl
  | some p =>
    have hp := decodeParty_partyToJson p
    rw [hp]
    rfl

set_option maxHeartbeats 1000000 in
theorem decodeStep_stepToJson (s : StepEnc) (h_can : StepCanonical s) :
    decodeStep (stepToJson s) = .ok s := by
  cases s with
  | invoke inv =>
    have h_inv := decodeInvocation_invocationToJson inv h_can
    have h_def : decodeStep (stepToJson (.invoke inv)) = (do
        let inv_dec ← decodeInvocation (invocationToJson inv)
        .ok (.invoke inv_dec)) := rfl
    rw [h_def, h_inv]
    rfl
  | issue grant =>
    have h_g := decodeGrant_grantToJson grant
    have h_def : decodeStep (stepToJson (.issue grant)) = (do
        let g_dec ← decodeGrant (grantToJson grant)
        .ok (.issue g_dec)) := rfl
    rw [h_def, h_g]
    rfl
  | revoke id =>
    rfl
  | unsupported _ =>
    contradiction

theorem decodeOutputObservation_outputObservationToJson (o : OutputObservationEnc) (h_can : PackedValueCanonical o.value) :
    decodeOutputObservation (outputObservationToJson o) = .ok o := by
  cases o with | mk step port val =>
  have h_val := decodePackedValue_canonical val h_can
  cases port with | mk c p =>
  have h_def : decodeOutputObservation (outputObservationToJson ⟨step, ⟨c, p⟩, val⟩) = (do
      let v_dec ← decodePackedValue (packedValueFullToJson val)
      .ok ⟨step, ⟨c, p⟩, v_dec⟩) := rfl
  rw [h_def, h_val]
  rfl

theorem decodeTypedExecutePayload_typedExecutePayloadToJson (p : TypedExecutePayloadEnc)
    (h_reg_nodup : (p.registry.entries.map (·.id)).Nodup)
    (h_reg_can : ∀ e ∈ p.registry.entries, TemplateCanonical e.template)
    (h_store_can : StoreCanonical p.store)
    (h_env_can : EnvironmentCanonical p.env)
    (h_req_can : RequestCanonical p.request)
    (h_state_valid : ∀ c ∈ p.state.cells, c.amount.den ≠ 0 ∧ Int.gcd c.amount.num.natAbs c.amount.den = 1 ∧ c.amount.num ≥ 0)
    (h_state_nodup : (p.state.cells.map (fun c => (c.domain, c.party, c.asset))).Nodup) :
    decodeTypedExecutePayload (typedExecutePayloadToJson p) = .ok p := by
  cases p with | mk reg store ctx env now req st =>
  have h_reg := decodeRegistry_registryToJson reg h_reg_nodup h_reg_can
  have h_store := decodeStore_storeToJson store h_store_can
  have h_ctx := decodeContext_contextToJson ctx
  have h_env := decodeEnvironment_environmentToJson env h_env_can
  have h_req := decodeRequest_requestToJson req h_req_can
  have h_st := decodeState_stateToJson st h_state_valid h_state_nodup
  have h_def : decodeTypedExecutePayload (typedExecutePayloadToJson ⟨reg, store, ctx, env, now, req, st⟩) = (do
      let reg_dec ← decodeRegistry (registryToJson reg)
      let store_dec ← decodeStore (storeToJson store)
      let ctx_dec ← decodeContext (contextToJson ctx)
      let env_dec ← decodeEnvironment (environmentToJson env)
      let req_dec ← decodeRequest (requestToJson req)
      let st_dec ← decodeState (stateToJson st)
      .ok ⟨reg_dec, store_dec, ctx_dec, env_dec, now, req_dec, st_dec⟩) := rfl
  rw [h_def, h_reg, h_store, h_ctx, h_env, h_req, h_st]
  rfl

theorem decodeCompositionStepPayload_compositionStepPayloadToJson (p : CompositionStepPayloadEnc)
    (h_cfg_nodup : (p.config.registry.entries.map (·.id)).Nodup)
    (h_cfg_can : ∀ e ∈ p.config.registry.entries, TemplateCanonical e.template)
    (h_bnd_can : BoundaryCanonical p.boundary)
    (h_hist_can : HistoryCanonical p.history)
    (h_step_can : StepCanonical p.step)
    (h_pre_valid : ∀ c ∈ p.pre.state.cells, c.amount.den ≠ 0 ∧ Int.gcd c.amount.num.natAbs c.amount.den = 1 ∧ c.amount.num ≥ 0)
    (h_pre_nodup : (p.pre.state.cells.map (fun c => (c.domain, c.party, c.asset))).Nodup)
    (h_pre_caps : StoreCanonical p.pre.capabilities) :
    decodeCompositionStepPayload (compositionStepPayloadToJson p) = .ok p := by
  cases p with | mk cfg bnd idx hist step pre =>
  have h_cfg := decodeConfig_configToJson cfg h_cfg_nodup h_cfg_can
  have h_bnd := decodeBoundary_boundaryToJson bnd h_bnd_can
  have h_hist : (hist.map outputObservationToJson).mapM decodeOutputObservation = .ok hist := by
    apply list_mapM_decode_ok; intro o ho; exact decodeOutputObservation_outputObservationToJson o (h_hist_can o ho)
  have h_step := decodeStep_stepToJson step h_step_can
  have h_pre := decodeWorld_worldToJson pre h_pre_valid h_pre_nodup h_pre_caps
  have h_def : decodeCompositionStepPayload (compositionStepPayloadToJson ⟨cfg, bnd, idx, hist, step, pre⟩) = (do
      let cfg_dec ← decodeConfig (configToJson cfg)
      let bnd_dec ← decodeBoundary (boundaryToJson bnd)
      let hist_dec ← (hist.map outputObservationToJson).mapM decodeOutputObservation
      let step_dec ← decodeStep (stepToJson step)
      let pre_dec ← decodeWorld (worldToJson pre)
      .ok ⟨cfg_dec, bnd_dec, idx, hist_dec, step_dec, pre_dec⟩) := rfl
  rw [h_def, h_cfg, h_bnd, h_hist, h_step, h_pre]
  rfl

theorem decodeCompositionRunPayload_compositionRunPayloadToJson (p : CompositionRunPayloadEnc)
    (h_cfg_nodup : (p.config.registry.entries.map (·.id)).Nodup)
    (h_cfg_can : ∀ e ∈ p.config.registry.entries, TemplateCanonical e.template)
    (h_bnds_can : ∀ b ∈ p.boundaries, BoundaryCanonical b)
    (h_steps_can : ∀ s ∈ p.steps, StepCanonical s)
    (h_w_valid : ∀ c ∈ p.world.state.cells, c.amount.den ≠ 0 ∧ Int.gcd c.amount.num.natAbs c.amount.den = 1 ∧ c.amount.num ≥ 0)
    (h_w_nodup : (p.world.state.cells.map (fun c => (c.domain, c.party, c.asset))).Nodup)
    (h_w_caps : StoreCanonical p.world.capabilities) :
    decodeCompositionRunPayload (compositionRunPayloadToJson p) = .ok p := by
  cases p with | mk cfg bnds world steps =>
  have h_cfg := decodeConfig_configToJson cfg h_cfg_nodup h_cfg_can
  have h_bnds : (bnds.map boundaryToJson).mapM decodeBoundary = .ok bnds := by
    apply list_mapM_decode_ok; intro b hb; exact decodeBoundary_boundaryToJson b (h_bnds_can b hb)
  have h_world := decodeWorld_worldToJson world h_w_valid h_w_nodup h_w_caps
  have h_steps : (steps.map stepToJson).mapM decodeStep = .ok steps := by
    apply list_mapM_decode_ok; intro s hs; exact decodeStep_stepToJson s (h_steps_can s hs)
  have h_def : decodeCompositionRunPayload (compositionRunPayloadToJson ⟨cfg, bnds, world, steps⟩) = (do
      let cfg_dec ← decodeConfig (configToJson cfg)
      let bnds_dec ← (bnds.map boundaryToJson).mapM decodeBoundary
      let world_dec ← decodeWorld (worldToJson world)
      let steps_dec ← (steps.map stepToJson).mapM decodeStep
      .ok ⟨cfg_dec, bnds_dec, world_dec, steps_dec⟩) := rfl
  rw [h_def, h_cfg, h_bnds, h_world, h_steps]
  rfl

end DefiKernel.Certificates
