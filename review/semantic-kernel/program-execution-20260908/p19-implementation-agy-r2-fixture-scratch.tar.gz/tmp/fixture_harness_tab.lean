
import DefiKernel.Certificates.Schema
import DefiKernel.Certificates.Decode
import DefiKernel.Certificates.Check
import DefiKernel.Certificates.Observation

open DefiKernel.Certificates

def main (args : List String) : IO Unit := do
  let mode := args[0]!
  let path := args[1]!
  let content ← IO.FS.readBinFile path
  if mode == "decode" then
    match decodeBytes content with
    | .ok ir =>
      let modeStr := match ir with
        | .execution (.typed _ _) => "typed-execute"
        | .execution (.step _ _) => "composition-step"
        | .execution (.run _ _) => "composition-run"
        | .audit _ => "audit"
        | .codec _ => "codec"
      IO.println s!"RESULT\tdecode\tok\t{modeStr}"
    | .error e =>
      IO.println s!"RESULT\tdecode\terror\t{repr e}"
  else if mode == "check" then
    match checkBytes content with
    | .codec res =>
      match res with
      | .ok _ => IO.println "RESULT\tcodec\tok"
      | .malformed f => IO.println s!"RESULT\tcodec\tmalformed\t{repr f}"
      | .blocked b => IO.println s!"RESULT\tcodec\tblocked\t{b}"
    | .execution rep =>
      let stStr := match rep.status with | .accepted => "accepted" | .refused => "refused" | .incomplete => "incomplete"
      let (fClass, fCtor, fPayload) := match rep.failure with
        | none => ("none", "none", "")
        | some fp => (s!"{repr fp.class}", fp.ctor, fp.payload.getD "")
      IO.println s!"RESULT\texecution\t{stStr}\t{fClass}\t{fCtor}\t{fPayload}\t{rep.world.state.cells.length}\t{rep.world.capabilities.entries.length}\t{rep.outputs.length}\t{rep.events.length}\t{rep.nextIndex}"
    | .audit res =>
      let stStr := match res.status with | .passed => "passed" | .failed => "failed" | .blocked => "blocked"
      IO.println s!"RESULT\taudit\t{stStr}"
