
import Lean

theorem string_fromUTF8?_toUTF8 (s : String) : String.fromUTF8? s.toUTF8 = some s := by
  dsimp [String.fromUTF8?, String.toUTF8]
  have h : s.toByteArray.IsValidUTF8 := s.isValidUTF8
  rw [dif_pos h]
  rfl
