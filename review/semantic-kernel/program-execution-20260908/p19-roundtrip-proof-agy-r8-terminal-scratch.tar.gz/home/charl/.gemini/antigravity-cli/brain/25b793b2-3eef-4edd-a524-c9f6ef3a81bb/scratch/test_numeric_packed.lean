import DefiKernel.Certificates.Schema
import DefiKernel.Certificates.Decode
import DefiKernel.Certificates.Correspondence

open DefiKernel.Certificates

theorem decodePackedValue_scalar_val (v : Nat) :
    decodePackedValue (Lean.Json.mkObj [
      ("unit", Lean.Json.mkObj [("tag", Lean.Json.str "scalar")]),
      ("value", Lean.Json.mkObj [("num", Lean.Json.num v), ("den", Lean.Json.num 1)])
    ]) = .ok ⟨.numeric .scalar, (RatEnc.mk (v : Int) 1).toRat, false⟩ := by
  have h_step : decodePackedValue (Lean.Json.mkObj [
      ("unit", Lean.Json.mkObj [("tag", Lean.Json.str "scalar")]),
      ("value", Lean.Json.mkObj [("num", Lean.Json.num v), ("den", Lean.Json.num 1)])
    ]) = (decodeRational (v : Int) 1 >>= fun (r : RatEnc) ↦ .ok ⟨.numeric .scalar, r.toRat, false⟩) := rfl
  have h_dec : decodeRational (v : Int) 1 = .ok ⟨(v : Int), 1⟩ := by
    apply rational_decode_canonical
    · decide
    · simp
  rw [h_step, h_dec]
  rfl

theorem decodePackedValue_amount_val (a : Asset) (v : Nat) :
    decodePackedValue (Lean.Json.mkObj [
      ("unit", Lean.Json.mkObj [
        ("tag", Lean.Json.str "amount"),
        ("asset", Lean.Json.str (match a with | .usd => "usd" | .share => "share" | .collateral => "collateral" | .debt => "debt"))
      ]),
      ("value", Lean.Json.mkObj [("num", Lean.Json.num v), ("den", Lean.Json.num 1)])
    ]) = .ok ⟨.numeric (.amount a), (RatEnc.mk (v : Int) 1).toRat, false⟩ := by
  have h_dec : decodeRational (v : Int) 1 = .ok ⟨(v : Int), 1⟩ := by
    apply rational_decode_canonical
    · decide
    · simp
  cases a with
  | usd =>
    have h_step : decodePackedValue (Lean.Json.mkObj [
        ("unit", Lean.Json.mkObj [("tag", Lean.Json.str "amount"), ("asset", Lean.Json.str "usd")]),
        ("value", Lean.Json.mkObj [("num", Lean.Json.num v), ("den", Lean.Json.num 1)])
      ]) = (decodeRational (v : Int) 1 >>= fun (r : RatEnc) ↦ .ok ⟨.numeric (.amount .usd), r.toRat, false⟩) := rfl
    rw [h_step, h_dec]
    rfl
  | share =>
    have h_step : decodePackedValue (Lean.Json.mkObj [
        ("unit", Lean.Json.mkObj [("tag", Lean.Json.str "amount"), ("asset", Lean.Json.str "share")]),
        ("value", Lean.Json.mkObj [("num", Lean.Json.num v), ("den", Lean.Json.num 1)])
      ]) = (decodeRational (v : Int) 1 >>= fun (r : RatEnc) ↦ .ok ⟨.numeric (.amount .share), r.toRat, false⟩) := rfl
    rw [h_step, h_dec]
    rfl
  | collateral =>
    have h_step : decodePackedValue (Lean.Json.mkObj [
        ("unit", Lean.Json.mkObj [("tag", Lean.Json.str "amount"), ("asset", Lean.Json.str "collateral")]),
        ("value", Lean.Json.mkObj [("num", Lean.Json.num v), ("den", Lean.Json.num 1)])
      ]) = (decodeRational (v : Int) 1 >>= fun (r : RatEnc) ↦ .ok ⟨.numeric (.amount .collateral), r.toRat, false⟩) := rfl
    rw [h_step, h_dec]
    rfl
  | debt =>
    have h_step : decodePackedValue (Lean.Json.mkObj [
        ("unit", Lean.Json.mkObj [("tag", Lean.Json.str "amount"), ("asset", Lean.Json.str "debt")]),
        ("value", Lean.Json.mkObj [("num", Lean.Json.num v), ("den", Lean.Json.num 1)])
      ]) = (decodeRational (v : Int) 1 >>= fun (r : RatEnc) ↦ .ok ⟨.numeric (.amount .debt), r.toRat, false⟩) := rfl
    rw [h_step, h_dec]
    rfl
