import Lean

def hexDigit (n : Nat) : Char :=
  if n = 0 then '0'
  else if n = 1 then '1'
  else if n = 2 then '2'
  else if n = 3 then '3'
  else if n = 4 then '4'
  else if n = 5 then '5'
  else if n = 6 then '6'
  else if n = 7 then '7'
  else if n = 8 then '8'
  else if n = 9 then '9'
  else if n = 10 then 'a'
  else if n = 11 then 'b'
  else if n = 12 then 'c'
  else if n = 13 then 'd'
  else if n = 14 then 'e'
  else 'f'

def hexVal (c : Char) : Option Nat :=
  if c >= '0' && c <= '9' then some (c.toNat - '0'.toNat)
  else if c >= 'a' && c <= 'f' then some (c.toNat - 'a'.toNat + 10)
  else if c >= 'A' && c <= 'F' then some (c.toNat - 'A'.toNat + 10)
  else none

def lexString (acc : List Char) : List Char -> Except String (String × List Char)
  | [] => .error "unterminated string"
  | '"' :: rest => .ok (String.ofList acc.reverse, rest)
  | '\\' :: 'u' :: h1 :: h2 :: h3 :: h4 :: rest =>
    match hexVal h1, hexVal h2, hexVal h3, hexVal h4 with
    | some v1, some v2, some v3, some v4 =>
      let val := ((v1 * 16 + v2) * 16 + v3) * 16 + v4
      if val < 0x110000 && !(0xd800 <= val && val < 0xe000) then
        lexString (Char.ofNat val :: acc) rest
      else .error "invalid unicode codepoint"
    | _, _, _, _ => .error "invalid hex in unicode escape"
  | '\\' :: '"' :: rest => lexString ('"' :: acc) rest
  | '\\' :: '\\' :: rest => lexString ('\\' :: acc) rest
  | '\\' :: '/' :: rest => lexString ('/' :: acc) rest
  | '\\' :: 'b' :: rest => lexString ('\x08' :: acc) rest
  | '\\' :: 'f' :: rest => lexString ('\x0c' :: acc) rest
  | '\\' :: 'n' :: rest => lexString ('\n' :: acc) rest
  | '\\' :: 'r' :: rest => lexString ('\x0d' :: acc) rest
  | '\\' :: 't' :: rest => lexString ('\t' :: acc) rest
  | '\\' :: _ => .error "unknown escape"
  | c :: rest =>
    if c.toNat < 32 then .error "unescaped control character"
    else lexString (c :: acc) rest

theorem hexVal_hexDigit (n : Nat) (h : n < 16) : hexVal (hexDigit n) = some n := by
  match n, h with
  | 0, _ => rfl
  | 1, _ => rfl
  | 2, _ => rfl
  | 3, _ => rfl
  | 4, _ => rfl
  | 5, _ => rfl
  | 6, _ => rfl
  | 7, _ => rfl
  | 8, _ => rfl
  | 9, _ => rfl
  | 10, _ => rfl
  | 11, _ => rfl
  | 12, _ => rfl
  | 13, _ => rfl
  | 14, _ => rfl
  | 15, _ => rfl
  | _ + 16, h => omega

theorem bool_cond_of_lt32 (n : Nat) (h : n < 32) :
    (decide (n < 1114112) && !(decide (55296 ≤ n) && decide (n < 57344))) = true := by
  have h1 : n < 1114112 := by omega
  have h2 : ¬ (55296 ≤ n) := by omega
  rw [decide_eq_true h1, decide_eq_false h2]
  rfl

theorem lexString_u00 (c : Char) (h_lt : c.toNat < 32) (acc rest : List Char) :
    lexString acc ('\\' :: 'u' :: '0' :: '0' :: hexDigit (c.toNat / 16) :: hexDigit (c.toNat % 16) :: rest) =
      lexString (c :: acc) rest := by
  change (match hexVal '0', hexVal '0', hexVal (hexDigit (c.toNat / 16)), hexVal (hexDigit (c.toNat % 16)) with
    | some v1, some v2, some v3, some v4 =>
      let val := ((v1 * 16 + v2) * 16 + v3) * 16 + v4
      if val < 0x110000 && !(0xd800 <= val && val < 0xe000) then
        lexString (Char.ofNat val :: acc) rest
      else .error "invalid unicode codepoint"
    | _, _, _, _ => .error "invalid hex in unicode escape") = lexString (c :: acc) rest
  have h1 : hexVal '0' = some 0 := rfl
  have h3 : hexVal (hexDigit (c.toNat / 16)) = some (c.toNat / 16) := by
    apply hexVal_hexDigit; omega
  have h4 : hexVal (hexDigit (c.toNat % 16)) = some (c.toNat % 16) := by
    apply hexVal_hexDigit; omega
  rw [h1, h3, h4]
  dsimp
  have h_val : ((0 * 16 + 0) * 16 + c.toNat / 16) * 16 + c.toNat % 16 = c.toNat := by
    omega
  rw [h_val]
  have hb := bool_cond_of_lt32 c.toNat h_lt
  rw [hb]
  dsimp
  rw [Char.ofNat_toNat]


theorem lexString_normal (c : Char) (h_q : c ≠ '"') (h_s : c ≠ '\\') (h_ge : ¬ (c.toNat < 32))
    (acc rest : List Char) :
    lexString acc (c :: rest) = lexString (c :: acc) rest := by
  have h_cases : (c :: rest) = match c :: rest with
    | [] => []
    | x :: xs => x :: xs := rfl
  rw [lexString]
  split
  · rename_i h_eq; injection h_eq with hc _; subst hc; contradiction
  · rename_i h_eq; injection h_eq with hc _; subst hc; contradiction
  · rename_i h_eq; injection h_eq with hc _; subst hc; contradiction
  · rename_i h_eq; injection h_eq with hc _; subst hc; contradiction
  · rename_i h_eq; injection h_eq with hc _; subst hc; contradiction
  · rename_i h_eq; injection h_eq with hc _; subst hc; contradiction
  · rename_i h_eq; injection h_eq with hc _; subst hc; contradiction
  · rename_i h_eq; injection h_eq with hc _; subst hc; contradiction
  · rename_i h_eq; injection h_eq with hc _; subst hc; contradiction
  · rename_i h_eq; injection h_eq with hc _; subst hc; contradiction
  · rename_i h_eq; injection h_eq with hc _; subst hc; contradiction
  · rename_i h_eq; injection h_eq with hc _; subst hc; contradiction
  · split
    · contradiction
    · rfl

