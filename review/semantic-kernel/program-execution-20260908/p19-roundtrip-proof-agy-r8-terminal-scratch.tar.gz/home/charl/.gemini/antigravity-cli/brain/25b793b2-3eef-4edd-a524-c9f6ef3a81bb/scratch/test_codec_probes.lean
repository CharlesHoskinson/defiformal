import Lean

def hexDigit (n : Nat) : Char :=
  if n = 0 then '0'
  else if n = 1 then '1'
  else if n = 2 then '2'
  else if n = 3 then '3'
  else if n = 4 then '4'
  else if n = 5 then '5'
  else if n = 6 then '6'
  else if n = 7 then '7'
  else if n = 8 then '8'
  else if n = 9 then '9'
  else if n = 10 then 'a'
  else if n = 11 then 'b'
  else if n = 12 then 'c'
  else if n = 13 then 'd'
  else if n = 14 then 'e'
  else 'f'

def hexVal (c : Char) : Option Nat :=
  if c >= '0' && c <= '9' then some (c.toNat - '0'.toNat)
  else if c >= 'a' && c <= 'f' then some (c.toNat - 'a'.toNat + 10)
  else if c >= 'A' && c <= 'F' then some (c.toNat - 'A'.toNat + 10)
  else none

def escapeChar (c : Char) : List Char :=
  if c = '"' then ['\\', '"']
  else if c = '\\' then ['\\', '\\']
  else if c.toNat < 32 then
    ['\\', 'u', '0', '0', hexDigit (c.toNat / 16), hexDigit (c.toNat % 16)]
  else [c]

def escapeChars : List Char -> List Char
  | [] => []
  | c :: cs => escapeChar c ++ escapeChars cs

def escapeJsonString (s : String) : String :=
  String.ofList ('"' :: (escapeChars s.toList ++ ['"']))

def lexString (acc : List Char) : List Char -> Except String (String × List Char)
  | [] => .error "unterminated string"
  | '"' :: rest => .ok (String.ofList acc.reverse, rest)
  | '\\' :: 'u' :: h1 :: h2 :: h3 :: h4 :: rest =>
    match hexVal h1, hexVal h2, hexVal h3, hexVal h4 with
    | some v1, some v2, some v3, some v4 =>
      let val := ((v1 * 16 + v2) * 16 + v3) * 16 + v4
      if val < 0x110000 && !(0xd800 <= val && val < 0xe000) then
        lexString (Char.ofNat val :: acc) rest
      else
        .error "invalid unicode codepoint"
    | _, _, _, _ => .error "invalid hex in unicode escape"
  | '\\' :: '"' :: rest => lexString ('"' :: acc) rest
  | '\\' :: '\\' :: rest => lexString ('\\' :: acc) rest
  | '\\' :: '/' :: rest => lexString ('/' :: acc) rest
  | '\\' :: 'b' :: rest => lexString ('\x08' :: acc) rest
  | '\\' :: 'f' :: rest => lexString ('\x0c' :: acc) rest
  | '\\' :: 'n' :: rest => lexString ('\n' :: acc) rest
  | '\\' :: 'r' :: rest => lexString ('\r' :: acc) rest
  | '\\' :: 't' :: rest => lexString ('\t' :: acc) rest
  | '\\' :: _ => .error "unknown escape"
  | c :: rest =>
    if c.toNat < 32 then .error "unescaped control character"
    else lexString (c :: acc) rest

def parserStringMatches (raw expected : String) : Bool :=
  match raw.toList with
  | '"' :: rest =>
    match lexString [] rest with
    | .ok (actual, []) => actual == expected
    | _ => false
  | _ => false

#eval parserStringMatches "\"plain\"" "plain"
#eval parserStringMatches "\"\\\"\"" "\""
#eval parserStringMatches "\"\\u000a\"" "\n"
#eval parserStringMatches "\"\\u0000\"" (String.singleton (Char.ofNat 0))
#eval parserStringMatches "\"\\u001f\"" (String.singleton (Char.ofNat 31))

#eval match lexString [] ['\n', '"'] with | .error _ => true | .ok _ => false
#eval match lexString [] ['\\', 'q', '"'] with | .error _ => true | .ok _ => false

#eval escapeJsonString "plain" == "\"plain\""
#eval escapeJsonString "\n" == "\"\\u000a\""
#eval escapeJsonString (String.singleton (Char.ofNat 0)) == "\"\\u0000\""
#eval match Lean.Json.parse (escapeJsonString (String.singleton (Char.ofNat 0))) with
  | .ok _ => true
  | .error _ => false

-- Theorem: lexString inverts escapeChars on any list of characters
theorem lexString_escapeChars (cs : List Char) (acc rest : List Char) :
    lexString acc (escapeChars cs ++ ('"' :: rest)) = .ok (String.ofList (acc.reverse ++ cs), rest) := by
  induction cs generalizing acc with
  | nil =>
    simp [escapeChars, lexString]
  | cons c cs ih =>
    simp only [escapeChars, List.append_assoc]
    dsimp [escapeChar]
    split
    · -- c = '"'
      rename_i hc
      subst hc
      dsimp [lexString]
      have := ih ('"' :: acc)
      simp only [List.reverse_cons, List.append_assoc, List.singleton_append] at this
      exact this
    · split
      · -- c = '\\'
        rename_i _ hc
        subst hc
        dsimp [lexString]
        have := ih ('\\' :: acc)
        simp only [List.reverse_cons, List.append_assoc, List.singleton_append] at this
        exact this
      · split
        · -- c.toNat < 32
          rename_i _ _ h_lt
          -- escapeChar emits ['\\', 'u', '0', '0', hexDigit (c.toNat / 16), hexDigit (c.toNat % 16)]
          sorry
        · -- normal char
          sorry

