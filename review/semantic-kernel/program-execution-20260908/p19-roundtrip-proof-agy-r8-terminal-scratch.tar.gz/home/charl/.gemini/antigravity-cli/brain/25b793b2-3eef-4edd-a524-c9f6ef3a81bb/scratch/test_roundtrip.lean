import DefiKernel.Certificates.Correspondence

namespace DefiKernel.Certificates

set_option maxRecDepth 200000
set_option maxHeartbeats 2000000

theorem canonicalWitnessIR_roundtrip : decodeBytes (encodeModule canonicalWitnessIR) = .ok canonicalWitnessIR := by
  decide

end DefiKernel.Certificates
