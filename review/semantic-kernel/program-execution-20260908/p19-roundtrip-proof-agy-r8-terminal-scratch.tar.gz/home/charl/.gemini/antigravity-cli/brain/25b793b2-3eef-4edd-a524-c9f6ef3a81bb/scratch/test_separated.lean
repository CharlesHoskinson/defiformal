import Lean

def hexDigit (n : Nat) : Char :=
  if n = 0 then '0'
  else if n = 1 then '1'
  else if n = 2 then '2'
  else if n = 3 then '3'
  else if n = 4 then '4'
  else if n = 5 then '5'
  else if n = 6 then '6'
  else if n = 7 then '7'
  else if n = 8 then '8'
  else if n = 9 then '9'
  else if n = 10 then 'a'
  else if n = 11 then 'b'
  else if n = 12 then 'c'
  else if n = 13 then 'd'
  else if n = 14 then 'e'
  else 'f'

def hexVal (c : Char) : Option Nat :=
  if c >= '0' && c <= '9' then some (c.toNat - '0'.toNat)
  else if c >= 'a' && c <= 'f' then some (c.toNat - 'a'.toNat + 10)
  else if c >= 'A' && c <= 'F' then some (c.toNat - 'A'.toNat + 10)
  else none

mutual
def lexEscape (acc : List Char) : List Char -> Except String (String × List Char)
  | 'u' :: h1 :: h2 :: h3 :: h4 :: rest =>
    match hexVal h1, hexVal h2, hexVal h3, hexVal h4 with
    | some v1, some v2, some v3, some v4 =>
      let val := ((v1 * 16 + v2) * 16 + v3) * 16 + v4
      if val < 0x110000 && !(0xd800 <= val && val < 0xe000) then
        lexString (Char.ofNat val :: acc) rest
      else .error "invalid unicode codepoint"
    | _, _, _, _ => .error "invalid hex in unicode escape"
  | '"' :: rest => lexString ('"' :: acc) rest
  | '\\' :: rest => lexString ('\\' :: acc) rest
  | '/' :: rest => lexString ('/' :: acc) rest
  | 'b' :: rest => lexString ('\x08' :: acc) rest
  | 'f' :: rest => lexString ('\x0c' :: acc) rest
  | 'n' :: rest => lexString ('\n' :: acc) rest
  | 'r' :: rest => lexString ('\x0d' :: acc) rest
  | 't' :: rest => lexString ('\t' :: acc) rest
  | _ => .error "unknown escape"

def lexString (acc : List Char) : List Char -> Except String (String × List Char)
  | [] => .error "unterminated string"
  | '"' :: rest => .ok (String.ofList acc.reverse, rest)
  | '\\' :: rest => lexEscape acc rest
  | c :: rest =>
    if c.toNat < 32 then .error "unescaped control character"
    else lexString (c :: acc) rest
end

theorem lexString_quote (acc rest : List Char) :
    lexString acc ('\\' :: '"' :: rest) = lexString ('"' :: acc) rest := by
  rfl

theorem lexString_slash (acc rest : List Char) :
    lexString acc ('\\' :: '\\' :: rest) = lexString ('\\' :: acc) rest := by
  rfl


theorem hexVal_hexDigit_of_lt_16 (n : Nat) (h : n < 16) :
    hexVal (hexDigit n) = some n := by
  interval_cases n <;> rfl

theorem hexDigit_div16_of_lt_32 (c : Nat) (h : c < 32) :
    c / 16 < 16 := by
  omega

theorem hexDigit_mod16_of_lt_32 (c : Nat) (h : c < 32) :
    c % 16 < 16 := by
  omega

