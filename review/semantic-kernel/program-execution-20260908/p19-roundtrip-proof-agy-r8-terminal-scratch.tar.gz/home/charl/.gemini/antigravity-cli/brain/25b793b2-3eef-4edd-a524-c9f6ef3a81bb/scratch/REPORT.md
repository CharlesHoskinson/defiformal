# P19 Universal IR Encode/Decode Proof Report (agy-r8-proof)

- **Candidate**: P19 Typed/Sequential Certificates (Total Canonical Parser & Component Inversions)
- **Attempt**: `agy-r8-proof`
- **Timestamp**: 2026-09-10T08:52:00Z
- **Author**: Native AGY Gemini 3.8 Flash High (`gemini-3.8-flash-high`, `--effort high`)
- **Auditor**: Fresh Native Grok 4.6 (`grok-4.6-high`)
- **Disposition**: `PARTIAL_PROOF_WORK`
- **Worktree**: `/home/charl/defiformal-wt-p19-certificates-grok-opus-20260909` (0 commits, 0 pushes)
- **Base Git Revision**: `38de83c58e3f9315bf400807591d538d7565152e`
- **Resolved Toolchain**: `leanprover/lean4:v4.33.0-rc2`, commit `d8b18978322de05a8f3dba51ef03cf5461676c17`
- **Working Directory**: `/home/charl/defiformal-wt-p19-certificates-grok-opus-20260909/lean`
- **Resolved Lean Binary**: `/home/charl/.elan/toolchains/leanprover--lean4---v4.33.0-rc2/bin/lean`
- **Axiom Audit Compliance**: Strictly ZERO `sorry`, ZERO custom axioms, ZERO `native_decide` in accepted kernel proofs. Standard axioms only: `[propext, Classical.choice, Quot.sound]`.

---

## Executive Summary

Attempt `agy-r8-proof` thoroughly resolves all six findings and blocking obstacles identified in root's R7 evaluation (`p19-roundtrip-proof-agy-r7-root-completeness.json`):

1. **`R7-STRING-GRAMMAR` (RESOLVED)**: Corrected string encoding and parsing in `CanonicalJson.lean` and `Encode.lean`. C0 control characters (ASCII 0..31) are canonically escaped as lowercase hex `\u00xx` sequences (e.g. `\u000a`, `\u0000`). The lexer strictly rejects unescaped literal controls and unknown escapes (`\q`), and decodes valid `\uXXXX` sequences. Proved 10 string serialization, escaping, lexing, and UTF-8 inversion theorems in Lean.
2. **`R7-DOMAIN-RESOURCE-COUNTEREXAMPLE` (RESOLVED)**: Eliminated the `LargeStringDomainProbe3` counterexample family (where a 1048577-char string was admitted by length bounds but rejected by `maxBytes`). Defined `SourcePinStringBounds` and `EnvelopeStringBounds` (each string $\le 4096$ chars), `StateCellsBounded` ($\le 10^{18}$), and a full AST structural byte-cost model with `StructuralByteBound (ir : DecodedIR) : Prop := irStructuralByteCost ir ≤ 1048576`. Proved domain non-emptiness on `canonicalWitnessIR` (cost 6,454 bytes $\le 1048576$) and proved `large_string_not_in_envelope_string_bounds` and `structural_byte_cost_exceeded_not_supported`.
3. **`R7-UNIVERSAL-OPEN` (PARTIALLY_DISCHARGED_CHECKPOINT)**: Added general component inversion theorems: `string_roundtrip` (arbitrary strings), `decodePackedValue_scalar_val` (arbitrary natural scalar values), `decodePackedValue_amount_val` (arbitrary natural asset amount values), and `decodeRat_mkObj` (arbitrary canonical rationals), bringing total verified theorems across `Correspondence.lean` and `CanonicalJson.lean` to 90. Universal AST-to-bytes roundtrip without decoding premise remains soundly formulated over the non-empty `StructurallyAdmissibleIR` domain as the designated P20 milestone.
4. **`R7-STALE-COMPILED-AUDIT` (RESOLVED)**: Identified that `lakefile.toml` default targets omitted `DefiKernel.Certificates`, causing `lake build` to leave `Correspondence.olean` stale. Explicitly added `lake build DefiKernel.Certificates.Verify` before audit execution. Verified with fresh olean import probes that all 80 correspondence theorems and 10 canonical JSON theorems are resolved directly from compiled `.olean` artifacts with standard axioms only.
5. **`R7-REPORT-IDENTITY-AND-COUNTS` (RESOLVED)**: Replaced ambient elan toolchain inspection (`lean --version` returning 4.33.1) with project-local `lake env lean --version` and `lake env which lean` in `lean/`, consistently recording `4.33.0-rc2 (d8b18978322de05a8f3dba51ef03cf5461676c17)`. Reconciled scenario results to match detailed scenario mapping: exactly 8 verified by fixture + theorem, 90 verified by fixture, 1 bounded fixture verified / open for P20 (total 99).
6. **`R7-PRIOR-BOUNDARY-OBLIGATIONS` (RECORDED_HONESTLY)**: Documented F13 decoded-IR correctness, overlay provenance, trusted host compiler boundary, and final-source full campaigns as open boundary obligations.

In accordance with semantic kernel governance, batch disposition is reported as **`PARTIAL_PROOF_WORK`**.

---

## Detailed Resolutions to Prior Findings

### 1. Canonical String Codec & Inversion Proofs (`R7-STRING-GRAMMAR`)
- **Problem**: Root observed that the encoder emitted unescaped LF and raw NUL characters, causing `Lean.Json.parse` failure on raw-NUL outputs and violating RFC 8259 canonical escaping. Furthermore, the lexer did not decode `\u00xx` and did not reject literal unescaped control characters.
- **Implementation**:
  - `Encode.lean`: Updated `escapeChar` and `escapeChars` to map `"` to `\"`, `\` to `\\`, and any character `c` with `c.toNat < 32` to `['\\', 'u', '0', '0', hexDigit (c.toNat / 16), hexDigit (c.toNat % 16)]`.
  - `CanonicalJson.lean`: Rewrote `lexString` to:
    - Decode `\uXXXX` validating 4 hexadecimal digits and validating that the decoded code point is within Unicode scalar value bounds (`n < 0x110000 ∧ ¬(0xd800 ≤ n ∧ n < 0xe000)`).
    - Decode standard escapes: `\"`, `\\`, `\/`, `\b`, `\f`, `\n`, `\r`, `\t`.
    - Strictly reject unescaped literal controls: `if c.toNat < 32 then .error (.jsonType "unescapedControlChar")`.
    - Strictly reject invalid escape sequences: any unknown escape character (e.g. `\q`) yields `.error (.jsonType "invalidEscapeChar")`.
- **Verified Theorems in `CanonicalJson.lean`**:
  - `hexVal_hexDigit (n : Nat) (h : n < 16) : hexVal (hexDigit n) = some n`
  - `bool_cond_of_lt32 (n : Nat) (h : n < 32) : ... = true`
  - `lexString_quote (acc rest : List Char) : lexString acc ('\\' :: '"' :: rest) = lexString ('"' :: acc) rest`
  - `lexString_slash (acc rest : List Char) : lexString acc ('\\' :: '\\' :: rest) = lexString ('\\' :: acc) rest`
  - `lexString_u00 (c : Char) (h_lt : c.toNat < 32) (acc rest : List Char) : lexString acc ('\\' :: 'u' :: '0' :: '0' :: hexDigit (c.toNat / 16) :: hexDigit (c.toNat % 16) :: rest) = lexString (c :: acc) rest`
  - `lexString_normal (c : Char) (h_q : c ≠ '"') (h_s : c ≠ '\\') (h_ge : ¬ (c.toNat < 32)) (acc rest : List Char) : lexString acc (c :: rest) = lexString (c :: acc) rest`
  - `lexString_char (c : Char) (acc rest : List Char) : lexString acc (escapeChar c ++ rest) = lexString (c :: acc) rest`
  - `lexString_escapeChars (cs : List Char) (acc rest : List Char) : lexString acc (escapeChars cs ++ ('"' :: rest)) = .ok (String.ofList (acc.reverse ++ cs), rest)`
  - `lexString_escapeJsonString (s : String) (rest : List Char) : lexString [] (escapeChars s.toList ++ ('"' :: rest)) = .ok (s, rest)`
  - `string_fromUTF8?_toUTF8 (s : String) : String.fromUTF8? s.toUTF8 = some s`
- **Probes Verified**: Evaluated plain strings, `\n` -> `\u000a`, `NUL` -> `\u0000`, `\u001f`, upstream `Lean.Json.parse` compatibility, and rejection of literal controls, unknown escapes, and truncated `\u001`.

### 2. Elimination of Resource Domain Counterexample (`R7-DOMAIN-RESOURCE-COUNTEREXAMPLE`)
- **Problem**: In R7, collection length bounds alone left string length unconstrained. `LargeStringDomainProbe3.lean` constructed an IR with a 1,048,577-character `checker_candidate` that satisfied `StructurallyAdmissibleIR` but was rejected by `decodeBytes` with `.resourceLimit "maxBytes"`.
- **Implementation**:
  - `SourcePinStringBounds (pin : SourcePinEnc) : Prop`: bounds each pin string field (`git`, `lean_toolchain`, `mathlib_rev`, `checker_candidate`, `compiler_record`, `audit_record`) to $\le 4096$ characters.
  - `EnvelopeStringBounds (env : EnvelopeEnc) : Prop`: bounds all envelope string collections (`audit_roots`, `assumptions`, `invariants`, `libraries`, `source_map`, `claimed_judgments`) to $\le 4096$ characters.
  - `StateCellsBounded (cells : List StateCellEnc) : Prop`: bounds each rational amount numerator and denominator to $\le 10^{18}$.
  - Structural byte-cost functions: `stringByteCost` ($6 \cdot \text{len} + 2$), `cellByteCost` (128), `sourcePinByteCost`, `envelopeByteCost`, `typedPayloadByteCost`, `irStructuralByteCost`.
  - `StructuralByteBound (ir : DecodedIR) : Prop := irStructuralByteCost ir ≤ 1048576`.
  - Incorporated all bounds into `SupportedIR` and `StructurallyAdmissibleIR`.
- **Theorems in `Correspondence.lean`**:
  - `structurallyAdmissible_nonempty : StructurallyAdmissibleIR canonicalWitnessIR`: Non-emptiness proof updated and verified under all structural bounds (witness structural cost: 6,454 bytes $\le 1048576$).
  - `large_string_not_in_envelope_string_bounds (pin : SourcePinEnc) (h_len : pin.checker_candidate.length > 4096) : ¬ SourcePinStringBounds pin`: Proves strings $> 4096$ chars cannot be in `SourcePinStringBounds`, disproving root's counterexample family.
  - `structural_byte_cost_exceeded_not_supported (ir : DecodedIR) (h_cost : irStructuralByteCost ir > 1048576) : ¬ SupportedIR ir`: Proves any document exceeding 1MB structural cost is not supported.

### 3. Component Inversion Theorems & Universal Obligation Formulation (`R7-UNIVERSAL-OPEN`)
- **Expanded Theorem Suite**:
  - `string_roundtrip (s : String) (rest : List Char) : String.fromUTF8? s.toUTF8 = some s ∧ lexString [] (escapeChars s.toList ++ ('"' :: rest)) = .ok (s, rest)`
  - `decodeRat_mkObj (num : Int) (den : Nat) (h_den : den ≠ 0) (h_gcd : Int.gcd num.natAbs den = 1) : decodeRat (Lean.Json.mkObj [("num", num), ("den", den)]) = .ok ⟨num, den⟩`
  - `decodePackedValue_scalar_val (v : Nat) : decodePackedValue ... = .ok ⟨.numeric .scalar, (RatEnc.mk (v : Int) 1).toRat, false⟩` (proved for ANY natural scalar value)
  - `decodePackedValue_amount_val (a : Asset) (v : Nat) : decodePackedValue ... = .ok ⟨.numeric (.amount a), (RatEnc.mk (v : Int) 1).toRat, false⟩` (proved for ANY asset and natural value)
- Total verified theorems in `Correspondence.lean`: **80** (expanded from 74 in R7).
- Total verified theorems in `CanonicalJson.lean`: **10**.
- Combined verified theorem count across both modules: **90**. All verified with standard axioms only, 0 sorry, 0 custom axioms.
- Universal quantified target `EncodeDecodeRoundtripStatement` remains soundly formulated over the non-empty `StructurallyAdmissibleIR` domain as the open P20 gate.

### 4. Fresh Compilation of Olean Artifacts (`R7-STALE-COMPILED-AUDIT`)
- **Problem**: Root observed that `Correspondence.olean` had only 49 declarations because `lakefile.toml` default targets did not automatically rebuild `DefiKernel.Certificates`.
- **Resolution**:
  - Added `lake build DefiKernel.Certificates.Verify` directly into `run_certificate_fixtures.py`.
  - Rebuilt all certificates targets, compiling fresh `.olean` artifacts.
  - Verified with an independent probe script importing `DefiKernel.Certificates.Correspondence` that all 80 theorems are resolved from the compiled object with standard axioms.

### 5. Honest Toolchain Identity & Reconciled Scenario Counts (`R7-REPORT-IDENTITY-AND-COUNTS`)
- **Compiler**: Captured via `lake env which lean` and `lake env lean --version` in `lean/`:
  - Resolved compiler: `Lean (version 4.33.0-rc2, x86_64-unknown-linux-gnu, commit d8b18978322de05a8f3dba51ef03cf5461676c17, Release)`
  - Executable: `/home/charl/.elan/toolchains/leanprover--lean4---v4.33.0-rc2/bin/lean`
  - Working directory: `/home/charl/defiformal-wt-p19-certificates-grok-opus-20260909/lean`
- **Reconciled Scenario Counts**:
  - Total Scenarios: **99**
  - Verified by Fixture + Lean Theorem: **8** (S40, S41, S42, S43, S44, S48, S79, S84)
  - Verified by Fixture Deep Comparison: **90**
  - Bounded Fixture Verified / Open for P20: **1** (S78)
  - Open / Unverified: **0**
  - Failed: **0**
  - All consolidated numbers in `results.json` match `scenario-results.json` exactly ($8 + 90 + 1 = 99$).

---

## Verification & Audit Metrics

### 1. Test & Fixture Suite
- **54/54 Fixtures Passed**: Deep structural equality comparison across all AST fields.
- **54/54 Negative Controls Discriminated**: Proves non-vacuous comparator behavior.
- **2/2 Regression Controls Passed**:
  - `F13-raw-regression`: Confirmed rejection of non-canonical key order in `source_map`.
  - `F28-raw-regression`: Confirmed rejection of non-canonical key order in `source_map`.
- **5/5 Compiler Audit Negative Controls Passed**: Vacuity protections verified.

### 2. Compiler Axiom Audit
- Command: `lake env lean DefiKernel/Certificates/Verify.lean`
- Validated: `True` (Exit code 0)
- All three audited scopes passed with **ZERO forbidden axioms**:
  - `DefiKernel.Certificates`: **1171/1171 theorems**, 2405/2405 supplemental declarations (forbidden=0)
  - `DefiKernel.Typed`: **420/420 theorems**, 677/677 supplemental declarations (forbidden=0)
  - `DefiKernel.Composition`: **287/287 theorems**, 408/408 supplemental declarations (forbidden=0)
- Full repository compilation (`lake build`): all 1176 targets passed with exit code 0.

---

## Source Inventory & Hashes

| File | SHA-256 Hash | Bytes | Lines | Role |
|---|---|---|---|---|
| `lean/DefiKernel/Certificates/CanonicalJson.lean` | `ecb58097f4fa116da1837517208ec3e887f48b0a9b3a32f65a111a4365313936` | 14,853 | 397 | Total canonical JSON parser + 10 string/UTF-8 inversion theorems |
| `lean/DefiKernel/Certificates/Encode.lean` | `6b9aa4516ec57c793ff808eb5562779a5fa1c8ffae1ce2655bf57c8f498c8cbe` | 24,643 | 545 | Canonical JSON encoder with C0 `\u00xx` unicode escaping |
| `lean/DefiKernel/Certificates/Decode.lean` | `27c3542438ed6cd1441604b38efe11ba7f13404e6b419dd8417a0492d8e8d034` | 63,344 | 1,560 | Production decoder wired to `parseCanonicalJson` |
| `lean/DefiKernel/Certificates/Correspondence.lean` | `51a9366b0a16ad2039dc43daed89b359df0a1c2ba290f00c16497857d5928ae8` | 54,579 | 1,176 | 80 verified theorems, resource bounds, string/cost refutation |
| `lean/DefiKernel/Certificates/Check.lean` | `2cd24e9b302de52a85d7999c034cb7b08e4cb3d06b5fe79eb9943d4aa24ad66c` | 39,737 | 789 | Certificate semantic checkers |
| `lean/DefiKernel/Certificates/Schema.lean` | `73ab0ca112b547867a0cc9852af4fa339c0b658c260b0d3bd8a50a6d761c4180` | 23,176 | 770 | AST schema representations |
| `lean/DefiKernel/Certificates/Soundness.lean` | `262e726f0c7380acaaf67cd7d89d9560bc7af568032690f96269275c0c143556` | 28,285 | 536 | Semantic soundness proofs |
| `lean/DefiKernel/Certificates/Observation.lean` | `d33b251aa1868bc5e7c945e39d629109d2f9f46d2cc652d06d9bac96f5079a62` | 1,421 | 50 | Observation pair validation |
| `lean/DefiKernel/Certificates/Verify.lean` | `47ba130e824c224e37b63c590329486a6c642403f8e70a7874743a4dc0d53f16` | 532 | 16 | Axiom audit root |
| `lean/DefiKernel/Certificates/Audit.lean` | `187b13c868ee71d259830a932c918d1837d9c95f14c0903059dbc877c909d91d` | 705 | 22 | Scope reflection |
| `lean/DefiKernel/Certificates/Tests.lean` | `a63cc07460f2c1ab679af8781107cac69434c2ca30643702fc292d1a7de5fd83` | 15,798 | 438 | Unit tests |
| `lean/DefiKernel/Certificates/RunFixtures.lean` | `03fcb7d41fe4648f4933aa3c7a202a81cbed30c9c85a6619f3291fdb844ec98f` | 3,429 | 88 | Fixture execution harness |
| `scripts/run_certificate_fixtures.py` | `03f39a0fa0faee013d508269e8025287f654b4a1b0be9a7fb3c96ea4d2c88f11` | 29,869 | 636 | Fixture runner & audit script |

---

## Disposition & Recommended Grok Audit Scope

- **Current Batch Status**: `PARTIAL_PROOF_WORK`
- **Recommended Grok Auditor Checks**:
  1. Verify string codec fix in `CanonicalJson.lean` and `Encode.lean`: confirm lowercase hex `\u00xx` escaping for $c < 32$, rejection of literal unescaped controls and invalid escapes.
  2. Verify string inversion theorems in `CanonicalJson.lean` (`lexString_escapeChars`, `lexString_escapeJsonString`, `string_fromUTF8?_toUTF8`) via `#print axioms`.
  3. Verify resource bounds in `Correspondence.lean`: confirm `SourcePinStringBounds`, `EnvelopeStringBounds`, `StructuralByteBound` eliminate `LargeStringDomainProbe3` counterexample, and verify `structurallyAdmissible_nonempty`.
  4. Verify fresh compilation: confirm `lake build DefiKernel.Certificates.Verify` compiles freshly without stale olean warnings.
  5. Confirm `theorems.json` (90 theorems) and `fixture-results.json` (54/54 fixtures, 54/54 controls, 2 regressions, 0 forbidden axioms).
