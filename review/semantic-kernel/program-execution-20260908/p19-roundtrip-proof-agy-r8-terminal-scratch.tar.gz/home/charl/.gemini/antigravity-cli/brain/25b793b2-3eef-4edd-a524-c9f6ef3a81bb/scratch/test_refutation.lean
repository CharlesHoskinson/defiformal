import DefiKernel.Certificates.Schema
import DefiKernel.Certificates.Decode
import DefiKernel.Certificates.CanonicalJson
import DefiKernel.Certificates.Correspondence

open DefiKernel.Certificates

/-- General string roundtrip theorem: any string roundtrips through canonical UTF-8 encoding and lexString. -/
theorem string_roundtrip_test (s : String) (rest : List Char) :
    String.fromUTF8? s.toUTF8 = some s ∧
    lexString [] (escapeChars s.toList ++ ('"' :: rest)) = .ok (s, rest) :=
  ⟨string_fromUTF8?_toUTF8 s, lexString_escapeJsonString s rest⟩

/-- Theorem: strings exceeding 4096 characters are not in EnvelopeStringBounds. -/
theorem large_string_not_in_envelope_string_bounds_test (pin : SourcePinEnc)
    (h_len : pin.checker_candidate.length > 4096) :
    ¬ (pin.git.length ≤ 4096 ∧
       pin.lean_toolchain.length ≤ 4096 ∧
       pin.mathlib_rev.length ≤ 4096 ∧
       pin.checker_candidate.length ≤ 4096 ∧
       (match pin.compiler_record with | some s => s.length ≤ 4096 | none => True) ∧
       (match pin.audit_record with | some s => s.length ≤ 4096 | none => True)) := by
  intro h_bounds
  have h_bound := h_bounds.2.2.2.1
  omega
