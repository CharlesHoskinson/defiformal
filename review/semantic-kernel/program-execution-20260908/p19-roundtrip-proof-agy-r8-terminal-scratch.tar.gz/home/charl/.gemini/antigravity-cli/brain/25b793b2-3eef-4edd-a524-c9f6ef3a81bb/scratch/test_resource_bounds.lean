import DefiKernel.Certificates.Schema
import DefiKernel.Certificates.CanonicalJson
open DefiKernel.Certificates

def SourcePinStringBounds (pin : SourcePinEnc) : Prop :=
  pin.git.length ≤ 4096 ∧
  pin.lean_toolchain.length ≤ 4096 ∧
  pin.mathlib_rev.length ≤ 4096 ∧
  pin.checker_candidate.length ≤ 4096 ∧
  (match pin.compiler_record with | some s => s.length ≤ 4096 | none => True) ∧
  (match pin.audit_record with | some s => s.length ≤ 4096 | none => True)

def EnvelopeStringBounds (env : EnvelopeEnc) : Prop :=
  SourcePinStringBounds env.source_pin ∧
  (∀ s ∈ env.audit_roots, s.length ≤ 4096) ∧
  (∀ s ∈ env.assumptions, s.length ≤ 4096) ∧
  (∀ s ∈ env.invariants, s.length ≤ 4096) ∧
  (∀ lib ∈ env.libraries, lib.theoremName.length ≤ 4096 ∧ match lib.moduleName with | some m => m.length ≤ 4096 | none => True) ∧
  (∀ pair ∈ env.source_map, pair.1.length ≤ 4096 ∧ pair.2.length ≤ 4096) ∧
  (∀ s ∈ env.claimed_judgments, s.length ≤ 4096)

def stringByteCost (s : String) : Nat := s.length * 6 + 2
def cellByteCost (_ : StateCellEnc) : Nat := 128

def sourcePinByteCost (pin : SourcePinEnc) : Nat :=
  stringByteCost pin.git + stringByteCost pin.lean_toolchain +
  stringByteCost pin.mathlib_rev + stringByteCost pin.checker_candidate + 128

def envelopeByteCost (env : EnvelopeEnc) : Nat :=
  sourcePinByteCost env.source_pin +
  (env.audit_roots.map stringByteCost).sum +
  (env.assumptions.map stringByteCost).sum +
  (env.invariants.map stringByteCost).sum +
  (env.source_map.map (fun (k, v) => stringByteCost k + stringByteCost v)).sum +
  (env.claimed_judgments.map stringByteCost).sum + 512

def typedPayloadByteCost (p : TypedExecutePayloadEnc) : Nat :=
  (p.state.cells.map cellByteCost).sum +
  p.registry.entries.length * 512 +
  p.store.entries.length * 256 +
  p.env.entries.length * 256 +
  p.request.arguments.length * 128 +
  p.request.capabilityIds.length * 32 +
  p.request.parties.length * 32 + 512

def irStructuralByteCost (ir : DecodedIR) : Nat :=
  match ir with
  | .execution (.typed env payload) => envelopeByteCost env + typedPayloadByteCost payload
  | .execution (.step env _) => envelopeByteCost env + 8192
  | .execution (.run env _) => envelopeByteCost env + 16384
  | .audit _ => 4096
  | .codec _ => 4096

def StructuralByteBound (ir : DecodedIR) : Prop :=
  irStructuralByteCost ir ≤ 1048576

def StructuralDepthBound (_ : DecodedIR) : Prop :=
  True

#check StructuralByteBound
#check StructuralDepthBound

def standard32Cells : List StateCellEnc :=
  let parties : List Party := [.alice, .bob, .vault, .pool]
  let assets : List Asset := [.usd, .share, .collateral, .debt]
  let domains : List Domain := [.main, .other]
  domains.flatMap fun d ↦
    parties.flatMap fun p ↦
      assets.map fun a ↦
        ⟨d, p, a, ⟨0, 1⟩⟩

def canonicalWitnessIR : DecodedIR :=
  .execution (.typed
    ⟨1, "typed-execute", ⟨"a12b7cac05a818cc8d35c2ca440b7170a2807e92", "leanprover/lean4:v4.33.0-rc2",
      "51e6992efd06126df61a496bebf8f49482a4e129", "", none, none⟩,
      ["DefiKernel.Certificates", "DefiKernel.Typed", "DefiKernel.Composition"],
      ⟨[.alice, .bob, .vault, .pool], [.usd, .share, .collateral, .debt], [.main, .other]⟩,
      ["environment-authenticity"], [], [], [], [], none, false, false⟩
    ⟨⟨[]⟩, ⟨[]⟩, ⟨.alice, .main⟩, ⟨[]⟩, 100, ⟨0, [.alice], [], [], some .alice⟩, ⟨standard32Cells⟩⟩)

#eval irStructuralByteCost canonicalWitnessIR
#eval irStructuralByteCost canonicalWitnessIR ≤ 1048576

