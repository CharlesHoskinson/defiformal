
theorem test1 (s : String) : String.ofList s.toList = s :=
  String.ofList_toList
