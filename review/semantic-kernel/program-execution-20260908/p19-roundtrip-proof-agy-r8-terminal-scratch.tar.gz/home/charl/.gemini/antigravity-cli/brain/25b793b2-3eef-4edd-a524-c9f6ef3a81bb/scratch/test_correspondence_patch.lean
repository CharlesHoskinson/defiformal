import DefiKernel.Certificates.Schema
import DefiKernel.Certificates.Decode
import DefiKernel.Certificates.Check
import DefiKernel.Certificates.Observation
import DefiKernel.Certificates.CanonicalJson

namespace DefiKernel.Certificates

set_option linter.style.longLine false

def standard32CellKeys : List (Domain × Party × Asset) :=
  let parties : List Party := [.alice, .bob, .vault, .pool]
  let assets : List Asset := [.usd, .share, .collateral, .debt]
  let domains : List Domain := [.main, .other]
  domains.flatMap fun d ↦
    parties.flatMap fun p ↦
      assets.map fun a ↦ (d, p, a)

def StateCellsMatchStandard32 (cells : List StateCellEnc) : Prop :=
  cells.length = 32 ∧
  cells.map (fun c ↦ (c.domain, c.party, c.asset)) = standard32CellKeys ∧
  cells.all (fun c ↦ c.amount.den > 0 ∧ c.amount.num ≥ 0 ∧ Int.gcd c.amount.num.natAbs c.amount.den = 1) = true

def StandardTypesEnum (t : TypesEnumEnc) : Prop :=
  t.parties = [.alice, .bob, .vault, .pool] ∧
  t.assets = [.usd, .share, .collateral, .debt] ∧
  t.domains = [.main, .other]

def SourceMapSorted (sm : List (String × String)) : Prop :=
  isSortedStrictAscending (sm.map Prod.fst) = true

def PackedValueCanonical (v : PackedValueEnc) : Prop :=
  (v.unit = .bool → v.valRat = 0) ∧
  (∀ nu, v.unit = .numeric nu → v.valBool = false)

def ExprEnc.depth : ExprEnc → Nat
  | .lit _ => 1
  | .arg _ _ => 1
  | .balance _ => 1
  | .observe _ => 1
  | .timestamp _ => 1
  | .now => 1
  | .unary _ x => 1 + x.depth
  | .binary _ x y => 1 + max x.depth y.depth
  | .ite c y n => 1 + max c.depth (max y.depth n.depth)

def ExprCanonical (e : ExprEnc) : Prop :=
  e.depth ≤ 64 ∧
  match e with
  | .lit v => PackedValueCanonical v
  | .unary _ x => ExprCanonical x
  | .binary _ x y => ExprCanonical x ∧ ExprCanonical y
  | .ite c y n => ExprCanonical c ∧ ExprCanonical y ∧ ExprCanonical n
  | _ => True

def TemplateCanonical (t : TemplateEnc) : Prop :=
  ExprCanonical t.guard ∧
  (∀ d ∈ t.deltas, ExprCanonical d.amount) ∧
  (∀ s ∈ t.supplyDeltas, ExprCanonical s.amount)

def RegistryCanonical (r : RegistryEnc) : Prop :=
  (r.entries.map (·.id)).Nodup ∧
  (∀ e ∈ r.entries, TemplateCanonical e.template)

def StoreCanonical (s : StoreEnc) : Prop :=
  s.entries.Nodup

def EnvironmentCanonical (env : EnvironmentEnc) : Prop :=
  ∀ e ∈ env.entries, PackedValueCanonical e.observation.value

def RequestCanonical (r : RequestEnc) : Prop :=
  ∀ a ∈ r.arguments, PackedValueCanonical a

def InputSourceCanonical : InputSourceEnc → Prop
  | .literal v => PackedValueCanonical v
  | .priorOutput _ _ => True

def InvocationCanonical (inv : InvocationEnc) : Prop :=
  ∀ i ∈ inv.inputs, InputSourceCanonical i

def StepCanonical : StepEnc → Prop
  | .invoke inv => InvocationCanonical inv
  | .issue _ => True
  | .revoke _ => True
  | .unsupported _ => False

def WorldCanonical (w : WorldEnc) : Prop :=
  StateCellsMatchStandard32 w.state.cells ∧
  StoreCanonical w.capabilities

def ClaimedNextStateCanonical (cns : Option WorldEnc) : Prop :=
  match cns with
  | none => True
  | some w => WorldCanonical w

def HistoryCanonical (h : List OutputObservationEnc) : Prop :=
  ∀ o ∈ h, PackedValueCanonical o.value

def BoundaryCanonical (b : BoundaryEnc) : Prop :=
  EnvironmentCanonical b.env

def EnvelopeLengthBounds (env : EnvelopeEnc) : Prop :=
  env.audit_roots.length ≤ 4096 ∧
  env.assumptions.length ≤ 4096 ∧
  env.invariants.length ≤ 4096 ∧
  env.libraries.length ≤ 4096 ∧
  env.source_map.length ≤ 4096 ∧
  env.claimed_judgments.length ≤ 4096

def SourcePinStringBounds (pin : SourcePinEnc) : Prop :=
  pin.git.length ≤ 4096 ∧
  pin.lean_toolchain.length ≤ 4096 ∧
  pin.mathlib_rev.length ≤ 4096 ∧
  pin.checker_candidate.length ≤ 4096 ∧
  (match pin.compiler_record with | some s => s.length ≤ 4096 | none => True) ∧
  (match pin.audit_record with | some s => s.length ≤ 4096 | none => True)

def EnvelopeStringBounds (env : EnvelopeEnc) : Prop :=
  SourcePinStringBounds env.source_pin ∧
  (∀ s ∈ env.audit_roots, s.length ≤ 4096) ∧
  (∀ s ∈ env.assumptions, s.length ≤ 4096) ∧
  (∀ s ∈ env.invariants, s.length ≤ 4096) ∧
  (∀ lib ∈ env.libraries, lib.theoremName.length ≤ 4096 ∧ match lib.moduleName with | some m => m.length ≤ 4096 | none => True) ∧
  (∀ pair ∈ env.source_map, pair.1.length ≤ 4096 ∧ pair.2.length ≤ 4096) ∧
  (∀ s ∈ env.claimed_judgments, s.length ≤ 4096)

def stringByteCost (s : String) : Nat := s.length * 6 + 2
def cellByteCost (_ : StateCellEnc) : Nat := 128

def sourcePinByteCost (pin : SourcePinEnc) : Nat :=
  stringByteCost pin.git + stringByteCost pin.lean_toolchain +
  stringByteCost pin.mathlib_rev + stringByteCost pin.checker_candidate + 128

def envelopeByteCost (env : EnvelopeEnc) : Nat :=
  sourcePinByteCost env.source_pin +
  (env.audit_roots.map stringByteCost).sum +
  (env.assumptions.map stringByteCost).sum +
  (env.invariants.map stringByteCost).sum +
  (env.source_map.map (fun (k, v) => stringByteCost k + stringByteCost v)).sum +
  (env.claimed_judgments.map stringByteCost).sum + 512

def typedPayloadByteCost (p : TypedExecutePayloadEnc) : Nat :=
  (p.state.cells.map cellByteCost).sum +
  p.registry.entries.length * 512 +
  p.store.entries.length * 256 +
  p.env.entries.length * 256 +
  p.request.arguments.length * 128 +
  p.request.capabilityIds.length * 32 +
  p.request.parties.length * 32 + 512

def irStructuralByteCost (ir : DecodedIR) : Nat :=
  match ir with
  | .execution (.typed env payload) => envelopeByteCost env + typedPayloadByteCost payload
  | .execution (.step env _) => envelopeByteCost env + 8192
  | .execution (.run env _) => envelopeByteCost env + 16384
  | .audit _ => 4096
  | .codec _ => 4096

def StructuralByteBound (ir : DecodedIR) : Prop :=
  irStructuralByteCost ir ≤ 1048576

def StateCellsBounded (cells : List StateCellEnc) : Prop :=
  cells.all (fun c ↦ c.amount.num.natAbs ≤ 1000000000000000000 && c.amount.den ≤ 1000000000000000000) = true

def TypedPayloadLengthBounds (p : TypedExecutePayloadEnc) : Prop :=
  p.registry.entries.length ≤ 4096 ∧
  p.store.entries.length ≤ 4096 ∧
  p.env.entries.length ≤ 4096 ∧
  p.request.arguments.length ≤ 4096 ∧
  p.request.capabilityIds.length ≤ 4096 ∧
  p.request.parties.length ≤ 4096

def StepPayloadLengthBounds (p : CompositionStepPayloadEnc) : Prop :=
  p.config.registry.entries.length ≤ 4096 ∧
  p.pre.capabilities.entries.length ≤ 4096 ∧
  p.boundary.env.entries.length ≤ 4096 ∧
  p.history.length ≤ 4096

def RunPayloadLengthBounds (p : CompositionRunPayloadEnc) : Prop :=
  p.config.registry.entries.length ≤ 4096 ∧
  p.world.capabilities.entries.length ≤ 4096 ∧
  p.boundaries.length ≤ 4096 ∧
  p.steps.length ≤ 4096 ∧
  (∀ b ∈ p.boundaries, b.env.entries.length ≤ 4096)

def SupportedIR (ir : DecodedIR) : Prop :=
  StructuralByteBound ir ∧
  match ir with
  | .execution (.typed env payload) =>
    env.schema_version = 1 ∧
    env.mode = "typed-execute" ∧
    StandardTypesEnum env.types ∧
    payload.state.cells.length = 32 ∧
    payload.state.cells.map (fun c ↦ (c.domain, c.party, c.asset)) = standard32CellKeys ∧
    payload.state.cells.all (fun c ↦ c.amount.den > 0 ∧ c.amount.num ≥ 0) = true ∧
    StateCellsBounded payload.state.cells ∧
    StoreCanonical payload.store ∧
    (payload.registry.entries.map (·.id)).Nodup ∧
    EnvelopeLengthBounds env ∧
    EnvelopeStringBounds env ∧
    TypedPayloadLengthBounds payload
  | .execution (.step env payload) =>
    env.schema_version = 1 ∧
    env.mode = "composition-step" ∧
    StandardTypesEnum env.types ∧
    (match payload.step with | .unsupported _ => False | _ => True) ∧
    payload.pre.state.cells.length = 32 ∧
    payload.pre.state.cells.map (fun c ↦ (c.domain, c.party, c.asset)) = standard32CellKeys ∧
    payload.pre.state.cells.all (fun c ↦ c.amount.den > 0 ∧ c.amount.num ≥ 0) = true ∧
    StateCellsBounded payload.pre.state.cells ∧
    StoreCanonical payload.pre.capabilities ∧
    (payload.config.registry.entries.map (·.id)).Nodup ∧
    EnvelopeLengthBounds env ∧
    EnvelopeStringBounds env ∧
    StepPayloadLengthBounds payload
  | .execution (.run env payload) =>
    env.schema_version = 1 ∧
    env.mode = "composition-run" ∧
    StandardTypesEnum env.types ∧
    payload.steps.all (fun s ↦ match s with | .unsupported _ => false | _ => true) = true ∧
    payload.world.state.cells.length = 32 ∧
    payload.world.state.cells.map (fun c ↦ (c.domain, c.party, c.asset)) = standard32CellKeys ∧
    payload.world.state.cells.all (fun c ↦ c.amount.den > 0 ∧ c.amount.num ≥ 0) = true ∧
    StateCellsBounded payload.world.state.cells ∧
    StoreCanonical payload.world.capabilities ∧
    (payload.config.registry.entries.map (·.id)).Nodup ∧
    EnvelopeLengthBounds env ∧
    EnvelopeStringBounds env ∧
    RunPayloadLengthBounds payload
  | .audit _ => False
  | .codec _ => False

def CanonicalIR (ir : DecodedIR) : Prop :=
  match ir with
  | .execution (.typed env payload) =>
    SourceMapSorted env.source_map ∧
    ClaimedNextStateCanonical env.claimed_next_state ∧
    payload.state.cells.all (fun c ↦ Int.gcd c.amount.num.natAbs c.amount.den = 1) = true ∧
    (∀ e ∈ payload.registry.entries, TemplateCanonical e.template) ∧
    RequestCanonical payload.request ∧
    EnvironmentCanonical payload.env
  | .execution (.step env payload) =>
    SourceMapSorted env.source_map ∧
    ClaimedNextStateCanonical env.claimed_next_state ∧
    payload.pre.state.cells.all (fun c ↦ Int.gcd c.amount.num.natAbs c.amount.den = 1) = true ∧
    StepCanonical payload.step ∧
    (∀ e ∈ payload.config.registry.entries, TemplateCanonical e.template) ∧
    HistoryCanonical payload.history ∧
    BoundaryCanonical payload.boundary
  | .execution (.run env payload) =>
    SourceMapSorted env.source_map ∧
    ClaimedNextStateCanonical env.claimed_next_state ∧
    payload.world.state.cells.all (fun c ↦ Int.gcd c.amount.num.natAbs c.amount.den = 1) = true ∧
    (∀ s ∈ payload.steps, StepCanonical s) ∧
    (∀ e ∈ payload.config.registry.entries, TemplateCanonical e.template) ∧
    (∀ b ∈ payload.boundaries, BoundaryCanonical b)
  | .audit _ => False
  | .codec _ => False

def StructurallyAdmissibleIR (ir : DecodedIR) : Prop :=
  SupportedIR ir ∧ CanonicalIR ir

def standard32Cells : List StateCellEnc :=
  let parties : List Party := [.alice, .bob, .vault, .pool]
  let assets : List Asset := [.usd, .share, .collateral, .debt]
  let domains : List Domain := [.main, .other]
  domains.flatMap fun d ↦
    parties.flatMap fun p ↦
      assets.map fun a ↦
        ⟨d, p, a, ⟨0, 1⟩⟩

def canonicalWitnessIR : DecodedIR :=
  .execution (.typed
    ⟨1, "typed-execute", ⟨"a12b7cac05a818cc8d35c2ca440b7170a2807e92", "leanprover/lean4:v4.33.0-rc2",
      "51e6992efd06126df61a496bebf8f49482a4e129", "", none, none⟩,
      ["DefiKernel.Certificates", "DefiKernel.Typed", "DefiKernel.Composition"],
      ⟨[.alice, .bob, .vault, .pool], [.usd, .share, .collateral, .debt], [.main, .other]⟩,
      ["environment-authenticity"], [], [], [], [], none, false, false⟩
    ⟨⟨[]⟩, ⟨[]⟩, ⟨.alice, .main⟩, ⟨[]⟩, 100, ⟨0, [.alice], [], [], some .alice⟩, ⟨standard32Cells⟩⟩)

theorem structurallyAdmissible_nonempty : StructurallyAdmissibleIR canonicalWitnessIR := by
  dsimp [StructurallyAdmissibleIR, SupportedIR, CanonicalIR, canonicalWitnessIR, StandardTypesEnum,
         SourceMapSorted, ClaimedNextStateCanonical, standard32Cells, standard32CellKeys,
         isSortedStrictAscending, StoreCanonical, RequestCanonical, EnvironmentCanonical,
         WorldCanonical, StateCellsMatchStandard32, EnvelopeLengthBounds, TypedPayloadLengthBounds,
         StructuralByteBound, StateCellsBounded]
  refine ⟨⟨by decide, ⟨rfl, rfl, ⟨rfl, rfl, rfl⟩, rfl, rfl, by decide, by decide, List.nodup_nil, List.nodup_nil, by decide, ?_, by decide⟩⟩, ?_⟩
  · refine ⟨⟨by decide, by decide, by decide, by decide, trivial, trivial⟩, ?_, ?_, ?_, ?_, ?_, ?_⟩
    · intro s hs
      cases hs with
      | head => decide
      | tail _ t =>
        cases t with
        | head => decide
        | tail _ t2 =>
          cases t2 with
          | head => decide
          | tail _ t3 => contradiction
    · intro s hs
      cases hs with
      | head => decide
      | tail _ t => contradiction
    · intro _ h; contradiction
    · intro _ h; contradiction
    · intro _ h; contradiction
    · intro _ h; contradiction
  · refine ⟨rfl, trivial, by decide, ?_, ?_, ?_⟩
    · intro _ h; contradiction
    · intro _ h; contradiction
    · intro _ h; contradiction

end DefiKernel.Certificates
#print axioms structurallyAdmissible_nonempty
#print axioms DefiKernel.Certificates.structurallyAdmissible_nonempty
