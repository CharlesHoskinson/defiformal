
import DefiKernel.Certificates.CanonicalJson
open DefiKernel.Certificates

#eval match parseCanonicalJson "\"\n\"" with | .error _ => true | .ok _ => false
#eval match parseCanonicalJson "\"\\q\"" with | .error _ => true | .ok _ => false
#eval match parseCanonicalJson "\"\\u001\"" with | .error _ => true | .ok _ => false
