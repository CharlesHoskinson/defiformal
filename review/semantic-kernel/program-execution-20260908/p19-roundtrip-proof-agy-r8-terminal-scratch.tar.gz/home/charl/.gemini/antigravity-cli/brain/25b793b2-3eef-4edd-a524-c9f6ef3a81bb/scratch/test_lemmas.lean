import DefiKernel.Certificates.Correspondence

namespace DefiKernel.Certificates

/-- ObservationRef decode roundtrip for all units. -/
theorem decodeObservationRef_roundtrip (d : Domain) (id : Nat) (u : UnitEnc) :
    decodeObservationRef (Lean.Json.mkObj [
      ("key", Lean.Json.mkObj [
        ("domain", Lean.Json.str (match d with | .main => "main" | .other => "other")),
        ("id", Lean.Json.num id)
      ]),
      ("unit", match u with
        | .bool => Lean.Json.mkObj [("tag", Lean.Json.str "bool")]
        | .numeric .scalar => Lean.Json.mkObj [("tag", Lean.Json.str "scalar")]
        | .numeric (.amount a) => Lean.Json.mkObj [
            ("tag", Lean.Json.str "amount"),
            ("asset", Lean.Json.str (match a with | .usd => "usd" | .share => "share" | .collateral => "collateral" | .debt => "debt"))
          ]
        | .numeric (.price b q) => Lean.Json.mkObj [
            ("tag", Lean.Json.str "price"),
            ("base", Lean.Json.str (match b with | .usd => "usd" | .share => "share" | .collateral => "collateral" | .debt => "debt")),
            ("quote", Lean.Json.str (match q with | .usd => "usd" | .share => "share" | .collateral => "collateral" | .debt => "debt"))
          ])
    ]) = .ok ⟨⟨d, id⟩, u⟩ := by
  cases d
  · cases u with
    | bool => rfl
    | numeric nu =>
      cases nu with
      | scalar => rfl
      | amount a => cases a <;> rfl
      | price b q => cases b <;> cases q <;> rfl
  · cases u with
    | bool => rfl
    | numeric nu =>
      cases nu with
      | scalar => rfl
      | amount a => cases a <;> rfl
      | price b q => cases b <;> cases q <;> rfl

theorem decodeRat_zero :
    decodeRat (Lean.Json.mkObj [("num", Lean.Json.num (0 : Int)), ("den", Lean.Json.num (1 : Nat))]) = .ok ⟨0, 1⟩ := by
  rfl

theorem decodePackedValue_scalar_zero :
    decodePackedValue (Lean.Json.mkObj [
      ("unit", Lean.Json.mkObj [("tag", Lean.Json.str "scalar")]),
      ("value", Lean.Json.mkObj [("num", Lean.Json.num (0 : Int)), ("den", Lean.Json.num (1 : Nat))])
    ]) = .ok ⟨.numeric .scalar, 0, false⟩ := by
  rfl

theorem decodePackedValue_amount_zero (a : Asset) :
    decodePackedValue (Lean.Json.mkObj [
      ("unit", Lean.Json.mkObj [
        ("tag", Lean.Json.str "amount"),
        ("asset", Lean.Json.str (match a with | .usd => "usd" | .share => "share" | .collateral => "collateral" | .debt => "debt"))
      ]),
      ("value", Lean.Json.mkObj [("num", Lean.Json.num (0 : Int)), ("den", Lean.Json.num (1 : Nat))])
    ]) = .ok ⟨.numeric (.amount a), 0, false⟩ := by
  cases a <;> rfl

theorem decodeBinaryOp_add (nu : NumericUnitEnc) :
    decodeBinaryOp (Lean.Json.mkObj [
      ("tag", Lean.Json.str "add"),
      ("numeric", match nu with
        | .scalar => Lean.Json.mkObj [("tag", Lean.Json.str "scalar")]
        | .amount a => Lean.Json.mkObj [
            ("tag", Lean.Json.str "amount"),
            ("asset", Lean.Json.str (match a with | .usd => "usd" | .share => "share" | .collateral => "collateral" | .debt => "debt"))
          ]
        | .price b q => Lean.Json.mkObj [
            ("tag", Lean.Json.str "price"),
            ("base", Lean.Json.str (match b with | .usd => "usd" | .share => "share" | .collateral => "collateral" | .debt => "debt")),
            ("quote", Lean.Json.str (match q with | .usd => "usd" | .share => "share" | .collateral => "collateral" | .debt => "debt"))
          ])
    ]) = .ok (.add nu) := by
  cases nu with
  | scalar => rfl
  | amount a => cases a <;> rfl
  | price b q => cases b <;> cases q <;> rfl

theorem decodeBinaryOp_convert (b q : Asset) :
    decodeBinaryOp (Lean.Json.mkObj [
      ("tag", Lean.Json.str "convert"),
      ("base", Lean.Json.str (match b with | .usd => "usd" | .share => "share" | .collateral => "collateral" | .debt => "debt")),
      ("quote", Lean.Json.str (match q with | .usd => "usd" | .share => "share" | .collateral => "collateral" | .debt => "debt"))
    ]) = .ok (.convert b q) := by
  cases b <;> cases q <;> rfl

def EnvelopeStructuralBounds (env : EnvelopeEnc) : Prop :=
  env.audit_roots.length ≤ 4096 ∧
  env.assumptions.length ≤ 4096 ∧
  env.invariants.length ≤ 4096 ∧
  env.libraries.length ≤ 4096 ∧
  env.source_map.length ≤ 4096 ∧
  env.claimed_judgments.length ≤ 4096 ∧
  env.mode.length ≤ 64

def PayloadStructuralBounds (p : TypedExecutePayloadEnc) : Prop :=
  p.registry.entries.length ≤ 4096 ∧
  p.store.entries.length ≤ 4096 ∧
  p.env.entries.length ≤ 4096 ∧
  p.request.arguments.length ≤ 4096 ∧
  p.request.capabilityIds.length ≤ 4096 ∧
  p.request.parties.length ≤ 4096

theorem decodeStep_issue (h : Party) (d : Domain) (op : Nat) :
    decodeStep (Lean.Json.mkObj [
      ("tag", Lean.Json.str "issue"),
      ("grant", Lean.Json.mkObj [
        ("holder", Lean.Json.str (match h with | .alice => "alice" | .bob => "bob" | .vault => "vault" | .pool => "pool")),
        ("domain", Lean.Json.str (match d with | .main => "main" | .other => "other")),
        ("operation", Lean.Json.num op),
        ("right", Lean.Json.mkObj [("tag", Lean.Json.str "invoke")])
      ])
    ]) = .ok (.issue ⟨h, d, op, .invoke⟩) := by
  cases h <;> cases d <;> rfl

theorem decodePackedCellRef_roundtrip (a : Asset) (d : Domain) (p : Party) :
    decodePackedCellRef (Lean.Json.mkObj [
      ("asset", Lean.Json.str (match a with | .usd => "usd" | .share => "share" | .collateral => "collateral" | .debt => "debt")),
      ("cell", Lean.Json.mkObj [
        ("domain", Lean.Json.str (match d with | .main => "main" | .other => "other")),
        ("owner", Lean.Json.mkObj [("tag", Lean.Json.str "literal"), ("party", Lean.Json.str (match p with | .alice => "alice" | .bob => "bob" | .vault => "vault" | .pool => "pool"))])
      ])
    ]) = .ok ⟨a, ⟨d, .literal p⟩⟩ := by
  cases a <;> cases d <;> cases p <;> rfl

theorem decodeEnvRead_observation (d : Domain) (id : Nat) :
    decodeEnvRead (Lean.Json.mkObj [
      ("tag", Lean.Json.str "observation"),
      ("key", Lean.Json.mkObj [
        ("domain", Lean.Json.str (match d with | .main => "main" | .other => "other")),
        ("id", Lean.Json.num id)
      ])
    ]) = .ok (.observation ⟨d, id⟩) := by
  cases d <;> rfl

theorem decodeSourcePin_roundtrip (git toolchain mathlib checker : String) :
    decodeSourcePin (Lean.Json.mkObj [
      ("git", Lean.Json.str git),
      ("lean_toolchain", Lean.Json.str toolchain),
      ("mathlib_rev", Lean.Json.str mathlib),
      ("checker_candidate", Lean.Json.str checker)
    ]) = .ok ⟨git, toolchain, mathlib, checker, none, none⟩ := by
  rfl

theorem decodeGrant_roundtrip (h : Party) (d : Domain) (op : Nat) :
    decodeGrant (Lean.Json.mkObj [
      ("holder", Lean.Json.str (match h with | .alice => "alice" | .bob => "bob" | .vault => "vault" | .pool => "pool")),
      ("domain", Lean.Json.str (match d with | .main => "main" | .other => "other")),
      ("operation", Lean.Json.num op),
      ("right", Lean.Json.mkObj [("tag", Lean.Json.str "invoke")])
    ]) = .ok ⟨h, d, op, .invoke⟩ := by
  cases h <;> cases d <;> rfl

theorem decodeCapability_invoke (h : Party) (d : Domain) (op : Nat) (l : Bool) :
    decodeCapability (Lean.Json.mkObj [
      ("holder", Lean.Json.str (match h with | .alice => "alice" | .bob => "bob" | .vault => "vault" | .pool => "pool")),
      ("domain", Lean.Json.str (match d with | .main => "main" | .other => "other")),
      ("operation", Lean.Json.num op),
      ("right", Lean.Json.mkObj [("tag", Lean.Json.str "invoke")]),
      ("live", Lean.Json.bool l)
    ]) = .ok ⟨h, d, op, .invoke, l⟩ := by
  cases h <;> cases d <;> cases l <;> rfl

theorem decodeExprFuel_balance (fuel : Nat) (a : Asset) (d : Domain) (p : Party) :
    decodeExprFuel (fuel + 1) (Lean.Json.mkObj [
      ("tag", Lean.Json.str "balance"),
      ("cell", Lean.Json.mkObj [
        ("asset", Lean.Json.str (match a with | .usd => "usd" | .share => "share" | .collateral => "collateral" | .debt => "debt")),
        ("cell", Lean.Json.mkObj [
          ("domain", Lean.Json.str (match d with | .main => "main" | .other => "other")),
          ("owner", Lean.Json.mkObj [("tag", Lean.Json.str "literal"), ("party", Lean.Json.str (match p with | .alice => "alice" | .bob => "bob" | .vault => "vault" | .pool => "pool"))])
        ])
      ])
    ]) = .ok (.balance ⟨a, ⟨d, .literal p⟩⟩) := by
  cases a <;> cases d <;> cases p <;> rfl

theorem decodeExprFuel_timestamp (fuel : Nat) (d : Domain) (id : Nat) :
    decodeExprFuel (fuel + 1) (Lean.Json.mkObj [
      ("tag", Lean.Json.str "timestamp"),
      ("key", Lean.Json.mkObj [
        ("domain", Lean.Json.str (match d with | .main => "main" | .other => "other")),
        ("id", Lean.Json.num id)
      ])
    ]) = .ok (.timestamp ⟨d, id⟩) := by
  cases d <;> rfl

theorem decodeExprFuel_unary_not (fuel : Nat) :
    decodeExprFuel (fuel + 2) (Lean.Json.mkObj [
      ("tag", Lean.Json.str "unary"),
      ("op", Lean.Json.mkObj [("tag", Lean.Json.str "not")]),
      ("x", Lean.Json.mkObj [("tag", Lean.Json.str "now")])
    ]) = .ok (.unary .not .now) := by
  rfl

theorem decodeExprFuel_binary_and (fuel : Nat) :
    decodeExprFuel (fuel + 2) (Lean.Json.mkObj [
      ("tag", Lean.Json.str "binary"),
      ("op", Lean.Json.mkObj [("tag", Lean.Json.str "and")]),
      ("x", Lean.Json.mkObj [("tag", Lean.Json.str "now")]),
      ("y", Lean.Json.mkObj [("tag", Lean.Json.str "now")])
    ]) = .ok (.binary .and .now .now) := by
  rfl

theorem decodeExprFuel_ite (fuel : Nat) :
    decodeExprFuel (fuel + 2) (Lean.Json.mkObj [
      ("tag", Lean.Json.str "ite"),
      ("condition", Lean.Json.mkObj [("tag", Lean.Json.str "now")]),
      ("yes", Lean.Json.mkObj [("tag", Lean.Json.str "now")]),
      ("no", Lean.Json.mkObj [("tag", Lean.Json.str "now")])
    ]) = .ok (.ite .now .now .now) := by
  rfl

theorem decodeExpr_balance (a : Asset) (d : Domain) (p : Party) :
    decodeExpr (Lean.Json.mkObj [
      ("tag", Lean.Json.str "balance"),
      ("cell", Lean.Json.mkObj [
        ("asset", Lean.Json.str (match a with | .usd => "usd" | .share => "share" | .collateral => "collateral" | .debt => "debt")),
        ("cell", Lean.Json.mkObj [
          ("domain", Lean.Json.str (match d with | .main => "main" | .other => "other")),
          ("owner", Lean.Json.mkObj [("tag", Lean.Json.str "literal"), ("party", Lean.Json.str (match p with | .alice => "alice" | .bob => "bob" | .vault => "vault" | .pool => "pool"))])
        ])
      ])
    ]) = .ok (.balance ⟨a, ⟨d, .literal p⟩⟩) := by
  cases a <;> cases d <;> cases p <;> rfl

theorem decodeExpr_timestamp (d : Domain) (id : Nat) :
    decodeExpr (Lean.Json.mkObj [
      ("tag", Lean.Json.str "timestamp"),
      ("key", Lean.Json.mkObj [
        ("domain", Lean.Json.str (match d with | .main => "main" | .other => "other")),
        ("id", Lean.Json.num id)
      ])
    ]) = .ok (.timestamp ⟨d, id⟩) := by
  cases d <;> rfl

theorem decodeExpr_unary_not :
    decodeExpr (Lean.Json.mkObj [
      ("tag", Lean.Json.str "unary"),
      ("op", Lean.Json.mkObj [("tag", Lean.Json.str "not")]),
      ("x", Lean.Json.mkObj [("tag", Lean.Json.str "now")])
    ]) = .ok (.unary .not .now) := by
  rfl

theorem decodeExpr_binary_and :
    decodeExpr (Lean.Json.mkObj [
      ("tag", Lean.Json.str "binary"),
      ("op", Lean.Json.mkObj [("tag", Lean.Json.str "and")]),
      ("x", Lean.Json.mkObj [("tag", Lean.Json.str "now")]),
      ("y", Lean.Json.mkObj [("tag", Lean.Json.str "now")])
    ]) = .ok (.binary .and .now .now) := by
  rfl

theorem decodeExpr_ite :
    decodeExpr (Lean.Json.mkObj [
      ("tag", Lean.Json.str "ite"),
      ("condition", Lean.Json.mkObj [("tag", Lean.Json.str "now")]),
      ("yes", Lean.Json.mkObj [("tag", Lean.Json.str "now")]),
      ("no", Lean.Json.mkObj [("tag", Lean.Json.str "now")])
    ]) = .ok (.ite .now .now .now) := by
  rfl

end DefiKernel.Certificates
