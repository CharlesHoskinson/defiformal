import DefiKernel.Certificates.Decode
import DefiKernel.Certificates.Correspondence

open DefiKernel.Certificates

theorem testTyped (env : EnvelopeEnc) (payload : TypedExecutePayloadEnc)
    (h_ver : env.schema_version = 1)
    (h_mode : env.mode = "typed-execute")
    (h_sm : env.source_map = [])
    (h_cns : env.claimed_next_state = none)
    (h_reg_can : RegistryCanonical payload.config.registry)
    (h_env_can : EnvCanonical payload.env)
    (h_req_can : RequestCanonical payload.request)
    (h_state_valid : ∀ c ∈ payload.state.cells, c.amount.den ≠ 0 ∧ Int.gcd c.amount.num.natAbs c.amount.den = 1 ∧ c.amount.num ≥ 0)
    (h_state_unique : (payload.state.cells.map (fun c => (c.domain, c.party, c.asset))).eraseDups.length = payload.state.cells.length)
    (raw : String) :
    ((do
      let env_dec ← decodeEnvelope (envelopeSortedFields env (typedExecutePayloadToJson payload))
      let payloadJ ← getField (envelopeSortedFields env (typedExecutePayloadToJson payload)) "payload"
      match env_dec.mode with
      | "typed-execute" =>
        let payload_dec ← decodeTypedExecutePayload payloadJ
        Except.ok (DecodedIR.execution (.typed env_dec payload_dec))
      | "composition-step" =>
        let payload_dec ← decodeCompositionStepPayload payloadJ
        Except.ok (DecodedIR.execution (.step env_dec payload_dec))
      | "composition-run" =>
        let payload_dec ← decodeCompositionRunPayload payloadJ
        Except.ok (DecodedIR.execution (.run env_dec payload_dec))
      | "codec" => Except.ok (DecodedIR.codec ⟨some env_dec, raw⟩)
      | "audit" =>
        let payload_dec ← decodeAuditPayload env_dec payloadJ true
        Except.ok (DecodedIR.audit payload_dec)
      | s => Except.error (.unknownIdentifier s)) : Except DecodeFailure DecodedIR) = Except.ok (DecodedIR.execution (.typed env payload)) := by
  have h_env := decodeEnvelope_sortedFields env (typedExecutePayloadToJson payload) h_ver h_sm h_cns
  have h_p := decodeTypedExecutePayload_typedExecutePayloadToJson payload h_reg_can h_env_can h_req_can h_state_valid h_state_unique
  rw [h_env]
  dsimp [bind, Except.bind]
  have h_fld : getField (envelopeSortedFields env (typedExecutePayloadToJson payload)) "payload" = .ok (typedExecutePayloadToJson payload) := rfl
  rw [h_fld]
  dsimp [bind, Except.bind]
  rw [h_mode]
  change (match "typed-execute" with
    | "typed-execute" =>
      match decodeTypedExecutePayload (typedExecutePayloadToJson payload) with
      | .ok payload_dec => Except.ok (DecodedIR.execution (.typed env payload_dec))
      | .error e => Except.error e
    | _ => _) = Except.ok (DecodedIR.execution (.typed env payload))
  rfl
