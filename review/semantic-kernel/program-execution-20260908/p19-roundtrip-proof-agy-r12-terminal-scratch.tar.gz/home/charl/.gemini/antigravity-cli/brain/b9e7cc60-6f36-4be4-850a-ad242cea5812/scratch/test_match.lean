def testMatch (s : String) (p : Nat) : Nat :=
  match s with
  | "typed-execute" => p + 1
  | "composition-step" => p + 2
  | _ => 0

theorem testMatch_eq (s : String) (p : Nat) (h : s = "typed-execute") : testMatch s p = p + 1 := by
  rw [h]
  rfl
