import DefiKernel.Certificates.Tests
open DefiKernel.Certificates.Tests

def main : IO Unit := do
  let results := runtimeChecks
  let mut allPassed := true
  for (name, passed) in results do
    if passed then
      IO.println s!"PASS: {name}"
    else
      IO.println s!"FAIL: {name}"
      allPassed := false
  if allPassed then
    IO.println "ALL 21 RUNTIME CHECKS PASSED"
  else
    IO.Process.exit 1
