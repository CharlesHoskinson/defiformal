import json
import hashlib
from pathlib import Path

repo_root = Path("/home/charl/defiformal-wt-p19-certificates-grok-opus-20260909")

tracked_files = [
    "lean/DefiKernel/Certificates/Schema.lean",
    "lean/DefiKernel/Certificates/Decode.lean",
    "lean/DefiKernel/Certificates/Encode.lean",
    "lean/DefiKernel/Certificates/CanonicalJson.lean",
    "lean/DefiKernel/Certificates/Check.lean",
    "lean/DefiKernel/Certificates/Observation.lean",
    "lean/DefiKernel/Certificates/Correspondence.lean",
    "lean/DefiKernel/Certificates/Soundness.lean",
    "lean/DefiKernel/Certificates/Verify.lean",
    "lean/DefiKernel/Certificates/Audit.lean",
    "lean/DefiKernel/Certificates/Tests.lean",
    "lean/DefiKernel/Certificates/RunFixtures.lean",
    "scripts/run_certificate_fixtures.py",
    "scripts/test_certificate_fixture_runner.py",
    "scripts/run_certificate_mutations.py",
    "scripts/test_certificate_mutation_runner.py",
    "scripts/run_all_p19_mutations.py"
]

sources_dict = {}

for rel in tracked_files:
    p = repo_root / rel
    data = p.read_bytes()
    sha = hashlib.sha256(data).hexdigest()
    lines = len(data.splitlines())
    sources_dict[rel] = {
        "sha256": sha,
        "bytes": len(data),
        "lines": lines
    }

manifest = {
    "schema": "defiformal-p19-source-manifest/v2",
    "timestamp_utc": "2026-09-10T16:45:00Z",
    "git_head": "38de83c58e3f9315bf400807591d538d7565152e",
    "lean_version": "Lean (version 4.33.0-rc2, x86_64-unknown-linux-gnu, commit d8b18978322de05a8f3dba51ef03cf5461676c17, Release)",
    "lean_executable": "/home/charl/.elan/toolchains/leanprover--lean4---v4.33.0-rc2/bin/lean",
    "cwd": "/home/charl/defiformal-wt-p19-certificates-grok-opus-20260909/lean",
    "sources": sources_dict
}

out_path = repo_root / "scratch/source-manifest.json"
out_path.write_text(json.dumps(manifest, indent=2))
print(f"Wrote {out_path}")
