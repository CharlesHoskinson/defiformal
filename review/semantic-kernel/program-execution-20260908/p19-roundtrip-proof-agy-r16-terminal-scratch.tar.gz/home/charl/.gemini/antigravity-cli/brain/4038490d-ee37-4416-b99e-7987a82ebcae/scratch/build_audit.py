import re
import json
import subprocess
from pathlib import Path

repo_root = Path("/home/charl/defiformal-wt-p19-certificates-grok-opus-20260909")
lean_dir = repo_root / "lean"

files = [
    lean_dir / "DefiKernel/Certificates/CanonicalJson.lean",
    lean_dir / "DefiKernel/Certificates/Correspondence.lean"
]

all_theorems = []

for f in files:
    content = f.read_text()
    rel_path = f.relative_to(repo_root)
    # Match theorem names including ? and '
    matches = re.finditer(r"^theorem\s+([A-Za-z0-9_'\?]+)\s*(.*?)(?::=|\bby\b)", content, re.MULTILINE | re.DOTALL)
    for m in matches:
        name = m.group(1)
        raw_stmt = m.group(2).strip()
        stmt = re.sub(r"\s+", " ", raw_stmt)
        all_theorems.append({
            "name": f"DefiKernel.Certificates.{name}",
            "raw_name": name,
            "file": str(rel_path),
            "statement": stmt
        })

print(f"Total theorems extracted: {len(all_theorems)}")
canon_count = sum(1 for t in all_theorems if "CanonicalJson" in t["file"])
corr_count = sum(1 for t in all_theorems if "Correspondence" in t["file"])
print(f"CanonicalJson theorems: {canon_count}")
print(f"Correspondence theorems: {corr_count}")

# Build query script
query_script_lines = [
    "import DefiKernel.Certificates.CanonicalJson",
    "import DefiKernel.Certificates.Correspondence",
    ""
]

for t in all_theorems:
    query_script_lines.append(f"#print axioms {t['name']}")

lean_code = "\n".join(query_script_lines)

res = subprocess.run(
    ["lake", "env", "lean", "--stdin"],
    cwd=str(lean_dir),
    input=lean_code,
    capture_output=True,
    text=True
)

if res.returncode != 0:
    print(f"Lean returned error: {res.stderr}")

probe_output = res.stdout.strip()

# Run Verify.lean
verify_res = subprocess.run(
    ["lake", "env", "lean", "DefiKernel/Certificates/Verify.lean"],
    cwd=str(lean_dir),
    capture_output=True,
    text=True
)

if verify_res.returncode != 0:
    print(f"Verify.lean returned error: {verify_res.stderr}")

verify_output = verify_res.stdout.strip()

# Combined audit log
header_probe = f"=== NAMED DECLARATIONS AXIOM PROBE ({len(all_theorems)} THEOREMS) ==="
header_verify = "=== TRANSITIVE COMPILER AXIOM AUDIT (Verify.lean) ==="

full_audit_log = f"{header_probe}\n{probe_output}\n\n\n{header_verify}\n{verify_output}\n"

audit_log_path = repo_root / "scratch/compiler-axiom-audit.log"
audit_log_path.parent.mkdir(parents=True, exist_ok=True)
audit_log_path.write_text(full_audit_log)
print(f"Wrote full audit log to {audit_log_path}")

# Parse axiom lines from probe_output
# Normalize newlines inside brackets
normalized_probe = re.sub(r"\[\s*([^\]]*?)\s*\]", lambda m: "[" + " ".join(m.group(1).split()) + "]", probe_output)

standard_axioms = {"propext", "Classical.choice", "Quot.sound"}

# Parse map
axiom_map = {}
for line in normalized_probe.split("\n"):
    line = line.strip()
    m1 = re.search(r"'([^']+)'\s+depends on axioms:\s*\[(.*?)\]", line)
    if m1:
        th_name = m1.group(1)
        axs = [a.strip() for a in m1.group(2).split(",") if a.strip()]
        axiom_map[th_name] = axs
        continue
    m2 = re.search(r"'([^']+)'\s+does not depend on any axioms", line)
    if m2:
        th_name = m2.group(1)
        axiom_map[th_name] = []
        continue

theorems_record = []
forbidden_count = 0
missing_count = 0

for t in all_theorems:
    name = t["name"]
    if name not in axiom_map:
        print(f"ERROR: Axioms not found for {name}")
        missing_count += 1
        axs = []
    else:
        axs = axiom_map[name]
    is_std = all(a in standard_axioms for a in axs)
    if not is_std:
        print(f"WARNING: Non-standard axioms in {name}: {axs}")
        forbidden_count += 1
    theorems_record.append({
        "name": name,
        "file": t["file"],
        "statement": t["statement"],
        "axioms": axs,
        "standard_only": is_std
    })

print(f"Missing axioms count: {missing_count}")
print(f"Forbidden axioms count: {forbidden_count}")

data = {
    "schema": "defiformal-p19-theorems/v3",
    "theorems_count": len(theorems_record),
    "canonical_json_theorems_count": canon_count,
    "correspondence_theorems_count": corr_count,
    "standard_axioms_only": (forbidden_count == 0 and missing_count == 0),
    "forbidden_axioms_count": forbidden_count,
    "modules": [
        "DefiKernel.Certificates.Correspondence",
        "DefiKernel.Certificates.CanonicalJson"
    ],
    "theorems": theorems_record
}

out_json = repo_root / "scratch/theorems.json"
out_json.write_text(json.dumps(data, indent=2))
print(f"Wrote {out_json} with {len(theorems_record)} theorems, forbidden_count={forbidden_count}, missing={missing_count}")
