import re
import json
import subprocess
from pathlib import Path

repo_root = Path("/home/charl/defiformal-wt-p19-certificates-grok-opus-20260909")
lean_dir = repo_root / "lean"

files = [
    lean_dir / "DefiKernel/Certificates/CanonicalJson.lean",
    lean_dir / "DefiKernel/Certificates/Correspondence.lean"
]

all_theorems = []

for f in files:
    content = f.read_text()
    rel_path = f.relative_to(repo_root)
    # Find all theorem lines: theorem <name>
    matches = re.finditer(r"^theorem\s+([A-Za-z0-9_']+)\s*(.*?)(?::=|\bby\b)", content, re.MULTILINE | re.DOTALL)
    for m in matches:
        name = m.group(1)
        stmt = m.group(2).strip()
        all_theorems.append({
            "name": f"DefiKernel.Certificates.{name}",
            "raw_name": name,
            "file": str(rel_path),
            "statement": stmt
        })

print(f"Total theorems extracted: {len(all_theorems)}")
canon_count = sum(1 for t in all_theorems if "CanonicalJson" in t["file"])
corr_count = sum(1 for t in all_theorems if "Correspondence" in t["file"])
print(f"CanonicalJson theorems: {canon_count}")
print(f"Correspondence theorems: {corr_count}")
