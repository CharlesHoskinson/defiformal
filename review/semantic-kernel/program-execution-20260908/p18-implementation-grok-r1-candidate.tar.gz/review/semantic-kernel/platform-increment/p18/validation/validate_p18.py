#!/usr/bin/env python3
"""P18 packet and example validation.

Schema validity is not proof, not source execution, and not acceptance.
Missing evidence or a zero denominator is blocked (exit 3), not success.
"""
from __future__ import annotations

import hashlib
import json
import sys
from pathlib import Path

from jsonschema import Draft202012Validator

ROOT = Path(__file__).resolve().parents[5]
SCHEMA = ROOT / "openspec/changes/reusable-verification-platform-program/contracts/evidence-packet.schema.json"
PACKETS = ROOT / "review/semantic-kernel/platform-increment/p18/packets"
FIXTURES = ROOT / "review/semantic-kernel/platform-increment/p18/validation/fixtures"
OLD_EXAMPLES = ROOT / "openspec/changes/reusable-verification-platform-program/contracts/examples"
USAGE = ROOT / "openspec/changes/reusable-verification-platform-program/contracts/evidence-packet-usage.md"

OLD_PACKET_HASHES = {
    "empty-denominator-blocked.packet.json": "04826ff3fb466211366ccb643eec1be4646b954a4922c6d5b6f7788fbf1783c1",
    "illustrative-not-credited.packet.json": "cf610eb2527d1fd2822cecb72d28bb8fda3896b097a149720e930886fbff5192",
    "token0-unexecuted-incomplete.packet.json": "9c3ea55a13792c089da218ccecf32f6b80dfa81d3c0c6649240cc9640ec065a4",
}


def sha256_file(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def fail(msg: str, failures: list[str]) -> None:
    failures.append(msg)


def check_packet_semantics(path: Path, packet: dict, failures: list[str]) -> dict:
    parts = packet["executions"]["partitions"]
    nonempty = sum(1 for p in parts if p["nonempty"])
    empty = sum(1 for p in parts if not p["nonempty"])
    declared = len(parts)
    d = packet["denominators"]["partitions"]
    if d["declared"] != declared or d["nonempty"] != nonempty or d["empty"] != empty:
        fail(f"{path.name}: partitions {d} != declared={declared} nonempty={nonempty} empty={empty}", failures)
    for p in parts:
        if p["nonempty"] and p["count"] < 1:
            fail(f"{path.name}: nonempty {p['id']} count {p['count']}", failures)
        if (not p["nonempty"]) and p["count"] != 0:
            fail(f"{path.name}: empty {p['id']} count {p['count']}", failures)
        if p["count"] != len(p.get("cases") or []):
            fail(f"{path.name}: {p['id']} count != len(cases)", failures)
    if packet["packet_status"] in {"illustrative", "blocked", "incomplete"} and packet["credit_eligible"]:
        fail(f"{path.name}: non-reviewed status with credit_eligible true", failures)
    mut = packet["denominators"]["mutations"]
    runs = packet["denominators"]["executions"]
    complete_ok = (
        packet["packet_id"] == "p18.token0.next-price.accepted-p16-increment"
        and nonempty > 0
        and runs["actually_run"] > 0
        and mut["compiled_production"] > 0
        and mut["unaffected_controls"] > 0
    )
    if packet["packet_id"] == "p18.token0.next-price.accepted-p16-increment":
        if nonempty == 0 or runs["actually_run"] == 0:
            fail(f"{path.name}: main packet has empty execution denominator", failures)
        if mut["compiled_production"] != 6 or mut["unaffected_controls"] != 6:
            fail(f"{path.name}: main packet mutants {mut}", failures)
        if packet["credit_eligible"] is True:
            fail(f"{path.name}: author set credit_eligible true before Opus review", failures)
        if packet["independent_verdict"]["verdict"] != "pending":
            fail(f"{path.name}: P18 independent verdict is not pending", failures)
        if packet["independent_verdict"]["requested_model"] != "opus":
            fail(f"{path.name}: requested_model is not opus", failures)
        if packet["independent_verdict"]["reported_model"] is not None:
            fail(f"{path.name}: reported_model must remain null until Opus returns", failures)
        for cls in packet["obligation_classes"]:
            if cls["class"] == "source_refinement" and cls["status"] != "open":
                fail("source_refinement is not open", failures)
            if cls["class"] == "representation_correspondence" and cls["status"] != "open":
                fail("representation_correspondence is not open", failures)
        src = ROOT / packet["identities"]["source"]["path"]
        model = ROOT / packet["identities"]["model"]["path"]
        if not src.is_file():
            fail(f"main packet source missing {src}", failures)
        elif sha256_file(src) != packet["identities"]["source"]["sha256"]:
            fail("main packet source hash mismatch", failures)
        if not model.is_file():
            fail(f"main packet model missing {model}", failures)
        elif sha256_file(model) != packet["identities"]["model"]["sha256"]:
            fail("main packet model hash mismatch", failures)
        for th in packet["theorem_evidence"]["theorems"]:
            tpath = ROOT / th["path"]
            if not tpath.is_file():
                fail(f"theorem path missing {tpath}", failures)
            elif sha256_file(tpath) != th["sha256"]:
                fail(f"theorem hash mismatch {th['name']}", failures)
        for ref in (
            "review/semantic-kernel/program-execution-20260908/p16-source-candidate-r6.tar.gz",
            "review/semantic-kernel/program-execution-20260908/p16-proof-recorder-candidate-r2.tar.gz",
            "review/semantic-kernel/program-execution-20260908/P16-SOURCE-ACCEPTANCE.md",
            "review/semantic-kernel/program-execution-20260908/P16-PROOF-RECORDER-ACCEPTANCE.md",
        ):
            if not (ROOT / ref).is_file():
                fail(f"missing bound archive/acceptance {ref}", failures)
    return {
        "path": path.name,
        "nonempty": nonempty,
        "actually_run": runs["actually_run"],
        "compiled_production": mut["compiled_production"],
        "unaffected_controls": mut["unaffected_controls"],
        "complete_operation_shape": complete_ok,
        "credit_eligible": packet["credit_eligible"],
    }


def main() -> int:
    failures: list[str] = []
    checks: list[dict] = []
    blocked_controls: list[str] = []
    schema = json.loads(SCHEMA.read_text())
    Draft202012Validator.check_schema(schema)
    validator = Draft202012Validator(schema)
    packets = sorted(PACKETS.glob("*.packet.json"))
    if not packets:
        fail("no packets", failures)
        print(json.dumps({"ok": False, "failures": failures}, indent=2))
        return 3

    p17 = [p for p in packets if "p17" in p.name.lower()]
    if p17:
        fail(f"P17 packets present while P17 is open: {[p.name for p in p17]}", failures)

    summaries = []
    for path in packets:
        packet = json.loads(path.read_text())
        errs = sorted(validator.iter_errors(packet), key=lambda e: list(e.path))
        if errs:
            for e in errs:
                fail(f"{path.name} schema: {e.message} at {list(e.path)}", failures)
            checks.append({"name": f"packet:{path.name}", "status": "schema_fail"})
            continue
        summaries.append(check_packet_semantics(path, packet, failures))
        checks.append({"name": f"packet:{path.name}", "status": "schema_ok"})
        if packet["packet_id"] == "p18.control.missing-evidence-blocked":
            missing = ROOT / packet["identities"]["source"]["path"]
            if missing.is_file():
                fail("missing-evidence control path unexpectedly exists", failures)
            else:
                blocked_controls.append("missing-evidence-path-absent")
            if packet["credit_eligible"] or packet["denominators"]["executions"]["actually_run"] != 0:
                fail("missing-evidence control granted run/credit", failures)
        if packet["packet_id"] == "p18.control.empty-denominator-blocked":
            if packet["denominators"]["partitions"]["nonempty"] != 0:
                fail("empty-denominator control is nonempty", failures)
            else:
                blocked_controls.append("empty-denominator-nonempty-0")
            if packet["credit_eligible"]:
                fail("empty-denominator control credit_eligible true", failures)

    invalid = json.loads((FIXTURES / "credit-self-assert.invalid.json").read_text())
    invalid_errs = list(validator.iter_errors(invalid))
    if not invalid_errs:
        fail("credit-self-assert.invalid.json was accepted by schema", failures)
    else:
        checks.append({"name": "negative_credit_self_assert", "count": len(invalid_errs), "status": "rejected_as_required"})
        blocked_controls.append("self-credit-schema-rejected")

    for name, expected in OLD_PACKET_HASHES.items():
        path = OLD_EXAMPLES / name
        if not path.is_file():
            fail(f"old illustrative packet missing {name}", failures)
            continue
        actual = sha256_file(path)
        if actual != expected:
            fail(f"old packet rewritten {name}: {actual}", failures)
        else:
            checks.append({"name": f"preserved:{name}", "status": "unchanged"})

    if not USAGE.is_file() or USAGE.stat().st_size == 0:
        fail("usage contract missing", failures)

    example = ROOT / "examples/platform-increment/lean/Token0ReleaseExample.lean"
    if not example.is_file() or example.stat().st_size == 0:
        fail("example Lean missing", failures)
    readme = ROOT / "examples/platform-increment/README.md"
    if "lake env lean" not in readme.read_text():
        fail("README missing lake env lean invocation", failures)
    if "/home/charl/.cache" in readme.read_text() or "/home/charl/defiformal-wt-" in (ROOT / "examples/platform-increment/environment.example.json").read_text():
        fail("API files bake a private path", failures)

    env_example = json.loads((ROOT / "examples/platform-increment/environment.example.json").read_text())
    for key in ("lake", "lean", "solc", "evm", "repository_root"):
        if env_example.get(key) not in (None,):
            fail(f"environment.example.json {key} is not null", failures)

    expected_obs = json.loads((ROOT / "examples/platform-increment/expected/token0-observations.json").read_text())
    if expected_obs["count"] != 12 or not expected_obs["rows"]:
        fail("expected observations empty", failures)
    if expected_obs["count"] != len(expected_obs["rows"]):
        fail("expected count mismatch", failures)

    semantic_credit = False
    main_summaries = [s for s in summaries if s["path"] == "p18.token0.next-price.packet.json"]
    if main_summaries and main_summaries[0]["credit_eligible"]:
        semantic_credit = True
        fail("validator must not treat the pending packet as credited", failures)

    if not blocked_controls:
        fail("missing/empty/self-credit controls did not fire", failures)

    result = {
        "validator": "review/semantic-kernel/platform-increment/p18/validation/validate_p18.py",
        "schema_validity_is_not_proof": True,
        "semantic_credit": semantic_credit,
        "packet_count": len(packets),
        "checks": checks,
        "check_count": len(checks),
        "blocked_controls": blocked_controls,
        "summaries": summaries,
        "failure_count": len(failures),
        "failures": failures,
        "ok": len(failures) == 0,
        "exit_meaning": "0 structural+link checks passed with credit false; 1 claim false; 3 blocked",
    }
    print(json.dumps(result, indent=2))
    if failures:
        if any("missing" in f and "main packet" in f for f in failures):
            return 3
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
