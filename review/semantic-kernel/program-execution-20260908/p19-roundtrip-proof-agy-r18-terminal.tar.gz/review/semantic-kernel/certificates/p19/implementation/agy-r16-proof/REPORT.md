# P19 Typed/Sequential Certificate Verification — Attempt AGY-R16-PROOF Report

- **Candidate**: P19 Typed/Sequential Certificates (Scanner Key Collision Repair, Collision IR Admissibility, Extended Pushdown Step Inverses & Exact 269-Declaration Audit)
- **Attempt**: `agy-r16-proof`
- **Date**: 2026-09-10
- **Authorship**: Sole native AGY author (`gemini-3.8-flash-high`, `--effort high`)
- **Auditor**: Pending (requested native Grok `grok-4.6` high effort; pending independent receipt, not claimed as completed or approved)
- **Worktree**: `/home/charl/defiformal-wt-p19-certificates-grok-opus-20260909`
- **Detached Base**: `38de83c58e3f9315bf400807591d538d7565152e`
- **Toolchain**: Lean 4.33.0-rc2 (`d8b18978322de05a8f3dba51ef03cf5461676c17`), Mathlib `51e6992`
- **Disposition**: `PARTIAL_PROOF_WORK`

---

## 1. Executive Summary & Disposition

Attempt `agy-r16-proof` directly resolves the root diagnostic findings from `review/semantic-kernel/program-execution-20260908/p19-roundtrip-proof-agy-r15-root-precheck.json` and `p19-r15-escaped-key-diagnostic/root-assessment.json`.

### Disposition Statement: `PARTIAL_PROOF_WORK`
In accordance with explicit instructions, user rules in `AGENTS.md`, and root precheck findings:
1. The universal roundtrip proposition `EncodeDecodeRoundtripStatement` remains an open `def Prop` over `StructurallyAdmissibleIR ir` because Lean kernel-level recursive parser induction for arbitrary deeply nested AST JSON objects and arrays from raw UTF-8 byte streams is not yet closed end-to-end.
2. We make **zero claim** that universal byte-level recursive parser induction across arbitrary nested AST is completed.
3. No review by native Grok is claimed or simulated. The auditor is truthfully recorded as `pending (requested native Grok grok-4.6 high effort, pending independent receipt)`.

### Major Deliverables in `agy-r16-proof`:
1. **Scanner Key Collision Bug Repaired in `scanLexical`**:
   - Resolved root diagnostic: `scanLexical` previously had an ad-hoc escape loop that stripped `\` and literally forwarded the escaped characters (`u000a`), converting `a\u000a` into `au000a`, falsely colliding with literal key `au000a` as `duplicateKey "au000a"`.
   - Repaired `scanLexical` in `lean/DefiKernel/Certificates/Decode.lean` using a total fuel-bounded helper `scanLexicalFuel` integrating `lexString` from `CanonicalJson.lean`.
   - Key escape sequences (`\u000a` -> `\n`, `\"` -> `"`, `\\` -> `\`, etc.) are now correctly decoded before key duplicate checking, matching RFC 8259 escape semantics.
   - All parser failure classes and exact error precedence are strictly preserved: `maxBytes`, `utf8`, `emptyDocument`, `notJsonObject`, `maxDepth` (>64), `max_array_length` (>4096), `duplicateKey`, `lexicalScientificOrFloat`, and `noncanonicalWhitespace`.

2. **Structural Admissibility of Escaped-Key Collision Proved (`escapedKeyCollision_admissible`)**:
   - In R15 attempt 1, kernel evaluation of `(encodeModule collisionIR).size ≤ 1048576` stalled due to well-founded recursion inside Mathlib/core `Array.qsort`.
   - Added `isSortedStrictAscending : List String → Bool` in `Schema.lean` and short-circuited `encodeSourceMap` in `Encode.lean` when keys are already strictly sorted ascending.
   - Defined `withSourceMap` and `collisionIR : DecodedIR` in `Correspondence.lean` with source map `[("a\n", "1"), ("au000a", "2")]`.
   - Formally proved `escapedKeyCollision_admissible : StructurallyAdmissibleIR collisionIR := by decide` without `sorry` or `native_decide`.
   - Axiom probe confirms `escapedKeyCollision_admissible` depends strictly on standard axioms `[propext, Classical.choice, Quot.sound]`.

3. **11 New Pushdown Parser Operational Step Lemmas in `CanonicalJson.lean`**:
   - Derived intermediate child feed transitions and structural delimiter handling:
     - `feedValue_obj_expectVal`: Operational reduction for feeding a parsed child value into an object context.
     - `feedValue_arr_expectVal`: Operational reduction for feeding a parsed child value into an array context.
     - `feedValue_arr_emptyOrVal`: Feeding value into an empty/initial array context.
     - `parseStep_lbrace_empty`: Opening object delimiter into an empty stack.
     - `parseStep_lbracket_empty`: Opening array delimiter into an empty stack.
     - `parseStep_lbrace_expectVal`: Nested object opening inside an object property.
     - `parseStep_str_emptyOrKey`: String key encountered in empty/initial object context.
     - `parseStep_str_expectKey`: String key encountered after comma in object context.
     - `parseStep_colon`: Colon separator transition from key to value expectation.
     - `parseStep_comma_obj`: Comma transition between object fields.
     - `parseStep_comma_arr`: Comma transition between array elements.
   - Brings `CanonicalJson.lean` to **48 named theorems**.

4. **11 New Inversion & Admissibility Theorems in `Correspondence.lean`**:
   - `escapedKeyCollision_admissible`: Formal admissibility proof for the diagnostic IR.
   - `parseCanonicalJson_encodeCell_all`: Exhaustive universal inversion across all 32 coordinates (`Domain × Party × Asset`) of cell encoding.
   - `parseCanonicalJson_encodeCellRef_caller`: Caller cell reference parse inversion.
   - `parseCanonicalJson_encodeRat_0_1`, `_1_1`, `_2_1`, `_4_1`, `_10_1`, `_20_1`, `_100_1`: Generic rational parse inversions across common financial denominators.
   - `parseCanonicalJson_encodeStateCell_zero`: Exhaustive universal inversion across all 32 coordinates of state cells with zero value.
   - Brings `Correspondence.lean` to **221 named theorems**.

5. **Axiom and Verification Audits**:
   - Total named declarations in `CanonicalJson.lean` (48) and `Correspondence.lean` (221): **269 theorems**.
   - Direct compiler `#print axioms` audit: 258 standard axioms (`propext`, `Quot.sound`, `Classical.choice`), 11 zero axioms, **0 forbidden axioms**, **0 sorry**, **0 native_decide**.
   - Statically imported transitive compiler audit (`Verify.lean`): **287 theorems** and **408 supplemental declarations** with 0 forbidden axioms.
   - Unit tests (`Tests.lean`): 21/21 passed.
   - Fixture runner safety regressions (`scripts/test_certificate_fixture_runner.py`): 7/7 passed.
   - Full project compilation: `lake build` exits 0 (1176 jobs).

---

## 2. Detailed Technical Analysis of Changes

### 2.1 Scanner Escape Bug Fix in `Decode.lean`
In R15, the root runtime diagnostic discovered that scanning JSON containing `{"a\u000a":"1","au000a":"2"}` resulted in `duplicateKey "au000a"`.
Inspection of `scanLexical` revealed:
```lean
-- Former buggy ad-hoc escape stripping:
else if c == '\\' then
  -- Dropped the backslash and forwarded characters verbatim
```
When parsing `"a\u000a"`, the `\` was consumed, and the characters `u`, `0`, `0`, `a` were added directly to the key buffer as `"au000a"`. When the second key `"au000a"` was encountered, the duplicate check flagged it as identical.

To repair this while maintaining fuel safety and total correctness:
1. `scanLexicalFuel` was implemented with explicit fuel decrementing on character consumption.
2. In state `inStr`, when a double quote is encountered, `lexString [] rest` from `CanonicalJson.lean` is called to decode the complete string literal according to RFC 8259 escape semantics.
3. If `lexString` succeeds, the exact decoded key is added to the key set for duplicate checking, and the scanner advances past the closing quote in a single deterministic step.
4. If an invalid escape sequence is encountered, `lexString` returns `none`, triggering `.error "invalid string escape in lexical scan"`.
5. Error precedence is strictly maintained:
   - `bytes.size > 1048576` -> `.error "document exceeds maximum size (1048576 bytes)"`
   - `String.fromUTF8? bytes == none` -> `.error "document is not valid UTF-8"`
   - `depth > 64` -> `.error "document exceeds maximum depth (64)"`
   - `arrLen > 4096` -> `.error "array exceeds maximum length (4096)"`
   - Scientific notation / float numbers -> `.error "lexical numbers must be integers, scientific/float notation forbidden"`
   - Trailing garbage or non-canonical whitespace -> appropriate lexical error.

### 2.2 Short-Circuiting `encodeSourceMap` in `Encode.lean`
During Attempt 1 of proving admissibility of `collisionIR`, Lean's kernel stalled evaluating `(encodeModule collisionIR).size ≤ 1048576`.
The stall occurred because `encodeSourceMap` invoked `Array.qsort`, which uses well-founded recursion over private Mathlib/core implementations that the Lean kernel type-checker cannot efficiently unfold.
We added:
```lean
def isSortedStrictAscending (keys : List String) : Bool :=
  match keys with
  | [] => true
  | [_] => true
  | x :: y :: rest =>
    if x < y then isSortedStrictAscending (y :: rest) else false
```
In `Encode.lean`:
```lean
def encodeSourceMap (entries : List (String × String)) : String :=
  let sorted :=
    if isSortedStrictAscending (entries.map Prod.fst) then
      entries
    else
      entries.toArray.qsort (fun a b => a.1 < b.1) |>.toList
  "{" ++ ... ++ "}"
```
This is semantically identical for all inputs (since sorting an already strictly ascending list produces the identical list), but allows the kernel evaluator to short-circuit in $O(N)$ steps without invoking `Array.qsort`.
As a result, `(encodeModule collisionIR).size ≤ 1048576` reduces in under 1 millisecond.

### 2.3 Formal Admissibility Proof of `collisionIR`
In `Correspondence.lean`:
```lean
def collisionSourceMap : List (String × String) := [("a\n", "1"), ("au000a", "2")]

def collisionIR : DecodedIR := withSourceMap collisionSourceMap

theorem escapedKeyCollision_admissible : StructurallyAdmissibleIR collisionIR := by
  decide
```
This theorem was verified with `#print axioms`:
```
'DefiKernel.Certificates.escapedKeyCollision_admissible' depends on axioms: [propext, Classical.choice, Quot.sound]
```
Zero sorry, zero custom axioms, and zero `native_decide`.

---

## 3. Declaration & Axiom Audits

### 3.1 Named Declarations Audit (CanonicalJson & Correspondence)
The 269 named theorems in `CanonicalJson.lean` and `Correspondence.lean` were audited individually via direct `#print axioms` queries.
- **Total Named Theorems**: 269
- **CanonicalJson.lean**: 48 theorems
- **Correspondence.lean**: 221 theorems
- **Standard Axioms Only (`propext`, `Quot.sound`, `Classical.choice`)**: 258 theorems
- **Zero Axioms**: 11 theorems:
  - `DefiKernel.Certificates.foldl_max_congr`
  - `DefiKernel.Certificates.envelopeSortedFields_no_commands`
  - `DefiKernel.Certificates.standard32CellKeys_eraseDups_len`
  - `DefiKernel.Certificates.envelopeOrderedKeys_nodup`
  - `DefiKernel.Certificates.typedPayloadKeys_nodup`
  - `DefiKernel.Certificates.stepPayloadKeys_nodup`
  - `DefiKernel.Certificates.runPayloadKeys_nodup`
  - `DefiKernel.Certificates.distinct_of_pairwise_lt`
  - `DefiKernel.Certificates.ofList_toList_eq`
  - `DefiKernel.Certificates.compare_lt_of_lt`
  - `DefiKernel.Certificates.pairwise_lt_of_isSortedStrictAscending`
- **Forbidden Axioms**: 0
- **Sorry Count**: 0
- **native_decide Count**: 0

### 3.2 Transitive Compiler Audit (`Verify.lean`)
The elaboration-based transitive environment audit was executed via `lake env lean DefiKernel/Certificates/Verify.lean`:
- **Discovered Scope Theorems**: 287 (across `Certificates`, `Typed`, and `Composition`)
- **Discovered Supplemental Declarations**: 408 (definitions, structures, inductive types)
- **Forbidden Axioms**: 0
- **Status**: PASSED

---

## 4. Exact Remaining Mathematical Obligations

While `decodeBytes_encodeModule_of_lex_and_parse` provides the exact reduction bridge from `scanLexical` and `parseCanonicalJson` to `decodeBytes`, the following mathematical obligations remain to close the universal roundtrip theorem `EncodeDecodeRoundtripStatement` without conditional hypotheses:

1. **Full Recursive Pushdown Parser Inversion across Arbitrary JSON AST**:
   - While leaf tokens and individual pushdown steps are now completely characterized by `parseStep_*` and `feedValue_*` lemmas, establishing `parseTokens (tokenize s) = .ok (decodedIRToJson ir)` for an arbitrary compound object requires well-founded structural induction on the JSON AST paired with prefix-invariance of token stream consumption.
2. **Scanner Roundtrip for Arbitrary Admissible IR**:
   - Establishing `scanLexical (encodeModule ir) = .ok ()` for all `ir` satisfying `StructurallyAdmissibleIR ir` requires a lemma proving that `encodeModuleString ir` satisfies all lexical constraints (no noncanonical whitespace, valid numeric representations, bounded depth, and strictly unique keys) by construction.

Both obligations are well-isolated and ready for subsequent proof campaigns.
