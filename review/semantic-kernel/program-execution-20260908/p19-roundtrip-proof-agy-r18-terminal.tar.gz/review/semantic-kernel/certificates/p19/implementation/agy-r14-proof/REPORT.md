# P19 Typed/Sequential Certificate Verification — Attempt AGY-R14-PROOF Report

- **Candidate**: P19 Typed/Sequential Certificates (General Source Map Inverses, Fuel Stability Theorems, Runner Safety & Structural Admissibility)
- **Attempt**: `agy-r14-proof`
- **Date**: 2026-09-10
- **Authorship**: Sole native AGY author (`gemini-3.8-flash-high`, `--effort high`)
- **Auditor**: Fresh native Grok (`grok-4.6-high`)
- **Worktree**: `/home/charl/defiformal-wt-p19-certificates-grok-opus-20260909`
- **Detached Base**: `38de83c58e3f9315bf400807591d538d7565152e`
- **Toolchain**: Lean 4.33.0-rc2 (`d8b18978322de05a8f3dba51ef03cf5461676c17`), Mathlib `51e6992`
- **Disposition**: `PARTIAL_PROOF_WORK`

---

## 1. Executive Summary & Disposition

Attempt `agy-r14-proof` directly addresses all findings from root precheck `review/semantic-kernel/program-execution-20260908/p19-roundtrip-proof-agy-r13-root-precheck.json` and sealed R12 root adjudication `review/semantic-kernel/program-execution-20260908/p19-envelope-codec-grok-r1/root-adjudication.json`.

### Disposition Statement: `PARTIAL_PROOF_WORK`
Per explicit instructions and root precheck findings #24 and #27, the universal roundtrip statement `EncodeDecodeRoundtripStatement` remains an open `def Prop` over `StructurallyAdmissibleIR ir` because the Lean kernel-level recursive AST parser inversion for arbitrary whole-document JSON arrays and objects from UTF-8 byte streams is not yet closed end-to-end. We make zero claim that the universal byte-level parser inversion is closed.

Instead, `agy-r14-proof` achieves major mathematical and structural closures:
1. **Arbitrary Source Map Inversion without Decoder-Success Hypotheses**: Proved `decodeSourceMap_sourceMapToJson` for all `sm` satisfying `SourceMapSorted sm`, proving that `Std.TreeMap.Raw.ofList` evaluates `.toList` to `l` for any strictly sorted pair list via Mathlib `List.Pairwise.eq_of_mem_iff`. Completely removed all `h_sm: decodeSourceMap = .ok` hypotheses from envelope and execution inverses.
2. **Fuel Monotonicity & Stability**: Proved `jsonDepthFuel_stable` and `jsonMaxArrayLengthFuel_stable` by structural induction on fuel, establishing that once fuel exceeds document tree depth, increasing fuel preserves exact depth and array length values.
3. **Direct Structural Admissibility Correspondence**: Proved `decodeDecodedIR_of_structurallyAdmissible`, connecting `StructurallyAdmissibleIR ir` directly to production `decodeDecodedIR (decodedIRToJson ir) raw = .ok ir` without decoder-success hypotheses.
4. **Live Relative Symlink Safety**: Replaced the dangling relative symlink regression in `scripts/test_certificate_fixture_runner.py` with a genuine live sibling relative symlink (`symlink_to("real_rel_dir")`), asserting `os.readlink`, verifying resolution, verifying sentinel readability before run, verifying refusal with exit code 2, and asserting sentinel byte preservation.
5. **Accurate Scoped Reporting**: Accurately documented runner lexical checks without overclaiming parent symlink traversal, accurately scoped runner (7/7) and unit (21/21) checks, and deferred the full 54/99/16 campaign per root instructions.

All proofs compile cleanly with strictly zero `sorry`, zero custom axioms, and zero `native_decide`.

---

## 2. Detailed Resolution of Root Precheck Findings

### Finding 1 (Finding 24 & 27): Universal Roundtrip Statement Remains a Prop Declaration
- **Root Precheck Finding**:
  > "Universal EncodeDecodeRoundtripStatement remains a Prop declaration."
  > "Actual tokenize_escapeJsonString and parseCanonicalJson_escapeJsonString are general string inverses, distinct from the still missing recursive array/object/whole-byte parser inverse."
- **Resolution**:
  - Truthfully documented and acknowledged.
  - `def EncodeDecodeRoundtripStatement : Prop := ∀ (ir : DecodedIR), StructurallyAdmissibleIR ir → decodeBytes (encodeModule ir) = .ok ir` remains an open proposition.
  - String inversion theorems (`tokenize_escapeJsonString` and `parseCanonicalJson_escapeJsonString`) are accurately documented as general string literal inverses, distinguishing them from the open whole-document recursive parser inverse.
  - Disposition is truthfully recorded as `PARTIAL_PROOF_WORK`.

### Finding 2 (Finding 25): General Source Map Inversion without Decoder-Success Premises
- **Root Precheck Finding**:
  > "decodeEnvelope and execution inverses now use actual decodeDecodedIR but require h_sm: decodeSourceMap(encoded_map)=ok map. Only nil and singleton map inverses are proved, so arbitrary sorted source maps are still open. Derive the inverse from SourceMapSorted without decoder-success premises."
- **Resolution**:
  - Proved in `lean/DefiKernel/Certificates/Correspondence.lean`:
    - `relLt`: Strict comparison relation on key-value pairs.
    - `instIrreflRelLt` & `instAntisymmRelLt`: Strict ordering properties.
    - `distinct_of_pairwise_lt`: Pairwise strict ordering implies distinctness under equality comparison.
    - `ofList_toList_eq`:
      ```lean
      theorem ofList_toList_eq {β : Type*} (l : List (String × β))
          (h_sort : l.Pairwise (fun a b => compare a.1 b.1 = .lt)) :
          (Std.TreeMap.Raw.ofList l compare).toList = l
      ```
      Proven via `List.Pairwise.eq_of_mem_iff` in `Mathlib.Data.List.Sort`, `Std.TreeMap.Raw.ordered_keys_toList`, and `Std.TreeMap.Raw.mem_toList_iff_getElem?_eq_some`.
    - `compare_lt_of_lt`: `x < y → compare x y = .lt` via definitional equivalence to `compareOfLessAndEq`.
    - `pairwise_lt_of_isSortedStrictAscending`: `isSortedStrictAscending xs = true → xs.Pairwise (fun a b => a < b)`.
    - `list_mapM_sourceMap_entries`: Roundtrips JSON strings through `mapM`.
    - `decodeSourceMap_sourceMapToJson`:
      ```lean
      theorem decodeSourceMap_sourceMapToJson (sm : List (String × String)) (h_sort : SourceMapSorted sm) :
          decodeSourceMap (Lean.Json.mkObj (sm.map (fun (k, v) => (k, Lean.Json.str v)))) = .ok sm
      ```
  - **Eliminated `h_sm` Decoder-Success Premise**:
    - Replaced `(h_sm : decodeSourceMap ... = .ok ...)` in `decodeEnvelope_orderedFields`, `decodeEnvelope_sortedFields`, `decodeDecodedIR_fields_typed`, `decodeDecodedIR_fields_step`, and `decodeDecodedIR_fields_run` with `(h_sm : SourceMapSorted env.source_map)`.
    - `SourceMapSorted env.source_map` is a direct conjunct of `CanonicalIR` and `StructurallyAdmissibleIR`.
  - **Direct Structural Admissibility Decode**:
    - Proved `decodeDecodedIR_of_structurallyAdmissible`:
      ```lean
      theorem decodeDecodedIR_of_structurallyAdmissible (ir : DecodedIR)
          (h_adm : StructurallyAdmissibleIR ir) (raw : String) :
          decodeDecodedIR (decodedIRToJson ir) raw = .ok ir
      ```
      This proves that every structurally admissible IR directly decodes from its canonical JSON encoding without any unproved decoder hypotheses.

### Finding 3 (Finding 26): Fuel Monotonicity & Stability Theorems
- **Root Precheck Finding**:
  > "jsonDepthFuel_adequate_of_le64 and jsonMaxArrayLengthFuel_adequate both prove only jsonDepth j <100 from <=64 via omega. Neither states fuel stability, maximum-array correctness or parser agreement. parser_max_depth_bound/parser_max_array_bound merely return their hypotheses."
- **Resolution**:
  - In `lean/DefiKernel/Certificates/Correspondence.lean`, proved structural foldl lemmas:
    - `foldl_max_ge`: Monotonicity helper for accumulator in foldl max.
    - `mem_le_foldl_max`: Bounding elements by foldl max.
    - `foldl_max_congr`: Pointwise equality congruence for foldl max.
  - Proved fuel stability theorems by mathematical induction on fuel:
    - `jsonDepthFuel_stable`:
      ```lean
      theorem jsonDepthFuel_stable (f : Nat) (j : Lean.Json) (h : jsonDepthFuel f j < f) :
          ∀ g ≥ f, jsonDepthFuel g j = jsonDepthFuel f j
      ```
    - `jsonMaxArrayLengthFuel_stable`:
      ```lean
      theorem jsonMaxArrayLengthFuel_stable (f : Nat) (j : Lean.Json) (h : jsonDepthFuel f j < f) :
          ∀ g ≥ f, jsonMaxArrayLengthFuel g j = jsonMaxArrayLengthFuel f j
      ```
    - `jsonDepth_bound_lt_fuel`: `jsonDepth j ≤ 64 → jsonDepth j < 100` via `omega`.
    - `jsonDepth_stable_of_le64`:
      ```lean
      theorem jsonDepth_stable_of_le64 (j : Lean.Json) (h : jsonDepth j ≤ 64) :
          ∀ g ≥ 100, jsonDepthFuel g j = jsonDepth j
      ```
    - `jsonMaxArrayLength_stable_of_le64`:
      ```lean
      theorem jsonMaxArrayLength_stable_of_le64 (j : Lean.Json) (h : jsonDepth j ≤ 64) :
          ∀ g ≥ 100, jsonMaxArrayLengthFuel g j = jsonMaxArrayLength j
      ```
  - Preserved `jsonDepthFuel_adequate_of_le64` and `jsonMaxArrayLengthFuel_adequate` as compatibility aliases, explicitly distinguishing the numerical `omega` bounds from the inductive fuel stability theorems.

### Finding 4 (Finding 29 & 30): Runner Lexical Checks & Live Relative Symlink Refusal
- **Root Precheck Findings**:
  > "Runner checks the lexical final component before resolution. Reported prevention of all parent symlink traversal is not established by checking is_symlink on the resolved path. Fresh child under a parent symlink may be legitimate; no new blanket parent prohibition is required for evidence preservation."
  > "Relative-symlink regression constructs a relative target including temporary parent name again, producing a dangling link instead of testing a live relative link. Add a live relative-link refusal test."
- **Resolution**:
  - **Runner Scope Documentation**:
    - The fixture runner `scripts/run_certificate_fixtures.py` verifies:
      1. Lexical output path `raw_out` is inspected with `is_symlink()` and `os.path.islink()` prior to resolution.
      2. If the lexical path exists, it must be an empty directory (refusing overwrite of existing non-empty paths or regular files).
      3. The resolved target is also inspected to ensure it does not point to an existing non-empty path.
    - We explicitly do NOT claim a blanket parent symlink prohibition, as creating a fresh child under a parent symlink is legitimate and not prohibited.
  - **Live Relative Symlink Refusal Test**:
    - Rewrote `test_relative_symlink_refused` in `scripts/test_certificate_fixture_runner.py`:
      ```python
      def test_relative_symlink_refused(repo_root: Path, runner: Path):
          with tempfile.TemporaryDirectory(dir=repo_root) as tmpdir:
              tmp_path = Path(tmpdir)
              real_dir = tmp_path / "real_rel_dir"
              real_dir.mkdir()
              sentinel = real_dir / "sentinel.txt"
              sentinel_payload = "live_relative_symlink_sentinel_content_p19"
              sentinel.write_text(sentinel_payload, encoding="utf-8")

              symlink_path = tmp_path / "symlink_rel"
              symlink_path.symlink_to("real_rel_dir")

              assert symlink_path.is_symlink()
              assert os.readlink(symlink_path) == "real_rel_dir"
              assert symlink_path.resolve() == real_dir.resolve()
              assert symlink_path.exists()
              assert (symlink_path / "sentinel.txt").read_text(encoding="utf-8") == sentinel_payload

              rel_arg = symlink_path.relative_to(repo_root)
              cmd_rel = [sys.executable, str(runner), "--out", str(rel_arg)]
              proc_rel = subprocess.run(cmd_rel, cwd=repo_root, capture_output=True, text=True)

              assert proc_rel.returncode == 2
              assert "Refusing output path because it is a symlink" in proc_rel.stderr
              assert sentinel.read_text(encoding="utf-8") == sentinel_payload
              assert not (real_dir / "fixture-results.json").exists()

              cmd_abs = [sys.executable, str(runner), "--out", str(symlink_path)]
              proc_abs = subprocess.run(cmd_abs, cwd=repo_root, capture_output=True, text=True)

              assert proc_abs.returncode == 2
              assert "Refusing output path because it is a symlink" in proc_abs.stderr
              assert sentinel.read_text(encoding="utf-8") == sentinel_payload
      ```
    - Confirmed passes 7/7 regressions cleanly.

### Finding 5 (Finding 31): Scoped Evidence Preservation
- **Root Precheck Finding**:
  > "Full54/99/16 campaign deferred; reported7 runner checks and21 Tests require actual scoped evidence, not aggregate proof credit."
- **Resolution**:
  - Full 54 fixture, 99 scenario, and 16 mutation campaigns remain deferred as ordered by root.
  - Evidence is strictly scoped to changed-code verification:
    - 7/7 runner output safety tests (`scripts/test_certificate_fixture_runner.py`).
    - 21/21 runtime unit tests (`lean/DefiKernel/Certificates/Tests.lean`).
    - Exact 217 named kernel theorems in `theorems.json` verified with zero forbidden axioms.

---

## 3. Theorem & Axiom Inventory

### Summary Metrics
- **Total Named Theorems**: 217 (23 in `CanonicalJson.lean`, 194 in `Correspondence.lean`)
  - Previously in R13: 200 theorems (23 CanonicalJson + 177 Correspondence)
  - Newly added in R14: 17 theorems
- **Standard Axioms Only**: 210 theorems (depend exclusively on `propext`, `Quot.sound`, `Classical.choice`)
- **Zero Axiom Theorems**: 7 theorems
- **Forbidden Axioms**: 0
- **`sorry` Count**: 0
- **`native_decide` Count**: 0

### New Theorems Added in R14
1. `foldl_max_ge`: Accumulator monotonicity under foldl max.
2. `mem_le_foldl_max`: List element bound under foldl max.
3. `foldl_max_congr`: Congruence lemma for foldl max under pointwise equality.
4. `jsonDepthFuel_stable`: Depth fuel stability for fuel exceeding depth.
5. `jsonMaxArrayLengthFuel_stable`: Array length fuel stability for fuel exceeding depth.
6. `jsonDepth_bound_lt_fuel`: Depth bound strictly less than fuel limit.
7. `jsonDepth_stable_of_le64`: Invariant depth value for any fuel ≥ 100.
8. `jsonMaxArrayLength_stable_of_le64`: Invariant max array length value for any fuel ≥ 100.
9. `distinct_of_pairwise_lt`: Distinctness of elements under strict ordering.
10. `ofList_toList_eq`: Evaluation identity for `Std.TreeMap.Raw.ofList` on strictly sorted pairs.
11. `compare_lt_of_lt`: String comparison evaluation to `.lt` from `<`.
12. `pairwise_lt_of_isSortedStrictAscending`: Ascending list sort implies pairwise `<`.
13. `list_mapM_sourceMap_entries`: Exact `mapM` roundtrip for source map string values.
14. `decodeSourceMap_sourceMapToJson`: Universal source map decode inversion from `SourceMapSorted`.
15. `standard32CellKeys_eraseDups_len`: Kernel computation (`by decide`) that standard 32-cell keys are unique.
16. `all_mem_of_all_eq_true`: Membership projection for boolean list predicates.
17. `decodeDecodedIR_of_structurallyAdmissible`: Direct decode correspondence theorem for all `StructurallyAdmissibleIR`.

---

## 4. Verification Commands & Replay Manifest

| Command ID | Command | Exit Code | Purpose |
|---|---|:---:|---|
| **CMD-01** | `lake build DefiKernel.Certificates.Correspondence` | 0 | Compile Correspondence.lean with source map, fuel stability, and admissibility theorems |
| **CMD-02** | `lake build` | 0 | Full build of DefiKernel project (1176 jobs) |
| **CMD-03** | `lake env lean DefiKernel/Certificates/Verify.lean` | 0 | Transitive compiler axiom audit across Certificates, Typed, and Composition scopes |
| **CMD-04** | `python3 scripts/test_certificate_fixture_runner.py` | 0 | Fixture runner output safety regression test suite (7/7 pass, including live relative symlink) |
| **CMD-05** | `lake build DefiKernel.Certificates.Tests` | 0 | Compile and verify all 21 runtime unit checks in Tests.lean |

---

## 5. Conclusion & Next Steps

Attempt `agy-r14-proof` successfully resolves all 4 technical findings from root precheck R13:
- Full general source map inversion is proven without decoder-success hypotheses.
- Fuel stability is proven inductively for depth and array bounds.
- Live relative symlink refusal is verified with target and sentinel preservation.
- Document and runner claims are accurately scoped with zero overclaiming.
- Universal `EncodeDecodeRoundtripStatement` remains an explicit open `Prop` pending the recursive AST parser bridge.
