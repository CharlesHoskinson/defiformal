# P19 Typed/Sequential Certificate Verification — Attempt AGY-R18-PROOF Report

- **Candidate**: P19 Typed/Sequential Certificates (Scanner Mixed-Error Precedence Restoration & Pushdown Parser Inversion Extensions)
- **Attempt**: `agy-r18-proof`
- **Date**: 2026-09-10
- **Authorship**: Sole native AGY author (`gemini-3.8-flash-high`, `--effort high`)
- **Auditor**: Pending (requested fresh native Grok `grok-4.6` high effort session; pending independent audit receipt, not simulated or pre-approved)
- **Worktree**: `/home/charl/defiformal-wt-p19-certificates-grok-opus-20260909`
- **Detached Base**: `38de83c58e3f9315bf400807591d538d7565152e`
- **Toolchain**: Lean 4.33.0-rc2 (`d8b18978322de05a8f3dba51ef03cf5461676c17`), Mathlib `51e6992`
- **Disposition**: `PARTIAL_PROOF_WORK`

---

## 1. Executive Summary & Disposition

### Disposition Statement: `PARTIAL_PROOF_WORK`
1. The universal roundtrip theorem `EncodeDecodeRoundtripStatement` remains an open `def Prop` over `StructurallyAdmissibleIR ir`. While substantial progress has been made (including universal rational parsing/end-to-end roundtrip, unit/numericUnit/unaryOp parsing and end-to-end roundtrips, pushdown first-field and scalar property reduction lemmas), the full derivation of whole-document lexical scanner success `h_lex` and pushdown parser inversion `h_parse` across arbitrary recursive `ExprEnc` ASTs and envelope structures is not yet closed end-to-end in the Lean kernel.
2. We make **zero claim** that universal byte-level recursive parser induction across arbitrary nested AST expressions is completed.
3. No review by native Grok is claimed or simulated. The auditor is truthfully recorded as `pending (fresh native Grok grok-4.6 session requested, pending independent receipt)`.

### Major Deliverables in `agy-r18-proof`:
1. **Production Scanner Mixed-Error Failure Precedence Repaired**:
   - Fixed the regression identified in root diagnostic `p19-r16-error-precedence-diagnostic` and finding `p19-r16-root-error-precedence-finding.json`.
   - In R16/R17, `scanLexicalFuel` immediately returned `.error .notJsonObject` whenever `lexString` failed on a string literal escape, prematurely aborting scanner progress.
   - Introduced `skipStringChars` in `Decode.lean` to advance past malformed string bodies, allowing higher-precedence lexical errors (scientific notation, noncanonical whitespace, duplicate keys, and maxDepth resource limits) to be faithfully detected and reported.
   - All 4 changed diagnostic cases are restored to their exact R15 failure classifications:
     * `bad_escape_then_scientific` (`{"a":"\x","b":1e2}`) -> `lexicalScientificOrFloat`
     * `whitespace_then_bad_escape` (`{"a": "\x"}`) -> `noncanonicalWhitespace`
     * `bad_escape_then_duplicate` (`{"a":"\x","b":1,"b":2}`) -> `duplicateKey "b"`
     * `bad_escape_then_depth` (`{"a":"\x","b":[[[[...65...0...]]]]}`) -> `resourceLimit "maxDepth"`
   - The 2 unchanged control cases remain intact:
     * `scientific_then_bad_escape` (`{"b":1e2,"a":"\x"}`) -> `lexicalScientificOrFloat`
     * `duplicate_then_bad_escape` (`{"b":1,"b":2,"a":"\x"}`) -> `duplicateKey "b"`
   - Output matches R15 bit-for-bit: stdout hash `0ec3c792debf9f40328a2f78e0cd97b21303911262542cf2939ab3ca21d25d02`.
   - Decoded key identity is fully preserved: all 32 C0 collision positive roundtrips, true/equivalent escaped duplicate key rejections (`{"a":"1","a":"2"}`, `{"a":"1","\u0061":"2"}`), and quote/backslash controls (`{"q\"":"1","q":"2"}`, `{"b\\":"1","b":"2"}`) pass bit-for-bit matching `p19-scanner-repair-grok-r1` (stdout hash `6caac5c24bbef54474ebc6635ba526341a58169148fd2c8470407aa78f90df6d`).

2. **6 New Pushdown Automaton Reduction Lemmas in `CanonicalJson.lean`**:
   - `parse_obj_first_field_step`: Transition for initial key-value pair in empty/initial object frame (`emptyOrKey` state).
   - `parse_obj_first_field_comma`: Transition for initial key-value pair followed by delimiter comma in empty/initial object frame.
   - `parse_field_str_val`: Operational reduction for feeding scalar string property into object context expecting value.
   - `parse_field_num_val`: Operational reduction for feeding scalar number property into object context expecting value.
   - `parse_field_bool_val`: Operational reduction for feeding scalar boolean property into object context expecting value.
   - `parse_field_null_val`: Operational reduction for feeding scalar null property into object context expecting value.
   - Total named declarations in `CanonicalJson.lean` increased from 62 to **68**.

3. **6 New Parsing and End-to-End Inversion Theorems in `Correspondence.lean`**:
   - `parseCanonicalJson_encodeNumericUnit`: Universal canonical JSON parser inverse on all `NumericUnitEnc` forms.
   - `parseCanonicalJson_encodeUnit`: Universal canonical JSON parser inverse on all `UnitEnc` forms.
   - `parseCanonicalJson_encodeUnaryOp`: Universal canonical JSON parser inverse on all `UnaryOpEnc` forms.
   - `numericUnit_end_to_end_universal`: Universal end-to-end codec roundtrip for numeric units.
   - `unit_end_to_end_universal`: Universal end-to-end codec roundtrip for units.
   - `unaryOp_end_to_end_universal`: Universal end-to-end codec roundtrip for unary operations.
   - Total named declarations in `Correspondence.lean` increased from 237 to **243**.

4. **Preservation of All 299 Prior Declarations and Zero Source Line Removals**:
   - All 299 declarations from R17 are strictly preserved (verified by automated identifier set comparison).
   - Zero historical source lines removed from `CanonicalJson.lean` and `Correspondence.lean`.
   - Total named declarations in `CanonicalJson.lean` and `Correspondence.lean` now stand at exact **311**.
   - Compiler `#print axioms` audit: 299 standard axioms (`propext`, `Quot.sound`, `Classical.choice`), 12 zero axioms, **0 forbidden axioms**, **0 sorry**, **0 native_decide**.

5. **Disaggregated Transitive Axiom Audit by Prefix**:
   - Corrected historical reporting confusion: the prior 287/408 figure was `DefiKernel.Composition` scope only.
   - Transitive compiler audit via `Verify.lean` reported separately across all 3 prefixes:
     * **`DefiKernel.Certificates`**: 1498/1498 theorems, 2545/2545 supplemental declarations, 0 forbidden axioms.
     * **`DefiKernel.Typed`**: 420/420 theorems, 677/677 supplemental declarations, 0 forbidden axioms.
     * **`DefiKernel.Composition`**: 287/287 theorems, 408/408 supplemental declarations, 0 forbidden axioms.

6. **Evidence Repair in `commands.json`**:
   - Captured actual ISO UTC timestamps (`start`, `end`), exit codes, exact `argv` lists, working directories `cwd`, raw stdout/stderr log paths, and SHA-256 stream hashes for all 8 executed commands.
   - Raw streams and probes preserved under `logs/` and `probes/`.

---

## 2. Technical Analysis: Scanner Mixed-Error Failure Precedence Repair

### 2.1 The Root Cause in R16/R17
In R16, `scanLexicalFuel` was introduced to fix an escaped key collision bug where `\u000a` was previously treated as literal `u000a` during key accumulation. However, R16 implemented string scanning as:
```lean
match lexString [] rest with
| .error e => .error e
| .ok (s, rest') => ...
```
When `lexString` encountered an invalid escape sequence (such as `\x`), it returned `.error .notJsonObject`, which caused `scanLexicalFuel` to immediately terminate.

Consequently, if a document contained an invalid string escape followed by a distinct scanner error (such as scientific notation `1e2`, duplicate keys `"b":1,"b":2`, depth > 64, or noncanonical whitespace), the scanner reported `notJsonObject` instead of the higher-precedence lexical/resource failure that R15 reported.

### 2.2 The Solution in R18
We introduced the structurally recursive helper `skipStringChars`:
```lean
def skipStringChars : List Char → Option (List Char)
  | [] => none
  | '"' :: rest => some rest
  | '\\' :: _ :: rest => skipStringChars rest
  | '\\' :: [] => none
  | _ :: rest => skipStringChars rest
```
And refactored `scanLexicalFuel`:
- In key position: `lexString [] rest` is attempted. If it succeeds, the decoded key `s` is added to `keys` and checked for duplicates. If it fails (e.g. malformed escape), `skipStringChars rest` advances past the string to the closing quote without aborting, setting `expectKey := false` so scanning of the remainder of the document continues.
- In value position: `lexString [] rest` is attempted. If it fails on a malformed escape, `skipStringChars rest` advances to the closing quote. Any subsequent lexical errors (such as scientific notation `1e2`, duplicate keys, or depth limit violations) are encountered and reported.
- At end-of-file, if any whitespace was encountered outside strings, `.error .noncanonicalWhitespace` is returned.
- If no lexical/resource errors are found and the document contains a malformed string escape, `scanLexical` completes successfully, and the subsequent `parseCanonicalJson` pass cleanly rejects the document with `.error .notJsonObject`.

### 2.3 Empirical Verification
The 6-case diagnostic probe (`probes/mixed_error_precedence.lean`) was executed and yielded:
```
["bad_escape_then_scientific;scan=DefiKernel.Certificates.DecodeFailure.lexicalScientificOrFloat;decode=DefiKernel.Certificates.DecodeFailure.lexicalScientificOrFloat",
 "whitespace_then_bad_escape;scan=DefiKernel.Certificates.DecodeFailure.noncanonicalWhitespace;decode=DefiKernel.Certificates.DecodeFailure.noncanonicalWhitespace",
 "bad_escape_then_duplicate;scan=DefiKernel.Certificates.DecodeFailure.duplicateKey \"b\";decode=DefiKernel.Certificates.DecodeFailure.duplicateKey \"b\"",
 "bad_escape_then_depth;scan=DefiKernel.Certificates.DecodeFailure.resourceLimit \"maxDepth\";decode=DefiKernel.Certificates.DecodeFailure.resourceLimit \"maxDepth\"",
 "scientific_then_bad_escape;scan=DefiKernel.Certificates.DecodeFailure.lexicalScientificOrFloat;decode=DefiKernel.Certificates.DecodeFailure.lexicalScientificOrFloat",
 "duplicate_then_bad_escape;scan=DefiKernel.Certificates.DecodeFailure.duplicateKey \"b\";decode=DefiKernel.Certificates.DecodeFailure.duplicateKey \"b\""]
```
SHA-256 of stdout: `0ec3c792debf9f40328a2f78e0cd97b21303911262542cf2939ab3ca21d25d02` (bit-for-bit identical to frozen R15 baseline).

The C0 and duplicate key control probe (`probes/c0_controls.lean`) was executed and yielded:
- 32/32 C0 control key collision cases passing (`scan=ok;decode=ok;parserObject=ok`).
- `{"a":"1","a":"2"}` -> `duplicateKey "a"` (scan and parser).
- `{"a":"1","\u0061":"2"}` -> `duplicateKey "a"` (scan and parser).
- `{"q\"":"1","q":"2"}` -> `scan=ok;parser=ok` (distinct keys preserved).
- `{"b\\":"1","b":"2"}` -> `scan=ok;parser=ok` (distinct keys preserved).
SHA-256 of stdout: `6caac5c24bbef54474ebc6635ba526341a58169148fd2c8470407aa78f90df6d` (bit-for-bit identical to frozen R16 baseline).

---

## 3. Axiom and Declaration Audit

### 3.1 Exact Inventory of Named Declarations
Across `lean/DefiKernel/Certificates/CanonicalJson.lean` (68) and `lean/DefiKernel/Certificates/Correspondence.lean` (243), exactly **311** named declarations were audited:
- **Standard axioms only** (`propext`, `Quot.sound`, `Classical.choice`): 299 declarations.
- **Zero axioms** (purely constructive / computational proofs): 12 declarations.
- **Forbidden axioms** (`sorry`, `sorryAx`, custom axioms): **0**.
- **`native_decide`**: **0**.

#### The 12 Zero-Axiom Declarations:
1. `DefiKernel.Certificates.distinct_of_pairwise_lt`
2. `DefiKernel.Certificates.envelopeOrderedKeys_nodup`
3. `DefiKernel.Certificates.foldl_max_congr`
4. `DefiKernel.Certificates.lexDigits_step_eq`
5. `DefiKernel.Certificates.rat_fromRat_num_den`
6. `DefiKernel.Certificates.rational_decode_canonical`
7. `DefiKernel.Certificates.rational_roundtrip`
8. `DefiKernel.Certificates.runPayloadKeys_nodup`
9. `DefiKernel.Certificates.standard32CellKeys_eraseDups_len`
10. `DefiKernel.Certificates.stepPayloadKeys_nodup`
11. `DefiKernel.Certificates.typedPayloadKeys_nodup`
12. `DefiKernel.Certificates.world_unique_of_canonical`

### 3.2 Transitive Verification Audit (`Verify.lean`)
Disaggregated prefix totals:
- **`DefiKernel.Certificates`**: 1498 theorems, 2545 supplemental declarations, 0 forbidden axioms.
- **`DefiKernel.Typed`**: 420 theorems, 677 supplemental declarations, 0 forbidden axioms.
- **`DefiKernel.Composition`**: 287 theorems, 408 supplemental declarations, 0 forbidden axioms.

### 3.3 Unit Tests and Fixture Regressions
- Unit test suite (`Tests.lean`): 21/21 passed.
- Fixture runner safety suite (`scripts/test_certificate_fixture_runner.py`): 7/7 passed.
- Full project build (`lake build DefiKernel`): 1122 jobs completed with 0 errors.

---

## 4. Strongest General Theorem and Unresolved Induction Case

### 4.1 Strongest General Theorems Proven in Kernel
1. **Universal Canonical Rational Inversion**:
   ```lean
   theorem parseCanonicalJson_encodeRat (r : RatEnc) :
       parseCanonicalJson (encodeRat r) = .ok (ratToJson r)
   ```
   Holds universally for all `r : RatEnc` without scalar bounds or preconditions.

2. **Universal Rational End-to-End Roundtrip**:
   ```lean
   theorem rat_end_to_end_universal (r : RatEnc)
       (h_den : r.den ≠ 0) (h_gcd : Int.gcd r.num.natAbs r.den = 1) :
       (do
         let j ← parseCanonicalJson (encodeRat r)
         decodeRat j) = .ok r
   ```

3. **Universal NumericUnit, Unit, and UnaryOp Inversions**:
   ```lean
   theorem numericUnit_end_to_end_universal (nu : NumericUnitEnc) :
       (do let j ← parseCanonicalJson (encodeNumericUnit nu); decodeNumericUnit j) = .ok nu

   theorem unit_end_to_end_universal (u : UnitEnc) :
       (do let j ← parseCanonicalJson (encodeUnit u); decodeUnit j) = .ok u

   theorem unaryOp_end_to_end_universal (op : UnaryOpEnc) :
       (do let j ← parseCanonicalJson (encodeUnaryOp op); decodeUnaryOp j) = .ok op
   ```

4. **Pushdown Automaton Context Transition Lemmas**:
   - `parse_obj_first_field_step`, `parse_obj_first_field_comma`
   - `parse_obj_field_step`, `parse_obj_field_comma`
   - `parse_field_str_val`, `parse_field_num_val`, `parse_field_bool_val`, `parse_field_null_val`
   - `parse_arr_feed_elem`
   - `parse_obj_rbrace`, `parse_arr_rbracket`
   - `parseTokens_of_foldlM`, `parseCanonicalJson_of_tokenize_parseTokens`

5. **Structural Connection Theorem**:
   ```lean
   theorem decodeBytes_encodeModule_of_lex_and_parse (ir : DecodedIR)
       (h_adm : StructurallyAdmissibleIR ir)
       (h_lex : scanLexical (encodeModule ir) = .ok ())
       (h_parse : parseCanonicalJson (encodeModuleString ir) = .ok (decodedIRToJson ir)) :
       decodeBytes (encodeModule ir) = .ok ir
   ```

### 4.2 Unresolved Induction Case
The remaining open obligation for the universal `EncodeDecodeRoundtripStatement` is to prove:
1. `h_lex : ∀ (ir : DecodedIR), StructurallyAdmissibleIR ir → scanLexical (encodeModule ir) = .ok ()`
2. `h_parse : ∀ (ir : DecodedIR), StructurallyAdmissibleIR ir → parseCanonicalJson (encodeModuleString ir) = .ok (decodedIRToJson ir)`

The bottleneck is arbitrary recursive AST expressions (`ExprEnc.unary`, `ExprEnc.binary`, `ExprEnc.ite`), lists of expressions (arguments, branches), source-map sorting equivalence, and full 14-field envelope tokenization.
In accordance with instructions, no shortcut (such as a disconnected easier codec, decoder-image premise, or artificial cap) was used. The campaign runs (54 fixtures, 99 scenarios, 16 mutants) remain deferred until this universal theorem closes.
