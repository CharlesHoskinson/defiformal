import Lean.Data.Json.Basic
import DefiKernel.Certificates.Schema

namespace DefiKernel.Certificates

set_option linter.style.longLine false

/-- Tokens produced by the canonical JSON lexer. -/
inductive JsonToken where
  | lbrace
  | rbrace
  | lbracket
  | rbracket
  | colon
  | comma
  | str (s : String)
  | num (n : Lean.JsonNumber)
  | bool (b : Bool)
  | null
  deriving Inhabited, BEq

def hexDigit (n : Nat) : Char :=
  if n = 0 then '0'
  else if n = 1 then '1'
  else if n = 2 then '2'
  else if n = 3 then '3'
  else if n = 4 then '4'
  else if n = 5 then '5'
  else if n = 6 then '6'
  else if n = 7 then '7'
  else if n = 8 then '8'
  else if n = 9 then '9'
  else if n = 10 then 'a'
  else if n = 11 then 'b'
  else if n = 12 then 'c'
  else if n = 13 then 'd'
  else if n = 14 then 'e'
  else 'f'

def hexVal (c : Char) : Option Nat :=
  if c >= '0' && c <= '9' then some (c.toNat - '0'.toNat)
  else if c >= 'a' && c <= 'f' then some (c.toNat - 'a'.toNat + 10)
  else if c >= 'A' && c <= 'F' then some (c.toNat - 'A'.toNat + 10)
  else none

def escapeChar (c : Char) : List Char :=
  if c = '"' then ['\\', '"']
  else if c = '\\' then ['\\', '\\']
  else if c.toNat < 32 then
    ['\\', 'u', '0', '0', hexDigit (c.toNat / 16), hexDigit (c.toNat % 16)]
  else [c]

def escapeChars : List Char → List Char
  | [] => []
  | c :: cs => escapeChar c ++ escapeChars cs

/-- Structurally recursive string literal parser on character list.
    Enforces canonical C0 unicode escaping, accepts standard JSON escapes,
    rejects malformed/unknown escapes, and rejects literal unescaped control characters. -/
def lexString (acc : List Char) : List Char → Except DecodeFailure (String × List Char)
  | [] => .error .notJsonObject
  | '"' :: rest => .ok (String.ofList acc.reverse, rest)
  | '\\' :: 'u' :: h1 :: h2 :: h3 :: h4 :: rest =>
    match hexVal h1, hexVal h2, hexVal h3, hexVal h4 with
    | some v1, some v2, some v3, some v4 =>
      let val := ((v1 * 16 + v2) * 16 + v3) * 16 + v4
      if val < 0x110000 && !(0xd800 ≤ val && val < 0xe000) then
        lexString (Char.ofNat val :: acc) rest
      else .error .notJsonObject
    | _, _, _, _ => .error .notJsonObject
  | '\\' :: '"' :: rest => lexString ('"' :: acc) rest
  | '\\' :: '\\' :: rest => lexString ('\\' :: acc) rest
  | '\\' :: '/' :: rest => lexString ('/' :: acc) rest
  | '\\' :: 'b' :: rest => lexString ('\x08' :: acc) rest
  | '\\' :: 'f' :: rest => lexString ('\x0c' :: acc) rest
  | '\\' :: 'n' :: rest => lexString ('\n' :: acc) rest
  | '\\' :: 'r' :: rest => lexString ('\x0d' :: acc) rest
  | '\\' :: 't' :: rest => lexString ('\t' :: acc) rest
  | '\\' :: _ => .error .notJsonObject
  | c :: rest =>
    if c.toNat < 32 then .error .notJsonObject
    else lexString (c :: acc) rest

/-- Structurally recursive integer digit parser on character list. -/
def lexDigits (acc : Nat) : List Char → Nat × List Char
  | [] => (acc, [])
  | c :: rest =>
    if c >= '0' && c <= '9' then
      lexDigits (acc * 10 + (c.toNat - '0'.toNat)) rest
    else
      (acc, c :: rest)

/-- Fuel-bounded total canonical tokenizer. Guaranteed terminating on fuel. -/
def tokenizeFuel (fuel : Nat) (chars : List Char) : Except DecodeFailure (List JsonToken) :=
  match fuel with
  | 0 => .error (.resourceLimit "tokenizeFuel")
  | fuel' + 1 =>
    match chars with
    | [] => .ok []
    | ' ' :: rest | '\t' :: rest | '\n' :: rest | '\r' :: rest =>
      tokenizeFuel fuel' rest
    | '{' :: rest => do
      let toks ← tokenizeFuel fuel' rest
      .ok (.lbrace :: toks)
    | '}' :: rest => do
      let toks ← tokenizeFuel fuel' rest
      .ok (.rbrace :: toks)
    | '[' :: rest => do
      let toks ← tokenizeFuel fuel' rest
      .ok (.lbracket :: toks)
    | ']' :: rest => do
      let toks ← tokenizeFuel fuel' rest
      .ok (.rbracket :: toks)
    | ':' :: rest => do
      let toks ← tokenizeFuel fuel' rest
      .ok (.colon :: toks)
    | ',' :: rest => do
      let toks ← tokenizeFuel fuel' rest
      .ok (.comma :: toks)
    | '"' :: rest => do
      let (s, rest') ← lexString [] rest
      let toks ← tokenizeFuel fuel' rest'
      .ok (.str s :: toks)
    | 't' :: 'r' :: 'u' :: 'e' :: rest => do
      let toks ← tokenizeFuel fuel' rest
      .ok (.bool true :: toks)
    | 'f' :: 'a' :: 'l' :: 's' :: 'e' :: rest => do
      let toks ← tokenizeFuel fuel' rest
      .ok (.bool false :: toks)
    | 'n' :: 'u' :: 'l' :: 'l' :: rest => do
      let toks ← tokenizeFuel fuel' rest
      .ok (.null :: toks)
    | '-' :: c :: rest =>
      if c >= '0' && c <= '9' then do
        let (n, rest') := lexDigits (c.toNat - '0'.toNat) rest
        let toks ← tokenizeFuel fuel' rest'
        .ok (.num ⟨- (n : Int), 0⟩ :: toks)
      else
        .error .notJsonObject
    | c :: rest =>
      if c >= '0' && c <= '9' then do
        let (n, rest') := lexDigits (c.toNat - '0'.toNat) rest
        let toks ← tokenizeFuel fuel' rest'
        .ok (.num ⟨(n : Int), 0⟩ :: toks)
      else
        .error .notJsonObject

/-- Entrypoint for canonical JSON tokenization. -/
def tokenize (s : String) : Except DecodeFailure (List JsonToken) :=
  let cs := s.toList
  tokenizeFuel (cs.length + 1) cs

/-- State within an object frame during pushdown parsing. -/
inductive ObjState where
  | emptyOrKey
  | expectKey
  | expectColon (key : String)
  | expectVal (key : String)
  | expectCommaOrRbrace

/-- State within an array frame during pushdown parsing. -/
inductive ArrState where
  | emptyOrVal
  | expectVal
  | expectCommaOrRbracket

/-- Stack frame for pushdown automaton parsing nested structures. -/
inductive StackFrame where
  | obj (acc : List (String × Lean.Json)) (st : ObjState)
  | arr (acc : Array Lean.Json) (st : ArrState)

/-- State of the pushdown parser. -/
structure ParserState where
  stack : List StackFrame
  result : Option Lean.Json

/-- Feeds a completed JSON value into the enclosing stack frame. -/
def feedValue (st : ParserState) (v : Lean.Json) : Except DecodeFailure ParserState :=
  match st.stack with
  | [] =>
    if st.result.isSome then .error .notJsonObject
    else .ok { stack := [], result := some v }
  | StackFrame.arr acc ArrState.emptyOrVal :: rest =>
    if acc.size >= 4096 then .error (.resourceLimit "max_array_length")
    else .ok { st with stack := StackFrame.arr (acc.push v) ArrState.expectCommaOrRbracket :: rest }
  | StackFrame.arr acc ArrState.expectVal :: rest =>
    if acc.size >= 4096 then .error (.resourceLimit "max_array_length")
    else .ok { st with stack := StackFrame.arr (acc.push v) ArrState.expectCommaOrRbracket :: rest }
  | StackFrame.obj acc (ObjState.expectVal key) :: rest =>
    if acc.any (fun (k, _) => k == key) then .error (.duplicateKey key)
    else .ok { st with stack := StackFrame.obj ((key, v) :: acc) ObjState.expectCommaOrRbrace :: rest }
  | _ => .error .notJsonObject

/-- Single transition step for the pushdown parser on one token. -/
def parseStep (st : ParserState) (tok : JsonToken) : Except DecodeFailure ParserState :=
  match tok with
  | .null => feedValue st .null
  | .bool b => feedValue st (.bool b)
  | .num n => feedValue st (.num n)
  | .str s =>
    match st.stack with
    | StackFrame.obj acc ObjState.emptyOrKey :: rest =>
      .ok { st with stack := StackFrame.obj acc (ObjState.expectColon s) :: rest }
    | StackFrame.obj acc ObjState.expectKey :: rest =>
      .ok { st with stack := StackFrame.obj acc (ObjState.expectColon s) :: rest }
    | _ =>
      feedValue st (.str s)
  | .colon =>
    match st.stack with
    | StackFrame.obj acc (ObjState.expectColon k) :: rest =>
      .ok { st with stack := StackFrame.obj acc (ObjState.expectVal k) :: rest }
    | _ => .error .notJsonObject
  | .comma =>
    match st.stack with
    | StackFrame.obj acc ObjState.expectCommaOrRbrace :: rest =>
      .ok { st with stack :=StackFrame.obj acc ObjState.expectKey :: rest }
    | StackFrame.arr acc ArrState.expectCommaOrRbracket :: rest =>
      .ok { st with stack := StackFrame.arr acc ArrState.expectVal :: rest }
    | _ => .error .notJsonObject
  | .lbrace =>
    if st.stack.length >= 64 then .error (.resourceLimit "maxDepth")
    else match st.stack with
    | [] =>
      if st.result.isSome then .error .notJsonObject
      else .ok { st with stack := [StackFrame.obj [] ObjState.emptyOrKey] }
    | StackFrame.arr _ ArrState.emptyOrVal :: _
    | StackFrame.arr _ ArrState.expectVal :: _
    | StackFrame.obj _ (ObjState.expectVal _) :: _ =>
      .ok { st with stack := StackFrame.obj [] ObjState.emptyOrKey :: st.stack }
    | _ => .error .notJsonObject
  | .rbrace =>
    match st.stack with
    | StackFrame.obj acc ObjState.emptyOrKey :: rest =>
      let objVal := Lean.Json.mkObj acc.reverse
      feedValue { st with stack := rest } objVal
    | StackFrame.obj acc ObjState.expectCommaOrRbrace :: rest =>
      let objVal := Lean.Json.mkObj acc.reverse
      feedValue { st with stack := rest } objVal
    | _ => .error .notJsonObject
  | .lbracket =>
    if st.stack.length >= 64 then .error (.resourceLimit "maxDepth")
    else match st.stack with
    | [] =>
      if st.result.isSome then .error .notJsonObject
      else .ok { st with stack := [StackFrame.arr #[] ArrState.emptyOrVal] }
    | StackFrame.arr _ ArrState.emptyOrVal :: _
    | StackFrame.arr _ ArrState.expectVal :: _
    | StackFrame.obj _ (ObjState.expectVal _) :: _ =>
      .ok { st with stack := StackFrame.arr #[] ArrState.emptyOrVal :: st.stack }
    | _ => .error .notJsonObject
  | .rbracket =>
    match st.stack with
    | StackFrame.arr acc ArrState.emptyOrVal :: rest =>
      let arrVal := Lean.Json.arr acc
      feedValue { st with stack := rest } arrVal
    | StackFrame.arr acc ArrState.expectCommaOrRbracket :: rest =>
      let arrVal := Lean.Json.arr acc
      feedValue { st with stack := rest } arrVal
    | _ => .error .notJsonObject

/-- Total pushdown parser over a token list. Guaranteed terminating by structural recursion. -/
def parseTokens (toks : List JsonToken) : Except DecodeFailure Lean.Json := do
  let finalSt ← toks.foldlM parseStep { stack := [], result := none }
  match finalSt.stack, finalSt.result with
  | [], some j => .ok j
  | _, _ => .error .notJsonObject

/-- Total canonical JSON parser. Converts string to Lean.Json with zero partiality. -/
def parseCanonicalJson (s : String) : Except DecodeFailure Lean.Json := do
  let toks ← tokenize s
  parseTokens toks

theorem hexVal_hexDigit (n : Nat) (h : n < 16) : hexVal (hexDigit n) = some n := by
  match n, h with
  | 0, _ => rfl
  | 1, _ => rfl
  | 2, _ => rfl
  | 3, _ => rfl
  | 4, _ => rfl
  | 5, _ => rfl
  | 6, _ => rfl
  | 7, _ => rfl
  | 8, _ => rfl
  | 9, _ => rfl
  | 10, _ => rfl
  | 11, _ => rfl
  | 12, _ => rfl
  | 13, _ => rfl
  | 14, _ => rfl
  | 15, _ => rfl
  | _ + 16, h => omega

theorem bool_cond_of_lt32 (n : Nat) (h : n < 32) :
    (decide (n < 1114112) && !(decide (55296 ≤ n) && decide (n < 57344))) = true := by
  have h1 : n < 1114112 := by omega
  have h2 : ¬ (55296 ≤ n) := by omega
  rw [decide_eq_true h1, decide_eq_false h2]
  rfl

theorem lexString_quote (acc rest : List Char) :
    lexString acc ('\\' :: '"' :: rest) = lexString ('"' :: acc) rest := by
  rfl

theorem lexString_slash (acc rest : List Char) :
    lexString acc ('\\' :: '\\' :: rest) = lexString ('\\' :: acc) rest := by
  rfl

theorem lexString_u00 (c : Char) (h_lt : c.toNat < 32) (acc rest : List Char) :
    lexString acc ('\\' :: 'u' :: '0' :: '0' :: hexDigit (c.toNat / 16) :: hexDigit (c.toNat % 16) :: rest) =
      lexString (c :: acc) rest := by
  change (match hexVal '0', hexVal '0', hexVal (hexDigit (c.toNat / 16)), hexVal (hexDigit (c.toNat % 16)) with
    | some v1, some v2, some v3, some v4 =>
      let val := ((v1 * 16 + v2) * 16 + v3) * 16 + v4
      if val < 0x110000 && !(0xd800 ≤ val && val < 0xe000) then
        lexString (Char.ofNat val :: acc) rest
      else .error .notJsonObject
    | _, _, _, _ => .error .notJsonObject) = lexString (c :: acc) rest
  have h1 : hexVal '0' = some 0 := rfl
  have h3 : hexVal (hexDigit (c.toNat / 16)) = some (c.toNat / 16) := by
    apply hexVal_hexDigit; omega
  have h4 : hexVal (hexDigit (c.toNat % 16)) = some (c.toNat % 16) := by
    apply hexVal_hexDigit; omega
  rw [h1, h3, h4]
  dsimp
  have h_val : ((0 * 16 + 0) * 16 + c.toNat / 16) * 16 + c.toNat % 16 = c.toNat := by
    omega
  rw [h_val]
  have hb := bool_cond_of_lt32 c.toNat h_lt
  rw [hb]
  dsimp
  rw [Char.ofNat_toNat]

set_option linter.style.multiGoal false
set_option linter.unusedTactic false
set_option linter.unreachableTactic false

theorem lexString_normal (c : Char) (h_q : c ≠ '"') (h_s : c ≠ '\\') (h_ge : ¬ (c.toNat < 32))
    (acc rest : List Char) :
    lexString acc (c :: rest) = lexString (c :: acc) rest := by
  rw [lexString]
  split
  · contradiction
  · rfl
  all_goals
    try (intro h; subst h; contradiction)
    try (intro _ _ _ _ _ h _; subst h; contradiction)
    try (intro _ h _; subst h; contradiction)
    try (intro _ h; subst h; contradiction)
    try contradiction

theorem lexString_char (c : Char) (acc rest : List Char) :
    lexString acc (escapeChar c ++ rest) = lexString (c :: acc) rest := by
  dsimp [escapeChar]
  split
  · rename_i hc
    subst hc
    exact lexString_quote acc rest
  · split
    · rename_i _ hc
      subst hc
      exact lexString_slash acc rest
    · split
      · rename_i _ _ h_lt
        exact lexString_u00 c h_lt acc rest
      · rename_i h_not_q h_not_s h_not_lt
        exact lexString_normal c h_not_q h_not_s h_not_lt acc rest

theorem lexString_escapeChars (cs : List Char) (acc rest : List Char) :
    lexString acc (escapeChars cs ++ ('"' :: rest)) = .ok (String.ofList (acc.reverse ++ cs), rest) := by
  induction cs generalizing acc with
  | nil =>
    simp only [escapeChars, List.nil_append, List.append_nil]
    rfl
  | cons c cs ih =>
    simp only [escapeChars, List.append_assoc]
    rw [lexString_char]
    have h := ih (c :: acc)
    simp only [List.reverse_cons, List.append_assoc, List.singleton_append] at h
    exact h

/-- General string lexing inversion theorem: for any string s, lexing its canonical escaped form returns s. -/
theorem lexString_escapeJsonString (s : String) (rest : List Char) :
    lexString [] (escapeChars s.toList ++ ('"' :: rest)) = .ok (s, rest) := by
  have h := lexString_escapeChars s.toList [] rest
  simp only [List.reverse_nil, List.nil_append] at h
  rw [String.ofList_toList] at h
  exact h

/-- UTF-8 byte serialization inverse: decoding the UTF-8 bytes of any string returns the string. -/
theorem string_fromUTF8?_toUTF8 (s : String) : String.fromUTF8? s.toUTF8 = some s := by
  dsimp [String.fromUTF8?, String.toUTF8]
  have h : s.toByteArray.IsValidUTF8 := s.isValidUTF8
  rw [dif_pos h]
  rfl

/-- Generic string tokenization theorem: tokenizing an escaped string literal produces a string token. -/
theorem tokenizeFuel_string (fuel : Nat) (str : String) (rest : List Char) :
    tokenizeFuel (fuel + 1) ('"' :: (escapeChars str.toList ++ ('"' :: rest))) =
      (do
        let toks ← tokenizeFuel fuel rest
        .ok (JsonToken.str str :: toks)) := by
  change (do
      let (s, rest') ← lexString [] (escapeChars str.toList ++ ('"' :: rest))
      let toks ← tokenizeFuel fuel rest'
      .ok (JsonToken.str s :: toks)) = (do
      let toks ← tokenizeFuel fuel rest
      .ok (JsonToken.str str :: toks))
  have h_lex := lexString_escapeJsonString str rest
  rw [h_lex]
  rfl

/-- Pushdown parser base token inversion: string token decodes to Json.str. -/
theorem parseTokens_str (s : String) : parseTokens [JsonToken.str s] = .ok (Lean.Json.str s) := rfl

/-- Pushdown parser base token inversion: num token decodes to Json.num. -/
theorem parseTokens_num (n : Lean.JsonNumber) : parseTokens [JsonToken.num n] = .ok (Lean.Json.num n) := rfl

/-- Pushdown parser base token inversion: bool token decodes to Json.bool. -/
theorem parseTokens_bool (b : Bool) : parseTokens [JsonToken.bool b] = .ok (Lean.Json.bool b) := rfl

/-- Pushdown parser base token inversion: null token decodes to Json.null. -/
theorem parseTokens_null : parseTokens [JsonToken.null] = .ok Lean.Json.null := rfl

/-- Pushdown parser empty array inversion. -/
theorem parseTokens_empty_arr : parseTokens [JsonToken.lbracket, JsonToken.rbracket] = .ok (Lean.Json.arr #[]) := rfl

/-- Pushdown parser empty object inversion. -/
theorem parseTokens_empty_obj : parseTokens [JsonToken.lbrace, JsonToken.rbrace] = .ok (Lean.Json.mkObj []) := rfl

/-- Direct canonical parsing on true literal. -/
theorem parseCanonicalJson_true : parseCanonicalJson "true" = .ok (Lean.Json.bool true) := rfl

/-- Direct canonical parsing on false literal. -/
theorem parseCanonicalJson_false : parseCanonicalJson "false" = .ok (Lean.Json.bool false) := rfl

/-- Direct canonical parsing on null literal. -/
theorem parseCanonicalJson_null : parseCanonicalJson "null" = .ok Lean.Json.null := rfl

/-- Direct canonical parsing on empty array literal. -/
theorem parseCanonicalJson_empty_arr : parseCanonicalJson "[]" = .ok (Lean.Json.arr #[]) := rfl

/-- Direct canonical parsing on empty object literal. -/
theorem parseCanonicalJson_empty_obj : parseCanonicalJson "{}" = .ok (Lean.Json.mkObj []) := rfl

/-- Empty string fuel step helper. -/
theorem tokenizeFuel_empty (fuel : Nat) : tokenizeFuel (fuel + 1) [] = .ok [] := rfl

/-- Pushdown parser step equivalence on null token. -/
theorem parseStep_null (st : ParserState) : parseStep st .null = feedValue st .null := rfl

/-- Pushdown parser step equivalence on bool token. -/
theorem parseStep_bool (st : ParserState) (b : Bool) : parseStep st (.bool b) = feedValue st (.bool b) := rfl

/-- Pushdown parser step equivalence on num token. -/
theorem parseStep_num (st : ParserState) (n : Lean.JsonNumber) : parseStep st (.num n) = feedValue st (.num n) := rfl

/-- Pushdown parser step on string token in empty stack state. -/
theorem parseStep_str_empty (s : String) :
    parseStep { stack := [], result := none } (.str s) = feedValue { stack := [], result := none } (.str s) := rfl

/-- Pushdown parser step on string token when expecting a value in an object. -/
theorem parseStep_str_expectVal (acc : List (String × Lean.Json)) (key s : String) (rest : List StackFrame) :
    parseStep { stack := StackFrame.obj acc (ObjState.expectVal key) :: rest, result := none } (.str s) =
    feedValue { stack := StackFrame.obj acc (ObjState.expectVal key) :: rest, result := none } (.str s) := rfl

/-- Pushdown parser step on string token in initial array state. -/
theorem parseStep_str_arr_empty (acc : Array Lean.Json) (s : String) (rest : List StackFrame) :
    parseStep { stack := StackFrame.arr acc ArrState.emptyOrVal :: rest, result := none } (.str s) =
    feedValue { stack := StackFrame.arr acc ArrState.emptyOrVal :: rest, result := none } (.str s) := rfl

/-- Pushdown parser step on string token when expecting array element. -/
theorem parseStep_str_arr_val (acc : Array Lean.Json) (s : String) (rest : List StackFrame) :
    parseStep { stack := StackFrame.arr acc ArrState.expectVal :: rest, result := none } (.str s) =
    feedValue { stack := StackFrame.arr acc ArrState.expectVal :: rest, result := none } (.str s) := rfl

/-- Pushdown parser feeding value into object frame expecting value. -/
theorem feedValue_obj_expectVal (acc : List (String × Lean.Json)) (key : String) (v : Lean.Json) (rest : List StackFrame)
    (h_not_dup : acc.any (fun (k, _) => k == key) = false) :
    feedValue { stack := StackFrame.obj acc (ObjState.expectVal key) :: rest, result := none } v =
    .ok { stack := StackFrame.obj ((key, v) :: acc) ObjState.expectCommaOrRbrace :: rest, result := none } := by
  dsimp [feedValue]
  split
  · rename_i h
    rw [h_not_dup] at h
    contradiction
  · rfl

/-- Pushdown parser feeding value into array frame expecting value. -/
theorem feedValue_arr_expectVal (acc : Array Lean.Json) (v : Lean.Json) (rest : List StackFrame)
    (h_len : ¬ (acc.size ≥ 4096)) :
    feedValue { stack := StackFrame.arr acc ArrState.expectVal :: rest, result := none } v =
    .ok { stack := StackFrame.arr (acc.push v) ArrState.expectCommaOrRbracket :: rest, result := none } := by
  dsimp [feedValue]
  split
  · rename_i h; contradiction
  · rfl

/-- Pushdown parser feeding value into initial array frame. -/
theorem feedValue_arr_emptyOrVal (acc : Array Lean.Json) (v : Lean.Json) (rest : List StackFrame)
    (h_len : ¬ (acc.size ≥ 4096)) :
    feedValue { stack := StackFrame.arr acc ArrState.emptyOrVal :: rest, result := none } v =
    .ok { stack := StackFrame.arr (acc.push v) ArrState.expectCommaOrRbracket :: rest, result := none } := by
  dsimp [feedValue]
  split
  · rename_i h; contradiction
  · rfl

/-- Pushdown parser step opening object on empty stack. -/
theorem parseStep_lbrace_empty :
    parseStep { stack := [], result := none } .lbrace =
    .ok { stack := [StackFrame.obj [] ObjState.emptyOrKey], result := none } := rfl

/-- Pushdown parser step opening array on empty stack. -/
theorem parseStep_lbracket_empty :
    parseStep { stack := [], result := none } .lbracket =
    .ok { stack := [StackFrame.arr #[] ArrState.emptyOrVal], result := none } := rfl

/-- Pushdown parser step opening nested object when expecting object value. -/
theorem parseStep_lbrace_expectVal (acc : List (String × Lean.Json)) (key : String) (rest : List StackFrame)
    (h_depth : rest.length + 2 ≤ 64) :
    parseStep { stack := StackFrame.obj acc (ObjState.expectVal key) :: rest, result := none } .lbrace =
    .ok { stack := StackFrame.obj [] ObjState.emptyOrKey :: StackFrame.obj acc (ObjState.expectVal key) :: rest, result := none } := by
  dsimp [parseStep]
  split
  · rename_i h
    have : rest.length + 1 < 64 := by omega
    omega
  · rfl

/-- Pushdown parser step transitioning key in initial object state. -/
theorem parseStep_str_emptyOrKey (acc : List (String × Lean.Json)) (s : String) (rest : List StackFrame) :
    parseStep { stack := StackFrame.obj acc ObjState.emptyOrKey :: rest, result := none } (.str s) =
    .ok { stack := StackFrame.obj acc (ObjState.expectColon s) :: rest, result := none } := rfl

/-- Pushdown parser step transitioning key in subsequent object state. -/
theorem parseStep_str_expectKey (acc : List (String × Lean.Json)) (s : String) (rest : List StackFrame) :
    parseStep { stack := StackFrame.obj acc ObjState.expectKey :: rest, result := none } (.str s) =
    .ok { stack := StackFrame.obj acc (ObjState.expectColon s) :: rest, result := none } := rfl

/-- Pushdown parser step transitioning on colon in object state. -/
theorem parseStep_colon (acc : List (String × Lean.Json)) (k : String) (rest : List StackFrame) :
    parseStep { stack := StackFrame.obj acc (ObjState.expectColon k) :: rest, result := none } .colon =
    .ok { stack := StackFrame.obj acc (ObjState.expectVal k) :: rest, result := none } := rfl

/-- Pushdown parser step transitioning on comma in object state. -/
theorem parseStep_comma_obj (acc : List (String × Lean.Json)) (rest : List StackFrame) :
    parseStep { stack := StackFrame.obj acc ObjState.expectCommaOrRbrace :: rest, result := none } .comma =
    .ok { stack := StackFrame.obj acc ObjState.expectKey :: rest, result := none } := rfl

/-- Pushdown parser step transitioning on comma in array state. -/
theorem parseStep_comma_arr (acc : Array Lean.Json) (rest : List StackFrame) :
    parseStep { stack := StackFrame.arr acc ArrState.expectCommaOrRbracket :: rest, result := none } .comma =
    .ok { stack := StackFrame.arr acc ArrState.expectVal :: rest, result := none } := rfl

/-- Pushdown parser feeding one element into an array frame followed by comma. -/
theorem parse_arr_feed_elem (toks : List JsonToken) (acc : Array Lean.Json) (rest : List StackFrame)
    (v : Lean.Json)
    (h_feed : toks.foldlM parseStep { stack := StackFrame.arr acc ArrState.expectVal :: rest, result := none } =
              .ok { stack := StackFrame.arr (acc.push v) ArrState.expectCommaOrRbracket :: rest, result := none }) :
    (toks ++ [JsonToken.comma]).foldlM parseStep { stack := StackFrame.arr acc ArrState.expectVal :: rest, result := none } =
    .ok { stack := StackFrame.arr (acc.push v) ArrState.expectVal :: rest, result := none } := by
  rw [List.foldlM_append]
  dsimp [bind, Except.bind]
  rw [h_feed]
  rfl

/-- Pushdown parser transition for key and colon in object frame. -/
theorem parse_obj_field_step (k : String) (v_toks : List JsonToken) (v : Lean.Json)
    (acc : List (String × Lean.Json)) (rest : List StackFrame)
    (_h_not_dup : acc.any (fun (k', _) => k' == k) = false)
    (h_val : v_toks.foldlM parseStep { stack := StackFrame.obj acc (ObjState.expectVal k) :: rest, result := none } =
             .ok { stack := StackFrame.obj ((k, v) :: acc) ObjState.expectCommaOrRbrace :: rest, result := none }) :
    (JsonToken.str k :: JsonToken.colon :: v_toks).foldlM parseStep { stack := StackFrame.obj acc ObjState.expectKey :: rest, result := none } =
    .ok { stack := StackFrame.obj ((k, v) :: acc) ObjState.expectCommaOrRbrace :: rest, result := none } := by
  have h_split : (JsonToken.str k :: JsonToken.colon :: v_toks) = [JsonToken.str k, JsonToken.colon] ++ v_toks := rfl
  rw [h_split, List.foldlM_append]
  dsimp [bind, Except.bind, parseStep]
  exact h_val

/-- Pushdown parser transition for key, colon, value and trailing comma in object frame. -/
theorem parse_obj_field_comma (k : String) (v_toks : List JsonToken) (v : Lean.Json)
    (acc : List (String × Lean.Json)) (rest : List StackFrame)
    (h_not_dup : acc.any (fun (k', _) => k' == k) = false)
    (h_val : v_toks.foldlM parseStep { stack := StackFrame.obj acc (ObjState.expectVal k) :: rest, result := none } =
             .ok { stack := StackFrame.obj ((k, v) :: acc) ObjState.expectCommaOrRbrace :: rest, result := none }) :
    ((JsonToken.str k :: JsonToken.colon :: v_toks) ++ [JsonToken.comma]).foldlM parseStep { stack := StackFrame.obj acc ObjState.expectKey :: rest, result := none } =
    .ok { stack := StackFrame.obj ((k, v) :: acc) ObjState.expectKey :: rest, result := none } := by
  rw [List.foldlM_append]
  have h_step := parse_obj_field_step k v_toks v acc rest h_not_dup h_val
  rw [h_step]
  rfl

/-- Pushdown parser closing object on rbrace. -/
theorem parse_obj_rbrace (acc : List (String × Lean.Json)) (rest : List StackFrame) :
    parseStep { stack := StackFrame.obj acc ObjState.expectCommaOrRbrace :: rest, result := none } .rbrace =
    feedValue { stack := rest, result := none } (Lean.Json.mkObj acc.reverse) := rfl

/-- Pushdown parser closing array on rbracket. -/
theorem parse_arr_rbracket (acc : Array Lean.Json) (rest : List StackFrame) :
    parseStep { stack := StackFrame.arr acc ArrState.expectCommaOrRbracket :: rest, result := none } .rbracket =
    feedValue { stack := rest, result := none } (Lean.Json.arr acc) := rfl

/-- Top-level parseTokens reduction from successful foldlM. -/
theorem parseTokens_of_foldlM (toks : List JsonToken) (j : Lean.Json)
    (h : toks.foldlM parseStep { stack := [], result := none } = .ok { stack := [], result := some j }) :
    parseTokens toks = .ok j := by
  dsimp [parseTokens]
  rw [h]
  rfl

/-- Modular parsing equivalence combining tokenizer and pushdown parser. -/
theorem parseCanonicalJson_of_tokenize_parseTokens (s : String) (toks : List JsonToken) (j : Lean.Json)
    (h_tok : tokenize s = .ok toks)
    (h_parse : parseTokens toks = .ok j) :
    parseCanonicalJson s = .ok j := by
  dsimp [parseCanonicalJson]
  rw [h_tok]
  dsimp [bind, Except.bind]
  exact h_parse

/-- Tokenizer step on lbrace delimiter. -/
theorem tokenizeFuel_lbrace (fuel : Nat) (rest : List Char) :
    tokenizeFuel (fuel + 1) ('{' :: rest) =
      (do
        let toks ← tokenizeFuel fuel rest
        .ok (JsonToken.lbrace :: toks)) := rfl

/-- Tokenizer step on rbrace delimiter. -/
theorem tokenizeFuel_rbrace (fuel : Nat) (rest : List Char) :
    tokenizeFuel (fuel + 1) ('}' :: rest) =
      (do
        let toks ← tokenizeFuel fuel rest
        .ok (JsonToken.rbrace :: toks)) := rfl

/-- Tokenizer step on colon delimiter. -/
theorem tokenizeFuel_colon (fuel : Nat) (rest : List Char) :
    tokenizeFuel (fuel + 1) (':' :: rest) =
      (do
        let toks ← tokenizeFuel fuel rest
        .ok (JsonToken.colon :: toks)) := rfl

/-- Tokenizer step on comma delimiter. -/
theorem tokenizeFuel_comma (fuel : Nat) (rest : List Char) :
    tokenizeFuel (fuel + 1) (',' :: rest) =
      (do
        let toks ← tokenizeFuel fuel rest
        .ok (JsonToken.comma :: toks)) := rfl

/-- Tokenizer step on lbracket delimiter. -/
theorem tokenizeFuel_lbracket (fuel : Nat) (rest : List Char) :
    tokenizeFuel (fuel + 1) ('[' :: rest) =
      (do
        let toks ← tokenizeFuel fuel rest
        .ok (JsonToken.lbracket :: toks)) := rfl

/-- Tokenizer step on rbracket delimiter. -/
theorem tokenizeFuel_rbracket (fuel : Nat) (rest : List Char) :
    tokenizeFuel (fuel + 1) (']' :: rest) =
      (do
        let toks ← tokenizeFuel fuel rest
        .ok (JsonToken.rbracket :: toks)) := rfl

/-- Character step equation for lexDigits. -/
theorem lexDigits_step_eq (c : Char) (acc : Nat) (rest : List Char) :
    lexDigits acc (c :: rest) =
      if c.isDigit then lexDigits (acc * 10 + (c.toNat - '0'.toNat)) rest
      else (acc, c :: rest) := rfl

/-- General digits parsing induction: lexDigits on any all-digit list reconstructs ofDigitChars. -/
theorem lexDigits_of_all_digits (l : List Char) (hl : ∀ c ∈ l, c.isDigit = true)
    (acc : Nat) (rest : List Char) (h_end : match rest with | [] => True | c :: _ => c.isDigit = false) :
    lexDigits acc (l ++ rest) = (Nat.ofDigitChars 10 l acc, rest) := by
  induction l generalizing acc with
  | nil =>
    simp only [List.nil_append, Nat.ofDigitChars_nil]
    cases rest with
    | nil => rfl
    | cons c cs =>
      rw [lexDigits_step_eq]
      dsimp at h_end
      rw [h_end]
      rfl
  | cons c cs ih =>
    simp only [List.cons_append, Nat.ofDigitChars_cons]
    have hc := hl c (by simp)
    have hcs : ∀ c' ∈ cs, c'.isDigit = true := fun c' hc' => hl c' (by simp [hc'])
    rw [lexDigits_step_eq]
    rw [hc]
    dsimp
    have h_comm : acc * 10 = 10 * acc := Nat.mul_comm _ _
    rw [h_comm]
    exact ih hcs (10 * acc + (c.toNat - '0'.toNat))

/-- Head/tail decomposition for lexDigits on decimal representation of natural numbers. -/
theorem lexDigits_head_tl (c : Char) (tl : List Char) (n : Nat)
    (h_eq : Nat.toDigits 10 n = c :: tl) (rest : List Char)
    (h_end : match rest with | [] => True | c :: _ => c.isDigit = false) :
    c.isDigit = true ∧
    lexDigits (c.toNat - '0'.toNat) (tl ++ rest) = (n, rest) := by
  have hl : ∀ x ∈ Nat.toDigits 10 n, x.isDigit = true := by
    intro x hx
    exact Nat.isDigit_of_mem_toDigits (by decide) (by decide) hx
  have hc : c.isDigit = true := by
    have : c ∈ Nat.toDigits 10 n := by simp [h_eq]
    exact hl c this
  have htl : ∀ x ∈ tl, x.isDigit = true := by
    intro x hx
    have : x ∈ Nat.toDigits 10 n := by simp [h_eq, hx]
    exact hl x this
  refine ⟨hc, ?_⟩
  rw [lexDigits_of_all_digits tl htl (c.toNat - '0'.toNat) rest h_end]
  have h_cons : Nat.ofDigitChars 10 (c :: tl) 0 = Nat.ofDigitChars 10 tl (10 * 0 + (c.toNat - '0'.toNat)) := rfl
  simp only [Nat.mul_zero, Nat.zero_add] at h_cons
  rw [← h_cons, ← h_eq]
  rw [Nat.ofDigitChars_ten_toDigits]

/-- Nonemptiness of natural decimal digit representation. -/
theorem toDigits_nonempty (n : Nat) : ∃ c tl, Nat.toDigits 10 n = c :: tl := by
  cases h : Nat.toDigits 10 n with
  | nil =>
    have h_len : 0 < (Nat.toDigits 10 n).length := Nat.length_toDigits_pos
    rw [h] at h_len
    contradiction
  | cons c tl =>
    exact ⟨c, tl, rfl⟩

/-- Fuel-bounded tokenizer transition on initial digit character. -/
theorem tokenizeFuel_digit_step (fuel : Nat) (c : Char) (tl : List Char) (rest : List Char)
    (hc : c.isDigit = true)
    (n : Nat)
    (h_lex : lexDigits (c.toNat - '0'.toNat) (tl ++ rest) = (n, rest)) :
    tokenizeFuel (fuel + 1) (c :: (tl ++ rest)) =
      (do
        let toks ← tokenizeFuel fuel rest
        .ok (JsonToken.num ⟨(n : Int), 0⟩ :: toks)) := by
  rw [tokenizeFuel]
  split
  · rw [h_lex]
  · rename_i h_not
    have hc_cond : (decide (c ≥ '0') && decide (c ≤ '9')) = true := hc
    contradiction
  all_goals
    try (intro h1; subst h1; revert hc; decide)
    try (intro _ h1 _; subst h1; revert hc; decide)
    try (intro _ h1; subst h1; revert hc; decide)
    try (intro _ _ h1 _; subst h1; revert hc; decide)

/-- General decimal tokenization for arbitrary natural numbers followed by non-digit delimiter. -/
theorem tokenizeFuel_nat (fuel : Nat) (n : Nat) (rest : List Char)
    (h_end : match rest with | [] => True | c :: _ => c.isDigit = false) :
    tokenizeFuel (fuel + 1) ((toString n).toList ++ rest) =
      (do
        let toks ← tokenizeFuel fuel rest
        .ok (JsonToken.num ⟨(n : Int), 0⟩ :: toks)) := by
  have h_repr : (toString n).toList = Nat.toDigits 10 n := by
    change (Nat.repr n).toList = Nat.toDigits 10 n
    exact Nat.toList_repr
  rw [h_repr]
  rcases toDigits_nonempty n with ⟨c, tl, h_digits⟩
  rw [h_digits]
  have ⟨hc, h_lex⟩ := lexDigits_head_tl c tl n h_digits rest h_end
  simp only [List.cons_append]
  exact tokenizeFuel_digit_step fuel c tl rest hc n h_lex

/-- General decimal tokenization for arbitrary integers (positive, zero, or negative). -/
theorem tokenizeFuel_int (fuel : Nat) (i : Int) (rest : List Char)
    (h_end : match rest with | [] => True | c :: _ => c.isDigit = false) :
    tokenizeFuel (fuel + 1) ((toString i).toList ++ rest) =
      (do
        let toks ← tokenizeFuel fuel rest
        .ok (JsonToken.num ⟨i, 0⟩ :: toks)) := by
  cases i with
  | ofNat n =>
    exact tokenizeFuel_nat fuel n rest h_end
  | negSucc n =>
    have h_repr : (toString (Int.negSucc n)).toList = '-' :: (Nat.repr (n + 1)).toList := by
      change ("-" ++ Nat.repr (n + 1)).toList = '-' :: (Nat.repr (n + 1)).toList
      rw [String.toList_append]
      rfl
    rw [h_repr]
    have h_nat_repr : (Nat.repr (n + 1)).toList = Nat.toDigits 10 (n + 1) := Nat.toList_repr
    rw [h_nat_repr]
    rcases toDigits_nonempty (n + 1) with ⟨c, tl, h_digits⟩
    rw [h_digits]
    have ⟨hc, h_lex⟩ := lexDigits_head_tl c tl (n + 1) h_digits rest h_end
    simp only [List.cons_append]
    rw [tokenizeFuel]
    have hc_cond : (decide (c ≥ '0') && decide (c ≤ '9')) = true := hc
    rw [hc_cond]
    dsimp
    have h_lex' : lexDigits (c.toNat - 48) (tl ++ rest) = (n + 1, rest) := h_lex
    rw [h_lex']
    have : (-↑(n + 1) : Int) = Int.negSucc n := rfl
    rw [this]

/-- Generic pushdown parser step inverse on canonical rational token sequence. -/
theorem parseTokens_rat (r : RatEnc) :
    parseTokens [
      JsonToken.lbrace,
      JsonToken.str "num", JsonToken.colon, JsonToken.num ⟨r.num, 0⟩,
      JsonToken.comma,
      JsonToken.str "den", JsonToken.colon, JsonToken.num ⟨(r.den : Int), 0⟩,
      JsonToken.rbrace
    ] = .ok (Lean.Json.mkObj [("num", Lean.Json.num r.num), ("den", Lean.Json.num (r.den : Int))]) := rfl

/-- Pushdown parser transition for first key and colon in empty/initial object frame. -/
theorem parse_obj_first_field_step (k : String) (v_toks : List JsonToken) (v : Lean.Json)
    (acc : List (String × Lean.Json)) (rest : List StackFrame)
    (h_val : v_toks.foldlM parseStep { stack := StackFrame.obj acc (ObjState.expectVal k) :: rest, result := none } =
             .ok { stack := StackFrame.obj ((k, v) :: acc) ObjState.expectCommaOrRbrace :: rest, result := none }) :
    (JsonToken.str k :: JsonToken.colon :: v_toks).foldlM parseStep { stack := StackFrame.obj acc ObjState.emptyOrKey :: rest, result := none } =
    .ok { stack := StackFrame.obj ((k, v) :: acc) ObjState.expectCommaOrRbrace :: rest, result := none } := by
  have h_split : (JsonToken.str k :: JsonToken.colon :: v_toks) = [JsonToken.str k, JsonToken.colon] ++ v_toks := rfl
  rw [h_split, List.foldlM_append]
  dsimp [bind, Except.bind, parseStep]
  exact h_val

/-- Pushdown parser transition for first key, colon, value and trailing comma in empty/initial object frame. -/
theorem parse_obj_first_field_comma (k : String) (v_toks : List JsonToken) (v : Lean.Json)
    (acc : List (String × Lean.Json)) (rest : List StackFrame)
    (h_val : v_toks.foldlM parseStep { stack := StackFrame.obj acc (ObjState.expectVal k) :: rest, result := none } =
             .ok { stack := StackFrame.obj ((k, v) :: acc) ObjState.expectCommaOrRbrace :: rest, result := none }) :
    ((JsonToken.str k :: JsonToken.colon :: v_toks) ++ [JsonToken.comma]).foldlM parseStep { stack := StackFrame.obj acc ObjState.emptyOrKey :: rest, result := none } =
    .ok { stack := StackFrame.obj ((k, v) :: acc) ObjState.expectKey :: rest, result := none } := by
  rw [List.foldlM_append]
  have h_step := parse_obj_first_field_step k v_toks v acc rest h_val
  rw [h_step]
  rfl

/-- Feeding scalar string property into object frame expecting value. -/
theorem parse_field_str_val (acc : List (String × Lean.Json)) (key s : String) (rest : List StackFrame)
    (h_not_dup : acc.any (fun (k, _) => k == key) = false) :
    [JsonToken.str s].foldlM parseStep { stack := StackFrame.obj acc (ObjState.expectVal key) :: rest, result := none } =
    .ok { stack := StackFrame.obj ((key, Lean.Json.str s) :: acc) ObjState.expectCommaOrRbrace :: rest, result := none } := by
  dsimp [List.foldlM, parseStep, bind, Except.bind]
  rw [feedValue_obj_expectVal acc key (.str s) rest h_not_dup]
  rfl

/-- Feeding scalar number property into object frame expecting value. -/
theorem parse_field_num_val (acc : List (String × Lean.Json)) (key : String) (n : Lean.JsonNumber) (rest : List StackFrame)
    (h_not_dup : acc.any (fun (k, _) => k == key) = false) :
    [JsonToken.num n].foldlM parseStep { stack := StackFrame.obj acc (ObjState.expectVal key) :: rest, result := none } =
    .ok { stack := StackFrame.obj ((key, Lean.Json.num n) :: acc) ObjState.expectCommaOrRbrace :: rest, result := none } := by
  dsimp [List.foldlM, parseStep, bind, Except.bind]
  rw [feedValue_obj_expectVal acc key (.num n) rest h_not_dup]
  rfl

/-- Feeding scalar boolean property into object frame expecting value. -/
theorem parse_field_bool_val (acc : List (String × Lean.Json)) (key : String) (b : Bool) (rest : List StackFrame)
    (h_not_dup : acc.any (fun (k, _) => k == key) = false) :
    [JsonToken.bool b].foldlM parseStep { stack := StackFrame.obj acc (ObjState.expectVal key) :: rest, result := none } =
    .ok { stack := StackFrame.obj ((key, Lean.Json.bool b) :: acc) ObjState.expectCommaOrRbrace :: rest, result := none } := by
  dsimp [List.foldlM, parseStep, bind, Except.bind]
  rw [feedValue_obj_expectVal acc key (.bool b) rest h_not_dup]
  rfl

/-- Feeding null property into object frame expecting value. -/
theorem parse_field_null_val (acc : List (String × Lean.Json)) (key : String) (rest : List StackFrame)
    (h_not_dup : acc.any (fun (k, _) => k == key) = false) :
    [JsonToken.null].foldlM parseStep { stack := StackFrame.obj acc (ObjState.expectVal key) :: rest, result := none } =
    .ok { stack := StackFrame.obj ((key, Lean.Json.null) :: acc) ObjState.expectCommaOrRbrace :: rest, result := none } := by
  dsimp [List.foldlM, parseStep, bind, Except.bind]
  rw [feedValue_obj_expectVal acc key .null rest h_not_dup]
  rfl

end DefiKernel.Certificates

