import DefiKernel.Certificates.CanonicalJson
import DefiKernel.Certificates.Encode

namespace DefiKernel.Certificates

theorem escapeTreeString_eq_escapeJsonString (s : String) :
    escapeTreeString s = escapeJsonString s := rfl

theorem encodeList_eq_intercalate (xs : List TreeJson) :
    TreeJson.encodeList xs = String.intercalate "," (xs.map TreeJson.encode) := by
  induction xs with
  | nil => rfl
  | cons x tl ih =>
    cases tl with
    | nil => rfl
    | cons y ys =>
      dsimp [TreeJson.encodeList]
      rw [ih]
      change x.encode ++ "," ++ ",".intercalate (y.encode :: ys.map TreeJson.encode) =
        ",".intercalate (x.encode :: y.encode :: ys.map TreeJson.encode)
      rw [String.intercalate_cons_cons]

theorem encode_arr_eq_jsonArr (xs : List TreeJson) :
    TreeJson.encode (.arr xs) = jsonArr (xs.map TreeJson.encode) := by
  dsimp [TreeJson.encode, jsonArr]
  rw [encodeList_eq_intercalate]

theorem encodeObj_eq_intercalate (kvs : List (String × TreeJson)) :
    TreeJson.encodeObj kvs = String.intercalate "," (kvs.map (fun (k, v) => escapeJsonString k ++ ":" ++ TreeJson.encode v)) := by
  induction kvs with
  | nil => rfl
  | cons f tl ih =>
    rcases f with ⟨k, v⟩
    cases tl with
    | nil => rfl
    | cons f2 kvs' =>
      rcases f2 with ⟨k2, v2⟩
      dsimp [TreeJson.encodeObj]
      rw [ih]
      change (escapeJsonString k ++ ":" ++ v.encode) ++ "," ++
        ",".intercalate ((escapeJsonString k2 ++ ":" ++ v2.encode) :: kvs'.map (fun (k', v') => escapeJsonString k' ++ ":" ++ v'.encode)) =
        ",".intercalate ((escapeJsonString k ++ ":" ++ v.encode) :: (escapeJsonString k2 ++ ":" ++ v2.encode) :: kvs'.map (fun (k', v') => escapeJsonString k' ++ ":" ++ v'.encode))
      rw [String.intercalate_cons_cons]

theorem encode_obj_eq_jsonObj (kvs : List (String × TreeJson)) :
    TreeJson.encode (.obj kvs) = jsonObj (kvs.map (fun (k, v) => (k, TreeJson.encode v))) := by
  dsimp [TreeJson.encode, jsonObj]
  rw [encodeObj_eq_intercalate]
  have h_map : (List.map (fun x => escapeJsonString x.1 ++ ":" ++ x.2) (kvs.map (fun x => (x.1, x.2.encode)))) =
      (kvs.map (fun (k, v) => escapeJsonString k ++ ":" ++ TreeJson.encode v)) := by
    simp only [List.map_map]
    rfl
  rw [h_map]

end DefiKernel.Certificates
