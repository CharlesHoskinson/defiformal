import DefiKernel.Certificates.Schema
import DefiKernel.Certificates.CanonicalJson
import DefiKernel.Certificates.Encode
import DefiKernel.Certificates.Correspondence

namespace DefiKernel.Certificates

theorem ratToTreeJson_valid (r : RatEnc) : TreeJson.Valid (ratToTreeJson r) := by
  dsimp [ratToTreeJson, TreeJson.Valid, TreeJson.ValidObj]
  simp only [List.map_cons, List.map_nil]
  refine ⟨by decide, trivial, trivial, trivial⟩

theorem partyToTreeJson_valid (p : Party) : TreeJson.Valid (partyToTreeJson p) := by
  cases p <;> trivial

theorem assetToTreeJson_valid (a : Asset) : TreeJson.Valid (assetToTreeJson a) := by
  cases a <;> trivial

theorem domainToTreeJson_valid (d : Domain) : TreeJson.Valid (domainToTreeJson d) := by
  cases d <;> trivial

theorem partyRefToTreeJson_valid (pr : PartyRefEnc) : TreeJson.Valid (partyRefToTreeJson pr) := by
  cases pr with
  | caller =>
    dsimp [partyRefToTreeJson, TreeJson.Valid, TreeJson.ValidObj]
    simp only [List.map_cons, List.map_nil]
    refine ⟨by decide, trivial, trivial⟩
  | argument idx =>
    dsimp [partyRefToTreeJson, TreeJson.Valid, TreeJson.ValidObj]
    simp only [List.map_cons, List.map_nil]
    refine ⟨by decide, trivial, trivial, trivial⟩
  | literal p =>
    dsimp [partyRefToTreeJson, TreeJson.Valid, TreeJson.ValidObj]
    simp only [List.map_cons, List.map_nil]
    refine ⟨by decide, trivial, partyToTreeJson_valid p, trivial⟩

theorem cellRefToTreeJson_valid (c : CellRefEnc) : TreeJson.Valid (cellRefToTreeJson c) := by
  dsimp [cellRefToTreeJson, TreeJson.Valid, TreeJson.ValidObj]
  simp only [List.map_cons, List.map_nil]
  refine ⟨by decide, domainToTreeJson_valid c.domain, partyRefToTreeJson_valid c.owner, trivial⟩

theorem packedCellRefToTreeJson_valid (c : PackedCellRefEnc) : TreeJson.Valid (packedCellRefToTreeJson c) := by
  dsimp [packedCellRefToTreeJson, TreeJson.Valid, TreeJson.ValidObj]
  simp only [List.map_cons, List.map_nil]
  refine ⟨by decide, assetToTreeJson_valid c.asset, cellRefToTreeJson_valid c.cell, trivial⟩

theorem observationKeyToTreeJson_valid (k : ObservationKeyEnc) : TreeJson.Valid (observationKeyToTreeJson k) := by
  dsimp [observationKeyToTreeJson, TreeJson.Valid, TreeJson.ValidObj]
  simp only [List.map_cons, List.map_nil]
  refine ⟨by decide, domainToTreeJson_valid k.domain, trivial, trivial⟩

theorem numericUnitToTreeJson_valid (nu : NumericUnitEnc) : TreeJson.Valid (numericUnitToTreeJson nu) := by
  cases nu with
  | scalar =>
    dsimp [numericUnitToTreeJson, TreeJson.Valid, TreeJson.ValidObj]
    simp only [List.map_cons, List.map_nil]
    refine ⟨by decide, trivial, trivial⟩
  | amount a =>
    dsimp [numericUnitToTreeJson, TreeJson.Valid, TreeJson.ValidObj]
    simp only [List.map_cons, List.map_nil]
    refine ⟨by decide, trivial, assetToTreeJson_valid a, trivial⟩
  | price b q =>
    dsimp [numericUnitToTreeJson, TreeJson.Valid, TreeJson.ValidObj]
    simp only [List.map_cons, List.map_nil]
    refine ⟨by decide, trivial, assetToTreeJson_valid b, assetToTreeJson_valid q, trivial⟩

theorem unitToTreeJson_valid (u : UnitEnc) : TreeJson.Valid (unitToTreeJson u) := by
  cases u with
  | bool =>
    dsimp [unitToTreeJson, TreeJson.Valid, TreeJson.ValidObj]
    simp only [List.map_cons, List.map_nil]
    refine ⟨by decide, trivial, trivial⟩
  | numeric nu => exact numericUnitToTreeJson_valid nu

theorem observationRefToTreeJson_valid (r : ObservationRefEnc) : TreeJson.Valid (observationRefToTreeJson r) := by
  dsimp [observationRefToTreeJson, TreeJson.Valid, TreeJson.ValidObj]
  simp only [List.map_cons, List.map_nil]
  refine ⟨by decide, observationKeyToTreeJson_valid r.key, unitToTreeJson_valid r.unit, trivial⟩

theorem unaryOpToTreeJson_valid (op : UnaryOpEnc) : TreeJson.Valid (unaryOpToTreeJson op) := by
  cases op with
  | not =>
    dsimp [unaryOpToTreeJson, TreeJson.Valid, TreeJson.ValidObj]
    simp only [List.map_cons, List.map_nil]
    refine ⟨by decide, trivial, trivial⟩
  | neg nu =>
    dsimp [unaryOpToTreeJson, TreeJson.Valid, TreeJson.ValidObj]
    simp only [List.map_cons, List.map_nil]
    refine ⟨by decide, trivial, numericUnitToTreeJson_valid nu, trivial⟩

theorem binaryOpToTreeJson_valid (op : BinaryOpEnc) : TreeJson.Valid (binaryOpToTreeJson op) := by
  cases op with
  | and | or =>
    dsimp [binaryOpToTreeJson, TreeJson.Valid, TreeJson.ValidObj]
    simp only [List.map_cons, List.map_nil]
    refine ⟨by decide, trivial, trivial⟩
  | eq u =>
    dsimp [binaryOpToTreeJson, TreeJson.Valid, TreeJson.ValidObj]
    simp only [List.map_cons, List.map_nil]
    refine ⟨by decide, trivial, unitToTreeJson_valid u, trivial⟩
  | add nu | sub nu | scale nu | divide nu | ratio nu | lt nu | le nu =>
    dsimp [binaryOpToTreeJson, TreeJson.Valid, TreeJson.ValidObj]
    simp only [List.map_cons, List.map_nil]
    refine ⟨by decide, trivial, numericUnitToTreeJson_valid nu, trivial⟩
  | convert b q | unconvert b q =>
    dsimp [binaryOpToTreeJson, TreeJson.Valid, TreeJson.ValidObj]
    simp only [List.map_cons, List.map_nil]
    refine ⟨by decide, trivial, assetToTreeJson_valid b, assetToTreeJson_valid q, trivial⟩

theorem exprToTreeJson_valid (e : ExprEnc) : TreeJson.Valid (exprToTreeJson e) := by
  induction e with
  | lit v =>
    dsimp [exprToTreeJson]
    cases h : v.unit with
    | bool =>
      dsimp [TreeJson.Valid, TreeJson.ValidObj]
      simp only [List.map_cons, List.map_nil]
      refine ⟨by decide, trivial, ⟨by decide, trivial, trivial⟩, trivial, trivial⟩
    | numeric nu =>
      dsimp [TreeJson.Valid, TreeJson.ValidObj]
      simp only [List.map_cons, List.map_nil]
      refine ⟨by decide, trivial, numericUnitToTreeJson_valid nu, ratToTreeJson_valid ⟨v.valRat.num, v.valRat.den⟩, trivial⟩
  | arg idx u =>
    dsimp [exprToTreeJson, TreeJson.Valid, TreeJson.ValidObj]
    simp only [List.map_cons, List.map_nil]
    refine ⟨by decide, trivial, trivial, unitToTreeJson_valid u, trivial⟩
  | balance c =>
    dsimp [exprToTreeJson, TreeJson.Valid, TreeJson.ValidObj]
    simp only [List.map_cons, List.map_nil]
    refine ⟨by decide, trivial, packedCellRefToTreeJson_valid c, trivial⟩
  | observe r =>
    dsimp [exprToTreeJson, TreeJson.Valid, TreeJson.ValidObj]
    simp only [List.map_cons, List.map_nil]
    refine ⟨by decide, trivial, observationRefToTreeJson_valid r, trivial⟩
  | timestamp k =>
    dsimp [exprToTreeJson, TreeJson.Valid, TreeJson.ValidObj]
    simp only [List.map_cons, List.map_nil]
    refine ⟨by decide, trivial, observationKeyToTreeJson_valid k, trivial⟩
  | now =>
    dsimp [exprToTreeJson, TreeJson.Valid, TreeJson.ValidObj]
    simp only [List.map_cons, List.map_nil]
    refine ⟨by decide, trivial, trivial⟩
  | unary op x ih =>
    dsimp [exprToTreeJson, TreeJson.Valid, TreeJson.ValidObj]
    simp only [List.map_cons, List.map_nil]
    refine ⟨by decide, trivial, unaryOpToTreeJson_valid op, ih, trivial⟩
  | binary op x y ih_x ih_y =>
    dsimp [exprToTreeJson, TreeJson.Valid, TreeJson.ValidObj]
    simp only [List.map_cons, List.map_nil]
    refine ⟨by decide, trivial, binaryOpToTreeJson_valid op, ih_x, ih_y, trivial⟩
  | ite c y n ih_c ih_y ih_n =>
    dsimp [exprToTreeJson, TreeJson.Valid, TreeJson.ValidObj]
    simp only [List.map_cons, List.map_nil]
    refine ⟨by decide, trivial, ih_c, ih_y, ih_n, trivial⟩

theorem parseTokens_exprToTreeJson (e : ExprEnc)
    (h_depth : TreeJson.depth (exprToTreeJson e) ≤ 64) :
    parseTokens (TreeJson.tokens (exprToTreeJson e)) = .ok (exprToJson e) := by
  have h_val := exprToTreeJson_valid e
  have h_parse := parseTokens_tree_valid (exprToTreeJson e) h_val h_depth
  rw [exprToTreeJson_toJson] at h_parse
  exact h_parse

end DefiKernel.Certificates
