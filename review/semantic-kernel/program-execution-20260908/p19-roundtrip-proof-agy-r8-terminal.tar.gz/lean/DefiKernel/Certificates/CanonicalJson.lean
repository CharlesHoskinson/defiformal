import Lean.Data.Json.Basic
import DefiKernel.Certificates.Schema

namespace DefiKernel.Certificates

set_option linter.style.longLine false

/-- Tokens produced by the canonical JSON lexer. -/
inductive JsonToken where
  | lbrace
  | rbrace
  | lbracket
  | rbracket
  | colon
  | comma
  | str (s : String)
  | num (n : Lean.JsonNumber)
  | bool (b : Bool)
  | null
  deriving Inhabited, BEq

def hexDigit (n : Nat) : Char :=
  if n = 0 then '0'
  else if n = 1 then '1'
  else if n = 2 then '2'
  else if n = 3 then '3'
  else if n = 4 then '4'
  else if n = 5 then '5'
  else if n = 6 then '6'
  else if n = 7 then '7'
  else if n = 8 then '8'
  else if n = 9 then '9'
  else if n = 10 then 'a'
  else if n = 11 then 'b'
  else if n = 12 then 'c'
  else if n = 13 then 'd'
  else if n = 14 then 'e'
  else 'f'

def hexVal (c : Char) : Option Nat :=
  if c >= '0' && c <= '9' then some (c.toNat - '0'.toNat)
  else if c >= 'a' && c <= 'f' then some (c.toNat - 'a'.toNat + 10)
  else if c >= 'A' && c <= 'F' then some (c.toNat - 'A'.toNat + 10)
  else none

def escapeChar (c : Char) : List Char :=
  if c = '"' then ['\\', '"']
  else if c = '\\' then ['\\', '\\']
  else if c.toNat < 32 then
    ['\\', 'u', '0', '0', hexDigit (c.toNat / 16), hexDigit (c.toNat % 16)]
  else [c]

def escapeChars : List Char → List Char
  | [] => []
  | c :: cs => escapeChar c ++ escapeChars cs

/-- Structurally recursive string literal parser on character list.
    Enforces canonical C0 unicode escaping, accepts standard JSON escapes,
    rejects malformed/unknown escapes, and rejects literal unescaped control characters. -/
def lexString (acc : List Char) : List Char → Except DecodeFailure (String × List Char)
  | [] => .error .notJsonObject
  | '"' :: rest => .ok (String.ofList acc.reverse, rest)
  | '\\' :: 'u' :: h1 :: h2 :: h3 :: h4 :: rest =>
    match hexVal h1, hexVal h2, hexVal h3, hexVal h4 with
    | some v1, some v2, some v3, some v4 =>
      let val := ((v1 * 16 + v2) * 16 + v3) * 16 + v4
      if val < 0x110000 && !(0xd800 ≤ val && val < 0xe000) then
        lexString (Char.ofNat val :: acc) rest
      else .error .notJsonObject
    | _, _, _, _ => .error .notJsonObject
  | '\\' :: '"' :: rest => lexString ('"' :: acc) rest
  | '\\' :: '\\' :: rest => lexString ('\\' :: acc) rest
  | '\\' :: '/' :: rest => lexString ('/' :: acc) rest
  | '\\' :: 'b' :: rest => lexString ('\x08' :: acc) rest
  | '\\' :: 'f' :: rest => lexString ('\x0c' :: acc) rest
  | '\\' :: 'n' :: rest => lexString ('\n' :: acc) rest
  | '\\' :: 'r' :: rest => lexString ('\x0d' :: acc) rest
  | '\\' :: 't' :: rest => lexString ('\t' :: acc) rest
  | '\\' :: _ => .error .notJsonObject
  | c :: rest =>
    if c.toNat < 32 then .error .notJsonObject
    else lexString (c :: acc) rest

/-- Structurally recursive integer digit parser on character list. -/
def lexDigits (acc : Nat) : List Char → Nat × List Char
  | [] => (acc, [])
  | c :: rest =>
    if c >= '0' && c <= '9' then
      lexDigits (acc * 10 + (c.toNat - '0'.toNat)) rest
    else
      (acc, c :: rest)

/-- Fuel-bounded total canonical tokenizer. Guaranteed terminating on fuel. -/
def tokenizeFuel (fuel : Nat) (chars : List Char) : Except DecodeFailure (List JsonToken) :=
  match fuel with
  | 0 => .error (.resourceLimit "tokenizeFuel")
  | fuel' + 1 =>
    match chars with
    | [] => .ok []
    | ' ' :: rest | '\t' :: rest | '\n' :: rest | '\r' :: rest =>
      tokenizeFuel fuel' rest
    | '{' :: rest => do
      let toks ← tokenizeFuel fuel' rest
      .ok (.lbrace :: toks)
    | '}' :: rest => do
      let toks ← tokenizeFuel fuel' rest
      .ok (.rbrace :: toks)
    | '[' :: rest => do
      let toks ← tokenizeFuel fuel' rest
      .ok (.lbracket :: toks)
    | ']' :: rest => do
      let toks ← tokenizeFuel fuel' rest
      .ok (.rbracket :: toks)
    | ':' :: rest => do
      let toks ← tokenizeFuel fuel' rest
      .ok (.colon :: toks)
    | ',' :: rest => do
      let toks ← tokenizeFuel fuel' rest
      .ok (.comma :: toks)
    | '"' :: rest => do
      let (s, rest') ← lexString [] rest
      let toks ← tokenizeFuel fuel' rest'
      .ok (.str s :: toks)
    | 't' :: 'r' :: 'u' :: 'e' :: rest => do
      let toks ← tokenizeFuel fuel' rest
      .ok (.bool true :: toks)
    | 'f' :: 'a' :: 'l' :: 's' :: 'e' :: rest => do
      let toks ← tokenizeFuel fuel' rest
      .ok (.bool false :: toks)
    | 'n' :: 'u' :: 'l' :: 'l' :: rest => do
      let toks ← tokenizeFuel fuel' rest
      .ok (.null :: toks)
    | '-' :: c :: rest =>
      if c >= '0' && c <= '9' then do
        let (n, rest') := lexDigits (c.toNat - '0'.toNat) rest
        let toks ← tokenizeFuel fuel' rest'
        .ok (.num ⟨- (n : Int), 0⟩ :: toks)
      else
        .error .notJsonObject
    | c :: rest =>
      if c >= '0' && c <= '9' then do
        let (n, rest') := lexDigits (c.toNat - '0'.toNat) rest
        let toks ← tokenizeFuel fuel' rest'
        .ok (.num ⟨(n : Int), 0⟩ :: toks)
      else
        .error .notJsonObject

/-- Entrypoint for canonical JSON tokenization. -/
def tokenize (s : String) : Except DecodeFailure (List JsonToken) :=
  let cs := s.toList
  tokenizeFuel (cs.length + 1) cs

/-- State within an object frame during pushdown parsing. -/
inductive ObjState where
  | emptyOrKey
  | expectKey
  | expectColon (key : String)
  | expectVal (key : String)
  | expectCommaOrRbrace

/-- State within an array frame during pushdown parsing. -/
inductive ArrState where
  | emptyOrVal
  | expectVal
  | expectCommaOrRbracket

/-- Stack frame for pushdown automaton parsing nested structures. -/
inductive StackFrame where
  | obj (acc : List (String × Lean.Json)) (st : ObjState)
  | arr (acc : Array Lean.Json) (st : ArrState)

/-- State of the pushdown parser. -/
structure ParserState where
  stack : List StackFrame
  result : Option Lean.Json

/-- Feeds a completed JSON value into the enclosing stack frame. -/
def feedValue (st : ParserState) (v : Lean.Json) : Except DecodeFailure ParserState :=
  match st.stack with
  | [] =>
    if st.result.isSome then .error .notJsonObject
    else .ok { stack := [], result := some v }
  | StackFrame.arr acc ArrState.emptyOrVal :: rest =>
    if acc.size >= 4096 then .error (.resourceLimit "max_array_length")
    else .ok { st with stack := StackFrame.arr (acc.push v) ArrState.expectCommaOrRbracket :: rest }
  | StackFrame.arr acc ArrState.expectVal :: rest =>
    if acc.size >= 4096 then .error (.resourceLimit "max_array_length")
    else .ok { st with stack := StackFrame.arr (acc.push v) ArrState.expectCommaOrRbracket :: rest }
  | StackFrame.obj acc (ObjState.expectVal key) :: rest =>
    if acc.any (fun (k, _) => k == key) then .error (.duplicateKey key)
    else .ok { st with stack := StackFrame.obj ((key, v) :: acc) ObjState.expectCommaOrRbrace :: rest }
  | _ => .error .notJsonObject

/-- Single transition step for the pushdown parser on one token. -/
def parseStep (st : ParserState) (tok : JsonToken) : Except DecodeFailure ParserState :=
  match tok with
  | .null => feedValue st .null
  | .bool b => feedValue st (.bool b)
  | .num n => feedValue st (.num n)
  | .str s =>
    match st.stack with
    | StackFrame.obj acc ObjState.emptyOrKey :: rest =>
      .ok { st with stack := StackFrame.obj acc (ObjState.expectColon s) :: rest }
    | StackFrame.obj acc ObjState.expectKey :: rest =>
      .ok { st with stack := StackFrame.obj acc (ObjState.expectColon s) :: rest }
    | _ =>
      feedValue st (.str s)
  | .colon =>
    match st.stack with
    | StackFrame.obj acc (ObjState.expectColon k) :: rest =>
      .ok { st with stack := StackFrame.obj acc (ObjState.expectVal k) :: rest }
    | _ => .error .notJsonObject
  | .comma =>
    match st.stack with
    | StackFrame.obj acc ObjState.expectCommaOrRbrace :: rest =>
      .ok { st with stack :=StackFrame.obj acc ObjState.expectKey :: rest }
    | StackFrame.arr acc ArrState.expectCommaOrRbracket :: rest =>
      .ok { st with stack := StackFrame.arr acc ArrState.expectVal :: rest }
    | _ => .error .notJsonObject
  | .lbrace =>
    if st.stack.length >= 64 then .error (.resourceLimit "maxDepth")
    else match st.stack with
    | [] =>
      if st.result.isSome then .error .notJsonObject
      else .ok { st with stack := [StackFrame.obj [] ObjState.emptyOrKey] }
    | StackFrame.arr _ ArrState.emptyOrVal :: _
    | StackFrame.arr _ ArrState.expectVal :: _
    | StackFrame.obj _ (ObjState.expectVal _) :: _ =>
      .ok { st with stack := StackFrame.obj [] ObjState.emptyOrKey :: st.stack }
    | _ => .error .notJsonObject
  | .rbrace =>
    match st.stack with
    | StackFrame.obj acc ObjState.emptyOrKey :: rest =>
      let objVal := Lean.Json.mkObj acc.reverse
      feedValue { st with stack := rest } objVal
    | StackFrame.obj acc ObjState.expectCommaOrRbrace :: rest =>
      let objVal := Lean.Json.mkObj acc.reverse
      feedValue { st with stack := rest } objVal
    | _ => .error .notJsonObject
  | .lbracket =>
    if st.stack.length >= 64 then .error (.resourceLimit "maxDepth")
    else match st.stack with
    | [] =>
      if st.result.isSome then .error .notJsonObject
      else .ok { st with stack := [StackFrame.arr #[] ArrState.emptyOrVal] }
    | StackFrame.arr _ ArrState.emptyOrVal :: _
    | StackFrame.arr _ ArrState.expectVal :: _
    | StackFrame.obj _ (ObjState.expectVal _) :: _ =>
      .ok { st with stack := StackFrame.arr #[] ArrState.emptyOrVal :: st.stack }
    | _ => .error .notJsonObject
  | .rbracket =>
    match st.stack with
    | StackFrame.arr acc ArrState.emptyOrVal :: rest =>
      let arrVal := Lean.Json.arr acc
      feedValue { st with stack := rest } arrVal
    | StackFrame.arr acc ArrState.expectCommaOrRbracket :: rest =>
      let arrVal := Lean.Json.arr acc
      feedValue { st with stack := rest } arrVal
    | _ => .error .notJsonObject

/-- Total pushdown parser over a token list. Guaranteed terminating by structural recursion. -/
def parseTokens (toks : List JsonToken) : Except DecodeFailure Lean.Json := do
  let finalSt ← toks.foldlM parseStep { stack := [], result := none }
  match finalSt.stack, finalSt.result with
  | [], some j => .ok j
  | _, _ => .error .notJsonObject

/-- Total canonical JSON parser. Converts string to Lean.Json with zero partiality. -/
def parseCanonicalJson (s : String) : Except DecodeFailure Lean.Json := do
  let toks ← tokenize s
  parseTokens toks

theorem hexVal_hexDigit (n : Nat) (h : n < 16) : hexVal (hexDigit n) = some n := by
  match n, h with
  | 0, _ => rfl
  | 1, _ => rfl
  | 2, _ => rfl
  | 3, _ => rfl
  | 4, _ => rfl
  | 5, _ => rfl
  | 6, _ => rfl
  | 7, _ => rfl
  | 8, _ => rfl
  | 9, _ => rfl
  | 10, _ => rfl
  | 11, _ => rfl
  | 12, _ => rfl
  | 13, _ => rfl
  | 14, _ => rfl
  | 15, _ => rfl
  | _ + 16, h => omega

theorem bool_cond_of_lt32 (n : Nat) (h : n < 32) :
    (decide (n < 1114112) && !(decide (55296 ≤ n) && decide (n < 57344))) = true := by
  have h1 : n < 1114112 := by omega
  have h2 : ¬ (55296 ≤ n) := by omega
  rw [decide_eq_true h1, decide_eq_false h2]
  rfl

theorem lexString_quote (acc rest : List Char) :
    lexString acc ('\\' :: '"' :: rest) = lexString ('"' :: acc) rest := by
  rfl

theorem lexString_slash (acc rest : List Char) :
    lexString acc ('\\' :: '\\' :: rest) = lexString ('\\' :: acc) rest := by
  rfl

theorem lexString_u00 (c : Char) (h_lt : c.toNat < 32) (acc rest : List Char) :
    lexString acc ('\\' :: 'u' :: '0' :: '0' :: hexDigit (c.toNat / 16) :: hexDigit (c.toNat % 16) :: rest) =
      lexString (c :: acc) rest := by
  change (match hexVal '0', hexVal '0', hexVal (hexDigit (c.toNat / 16)), hexVal (hexDigit (c.toNat % 16)) with
    | some v1, some v2, some v3, some v4 =>
      let val := ((v1 * 16 + v2) * 16 + v3) * 16 + v4
      if val < 0x110000 && !(0xd800 ≤ val && val < 0xe000) then
        lexString (Char.ofNat val :: acc) rest
      else .error .notJsonObject
    | _, _, _, _ => .error .notJsonObject) = lexString (c :: acc) rest
  have h1 : hexVal '0' = some 0 := rfl
  have h3 : hexVal (hexDigit (c.toNat / 16)) = some (c.toNat / 16) := by
    apply hexVal_hexDigit; omega
  have h4 : hexVal (hexDigit (c.toNat % 16)) = some (c.toNat % 16) := by
    apply hexVal_hexDigit; omega
  rw [h1, h3, h4]
  dsimp
  have h_val : ((0 * 16 + 0) * 16 + c.toNat / 16) * 16 + c.toNat % 16 = c.toNat := by
    omega
  rw [h_val]
  have hb := bool_cond_of_lt32 c.toNat h_lt
  rw [hb]
  dsimp
  rw [Char.ofNat_toNat]

set_option linter.style.multiGoal false
set_option linter.unusedTactic false
set_option linter.unreachableTactic false

theorem lexString_normal (c : Char) (h_q : c ≠ '"') (h_s : c ≠ '\\') (h_ge : ¬ (c.toNat < 32))
    (acc rest : List Char) :
    lexString acc (c :: rest) = lexString (c :: acc) rest := by
  rw [lexString]
  split
  · contradiction
  · rfl
  all_goals
    try (intro h; subst h; contradiction)
    try (intro _ _ _ _ _ h _; subst h; contradiction)
    try (intro _ h _; subst h; contradiction)
    try (intro _ h; subst h; contradiction)
    try contradiction

theorem lexString_char (c : Char) (acc rest : List Char) :
    lexString acc (escapeChar c ++ rest) = lexString (c :: acc) rest := by
  dsimp [escapeChar]
  split
  · rename_i hc
    subst hc
    exact lexString_quote acc rest
  · split
    · rename_i _ hc
      subst hc
      exact lexString_slash acc rest
    · split
      · rename_i _ _ h_lt
        exact lexString_u00 c h_lt acc rest
      · rename_i h_not_q h_not_s h_not_lt
        exact lexString_normal c h_not_q h_not_s h_not_lt acc rest

theorem lexString_escapeChars (cs : List Char) (acc rest : List Char) :
    lexString acc (escapeChars cs ++ ('"' :: rest)) = .ok (String.ofList (acc.reverse ++ cs), rest) := by
  induction cs generalizing acc with
  | nil =>
    simp only [escapeChars, List.nil_append, List.append_nil]
    rfl
  | cons c cs ih =>
    simp only [escapeChars, List.append_assoc]
    rw [lexString_char]
    have h := ih (c :: acc)
    simp only [List.reverse_cons, List.append_assoc, List.singleton_append] at h
    exact h

/-- General string lexing inversion theorem: for any string s, lexing its canonical escaped form returns s. -/
theorem lexString_escapeJsonString (s : String) (rest : List Char) :
    lexString [] (escapeChars s.toList ++ ('"' :: rest)) = .ok (s, rest) := by
  have h := lexString_escapeChars s.toList [] rest
  simp only [List.reverse_nil, List.nil_append] at h
  rw [String.ofList_toList] at h
  exact h

/-- UTF-8 byte serialization inverse: decoding the UTF-8 bytes of any string returns the string. -/
theorem string_fromUTF8?_toUTF8 (s : String) : String.fromUTF8? s.toUTF8 = some s := by
  dsimp [String.fromUTF8?, String.toUTF8]
  have h : s.toByteArray.IsValidUTF8 := s.isValidUTF8
  rw [dif_pos h]
  rfl

end DefiKernel.Certificates
