# P19 Typed/Sequential Certificate Verification — Attempt AGY-R19-PROOF Report

- **Candidate**: P19 Typed/Sequential Certificates (Scanner Unterminated/Whitespace Precedence Repair & Recursive Pushdown TreeJson / Expr Inversion Extensions)
- **Attempt**: `agy-r19-proof`
- **Date**: 2026-09-10
- **Authorship**: Sole native AGY author (`gemini-3.8-flash-high`, `--effort high`)
- **Auditor**: Pending (fresh native Grok `grok-4.6` high effort session requested; pending independent audit receipt, not simulated or pre-approved)
- **Worktree**: `/home/charl/defiformal-wt-p19-certificates-grok-opus-20260909`
- **Detached Base**: `38de83c58e3f9315bf400807591d538d7565152e`
- **Toolchain**: Lean 4.33.0-rc2 (`d8b18978322de05a8f3dba51ef03cf5461676c17`), Mathlib `51e6992`
- **Disposition**: `PARTIAL_PROOF_WORK`

---

## 1. Executive Summary & Disposition

### Disposition Statement: `PARTIAL_PROOF_WORK`
1. The universal roundtrip theorem `EncodeDecodeRoundtripStatement` remains an open `def Prop` over `StructurallyAdmissibleIR ir`. While major formal milestones have been established—including exact scanner error-precedence restoration across all root controls, inductive ordered JSON syntax (`TreeJson`), pushdown automaton reduction lemmas, universal rational end-to-end roundtrip, universal unit/numericUnit/unaryOp codec roundtrips, and core expression inversions (`now`, `lit`, `unary`, `binary`, `ite`, `balance`, `timestamp`, `observe`)—the full inductive closure connecting the raw envelope byte stream to whole-document `parseTokens` inversion across arbitrary recursive ASTs remains open in the Lean 4 kernel.
2. We make **zero claim** that universal byte-level recursive parser induction across arbitrary nested AST expressions is completed.
3. No review by native Grok is claimed or simulated. The auditor is truthfully recorded as `pending (fresh native Grok grok-4.6 session requested, pending independent receipt)`.
4. In strict accordance with program instructions, the 54-fixture / 99-scenario / 16-mutant acceptance campaigns remain deferred until this universal mathematical theorem closes.

### Major Deliverables in `agy-r19-proof`:
1. **Scanner Unterminated String / Whitespace Precedence Repaired**:
   - Resolved the root finding documented in `p19-r18-unterminated-precedence-finding.json`.
   - In R18, when `skipStringChars` returned `none` (unterminated string reaching EOF), `scanLexicalFuel` immediately returned `.error .notJsonObject`, omitting the check for prior `foundWhitespace`.
   - Repaired `scanLexicalFuel` in `Decode.lean` to enforce:
     ```lean
     | none => if foundWhitespace then .error .noncanonicalWhitespace else .error .notJsonObject
     ```
   - Replays and passes all 4 unterminated string regression controls matching R15:
     * `unterminated_value_space`: `noncanonicalWhitespace` (PASS, matches R15)
     * `unterminated_key_space`: `noncanonicalWhitespace` (PASS, matches R15)
     * `unterminated_value_no_space`: `notJsonObject` (PASS)
     * `unterminated_key_no_space`: `notJsonObject` (PASS)
   - Preserves all 6 mixed-error failure precedence diagnostic outputs (stdout SHA-256 `0ec3c792debf9f40328a2f78e0cd97b21303911262542cf2939ab3ca21d25d02`).
   - Preserves all 32 C0 collision roundtrips, duplicate keys, and quote/backslash controls (stdout SHA-256 `6caac5c24bbef54474ebc6635ba526341a58169148fd2c8470407aa78f90df6d`).
   - Enforces all resource bounds (1 MiB input cap, max depth 64, max array length 4096).

2. **13 New Pushdown Automaton Reduction Lemmas in `CanonicalJson.lean`**:
   - Formalized proof-level ordered JSON syntax relation `TreeJson` (inductive AST covering `null`, `bool`, `num`, `str`, `arr`, `obj` with semantic `toJson`, canonical `tokens`, and canonical `encode`).
   - Proved 13 pushdown parsing and inversion lemmas:
     * `parseStep_foldlM_tokens_null`, `parseStep_foldlM_tokens_bool`, `parseStep_foldlM_tokens_num`
     * `parseTokensList_nil`, `parseTokensObj_nil`
     * `parseTokens_empty_tree_obj`, `parseTokens_empty_tree_arr`
     * `parseTokens_tree_null`, `parseTokens_tree_bool`, `parseTokens_tree_num`, `parseTokens_tree_str`
     * `parseTokens_tree_empty_arr`, `parseTokens_tree_empty_obj`
   - Total named declarations in `CanonicalJson.lean` increased from 68 to **81**.

3. **19 New Parsing and End-to-End Inversion Theorems in `Correspondence.lean`**:
   - Proved canonical JSON parser inversion and end-to-end codec roundtrips for core expression forms:
     * `parseCanonicalJson_encodeExpr_now`, `expr_end_to_end_now`
     * `parseCanonicalJson_encodeExpr_lit_bool`, `parseCanonicalJson_encodeExpr_lit_bool_true`, `parseCanonicalJson_encodeExpr_lit_bool_false`
     * `expr_end_to_end_lit_bool_true`, `expr_end_to_end_lit_bool_false`
     * `parseCanonicalJson_encodeExpr_unary_not_now`, `expr_end_to_end_unary_not_now`
     * `parseCanonicalJson_encodeExpr_binary_and_now`, `expr_end_to_end_binary_and_now`
     * `parseCanonicalJson_encodeExpr_ite_now`, `expr_end_to_end_ite_now`
     * `parseCanonicalJson_encodeExpr_balance_caller`, `expr_end_to_end_balance_caller`
     * `parseCanonicalJson_encodeExpr_timestamp`, `expr_end_to_end_timestamp`
     * `parseCanonicalJson_encodeExpr_observe`, `expr_end_to_end_observe`
   - Total named declarations in `Correspondence.lean` increased from 243 to **262**.

4. **Preservation of All 311 Prior Declarations and Zero Source Line Removals**:
   - All 311 historical declarations are strictly preserved without modification.
   - Zero historical source lines removed from `CanonicalJson.lean` and `Correspondence.lean`.
   - Total named declarations in `CanonicalJson.lean` and `Correspondence.lean` now stand at exact **343**.
   - Compiler `#print axioms` audit on all 343 declarations: 331 standard axioms (`propext`, `Quot.sound`, `Classical.choice`), 12 zero axioms, **0 forbidden axioms**, **0 sorry**, **0 native_decide**.

5. **Disaggregated Transitive Axiom Audit by Prefix**:
   - Transitive compiler audit via `Verify.lean` reported separately across all 3 prefixes:
     * **`DefiKernel.Certificates`**: 1552/1552 theorems, 2628/2628 supplemental declarations, 0 forbidden axioms.
     * **`DefiKernel.Typed`**: 420/420 theorems, 677/677 supplemental declarations, 0 forbidden axioms.
     * **`DefiKernel.Composition`**: 287/287 theorems, 408/408 supplemental declarations, 0 forbidden axioms.

6. **Full Traceability in `commands.json`**:
   - Captured actual ISO UTC timestamps (`start`, `end`), exit codes, exact `argv` lists, working directories `cwd`, raw stdout/stderr log paths, and SHA-256 stream hashes for all 9 executed commands.
   - Raw streams, probes, and metadata preserved under `logs/` and `probes/`.

---

## 2. Technical Analysis: Scanner Unterminated Precedence Repair

### 2.1 The Root Cause in R18
In R18, `skipStringChars` was introduced to advance past string literals with malformed escape sequences to allow downstream lexical/resource errors to be detected. However, when an unterminated string reached end-of-file, `skipStringChars` returned `none`. In `scanLexicalFuel`:
```lean
-- R18 implementation:
| none => .error .notJsonObject
```
This immediately emitted `.notJsonObject`, failing to observe whether noncanonical whitespace (`foundWhitespace`) had occurred prior to the unterminated string. As a result, `{"a": "unterminated` returned `notJsonObject` instead of `noncanonicalWhitespace`, regressing relative to R15.

### 2.2 The Solution in R19
We corrected `scanLexicalFuel` in `lean/DefiKernel/Certificates/Decode.lean` across both string key and string value scanning branches:
```lean
-- R19 implementation:
| none => if foundWhitespace then .error .noncanonicalWhitespace else .error .notJsonObject
```

### 2.3 Empirical Verification
1. **Unterminated Precedence Probe (`probes/unterminated_precedence.lean`)**:
   - `unterminated_value_space` (`{"a": "val`): scan = `noncanonicalWhitespace`, decode = `noncanonicalWhitespace` (PASS, matches R15)
   - `unterminated_value_no_space` (`{"a":"val`): scan = `notJsonObject`, decode = `notJsonObject` (PASS)
   - `unterminated_key_space` (`{ "a"`): scan = `noncanonicalWhitespace`, decode = `noncanonicalWhitespace` (PASS, matches R15)
   - `unterminated_key_no_space` (`{"a`): scan = `notJsonObject`, decode = `notJsonObject` (PASS)

2. **Mixed-Error Precedence Probe (`probes/mixed_error_precedence.lean`)**:
   All 6 diagnostic cases remain bit-for-bit identical to the frozen R15 baseline:
   - `bad_escape_then_scientific` -> `lexicalScientificOrFloat`
   - `whitespace_then_bad_escape` -> `noncanonicalWhitespace`
   - `bad_escape_then_duplicate` -> `duplicateKey "b"`
   - `bad_escape_then_depth` -> `resourceLimit "maxDepth"`
   - `scientific_then_bad_escape` -> `lexicalScientificOrFloat`
   - `duplicate_then_bad_escape` -> `duplicateKey "b"`
   Stdout SHA-256: `0ec3c792debf9f40328a2f78e0cd97b21303911262542cf2939ab3ca21d25d02`.

3. **C0 Collision and Duplicate Controls (`probes/c0_controls.lean`)**:
   - 32/32 C0 control key collision cases passing (`scan=ok;decode=ok;parserObject=ok`).
   - `{"a":"1","a":"2"}` -> `duplicateKey "a"` (scan and parser).
   - `{"a":"1","\u0061":"2"}` -> `duplicateKey "a"` (scan and parser).
   - `{"q\"":"1","q":"2"}` -> `scan=ok;parser=ok` (distinct keys preserved).
   - `{"b\\":"1","b":"2"}` -> `scan=ok;parser=ok` (distinct keys preserved).
   Stdout SHA-256: `6caac5c24bbef54474ebc6635ba526341a58169148fd2c8470407aa78f90df6d`.

---

## 3. Formal Extensions: TreeJson and Recursive Expression Inversions

### 3.1 Inductive Syntax Relation: `TreeJson`
To provide a rigorous proof target for recursive pushdown parsing without ad-hoc string manipulations, we introduced the `TreeJson` inductive datatype in `CanonicalJson.lean`:
```lean
inductive TreeJson where
  | null
  | bool (b : Bool)
  | num (n : Int)
  | str (s : String)
  | arr (elements : List TreeJson)
  | obj (fields : List (String × TreeJson))
  deriving Repr, Inhabited
```
We defined mutual semantic interpretations:
- `TreeJson.toJson : TreeJson → Lean.Json`
- `TreeJson.tokens : TreeJson → List JsonToken`
- `TreeJson.encode : TreeJson → String`

And proved 13 reduction lemmas establishing the operational behavior of the pushdown parser on canonical token sequences generated by `TreeJson`.

### 3.2 Expression Inversions in `Correspondence.lean`
We extended `Correspondence.lean` with 19 theorems covering core expression forms in `ExprEnc`:
- `now`:
  * `parseCanonicalJson_encodeExpr_now`
  * `expr_end_to_end_now`
- `lit`:
  * `parseCanonicalJson_encodeExpr_lit_bool`
  * `parseCanonicalJson_encodeExpr_lit_bool_true`
  * `parseCanonicalJson_encodeExpr_lit_bool_false`
  * `expr_end_to_end_lit_bool_true`
  * `expr_end_to_end_lit_bool_false`
- `unary`:
  * `parseCanonicalJson_encodeExpr_unary_not_now`
  * `expr_end_to_end_unary_not_now`
- `binary`:
  * `parseCanonicalJson_encodeExpr_binary_and_now`
  * `expr_end_to_end_binary_and_now`
- `ite`:
  * `parseCanonicalJson_encodeExpr_ite_now`
  * `expr_end_to_end_ite_now`
- `balance`:
  * `parseCanonicalJson_encodeExpr_balance_caller`
  * `expr_end_to_end_balance_caller`
- `timestamp`:
  * `parseCanonicalJson_encodeExpr_timestamp`
  * `expr_end_to_end_timestamp`
- `observe`:
  * `parseCanonicalJson_encodeExpr_observe`
  * `expr_end_to_end_observe`

---

## 4. Axiom and Declaration Audit

### 4.1 Exact Inventory of Named Declarations
Across `CanonicalJson.lean` (81) and `Correspondence.lean` (262), exactly **343** named declarations were audited:
- **Standard axioms only** (`propext`, `Quot.sound`, `Classical.choice`): 331 declarations.
- **Zero axioms** (purely constructive / computational proofs): 12 declarations.
- **Forbidden axioms** (`sorry`, `sorryAx`, custom axioms): **0**.
- **`native_decide`**: **0**.

#### The 12 Zero-Axiom Declarations:
1. `DefiKernel.Certificates.distinct_of_pairwise_lt`
2. `DefiKernel.Certificates.envelopeOrderedKeys_nodup`
3. `DefiKernel.Certificates.foldl_max_congr`
4. `DefiKernel.Certificates.lexDigits_step_eq`
5. `DefiKernel.Certificates.rat_fromRat_num_den`
6. `DefiKernel.Certificates.rational_decode_canonical`
7. `DefiKernel.Certificates.rational_roundtrip`
8. `DefiKernel.Certificates.runPayloadKeys_nodup`
9. `DefiKernel.Certificates.standard32CellKeys_eraseDups_len`
10. `DefiKernel.Certificates.stepPayloadKeys_nodup`
11. `DefiKernel.Certificates.typedPayloadKeys_nodup`
12. `DefiKernel.Certificates.world_unique_of_canonical`

### 4.2 Transitive Verification Audit (`Verify.lean`)
Transitive compiler verification results across the entire kernel:
- **`DefiKernel.Certificates`**: 1552/1552 theorems, 2628/2628 supplemental declarations, 0 forbidden axioms.
- **`DefiKernel.Typed`**: 420/420 theorems, 677/677 supplemental declarations, 0 forbidden axioms.
- **`DefiKernel.Composition`**: 287/287 theorems, 408/408 supplemental declarations, 0 forbidden axioms.

### 4.3 Unit Tests and Fixture Regressions
- Unit test suite (`Tests.lean`): 21/21 passed.
- Fixture runner safety suite (`scripts/test_certificate_fixture_runner.py`): 7/7 passed.
- Full project build (`lake build DefiKernel`): completed cleanly with 0 errors.

---

## 5. Strongest General Theorem and Unresolved Induction Case

### 5.1 Strongest General Theorems Proven in Kernel
1. **Universal Canonical Rational Inversion**:
   ```lean
   theorem parseCanonicalJson_encodeRat (r : RatEnc) :
       parseCanonicalJson (encodeRat r) = .ok (ratToJson r)
   ```
   Holds universally for all `r : RatEnc` without scalar bounds or preconditions.

2. **Universal Rational End-to-End Roundtrip**:
   ```lean
   theorem rat_end_to_end_universal (r : RatEnc)
       (h_den : r.den ≠ 0) (h_gcd : Int.gcd r.num.natAbs r.den = 1) :
       (do
         let j ← parseCanonicalJson (encodeRat r)
         decodeRat j) = .ok r
   ```

3. **Universal NumericUnit, Unit, and UnaryOp Inversions**:
   ```lean
   theorem numericUnit_end_to_end_universal (nu : NumericUnitEnc) :
       (do let j ← parseCanonicalJson (encodeNumericUnit nu); decodeNumericUnit j) = .ok nu

   theorem unit_end_to_end_universal (u : UnitEnc) :
       (do let j ← parseCanonicalJson (encodeUnit u); decodeUnit j) = .ok u

   theorem unaryOp_end_to_end_universal (op : UnaryOpEnc) :
       (do let j ← parseCanonicalJson (encodeUnaryOp op); decodeUnaryOp j) = .ok op
   ```

4. **Pushdown Automaton Context Transition Lemmas**:
   - `parse_obj_first_field_step`, `parse_obj_first_field_comma`
   - `parse_obj_field_step`, `parse_obj_field_comma`
   - `parse_field_str_val`, `parse_field_num_val`, `parse_field_bool_val`, `parse_field_null_val`
   - `parse_arr_feed_elem`
   - `parse_obj_rbrace`, `parse_arr_rbracket`
   - `parseTokens_of_foldlM`, `parseCanonicalJson_of_tokenize_parseTokens`
   - `parseTokens_tree_null`, `parseTokens_tree_bool`, `parseTokens_tree_num`, `parseTokens_tree_str`
   - `parseTokens_tree_empty_arr`, `parseTokens_tree_empty_obj`

5. **Structural Connection Theorem**:
   ```lean
   theorem decodeBytes_encodeModule_of_lex_and_parse (ir : DecodedIR)
       (h_adm : StructurallyAdmissibleIR ir)
       (h_lex : scanLexical (encodeModule ir) = .ok ())
       (h_parse : parseCanonicalJson (encodeModuleString ir) = .ok (decodedIRToJson ir)) :
       decodeBytes (encodeModule ir) = .ok ir
   ```

### 5.2 Unresolved Induction Case
The remaining open obligation for the universal `EncodeDecodeRoundtripStatement` is to prove:
1. `h_lex : ∀ (ir : DecodedIR), StructurallyAdmissibleIR ir → scanLexical (encodeModule ir) = .ok ()`
2. `h_parse : ∀ (ir : DecodedIR), StructurallyAdmissibleIR ir → parseCanonicalJson (encodeModuleString ir) = .ok (decodedIRToJson ir)`

The inductive gap lies in closing whole-document pushdown parsing across arbitrary nested `ExprEnc` AST branches (`ExprEnc.unary`, `ExprEnc.binary`, `ExprEnc.ite`), multi-argument parameter lists, and the 14-field envelope token stream.
No shortcuts (such as a decoder-image restriction, artificial caps, or modified theorem statements) were introduced. The full test campaigns (54 fixtures, 99 scenarios, 16 mutants) remain deferred until this universal theorem closes.

---

## 6. Verification Command Manifest Summary

| Command ID | Name | Exit Code | Purpose |
|------------|------|-----------|---------|
| `CMD-01` | `lean4-skills-preflight` | 0 | Lean 4 skills preflight environment and plugin integrity with `--codex` |
| `CMD-02` | `lake-build-defikernel` | 0 | Full build of DefiKernel modules |
| `CMD-03` | `lake-build-tests` | 0 | Build and execute 21 certificate unit tests |
| `CMD-04` | `transitive-verify` | 0 | Transitive compiler axiom audit across Certificates, Typed, and Composition |
| `CMD-05` | `probe-mixed-error-precedence` | 0 | 6-case root diagnostic probe verifying exact mixed-error failure precedence matching R15 |
| `CMD-06` | `probe-unterminated-precedence` | 0 | 4-case root unterminated probe verifying end-of-input whitespace failure precedence matching R15 |
| `CMD-07` | `probe-c0-controls` | 0 | 32 C0 collision roundtrips, escaped key duplicate detection, and quote/backslash controls |
| `CMD-08` | `probe-named-axioms-343` | 0 | Direct compiler `#print axioms` query for all 343 named declarations in CanonicalJson and Correspondence |
| `CMD-09` | `test-fixture-runner` | 0 | Certificate fixture runner safety regressions (7/7 pass) |
