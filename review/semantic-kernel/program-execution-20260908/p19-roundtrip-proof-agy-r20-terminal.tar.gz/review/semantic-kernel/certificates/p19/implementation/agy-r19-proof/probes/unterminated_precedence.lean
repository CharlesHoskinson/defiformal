import DefiKernel.Certificates.Correspondence
namespace DefiKernel.Certificates
set_option maxRecDepth 500000
set_option maxHeartbeats 4000000

def unterminatedInputs : List (String × String) := [
  ("unterminated_value_space", "{\"a\": \"unterminated"),
  ("unterminated_value_no_space", "{\"a\":\"unterminated"),
  ("unterminated_key_space", "{\"a\":1, \"unterminated"),
  ("unterminated_key_no_space", "{\"a\":1,\"unterminated")
]

#eval unterminatedInputs.map fun (name, s) =>
  let scan := match scanLexical s.toUTF8 with | .ok _ => "ok" | .error e => reprStr e
  let dec := match decodeBytes s.toUTF8 with | .ok _ => "ok" | .error e => reprStr e
  s!"{name};scan={scan};decode={dec}"

end DefiKernel.Certificates
