#!/usr/bin/env python3
"""RR-4 metadata diagnostics: merge rule, finite allowance, D1 seed, funding label,
negative-theorem predicate fields. Separate from compiled mutations.

Intact control stays green. Each named failure has a falsifying mode with actual exit.
"""
from __future__ import annotations

import copy
import json
import sys
from pathlib import Path

ENGINE_DIR = Path(__file__).resolve().parent
sys.path.insert(0, str(ENGINE_DIR))

from common import ROOT, EVIDENCE, choose_run_dir, refuse_nonempty_dir, write_json  # noqa: E402

FIXTURES = ROOT / "openspec/changes/vault-platform-reuse-p17/fixtures.json"
UINT256_MAX = "115792089237316195423570985008687907853269984665640564039457584007913129639935"
RAY = "1000000000000000000000000000"


def _load() -> dict:
    return json.loads(FIXTURES.read_text())


def check_merge(data: dict) -> tuple[int, str]:
    defaults = data["construction"]["defaults"]
    overlays = data["construction"]["domain_overlay"]
    for fx in data["fixtures"]:
        if not fx.get("scored_source"):
            continue
        domain = fx.get("domain", "D0")
        constructed = dict(defaults)
        constructed.update(overlays.get(domain, {}))
        constructed.update(fx.get("pre_overrides") or {})
        stored = fx.get("pre") or {}
        for key, val in constructed.items():
            if key.startswith("chi_setup"):
                continue
            if key not in stored:
                return 1, f"{fx['id']} stored pre missing constructed key {key}"
            if str(stored[key]) != str(val) and stored[key] != val:
                return 1, f"{fx['id']} merge mismatch on {key}: stored={stored[key]!r} constructed={val!r}"
    return 0, "merge rule holds for scored fixtures"


def check_finite_allowance(data: dict) -> tuple[int, str]:
    for fx in data["fixtures"]:
        if not fx.get("scored_source"):
            continue
        if fx.get("operation") not in ("deposit", "mint"):
            continue
        if fx.get("expected", {}).get("status") != "success":
            continue
        allow = str((fx.get("pre") or {}).get("usds.allowance.S.vault", "0"))
        if allow == UINT256_MAX:
            return 1, f"{fx['id']} success entry uses UINT256_MAX allowance"
        if fx["id"] != "P17-DEP-ZERO" and allow == "0":
            # zero-asset success still enters the finite branch at 0
            pass
    return 0, "success transferFrom entries use finite allowances"


def check_d1_seed(data: dict) -> tuple[int, str]:
    for fx in data["fixtures"]:
        if fx.get("domain") != "D1":
            continue
        pre = fx.get("pre") or {}
        if pre.get("chi") == RAY:
            return 1, f"{fx['id']} D1 chi is RAY, not the storage seed"
        if pre.get("chi_setup_protocol_reachable") is True:
            return 1, f"{fx['id']} incorrectly claims D1 chi is protocol-reachable"
        if pre.get("chi_setup_is_harness_assumption") is not True:
            return 1, f"{fx['id']} D1 seed is not labelled a harness assumption"
    return 0, "D1 chi is a labelled harness storage seed without reachability claim"


def check_funding_label(data: dict) -> tuple[int, str]:
    for fx in data["fixtures"]:
        if fx.get("operation") not in ("redeem", "withdraw"):
            continue
        if not fx.get("scored_source"):
            continue
        funding = fx.get("funding")
        if funding != "independent_prestate_not_mutated_deposit":
            return 1, f"{fx['id']} funding label is {funding!r}, not independent prestate"
    return 0, "redeem/withdraw controls declare independent prestate funding"


def check_negative_predicate() -> tuple[int, str]:
    adapter = (ROOT / "lean/DefiKernel/Vault/Adapter.lean").read_text()
    if "no_credit_is_observation" not in adapter:
        return 1, "Adapter.no_credit_is_observation missing"
    if "no_credit_mismatch" not in adapter:
        return 1, "no_credit_mismatch missing"
    if ").Valid" not in adapter:
        return 1, "Valid conjunct missing from Adapter"
    # Valid holds; observation/post equality fails. Prose must not invert that.
    rr = ROOT / "review/semantic-kernel/vault-platform-reuse/p17/implementation/grok-r5/RR-COMPLIANCE.md"
    if rr.is_file():
        text = rr.read_text()
        if "fail `Evaluated.Valid`" in text or "fails `Evaluated.Valid`" in text:
            return 1, "RR-COMPLIANCE still claims Valid failure for the no-credit candidate"
        if "execute_ok_iff" not in text or "Valid" not in text:
            return 1, "RR-COMPLIANCE does not state Valid holds with observation mismatch"
    return 0, "negative theorem: Valid holds; no-credit candidate violates post equality"


def run_case(name: str, fn, expected_exit: int) -> dict:
    try:
        exit_code, reason = fn()
    except Exception as exc:
        exit_code, reason = 3, f"{type(exc).__name__}: {exc}"
    return {
        "id": name,
        "expected_exit": expected_exit,
        "actual_exit": exit_code,
        "reason": reason,
        "matched": exit_code == expected_exit,
        "kind": "metadata_diagnostic",
    }


def main() -> int:
    campaign = choose_run_dir(EVIDENCE)
    out_name = "rr4-metadata-diagnostics"
    idx = 1
    while (campaign / out_name).exists():
        idx += 1
        out_name = f"rr4-metadata-diagnostics-{idx}"
    out = refuse_nonempty_dir(campaign / out_name)
    data = _load()
    results = []
    results.append(run_case("intact-merge", lambda: check_merge(data), 0))
    results.append(run_case("intact-finite-allowance", lambda: check_finite_allowance(data), 0))
    results.append(run_case("intact-d1-seed", lambda: check_d1_seed(data), 0))
    results.append(run_case("intact-funding-label", lambda: check_funding_label(data), 0))
    results.append(run_case("intact-negative-predicate", check_negative_predicate, 0))

    broken_merge = copy.deepcopy(data)
    for fx in broken_merge["fixtures"]:
        if fx.get("id") == "P17-DEP-D0":
            fx["pre"]["chi"] = "1"
            break
    results.append(run_case("fail-merge-rule", lambda: check_merge(broken_merge), 1))

    broken_allow = copy.deepcopy(data)
    for fx in broken_allow["fixtures"]:
        if fx.get("id") == "P17-DEP-D0":
            fx["pre"]["usds.allowance.S.vault"] = UINT256_MAX
            break
    results.append(run_case("fail-finite-allowance", lambda: check_finite_allowance(broken_allow), 1))

    broken_d1 = copy.deepcopy(data)
    for fx in broken_d1["fixtures"]:
        if fx.get("domain") == "D1":
            fx["pre"]["chi_setup_protocol_reachable"] = True
            break
    results.append(run_case("fail-d1-seed-classification", lambda: check_d1_seed(broken_d1), 1))

    broken_fund = copy.deepcopy(data)
    for fx in broken_fund["fixtures"]:
        if fx.get("id") == "P17-RED-D0":
            fx["funding"] = "produced_by_deposit"
            break
    results.append(run_case("fail-control-funding-label", lambda: check_funding_label(broken_fund), 1))

    # Negative-predicate falsifier: claim Valid failed.
    def fail_negative():
        rr = out / "false-rr-prose.md"
        rr.write_text("`no_credit_mismatch` proves credit perturbations fail `Evaluated.Valid`\n")
        # Temporarily point check at this file by inlining.
        text = rr.read_text()
        if "fail `Evaluated.Valid`" in text:
            return 1, "prose claims Valid failure"
        return 0, "unexpected"
    results.append(run_case("fail-negative-theorem-predicate", fail_negative, 1))

    matched = sum(1 for r in results if r["matched"])
    report = {
        "kind": "metadata_diagnostic_not_compiled_mutation",
        "checks": len(results),
        "matched": matched,
        "results": results,
        "exit": 0 if matched == len(results) else 1,
    }
    write_json(out / "result.json", report)
    print(json.dumps({"checks": report["checks"], "matched": report["matched"], "exit": report["exit"],
                      "failed": [r["id"] for r in results if not r["matched"]]}))
    return int(report["exit"])


if __name__ == "__main__":
    raise SystemExit(main())
