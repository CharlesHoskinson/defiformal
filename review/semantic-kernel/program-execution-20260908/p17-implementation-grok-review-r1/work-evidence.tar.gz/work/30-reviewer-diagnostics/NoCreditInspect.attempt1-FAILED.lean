/- Preserved failed reviewer diagnostic (attempt 1).
   Cause: ToString DefiKernel.Vault.Failure missing on the unused error branch,
   which made #eval abort as depending on sorry. Axiom prints still succeeded.
   Attribution: reviewer defect, not a candidate defect. -/
import DefiKernel.Vault.Adapter
import DefiKernel.Vault.Examples

set_option relaxedAutoImplicit false
set_option autoImplicit false

namespace ReviewGrokR6Diag
open DefiKernel.Vault
open DefiKernel.Vault.Examples
open DefiKernel.Arithmetic

def identityPerturb (st : Ledger) : Ledger := st

def main : IO Unit := do
  let dep0 := deposit fundedDeposit wad .R .S
  match dep0 with
  | .ok (st, _) => do
    IO.println s!"intact_credit={creditPredicate st WAD}"
    IO.println s!"intact_neg={creditPredicate st WAD && !creditPredicate (noCreditPerturb st) WAD}"
    IO.println s!"identity_neg={creditPredicate st WAD && !creditPredicate (identityPerturb st) WAD}"
    IO.println s!"vault_usds={st.usds .vault}"
    IO.println s!"perturbed_usds={(noCreditPerturb st).usds .vault}"
    IO.println s!"identity_usds={(identityPerturb st).usds .vault}"
  | .error e =>
    IO.println s!"deposit_failed={e}"

#eval main

#print axioms DefiKernel.Vault.Adapter.no_credit_is_observation
#print axioms DefiKernel.Vault.Adapter.wad_Valid
#print axioms DefiKernel.Vault.Adapter.no_credit_mismatch

end ReviewGrokR6Diag
