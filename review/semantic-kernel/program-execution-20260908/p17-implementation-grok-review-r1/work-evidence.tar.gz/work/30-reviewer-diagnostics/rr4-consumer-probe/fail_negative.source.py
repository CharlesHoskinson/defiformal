def fail_negative():
        """Named falsifier: invert the compiled no-credit row, then call the same validator."""
        false_stdout = stdout.replace(f"{NEG_ROW}: true", f"{NEG_ROW}: false", 1)
        (out / "fail-negative-theorem-predicate.stdout.txt").write_text(false_stdout)
        false_obs = parse_runtime_negpred(false_stdout)
        write_json(out / "fail-negative-observation.json", false_obs if false_obs is not None else {"status": "missing_or_malformed"})
        return check_negative_predicate(false_obs)

    