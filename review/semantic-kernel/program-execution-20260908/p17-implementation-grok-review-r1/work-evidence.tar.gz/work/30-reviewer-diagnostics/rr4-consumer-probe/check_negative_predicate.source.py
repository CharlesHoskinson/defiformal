def check_negative_predicate(obs: dict | None) -> tuple[int, str]:
    """Score a compiled runtime observation of the no-credit predicate.

    Required meaning (not a source grep): honest credit holds
    (P17-POS-DEPOSIT-CREDIT) and the no-credit perturbation fails post equality
    (P17-NEG-MINT-NO-CREDIT). That is the runtime image of
    Adapter.no_credit_is_observation: Valid/credit holds; post equality fails.
    Missing/malformed observations are blocked 3. The theorem statement is not
    consulted and is not rewritten.
    """
    if obs is None:
        return 3, "blocked: missing or unusable compiled runtime observation"
    if not isinstance(obs, dict):
        return 3, "blocked: malformed observation type"
    if obs.get("denominator") in (0, None):
        return 3, "blocked: empty runtime denominator"
    pos = obs.get(POS_ROW)
    neg = obs.get(NEG_ROW)
    if pos not in (True, False) or neg not in (True, False):
        return 3, "blocked: required runtime rows missing or non-boolean"
    if pos is True and neg is True:
        return 0, (
            "compiled runtime: P17-POS-DEPOSIT-CREDIT true "
            "(credit/Valid analogue holds) and P17-NEG-MINT-NO-CREDIT true "
            "(no-credit perturb fails post equality)"
        )
    if pos is False and neg is True:
        return 1, "P17-POS-DEPOSIT-CREDIT false: honest credit/Valid analogue does not hold"
    if pos is True and neg is False:
        return 1, "P17-NEG-MINT-NO-CREDIT false: no-credit candidate no longer violates post equality"
    return 1, "P17-POS-DEPOSIT-CREDIT false and P17-NEG-MINT-NO-CREDIT false"
